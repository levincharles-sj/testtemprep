# 03_agentic_app.py
# Main application script for running the UDA-Hub support agent
# Run this after setting up both databases

from dotenv import load_dotenv
from utils import chat_interface

# Load environment variables (for OPENAI_API_KEY)
load_dotenv()

print("=" * 60)
print("UDA-Hub Multi-Agent Support System")
print("=" * 60)
print()

# =============================================================================
# Import the orchestrator from our workflow
# =============================================================================
# The orchestrator is a compiled LangGraph that coordinates:
# - Classifier Agent (categorizes tickets)
# - Resolver Agent (answers from knowledge base)
# - Escalation Agent (hands off to human support)

from agentic.workflow import orchestrator

# =============================================================================
# Run the Chat Interface
# =============================================================================
# The chat_interface function provides a simple REPL for testing
# - thread_id "1" enables short-term memory for the session
# - Type 'q', 'quit', or 'exit' to end the conversation

print("Chat with the UDA-Hub support agent.")
print("Type 'q' to quit.\n")

chat_interface(orchestrator, "1")

# =============================================================================
# Alternative: Manual Invocation
# =============================================================================
# You can also invoke the orchestrator directly:
#
# from langchain_core.messages import HumanMessage
#
# result = orchestrator.invoke(
#     input={"messages": [HumanMessage(content="I can't log in")]},
#     config={"configurable": {"thread_id": "test-1"}}
# )
# print(result["messages"][-1].content)
