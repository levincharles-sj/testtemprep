# UDA-Hub System Design

## Overview

UDA-Hub (Universal Decision Agent Hub) is a multi-agent customer support system built with LangGraph. It handles support tickets for CultPass, a cultural experiences subscription service.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        User Message                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CLASSIFIER AGENT                              │
│  - Analyzes message content                                      │
│  - Determines issue category                                     │
│  - Decides if escalation needed                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              │                               │
              ▼                               ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│   KNOWLEDGE RETRIEVAL   │     │   ESCALATION AGENT      │
│  (RAG with Chroma)      │     │  - Blocked accounts     │
│  - Semantic search      │     │  - Human requests       │
│  - OpenAI embeddings    │     │  - Complex issues       │
└─────────────────────────┘     └─────────────────────────┘
              │                               │
              ▼                               │
┌─────────────────────────┐                   │
│    RESOLVER AGENT       │                   │
│  - Generate response    │                   │
│    from KB articles     │                   │
│  - Personalize if       │                   │
│    user context avail   │                   │
└─────────────────────────┘                   │
              │                               │
              └───────────────┬───────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Response to User                             │
└─────────────────────────────────────────────────────────────────┘
```

## RAG Implementation (Retrieval Augmented Generation)

### How RAG Works in UDA-Hub

```
┌──────────────────────────────────────────────────────────────────┐
│                    RAG RETRIEVAL FLOW                            │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. INDEXING (during setup)                                      │
│     ┌─────────────┐    ┌──────────────┐    ┌─────────────────┐  │
│     │ KB Articles │ -> │ OpenAI       │ -> │ Chroma Vector   │  │
│     │ (14 docs)   │    │ Embeddings   │    │ Store           │  │
│     └─────────────┘    └──────────────┘    └─────────────────┘  │
│                                                                  │
│  2. RETRIEVAL (during query)                                     │
│     ┌─────────────┐    ┌──────────────┐    ┌─────────────────┐  │
│     │ User Query  │ -> │ OpenAI       │ -> │ Similarity      │  │
│     │             │    │ Embedding    │    │ Search          │  │
│     └─────────────┘    └──────────────┘    └─────────────────┘  │
│                                                   │              │
│                                                   ▼              │
│                                            ┌─────────────────┐  │
│                                            │ Top 3 Relevant  │  │
│                                            │ Articles        │  │
│                                            └─────────────────┘  │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

### Technical Details

**Embedding Model**: OpenAI `text-embedding-ada-002`
- Converts text to 1536-dimensional vectors
- Captures semantic meaning, not just keywords

**Vector Store**: Chroma
- Persists to `data/core/chroma_db/`
- Survives application restarts
- Fast similarity search

**Similarity Search**:
- Uses cosine similarity
- Returns top 3 most relevant articles
- Includes relevance scores (High/Medium/Low)

### Why Semantic Search > Keyword Search

| Keyword Search | Semantic Search |
|---------------|-----------------|
| "password" only matches "password" | "can't get in" matches "login issues" |
| Misses synonyms | Understands meaning |
| Exact match required | Fuzzy matching built-in |

### Example

Query: "I forgot my password and can't get into my account"

**Keyword approach** would need exact matches like "password" or "forgot"

**Semantic approach** understands:
- "can't get in" ≈ "access issues" ≈ "login problems"
- Returns the "How to Handle Login Issues" article even if words don't match exactly

## Components

### 1. Classifier Agent (`agentic/agents/classifier.py`)
- **Purpose**: Categorize incoming support tickets
- **Categories**:
  - `login_access` - Password, login issues
  - `subscription` - Plan questions, benefits
  - `billing` - Payments, refunds
  - `reservation` - Bookings, cancellations
  - `technical` - App issues, bugs
  - `account_blocked` - Suspended accounts (auto-escalate)
  - `general_inquiry` - Other questions
  - `escalation` - User requests human

### 2. RAG Tools (`agentic/tools/rag_tools.py`)
- **Purpose**: Semantic search over knowledge base
- **Components**:
  - `OpenAIEmbeddings` - Text to vector conversion
  - `Chroma` - Vector storage and retrieval
  - `search_knowledge_base` - Main search tool
  - `search_knowledge_by_category` - Category-optimized search

### 3. Resolver Agent (`agentic/agents/resolver.py`)
- **Purpose**: Answer questions using RAG results
- **Process**:
  1. Receives classified ticket + KB articles from RAG
  2. Generates helpful, accurate response
  3. Uses suggested phrasings from KB

### 4. Escalation Agent (`agentic/agents/escalation.py`)
- **Purpose**: Hand off to human support
- **Triggers**:
  - Blocked/suspended accounts
  - User explicitly requests human
  - Complex issues beyond KB scope

## Data Flow

1. **Input**: User message arrives
2. **Classification**: Determine category and escalation need
3. **Routing**: Either resolve or escalate
4. **Resolution Path**:
   - RAG retrieves semantically similar KB articles
   - Generate response with context
5. **Escalation Path**:
   - Acknowledge issue
   - Set expectations for human follow-up
6. **Output**: AI response to user

## Memory Architecture

### Short-term Memory (Session)
- Uses `thread_id` via LangGraph's MemorySaver
- Maintains conversation context within a session
- Resets between different tickets/sessions

### Long-term Memory (Optional)
- Can use semantic search for user preferences
- Stored in UDA-Hub database
- Persists across sessions

## Database Schema

### CultPass DB (External)
- Users, Subscriptions, Experiences, Reservations

### UDA-Hub DB (Core)
- Accounts, Users (mapped), Tickets, Knowledge Base

### Chroma Vector DB
- Knowledge article embeddings
- Persisted to `data/core/chroma_db/`

## Key Design Decisions

1. **No Prebuilt Agents**: Built StateGraph from scratch for full control
2. **RAG with Chroma**: Semantic search for better article matching
3. **OpenAI Embeddings**: Industry-standard embedding quality
4. **Fail-safe Escalation**: When in doubt, escalate to human
5. **KB-First Resolution**: Always check knowledge base before generating
6. **Stateless Agents**: Each node is pure function, state passed through
7. **Simple Routing**: Binary decision after classification
