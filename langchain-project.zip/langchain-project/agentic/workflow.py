"""
UDA-Hub Workflow - LangGraph orchestration for multi-agent support system.

This workflow coordinates:
1. Classifier Agent - Determines ticket type
2. Resolver Agent - Attempts to resolve using knowledge base
3. Escalation Agent - Hands off to human support when needed

Built from scratch using LangGraph StateGraph (not using prebuilt agents).
"""
from typing import TypedDict, Annotated, Literal
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

# Import our agents and tools
from agentic.agents.classifier import classify_ticket
from agentic.agents.resolver import generate_response
from agentic.agents.escalation import generate_escalation_response
from agentic.tools.rag_tools import search_knowledge_base


# Define the state that flows through our graph
class AgentState(TypedDict):
    """State that persists across the workflow."""
    messages: Annotated[list[BaseMessage], add_messages]  # Conversation history
    category: str  # Classified ticket category
    needs_escalation: bool  # Whether to escalate to human
    knowledge_context: str  # Retrieved KB articles
    user_context: str  # User information (if available)


# Initialize the LLM
model = ChatOpenAI(model="gpt-4o-mini", temperature=0)


# ============================================================================
# NODE FUNCTIONS - Each node performs a specific task in the workflow
# ============================================================================

def classify_node(state: AgentState) -> AgentState:
    """
    Node 1: Classify the incoming ticket.
    
    Takes the user's message and determines:
    - What category it belongs to
    - Whether it needs human escalation
    """
    # Get the last user message
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    # Classify the ticket
    classification = classify_ticket(user_message, model)
    
    return {
        **state,
        "category": classification["category"],
        "needs_escalation": classification["needs_escalation"],
    }


def retrieve_knowledge_node(state: AgentState) -> AgentState:
    """
    Node 2: Retrieve relevant knowledge base articles.
    
    Searches the KB based on the ticket category and message content.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    category = state.get("category", "general_inquiry")
    
    # Build search query from category and message
    search_terms = f"{category} {user_message}"
    
    # Search the knowledge base using our tool
    try:
        knowledge_context = search_knowledge_base.invoke(search_terms)
    except Exception as e:
        knowledge_context = f"Knowledge base search failed: {str(e)}"
    
    return {
        **state,
        "knowledge_context": knowledge_context,
    }


def resolve_node(state: AgentState) -> AgentState:
    """
    Node 3: Generate a resolution response.
    
    Uses the knowledge base and any user context to generate a helpful response.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    # Generate response using the resolver agent
    response = generate_response(
        user_message=user_message,
        category=state.get("category", "general_inquiry"),
        knowledge_context=state.get("knowledge_context", ""),
        user_context=state.get("user_context", ""),
        model=model
    )
    
    # Add the response to messages
    return {
        **state,
        "messages": [AIMessage(content=response)],
    }


def escalate_node(state: AgentState) -> AgentState:
    """
    Node 4: Handle escalation to human support.
    
    Generates an appropriate handoff message and notes for the human agent.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    # Generate escalation response
    response = generate_escalation_response(
        user_message=user_message,
        reason=state.get("category", "complex_issue"),
        user_context=state.get("user_context", ""),
        model=model
    )
    
    # Add the response to messages
    return {
        **state,
        "messages": [AIMessage(content=response)],
    }


# ============================================================================
# ROUTING FUNCTION - Determines flow through the graph
# ============================================================================

def route_after_classification(state: AgentState) -> Literal["retrieve_knowledge", "escalate"]:
    """
    Router: Decide whether to try resolving or escalate immediately.
    
    Escalation happens when:
    - Account is blocked (needs human review)
    - User explicitly requests human support
    """
    if state.get("needs_escalation", False):
        return "escalate"
    return "retrieve_knowledge"


# ============================================================================
# BUILD THE GRAPH
# ============================================================================

def build_workflow() -> StateGraph:
    """
    Construct the LangGraph workflow.
    
    Flow:
    1. classify -> (router) -> either retrieve_knowledge or escalate
    2. retrieve_knowledge -> resolve -> END
    3. escalate -> END
    """
    # Create the graph with our state schema
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("classify", classify_node)
    workflow.add_node("retrieve_knowledge", retrieve_knowledge_node)
    workflow.add_node("resolve", resolve_node)
    workflow.add_node("escalate", escalate_node)
    
    # Set entry point
    workflow.set_entry_point("classify")
    
    # Add conditional routing after classification
    workflow.add_conditional_edges(
        "classify",
        route_after_classification,
        {
            "retrieve_knowledge": "retrieve_knowledge",
            "escalate": "escalate",
        }
    )
    
    # Add edges for the rest of the flow
    workflow.add_edge("retrieve_knowledge", "resolve")
    workflow.add_edge("resolve", END)
    workflow.add_edge("escalate", END)
    
    return workflow


# ============================================================================
# COMPILE AND EXPORT
# ============================================================================

# Build the workflow
workflow = build_workflow()

# Compile with memory checkpointer for conversation persistence
# thread_id is used for short-term memory within a session
memory = MemorySaver()
orchestrator = workflow.compile(checkpointer=memory)
