package com.example.hooks;

import com.example.reporting.CustomExtentReporter;
import com.example.reporting.ReportConfiguration;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.*;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.Duration;
import java.util.Properties;

/**
 * Simplified Cucumber Hooks for Android Appium testing
 */
public class CucumberHooks {
    
    private static AndroidDriver driver;
    private static ThreadLocal<Long> scenarioStartTime = new ThreadLocal<>();
    
    @BeforeAll
    public static void beforeAllTests() {
        // Initialize report configuration with dynamic folder
        String reportFolder = ReportConfiguration.initializeReportConfiguration();
        
        // Also initialize in CustomExtentReporter for screenshot saving
        CustomExtentReporter.initializeReportFolder();
        
        CustomExtentReporter.logInfo("Test Execution Started");
        CustomExtentReporter.logInfo("Report Location: " + reportFolder);
    }
    
    @Before
    public void beforeScenario(Scenario scenario) {
        try {
            scenarioStartTime.set(System.currentTimeMillis());
            
            // Initialize Android driver
            driver = initializeAndroidDriver();
            
            CustomExtentReporter.logInfo("=".repeat(50));
            CustomExtentReporter.logInfo("Starting Scenario: " + scenario.getName());
            CustomExtentReporter.logInfo("=".repeat(50));
            
            // Add device information to report
            CustomExtentReporter.addDeviceInfo(driver);
            
        } catch (Exception e) {
            CustomExtentReporter.logError("Failed to initialize test: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
    
    @After
    public void afterScenario(Scenario scenario) {
        try {
            long duration = System.currentTimeMillis() - scenarioStartTime.get();
            
            // Capture screenshot based on scenario result
            if (scenario.isFailed()) {
                CustomExtentReporter.logFail("Scenario Failed: " + scenario.getName());
                CustomExtentReporter.captureFailureScreenshot(driver, scenario.getName().replaceAll(" ", "_"));
            } else {
                CustomExtentReporter.logPass("Scenario Passed: " + scenario.getName());
                // Optionally capture success screenshot
                CustomExtentReporter.captureAndAttachScreenshot(
                    driver, 
                    scenario.getName().replaceAll(" ", "_") + "_SUCCESS",
                    "Success Screenshot"
                );
            }
            
            // Log execution time
            CustomExtentReporter.logInfo("Execution time: " + (duration / 1000) + " seconds");
            CustomExtentReporter.logInfo("=".repeat(50));
            
        } catch (Exception e) {
            CustomExtentReporter.logError("Error in after scenario: " + e.getMessage());
        } finally {
            // Clean up driver
            if (driver != null) {
                try {
                    driver.quit();
                } catch (Exception e) {
                    // Silent fail
                }
                driver = null;
            }
        }
    }
    
    @AfterStep
    public void afterStep(Scenario scenario) {
        // Only capture screenshot on failure or if explicitly needed
        if (scenario.isFailed()) {
            CustomExtentReporter.captureAndAttachScreenshot(
                driver,
                "StepFailure_" + System.currentTimeMillis(),
                "Failed Step Screenshot"
            );
        }
    }
    
    @AfterAll
    public static void afterAllTests() {
        CustomExtentReporter.logInfo("Test Execution Completed");
        CustomExtentReporter.logInfo("Report available at: " + CustomExtentReporter.getReportFolder());
    }
    
    /**
     * Initialize Android driver with WiFi connection
     */
    private AndroidDriver initializeAndroidDriver() {
        Properties config = loadProperties();
        
        try {
            UiAutomator2Options options = new UiAutomator2Options();
            
            // Basic capabilities
            options.setPlatformName("Android");
            options.setAutomationName("UiAutomator2");
            
            // Device capabilities
            options.setDeviceName(getProperty(config, "device.name", "Android Device"));
            
            String udid = getProperty(config, "device.udid", "");
            if (!udid.isEmpty()) {
                options.setUdid(udid);
            }
            
            // App capabilities
            String appPath = getProperty(config, "app.path", "");
            if (!appPath.isEmpty()) {
                options.setApp(appPath);
            } else {
                // Use package and activity for installed app
                options.setAppPackage(getProperty(config, "app.package", "com.example.app"));
                options.setAppActivity(getProperty(config, "app.activity", "com.example.app.MainActivity"));
            }
            
            // WiFi optimization settings - always enabled
            options.setNewCommandTimeout(Duration.ofSeconds(300));
            options.setCapability("noReset", true);
            options.setCapability("fullReset", false);
            options.setCapability("ignoreUnimportantViews", true);
            options.setCapability("disableWindowAnimation", true);
            options.setCapability("settings[waitForIdleTimeout]", 100);
            
            // Appium server URL
            String appiumServerUrl = getProperty(config, "appium.server.url", "http://localhost:4723");
            
            CustomExtentReporter.logInfo("Connecting to Appium server: " + appiumServerUrl);
            CustomExtentReporter.logInfo("Device: " + options.getDeviceName());
            CustomExtentReporter.logInfo("App Package: " + options.getAppPackage());
            
            AndroidDriver androidDriver = new AndroidDriver(new URL(appiumServerUrl), options);
            
            // Set implicit wait from config
            int implicitWait = Integer.parseInt(getProperty(config, "implicit.wait", "10"));
            androidDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(implicitWait));
            
            CustomExtentReporter.logPass("Android driver initialized successfully");
            
            return androidDriver;
            
        } catch (Exception e) {
            CustomExtentReporter.logError("Failed to initialize Android driver: " + e.getMessage());
            throw new RuntimeException("Driver initialization failed", e);
        }
    }
    
    /**
     * Load properties from application.properties file
     */
    private Properties loadProperties() {
        Properties props = new Properties();
        try (InputStream input = getClass().getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (input != null) {
                props.load(input);
            }
        } catch (IOException e) {
            CustomExtentReporter.logWarning("Could not load application.properties: " + e.getMessage());
        }
        return props;
    }
    
    /**
     * Get property value with fallback to system property and default
     */
    private String getProperty(Properties props, String key, String defaultValue) {
        // First check system property (from Maven)
        String value = System.getProperty(key);
        if (value != null && !value.isEmpty()) {
            return value;
        }
        // Then check properties file
        value = props.getProperty(key);
        if (value != null && !value.isEmpty()) {
            return value;
        }
        // Finally use default
        return defaultValue;
    }
    
    /**
     * Get current driver instance
     */
    public static AndroidDriver getDriver() {
        return driver;
    }
}