# Android Appium Test Framework with ExtentReports

## Project Structure
```
project-root/
├── src/
│   └── test/
│       ├── java/
│       │   └── com/example/
│       │       ├── hooks/
│       │       │   └── CucumberHooks.java
│       │       ├── reporting/
│       │       │   ├── CustomExtentReporter.java
│       │       │   └── ReportConfiguration.java
│       │       ├── runner/
│       │       │   └── CucumberRunnerTests.java
│       │       └── stepdefs/
│       │           └── YourStepDefinitions.java
│       └── resources/
│           ├── features/
│           │   └── your-features.feature
│           └── extent.properties
├── Reports/  (Generated automatically)
│   └── Test-Reports-DDMMYYHHmmSS/
│       ├── ExtentReport.html
│       └── screenshots/
└── pom.xml
```

## Setup Instructions

### 1. Prerequisites
- Java 11 or higher
- Maven 3.6+
- Appium Server 2.0+
- Android device connected via WiFi
- Android SDK and ADB configured

### 2. Connect Android Device via WiFi

```bash
# First connect device via USB
adb devices

# Get device IP address (from device WiFi settings or)
adb shell ip addr show wlan0

# Enable TCP/IP on port 5555
adb tcpip 5555

# Disconnect USB and connect via WiFi
adb connect <device-ip>:5555

# Verify connection
adb devices
```

### 3. Start Appium Server

```bash
# Start Appium server
appium

# Or with specific port
appium -p 4723
```

### 4. Update Configuration

Update the following in `CucumberHooks.java`:

```java
// Update with your app details
options.setAppPackage("your.app.package");
options.setAppActivity("your.app.MainActivity");

// Or provide APK path
options.setApp("/path/to/your/app.apk");
```

### 5. Run Tests

```bash
# Run all tests
mvn clean test

# Run with specific device
mvn test -Ddevice.name="Your Device Name" -Ddevice.udid="device-serial"

# Run with specific Appium server
mvn test -Dappium.server="http://localhost:4723"
```

## Key Features

### Automatic Report Folder Creation
- Each test run creates a new timestamped folder: `Reports/Test-Reports-DDMMYYHHmmSS/`
- HTML report and screenshots are saved in this folder
- No manual cleanup needed between runs

### WiFi Optimizations
- **Base64 encoding** for screenshots (reduces I/O overhead)
- **Image compression** at 80% quality (reduces transfer size)
- **Automatic retry** for failed operations
- **Optimized Appium settings** for WiFi connections

### Screenshot Capabilities
```java
// Simple screenshot capture
String screenshot = CustomExtentReporter.captureScreenshot(driver, "name");

// Capture and attach to report
CustomExtentReporter.captureAndAttachScreenshot(driver, "name", "description");

// Automatic failure screenshots
CustomExtentReporter.captureFailureScreenshot(driver, "testName");
```

### Logging Methods
```java
CustomExtentReporter.logInfo("Information message");
CustomExtentReporter.logPass("Test passed");
CustomExtentReporter.logFail("Test failed");
CustomExtentReporter.logWarning("Warning message");
CustomExtentReporter.logError("Error message");
```

### Data Tables
```java
String[][] data = {
    {"Header1", "Header2"},
    {"Value1", "Value2"}
};
CustomExtentReporter.addDataTable("Title", data);
```

## Report Location
After test execution, find your report at:
```
Reports/Test-Reports-DDMMYYHHmmSS/ExtentReport.html
```

## Performance Tips for WiFi Testing

1. **Use 5GHz WiFi** when possible (less interference)
2. **Keep device close to router** for better signal
3. **Minimize background apps** on the device
4. **Use airplane mode + WiFi** to prevent cellular interference
5. **Enable "Stay awake"** in Developer Options
6. **Disable animations** in Developer Options:
   - Window animation scale: Off
   - Transition animation scale: Off
   - Animator duration scale: Off

## Troubleshooting

### WiFi Connection Issues
```bash
# If connection drops, reconnect:
adb connect <device-ip>:5555

# Kill and restart ADB server:
adb kill-server
adb start-server
adb connect <device-ip>:5555
```

### Slow Screenshots
- Ensure device is on 5GHz WiFi
- Check WiFi signal strength
- Reduce screenshot frequency (only on failures)
- Verify image compression is enabled

### Report Not Generated
- Check if `extent.properties` exists in `src/test/resources/`
- Verify ExtentCucumberAdapter plugin in runner class
- Check console output for the report location

## Example Output
```
Report Location: /path/to/project/Reports/Test-Reports-151124143022/
- ExtentReport.html (Main report)
- screenshots/ (All test screenshots)