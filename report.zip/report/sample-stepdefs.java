package com.example.stepdefs;

import com.example.hooks.CucumberHooks;
import com.example.reporting.CustomExtentReporter;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.junit.Assert;

/**
 * Sample step definitions showing CustomExtentReporter usage with Android
 */
public class SampleStepDefinitions {
    
    private AndroidDriver driver;
    
    @Given("the app is launched")
    public void launchApp() {
        driver = CucumberHooks.getDriver();
        CustomExtentReporter.logInfo("App launched successfully");
        
        // Take screenshot after launch
        CustomExtentReporter.captureAndAttachScreenshot(
            driver, 
            "AppLaunch",
            "Application Launch State"
        );
    }
    
    @When("I perform {string} action")
    public void performAction(String action) {
        CustomExtentReporter.logInfo("Performing action: " + action);
        
        try {
            // Your action implementation here
            switch(action.toLowerCase()) {
                case "login":
                    // Example login flow
                    driver.findElement(By.id("username")).sendKeys("testuser");
                    driver.findElement(By.id("password")).sendKeys("password");
                    driver.findElement(By.id("loginButton")).click();
                    break;
                    
                case "search":
                    driver.findElement(By.id("searchBox")).sendKeys("test query");
                    driver.findElement(By.id("searchButton")).click();
                    break;
                    
                default:
                    CustomExtentReporter.logWarning("Unknown action: " + action);
            }
            
            // Capture screenshot after action
            String screenshot = CustomExtentReporter.captureScreenshot(driver, action);
            CustomExtentReporter.addScreenshotToReport(screenshot, "After " + action);
            
            CustomExtentReporter.logPass("Action completed: " + action);
            
        } catch (Exception e) {
            CustomExtentReporter.logFail("Action failed: " + e.getMessage());
            CustomExtentReporter.captureFailureScreenshot(driver, action);
            throw new RuntimeException(e);
        }
    }
    
    @Then("I verify {string}")
    public void verifyElement(String element) {
        CustomExtentReporter.logInfo("Verifying: " + element);
        
        try {
            boolean isDisplayed = false;
            
            // Example verification
            switch(element.toLowerCase()) {
                case "home screen":
                    isDisplayed = driver.findElement(By.id("homeScreen")).isDisplayed();
                    break;
                    
                case "search results":
                    isDisplayed = driver.findElement(By.id("resultsList")).isDisplayed();
                    break;
                    
                default:
                    CustomExtentReporter.logWarning("Unknown element to verify: " + element);
            }
            
            if (isDisplayed) {
                CustomExtentReporter.logPass(element + " is displayed");
                
                // Capture verification screenshot
                CustomExtentReporter.captureAndAttachScreenshot(
                    driver,
                    "Verify_" + element.replaceAll(" ", "_"),
                    "Verification: " + element
                );
            } else {
                CustomExtentReporter.logFail(element + " is not displayed");
                CustomExtentReporter.captureFailureScreenshot(driver, "VerificationFailed");
                Assert.fail(element + " is not visible");
            }
            
        } catch (Exception e) {
            CustomExtentReporter.logFail("Verification failed: " + e.getMessage());
            CustomExtentReporter.captureFailureScreenshot(driver, "VerificationError");
            throw new RuntimeException(e);
        }
    }
    
    @When("I add test data to report")
    public void addTestDataToReport() {
        // Example of adding data table to report
        String[][] testData = {
            {"Field", "Value", "Status"},
            {"Username", "testuser", "Valid"},
            {"Password", "****", "Valid"},
            {"Device", "Android", "Connected"},
            {"Connection", "WiFi", "Stable"}
        };
        
        CustomExtentReporter.addDataTable("Test Data", testData);
        CustomExtentReporter.logInfo("Test data added to report");
    }
}