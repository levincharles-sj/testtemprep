package com.example.reporting;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

/**
 * Configures ExtentReport output path dynamically for each test run
 */
public class ReportConfiguration {
    
    private static String reportFolderPath;
    
    /**
     * Initialize report configuration before test execution
     * Call this in @BeforeAll hook
     */
    public static String initializeReportConfiguration() {
        try {
            // Create timestamped folder
            String timestamp = new SimpleDateFormat("ddMMyyHHmmss").format(new Date());
            String baseDir = System.getProperty("user.dir");
            reportFolderPath = baseDir + "/Reports/Test-Reports-" + timestamp + "/";
            
            // Create directories
            Path reportPath = Paths.get(reportFolderPath);
            Files.createDirectories(reportPath);
            
            // Update ExtentReport properties dynamically
            updateExtentProperties(reportFolderPath);
            
            System.out.println("Report will be generated at: " + reportFolderPath);
            
            return reportFolderPath;
            
        } catch (Exception e) {
            System.err.println("Failed to configure report: " + e.getMessage());
            return "Reports/";
        }
    }
    
    /**
     * Update extent.properties file with dynamic report path
     */
    private static void updateExtentProperties(String reportPath) {
        try {
            // Load existing properties
            Properties props = new Properties();
            String propertiesPath = "src/test/resources/extent.properties";
            File propsFile = new File(propertiesPath);
            
            if (propsFile.exists()) {
                try (FileInputStream fis = new FileInputStream(propsFile)) {
                    props.load(fis);
                }
            }
            
            // Update the output path
            props.setProperty("extent.reporter.spark.out", reportPath + "ExtentReport.html");
            
            // Set other properties
            props.setProperty("extent.reporter.spark.start", "true");
            props.setProperty("extent.reporter.spark.base64imagesrc", "true");
            props.setProperty("extent.reporter.spark.theme", "standard");
            props.setProperty("extent.reporter.spark.documenttitle", "Test Report - " + 
                new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
            props.setProperty("extent.reporter.spark.reportname", "Android Automation Report");
            props.setProperty("extent.reporter.spark.timestampformat", "dd-MM-yyyy HH:mm:ss");
            props.setProperty("screenshot.attach.failed", "true");
            
            // Save updated properties to a temporary location for this test run
            String tempPropsPath = "target/test-classes/extent.properties";
            File tempPropsFile = new File(tempPropsPath);
            tempPropsFile.getParentFile().mkdirs();
            
            try (FileOutputStream fos = new FileOutputStream(tempPropsFile)) {
                props.store(fos, "ExtentReports Configuration - Updated at runtime");
            }
            
            // Also set as system property for ExtentCucumberAdapter
            System.setProperty("extent.reporter.spark.out", reportPath + "ExtentReport.html");
            
        } catch (Exception e) {
            System.err.println("Could not update extent properties: " + e.getMessage());
        }
    }
    
    /**
     * Get current report folder path
     */
    public static String getReportFolderPath() {
        return reportFolderPath;
    }
}