package com.example.reporting;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import io.appium.java_client.android.AndroidDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Simplified ExtentReporter for Android Appium testing with WiFi optimization
 */
public class CustomExtentReporter {
    
    private static String currentReportFolder;
    private static final String BASE_REPORT_DIR = System.getProperty("user.dir") + "/Reports/";
    private static final float COMPRESSION_QUALITY = 0.8f;
    
    /**
     * Initialize report folder with timestamp
     * Creates Reports/Test-Reports-DDMMYYHHmmSS/ structure
     */
    public static String initializeReportFolder() {
        try {
            // Create base Reports directory if not exists
            Files.createDirectories(Paths.get(BASE_REPORT_DIR));
            
            // Create timestamped folder
            String timestamp = new SimpleDateFormat("ddMMyyHHmmss").format(new Date());
            currentReportFolder = BASE_REPORT_DIR + "Test-Reports-" + timestamp + "/";
            
            // Create the timestamped directory
            Path reportPath = Paths.get(currentReportFolder);
            Files.createDirectories(reportPath);
            
            // Create screenshots subdirectory
            Files.createDirectories(Paths.get(currentReportFolder + "screenshots/"));
            
            System.out.println("Report folder created: " + currentReportFolder);
            return currentReportFolder;
            
        } catch (IOException e) {
            System.err.println("Failed to create report directories: " + e.getMessage());
            return BASE_REPORT_DIR;
        }
    }
    
    /**
     * Get current report folder path
     */
    public static String getReportFolder() {
        if (currentReportFolder == null) {
            initializeReportFolder();
        }
        return currentReportFolder;
    }
    
    /**
     * Takes screenshot and returns Base64 string (optimized for WiFi)
     */
    public static String captureScreenshot(AndroidDriver driver, String screenshotName) {
        try {
            if (driver == null) {
                logError("Driver is null, cannot capture screenshot");
                return null;
            }
            
            // Capture screenshot as Base64 (best for WiFi)
            String base64Screenshot = driver.getScreenshotAs(OutputType.BASE64);
            
            // Compress the image
            String compressedBase64 = compressBase64Image(base64Screenshot);
            
            // Also save to file for reference
            saveScreenshotToFile(compressedBase64, screenshotName);
            
            return compressedBase64;
            
        } catch (Exception e) {
            logError("Screenshot capture failed: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Captures screenshot and adds to ExtentReport
     */
    public static void captureAndAttachScreenshot(AndroidDriver driver, String screenshotName, String description) {
        try {
            String base64Screenshot = captureScreenshot(driver, screenshotName);
            
            if (base64Screenshot != null) {
                ExtentCucumberAdapter.getCurrentStep()
                    .addScreenCaptureFromBase64String(base64Screenshot, description);
                logInfo("Screenshot attached: " + description);
            }
        } catch (Exception e) {
            logError("Failed to attach screenshot: " + e.getMessage());
        }
    }
    
    /**
     * Captures screenshot on failure
     */
    public static void captureFailureScreenshot(AndroidDriver driver, String testName) {
        try {
            String timestamp = new SimpleDateFormat("HHmmss").format(new Date());
            String screenshotName = testName + "_FAILURE_" + timestamp;
            
            String base64Screenshot = captureScreenshot(driver, screenshotName);
            
            if (base64Screenshot != null) {
                ExtentCucumberAdapter.getCurrentStep()
                    .fail("Test Failed - Screenshot attached")
                    .addScreenCaptureFromBase64String(base64Screenshot);
            }
        } catch (Exception e) {
            logError("Failed to capture failure screenshot: " + e.getMessage());
        }
    }
    
    /**
     * Add screenshot to report using Base64 string
     */
    public static void addScreenshotToReport(String base64Screenshot, String description) {
        try {
            if (base64Screenshot != null && !base64Screenshot.isEmpty()) {
                ExtentCucumberAdapter.getCurrentStep()
                    .addScreenCaptureFromBase64String(base64Screenshot, description);
            }
        } catch (Exception e) {
            logError("Failed to add screenshot to report: " + e.getMessage());
        }
    }
    
    /**
     * Save screenshot to file for backup
     */
    private static void saveScreenshotToFile(String base64Image, String fileName) {
        try {
            String screenshotPath = getReportFolder() + "screenshots/" + fileName + ".jpg";
            
            // Decode Base64 to bytes
            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            
            // Save to file
            FileUtils.writeByteArrayToFile(new File(screenshotPath), imageBytes);
            
        } catch (Exception e) {
            // Silent fail - file save is optional
        }
    }
    
    /**
     * Takes screenshot using AShot library (alternative method)
     * Note: AShot works better with web than with native mobile apps
     */
    public static String captureScreenshotWithAShot(AndroidDriver driver, String screenshotName) {
        try {
            if (driver == null) {
                logError("Driver is null, cannot capture screenshot");
                return null;
            }
            
            // Take screenshot using AShot
            Screenshot screenshot = new AShot().takeScreenshot(driver);
            BufferedImage image = screenshot.getImage();
            
            // Convert to Base64
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "png", baos);
            byte[] imageBytes = baos.toByteArray();
            String base64 = Base64.getEncoder().encodeToString(imageBytes);
            
            // Compress if needed
            String compressedBase64 = compressBase64Image(base64);
            
            // Save to file
            saveScreenshotToFile(compressedBase64, screenshotName);
            
            return compressedBase64;
            
        } catch (Exception e) {
            logWarning("AShot screenshot failed, falling back to native method: " + e.getMessage());
            // Fallback to native method
            return captureScreenshot(driver, screenshotName);
        }
    }
    
    /**
     * Compress Base64 image to reduce size for WiFi transfer
     */
    private static String compressBase64Image(String base64Image) {
        try {
            // Decode Base64 to bytes
            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            
            // Convert to BufferedImage
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
            
            // Compress
            ByteArrayOutputStream compressed = new ByteArrayOutputStream();
            ImageOutputStream ios = ImageIO.createImageOutputStream(compressed);
            
            Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
            ImageWriter writer = writers.next();
            writer.setOutput(ios);
            
            ImageWriteParam param = writer.getDefaultWriteParam();
            if (param.canWriteCompressed()) {
                param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                param.setCompressionQuality(COMPRESSION_QUALITY);
            }
            
            writer.write(null, new IIOImage(image, null, null), param);
            writer.dispose();
            ios.close();
            
            // Return as Base64
            return Base64.getEncoder().encodeToString(compressed.toByteArray());
            
        } catch (Exception e) {
            // If compression fails, return original
            return base64Image;
        }
    }
    
    // ============ LOGGING METHODS ============
    
    public static void logInfo(String message) {
        try {
            ExtentCucumberAdapter.getCurrentStep().info(message);
        } catch (Exception e) {
            System.out.println("[INFO] " + message);
        }
    }
    
    public static void logPass(String message) {
        try {
            ExtentCucumberAdapter.getCurrentStep()
                .pass(MarkupHelper.createLabel(message, ExtentColor.GREEN));
        } catch (Exception e) {
            System.out.println("[PASS] " + message);
        }
    }
    
    public static void logFail(String message) {
        try {
            ExtentCucumberAdapter.getCurrentStep()
                .fail(MarkupHelper.createLabel(message, ExtentColor.RED));
        } catch (Exception e) {
            System.out.println("[FAIL] " + message);
        }
    }
    
    public static void logWarning(String message) {
        try {
            ExtentCucumberAdapter.getCurrentStep()
                .warning(MarkupHelper.createLabel(message, ExtentColor.ORANGE));
        } catch (Exception e) {
            System.out.println("[WARN] " + message);
        }
    }
    
    public static void logError(String message) {
        try {
            ExtentCucumberAdapter.getCurrentStep()
                .fail(MarkupHelper.createLabel("ERROR: " + message, ExtentColor.RED));
        } catch (Exception e) {
            System.err.println("[ERROR] " + message);
        }
    }
    
    /**
     * Add test data table to report
     */
    public static void addDataTable(String title, String[][] data) {
        try {
            ExtentCucumberAdapter.getCurrentStep().info(title);
            ExtentCucumberAdapter.getCurrentStep().info(MarkupHelper.createTable(data));
        } catch (Exception e) {
            logError("Failed to add data table: " + e.getMessage());
        }
    }
    
    /**
     * Add JSON/code block to report
     */
    public static void addCodeBlock(String code, CodeLanguage language) {
        try {
            ExtentCucumberAdapter.getCurrentStep()
                .info(MarkupHelper.createCodeBlock(code, language));
        } catch (Exception e) {
            logError("Failed to add code block: " + e.getMessage());
        }
    }
    
    /**
     * Add device and app information
     */
    public static void addDeviceInfo(AndroidDriver driver) {
        try {
            if (driver != null && driver.getSessionId() != null) {
                Map<String, Object> sessionDetails = driver.getSessionDetails();
                
                String[][] deviceInfo = {
                    {"Property", "Value"},
                    {"Platform", sessionDetails.getOrDefault("platformName", "Android").toString()},
                    {"Device Name", sessionDetails.getOrDefault("deviceName", "Unknown").toString()},
                    {"Platform Version", sessionDetails.getOrDefault("platformVersion", "Unknown").toString()},
                    {"App Package", sessionDetails.getOrDefault("appPackage", "N/A").toString()},
                    {"App Activity", sessionDetails.getOrDefault("appActivity", "N/A").toString()},
                    {"Automation Name", sessionDetails.getOrDefault("automationName", "UiAutomator2").toString()},
                    {"Session ID", driver.getSessionId().toString()},
                    {"Connection Type", "WiFi"}
                };
                
                addDataTable("Device Information", deviceInfo);
            }
        } catch (Exception e) {
            logWarning("Could not retrieve device information: " + e.getMessage());
        }
    }
    
    /**
     * Add custom message with specific status
     */
    public static void log(Status status, String message) {
        try {
            ExtentCucumberAdapter.getCurrentStep().log(status, message);
        } catch (Exception e) {
            System.out.println("[" + status + "] " + message);
        }
    }
}