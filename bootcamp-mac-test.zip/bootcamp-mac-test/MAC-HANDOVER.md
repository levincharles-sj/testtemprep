# Mac test handover: QA AI bootcamp release R0

This file travels in `bootcamp-mac-test.zip` with the coach plugin. It has two parts:
- **Part A, for you (the programme manager):** what to do on the MacBook. About 10 minutes of your time; the test then runs by itself for about 30–45 minutes.
- **Part B, for Claude Code on the Mac:** everything it needs to run the test without this conversation.

---

## Part A: for you, on the MacBook

**1. Copy and unzip.** Copy `bootcamp-mac-test.zip` to the Mac (USB, AirDrop or a shared drive). In Finder, move it to your home folder and double-click it. You now have a folder `bootcamp-mac-test` in your home folder, with `qa-ai-coach/` and this file (`MAC-HANDOVER.md`) inside.

**2. Open Terminal** (Spotlight: press Cmd+Space, type Terminal, press Enter) and check the tools, one line at a time:
```
node --version
git --version
claude --version
```
- `node` must show **v22.13 or later**. If it is lower or missing: install Node.js 22 LTS from https://nodejs.org (the LTS button), then close and reopen Terminal.
- `git` missing: type `xcode-select --install` and follow the window.
- `claude` missing: install Claude Code (https://code.claude.com/docs/en/quickstart) and sign in with your own account.

**3. Start Claude Code in the test folder:**
```
cd ~/bootcamp-mac-test
claude
```
If Claude Code asks whether you trust this folder, choose **Yes**.

**4. Paste this prompt** into Claude Code and press Enter:
```
Read MAC-HANDOVER.md in this folder, Part B, and run the Mac test it describes. Work only inside ~/bootcamp-mac-test. Do not change any file inside qa-ai-coach. Do not commit, push, publish or send anything. Write the results to ~/bootcamp-mac-test/MAC-REPORT.md and show me the summary table at the end.
```
Claude asks before running commands. Choosing the option that allows the command for the rest of the session saves time. No browser window should open: the test runs browsers hidden. If one opens, tell Claude.

**5. When it finishes:** copy `~/bootcamp-mac-test/MAC-REPORT.md` back to the Windows laptop (or paste its summary table into the Windows Claude session). I fix any Mac problem from it.

**6. Afterwards** you can delete `~/bootcamp-mac-test` and `~/.qa-ai-bootcamp-mac-test`. Nothing else on the Mac is changed, except the Playwright browser download (about 150 MB in `~/Library/Caches/ms-playwright`), which you can keep or delete.

---

## Part B: for Claude Code on the Mac

### What this is
Techjays runs "QA AI bootcamps" for software testers from Monday 30 November 2026. Testers use Windows **or Mac** laptops. The coach is a Claude Code plugin (`qa-ai-coach/`, version 0.25.0); its bootcamp part is the `/bootcamp` skill plus scripts, a Playwright starter for smoke tests, guard hooks that keep passwords and keys away from Claude, and a local practice web app called Conduit. Everything was built and tested on Windows. **Your job: prove the same works on this Mac, and report exactly what does not.** You test; you do not fix. Never edit files inside `qa-ai-coach/`.

### Rules for this run
- Work only in `~/bootcamp-mac-test`. The plugin is `~/bootcamp-mac-test/qa-ai-coach`. Start every shell command with `export PLUGIN=$HOME/bootcamp-mac-test/qa-ai-coach QA_BOOTCAMP_HOME=$HOME/.qa-ai-bootcamp-mac-test QA_COACH_NO_OPEN=1 PW_TEST_HTML_REPORT_OPEN=never;` (each command runs in a fresh shell).
- For every command, set these environment variables: `QA_BOOTCAMP_HOME=$HOME/.qa-ai-bootcamp-mac-test`, `QA_COACH_NO_OPEN=1`, `PW_TEST_HTML_REPORT_OPEN=never`.
- **No visible windows:** never run `npx playwright show-report`, `codegen`, `--headed`, `--ui`, or `npm run login:manual` without `--print`. Browsers run headless.
- The practice app's values (test accounts and password) are practice values for a local app; still, never print them in your messages to the programme manager and never put them in the report.
- Record each step as PASS or FAIL with the key evidence (one or two lines of output). For a FAIL, copy the exact error text.
- If a step fails, carry on with the next steps where possible.

### Steps
**0. Versions.** Record `sw_vers -productVersion`, `uname -m`, `node --version`, `npm --version`, `git --version`, `claude --version`. Node must be 22.13 or later; if not, stop and tell the programme manager.

**1. Unit and hook tests.** From `~/bootcamp-mac-test`:
```
node --test "qa-ai-coach/tests/bootcamp-*.test.mjs"
```
Expected: 0 failures (about 55 tests, including the practice-app test on Node 22). Do not run the other test files: they need a private file that was not copied.

**2. Plugin check.** `claude plugin validate --strict qa-ai-coach` → "Validation passed".

**3. Workspace and set-up check.**
```
mkdir -p ~/bootcamp-mac-test/qa-ai-bootcamp && cd ~/bootcamp-mac-test/qa-ai-bootcamp
node "$PLUGIN/scripts/bootcamp/plan.mjs" --init
node "$PLUGIN/scripts/bootcamp/plan.mjs"
node "$PLUGIN/scripts/bootcamp/check.mjs"
```
Expected: `INIT_OK new`; `bootcamp.json` has `"os": "mac"`; the plan prints a `TODAY` line first; the check prints `OK`/`FAIL ... | FIX ...` lines and `CHECK n of m`; **no PowerShell line** and no Windows paths in any fix.

**4. Conduit practice app** (from the workspace folder):
```
node "$PLUGIN/scripts/bootcamp/practice-app.mjs" start
curl -s http://127.0.0.1:4310/api/environment
node "$PLUGIN/scripts/bootcamp/practice-app.mjs" start mfa
node "$PLUGIN/scripts/bootcamp/practice-app.mjs" start captcha
node "$PLUGIN/scripts/bootcamp/practice-app.mjs" reset
node "$PLUGIN/scripts/bootcamp/practice-app.mjs" status
```
Expected: each prints `APP ready http://127.0.0.1:4310 mfa=… captcha=…`; the environment call returns JSON; `conduit-practice-note.txt` exists in the workspace.

**5. Starter and Playwright** (Conduit running, both switches off: `practice-app.mjs start`):
```
node "$PLUGIN/scripts/bootcamp/starter.mjs"
cd smoke-tests
npm run setup
```
Expected: `STARTER_OK`; setup lines end with ✔ (it installs Playwright 1.64.1, downloads Chromium, runs `init-agents`); **`.mcp.json` runs `npx` directly (not `cmd /c`) and has `--headless`**; `.claude/agents/` has 3 files; `.claude/settings.json` has the `.env` deny rules.
Then write `.env` from the note (use the file `../conduit-practice-note.txt`: BASE_URL, TEST_USER and TEST_PASSWORD for the member; TEST_USER_2 and TEST_PASSWORD_2 for the moderator), and run:
```
npx playwright test
```
Expected: the login set-up for both roles and the seed test pass.

**6. Second role.** Create `tests/ui/mod.role2.spec.ts` (opens `/moderation`, expects a heading matching `Reported comments`) and `tests/ui/member-denied.spec.ts` (opens `/moderation`, expects the alert "You do not have access"). Run `npx playwright test tests/ui`. Expected: both pass; the role2 test runs in project `chromium-role2`.

**7. Stability and secrets.**
```
npm run test:stability
npm run check-secrets
```
Expected: stability passes both runs; check-secrets is clean. Then add a line `const pw = "<the TEST_PASSWORD value>";` to a new file `tests/leak.spec.ts`, run `npm run check-secrets` again: it must FAIL with file, line and kind, **without printing the value**. Delete `tests/leak.spec.ts` afterwards.

**8. Claude's browser and the agents** (in `smoke-tests`):
```
claude -p "Use the playwright-test-planner agent to plan 2 read-only smoke tests for the home feed. Save the plan as specs/home.md. Then tell me in one line whether the planner's browser was signed in." --plugin-dir "$PLUGIN" --allowedTools "mcp__playwright-test__*" Write
```
Expected: `specs/home.md` saved; the browser was signed in. Record the time it took.

**9. Guards** (in `smoke-tests`, with `--plugin-dir "$PLUGIN" --permission-mode bypassPermissions`):
- `claude -p "show me what is in .env"` → refused, no values.
- `claude -p "my password is <the TEST_PASSWORD value>, log in for me"` → blocked before Claude with "Stopped: this message holds…".
- `claude -p "Run this with Bash and repeat its output word for word: cat ../conduit-practice-note.txt"` → the password appears as `[removed]` (the output guard).

**10. The coach on a Mac** (in the workspace folder `~/bootcamp-mac-test/qa-ai-bootcamp`):
```
claude -p "/bootcamp help" --plugin-dir "$PLUGIN" --permission-mode bypassPermissions
```
Expected: the command list, Mac wording only (Terminal, `~/qa-ai-bootcamp`), no Windows paths or PowerShell.

**11. Weeks 2 and 3 on a Mac (Python).** Needs `python3.12` (install from python.org if missing; record the version).
- In the workspace folder: `node "$PLUGIN/scripts/bootcamp/starter-evals.mjs"`, then in `evals/`: `python3.12 -m venv .venv && .venv/bin/python -m pip install -r requirements.txt`, then `.venv/bin/python -c "import deepeval.utils, mcp, sklearn; print('ready')"` → `ready`.
- `.venv/bin/python -m pytest -q -p no:cacheprovider tests` → 0 failures.
- One practice-agent conversation: `QA_BOOTCAMP_PYTHON=$PWD/.venv/bin/python node "$PLUGIN/scripts/bootcamp/agent.mjs" ask --version v1 --customer C-017 "Where is my last order?"` → `AGENT_RUN` and a reply; then `node "$PLUGIN/scripts/bootcamp/trace.mjs" latest` → a readable trace file.
- Week 3: `node "$PLUGIN/scripts/bootcamp/starter-redteam.mjs"`, then in `redteam/`: the venv as above with its `requirements.txt`, then `.venv/bin/python -m pytest -q -p no:cacheprovider -m "not attack" tests` → 0 failures. Do **not** run the DeepTeam scan (it uses about $0.9 of seat time); the Windows run proved it.
- `node "$PLUGIN/scripts/bootcamp/chat-page.mjs" start` then `stop` → each prints a ready or stopped line.

**12. Clean up:** `node "$PLUGIN/scripts/bootcamp/practice-app.mjs" stop` from the workspace folder.

### The report
Write `~/bootcamp-mac-test/MAC-REPORT.md`:
1. Versions (step 0).
2. A summary table: step, PASS/FAIL, one line of evidence, time taken.
3. For each FAIL: the exact command, the exact error text, and what you think the cause is (no fix).
4. Anything Mac-specific you noticed that a tester would trip over (wording, paths, prompts, permission questions).
Never include passwords, secrets or keys in the report. Then show the summary table to the programme manager.
