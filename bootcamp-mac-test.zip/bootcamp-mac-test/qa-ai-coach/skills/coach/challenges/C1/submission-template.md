# C1 submission: test design pack

**What you hand in**
- [ ] This file, saved as `work/C1/C1-pack.md`, with sections 1–7 filled in
- [ ] `work/C1/C1-test-cases.csv` with at least 10 cases
- [ ] The self-check at the end, ticked

Then run `/coach submit C1` and upload the file it makes in the portal under **Project**.

**My version (from `work/C1/VARIANT.txt`):**
**Date submitted:**

> Keep the headings and table columns exactly as they are; the review reads them.

## 1. Requirement review (6 questions, most important first)
| Rank | Question for the product owner | Lens | Detail | My working answer for now (I test this until the product owner replies) | Found by (me / Claude / both) |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |

## 2. Partitions and boundaries
### 2a. The code or reference in detail 1
| Partition | Example value | Expected result | Detail |
|---|---|---|---|
| | | | |

| Edge | Value to test | Expected result | Clear or UNCLEAR? |
|---|---|---|---|
| | | | |

### 2b. One day limit (detail 9 or detail 11): detail __
| Edge | Value to test | Expected result | Clear or UNCLEAR? |
|---|---|---|---|
| | | | |

## 3. Decision table or state transitions
**I chose:** decision table (details 7 and 8) / state transitions (detail 6)

(Paste your table here. Every cell needs a detail number or "?". List the "?" cells as questions below the table.)

## 4. Risk for details 1 to 9 (no more than 4 High)
| Detail | Likelihood (1–3) | Impact (1–3) | Score | Priority | Reason (one line) |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |

## 5. Coverage matrix (details 1 to 9)
| Detail | Test cases (IDs from the CSV) | Covered? | Note |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| 8 | | | |
| 9 | | | |

## 6. Checking Claude
Either list 3 things the AI got wrong, **or**, for each section where Claude was right, say how you checked it.

| # | Section | What the AI said (quote) | Wrong or right? Which detail shows it | My fix, or how I checked |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

## 7. AI prompts used
Paste your main prompts, in order.

```
Prompt 1:
```

## Self-check before submitting
- [ ] 6 ranked questions, each with a detail and my working answer for now
- [ ] Boundary values on both sides of each edge; unclear edges marked UNCLEAR, not guessed
- [ ] Every cell of my decision table or state table has a detail number or "?"
- [ ] Details 1 to 9 are scored, no more than 4 are High, and each score has a reason
- [ ] Details 1 to 9 each have a test case, or a reason why not
- [ ] The CSV opens with every value under the right heading, and has at least 10 cases
- [ ] No expected result says "works", "successfully", "correctly" or "as expected"
- [ ] Section 6 shows 3 AI errors with the detail that shows each, or how I checked each section where Claude was right
- [ ] Prompts are included
