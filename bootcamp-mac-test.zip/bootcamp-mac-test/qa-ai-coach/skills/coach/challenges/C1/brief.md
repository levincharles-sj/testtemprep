# Week 1 project (P1): My AI testing toolkit and design pack

**Week 1 · you build it a little every day, in your daily hour · hand in on Friday of week 1, by the end of the day**
**There is no extra work outside your daily hour.** Each day's lesson adds one piece to this project.

## What you hand in
All of these are in your portfolio folder, `C:\qa-ai-coach\portfolio`. The coach builds each file from your answers during the week.
- [ ] `P1/behaviour-log.md`: your 3 experiments with Claude (Monday)
- [ ] `CLAUDE.md` and `P1/prompt-comparison.md`: your house rules, and your short and clear prompts with gap counts (Tuesday)
- [ ] `P1/requirement-review.md`, `P1/verification-checklist.md` and `P1/ai-error-log.md`: your checked review of the Redelivery spec (Wednesday)
- [ ] `P1/risk-register.md` and `P1/test-design.md`: your risks and test design (Thursday)
- [ ] `P1/test-cases.csv`, `P1/traceability.md` and your `requirement-review` skill (Friday)

## How it is checked
Each item is marked **Pass** or **Not yet**, with a short comment. "Not yet" is normal: you fix it in a short slot next Tuesday.

**Core (everyone must pass all of these):**
- [ ] Each experiment in your behaviour log has a quote from Claude and a testing conclusion in your own words.
- [ ] Your `CLAUDE.md` has at least 5 house rules, and your prompt comparison gives the real-gap count for both prompts and says what changed (count, shape, invented details).
- [ ] You found at least 3 mistakes in Claude's work, and each one names the requirement line it gets wrong.
- [ ] Every high risk has tests, and each test design method is used correctly.
- [ ] Every requirement links to at least one test, or is listed as a gap; the CSV opens cleanly in Excel.
- [ ] Your `requirement-review` skill runs on a new story and follows your house rules.

**Stand out (optional, for extra credit on your portfolio):**
- A pairwise model made with Microsoft's PICT tool.
- A skill that marks every claim that has no source line.

## How to hand it in
1. On Friday, in your **COACH** window, type `/coach submit P1`.
2. The coach makes one file in `C:\qa-ai-coach\submissions`.
3. Open the portal. Go to **Project**. Upload that file on the **Week 1 project** card.
4. You are finished only when the portal shows **Handed in**.
