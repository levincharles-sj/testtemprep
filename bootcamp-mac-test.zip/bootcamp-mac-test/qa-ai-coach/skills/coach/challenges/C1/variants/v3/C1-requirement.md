# Parcelly story PAR-132: Book parcels in bulk from a file

*Parcelly is our made-up practice delivery company. This story is the source for challenge C1. Treat it as the requirement. If something is not in it, it is a gap, not a fact.*

**Story**
As a business customer who sends many parcels,
I want to book them all at once from a CSV file,
so that I don't have to book each parcel by hand.

**Details from the product owner**
1. Every row in a bulk file has an **order reference**: `ORD-` followed by 5 digits, for example `ORD-04521`.
2. The business user uploads a CSV file on the **Bulk booking** page and selects **Upload**. A file can have up to 500 rows.
3. If a row's order reference is not in the right format, that row shows "Invalid order reference."
4. If the format is right but the order reference was used before, the row shows "Duplicate order reference."
5. Only users with the **Admin** or **Shipper** role in the business account can upload files.
6. An upload moves through these statuses: **Uploaded → Checking → Ready to confirm → Booked.** If any row has an error, it moves **Checking → Has errors**.
7. Booked parcels are collected from the business address on the next working day. Uploads of more than 50 parcels need a large van, which needs 2 working days' notice.
8. Parcelly collects Monday to Saturday. There are no collections on Sundays or public holidays.
9. An upload with errors can be fixed and uploaded again within 7 days. After that, the upload is closed.
10. The upload history shows each upload's date and time in India time (IST).
11. Uploaded files are kept for 60 days, then deleted.
