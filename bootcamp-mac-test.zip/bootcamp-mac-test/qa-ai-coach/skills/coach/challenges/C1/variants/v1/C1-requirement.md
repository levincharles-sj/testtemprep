# Parcelly story PAR-130: Track a parcel

*Parcelly is our made-up practice delivery company. This story is the source for challenge C1. Treat it as the requirement. If something is not in it, it is a gap, not a fact.*

**Story**
As a customer who has sent or is expecting a parcel,
I want to track it,
so that I know where it is and when it will arrive.

**Details from the product owner**
1. Every parcel has a tracking number: **PB** followed by 7 digits, for example `PB1002345`.
2. The customer enters the tracking number on the **Track parcel** page and selects **Track**.
3. If the tracking number is not in the right format, the page shows "Please enter a valid tracking number."
4. If the format is right but no parcel has that number, the page shows "We can't find this parcel."
5. Only the account that booked the parcel can see the full tracking details.
6. A parcel moves through these statuses: **Booked → Label created → Collected → In transit → Out for delivery → Delivered.** Missed deliveries follow story PAR-112 (redelivery) and are not part of this story.
7. The page shows an **estimated delivery date**. Standard delivery: 2 to 3 working days after collection. Express delivery: the next working day after collection.
8. Parcelly delivers Monday to Saturday. There are no deliveries on Sundays or public holidays.
9. If the parcel is not delivered by the estimated date, the page shows **Delayed** in orange. If it is more than 5 days late, the page also shows a **Contact support** button.
10. The tracking history shows every status with its date and time, in India time (IST).
11. Tracking details are kept for 90 days after delivery.
