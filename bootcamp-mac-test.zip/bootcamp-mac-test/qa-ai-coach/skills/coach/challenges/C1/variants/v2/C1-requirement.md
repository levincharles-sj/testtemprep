# Parcelly story PAR-131: Collect a parcel from a Parcelly Locker

*Parcelly is our made-up practice delivery company. This story is the source for challenge C1. Treat it as the requirement. If something is not in it, it is a gap, not a fact.*

**Story**
As a customer who is expecting a parcel,
I want to collect it from a Parcelly Locker near my home,
so that I, or someone I trust, can pick it up without waiting at home.

**Details from the product owner**
1. Every locker parcel has a **collection code**: 6 digits, for example `482913`.
2. When the parcel is in the locker, the receiver enters the code on the locker screen and selects **Open**.
3. If the code is not in the right format, the screen shows "Please enter a 6-digit code."
4. If the format is right but the code doesn't match a parcel in this locker, the screen shows "Code not recognised." After 3 wrong codes in a row, the screen locks.
5. Only the receiver gets the collection code, by SMS to the mobile number on the booking.
6. A locker parcel moves through these statuses: **Booked → In transit → In locker → Collected.** If it is not collected in time, it moves **In locker → Expired → Returned to depot**.
7. A parcel goes in the smallest free locker door it fits: **Small**, **Medium** or **Large**. If no door of that size is free, it goes in a bigger free door.
8. Parcels that need a signature, and parcels heavier than 15 kg, are not sent to a locker. They are delivered to the receiver's address.
9. The receiver has 3 days to collect the parcel. On day 2 they get a reminder SMS. If the parcel is not collected in time, the status becomes **Expired**.
10. The locker screen and the SMS messages show dates and times in India time (IST).
11. The locker keeps a photo of each collection for 30 days.
