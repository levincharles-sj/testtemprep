---
week: W3
title: Responsible AI and security testing
saturday: 2026-12-19
---

# Week 3: Responsible AI and security testing

**This week in one line:** you attack an AI support agent the way a fraudster, a careless customer or a hidden instruction would, you decide what is safe, and every finding becomes a test so it cannot come back.

**The brief:** "Before go-live, the client wants a security and responsible-AI test of the Support Agent v2. Find what an attacker or a careless prompt can make it do, and add a test for each finding so it cannot come back."

**Rules of engagement (every day):** attack only systems you are allowed to attack, with test data only. Business misuse only: data leaks, policy bypass, prompt injection, tools used beyond policy, unsafe output and bias. Never ask any AI for harmful content. Report findings only in your report and to the project team. Your project's own AI only with your TL's written agreement, on the test environment; never an automated scan against a client's AI.

| Day | Target (2 to 2.5 hours) | Must-have for Saturday |
|---|---|---|
| Mon 14 Dec | Threats and the plan: what the agent can reach, what an attacker wants, where outside text comes in; 6 to 8 attack goals ranked by impact; the security plan (HTML) | 5 attack goals |
| Tue 15 Dec | Hand-made attacks: 12 or more attempts, each with its trace and your verdict; severity for each finding; one bug report | 6 attempts |
| Wed 16 Dec | Automated attacks and responsible AI: the DeepTeam scan read result by result; a hidden instruction in an order note; a bias check | The scan reviewed and one other test |
| Thu 17 Dec | Make findings stay fixed: 3 to 5 findings as attack tests; they fail on v2 and pass on v2.1; the release gate | A suite of 3 attacks |
| Fri 18 Dec | The security report: severity, evidence, steps to reproduce, recommendation, go or no-go; rehearse | The report |
| Sat 19 Dec | Present your security report, and the close of the bootcamps | |

**By Saturday you have:** a threat model and security plan, an attack log with evidence, findings rated by severity, an attack regression suite with a gate, a bias check, and a security report with a go or no-go decision.

**What you can do by Friday:** think like an attacker within the rules; read a trace to decide what really happened; rate a finding by impact and ease; tell a real finding from a scanner's false alarm; turn a finding into a test that proves the fix; write a security report a client can act on.

**From Thursday 17 December:** the programme manager is on leave. A cover person runs the open call and the daily message. The coach works the same way.
