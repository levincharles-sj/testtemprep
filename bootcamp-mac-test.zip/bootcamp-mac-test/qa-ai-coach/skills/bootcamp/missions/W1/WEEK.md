---
week: W1
title: AI-driven test automation on your app
saturday: 2026-12-05
---

# Week 1: AI-driven test automation on your app

**This week in one line:** Claude Code and Playwright build a smoke test pack for your project's app, you decide and check every test, and you show how it runs in CI.

**The brief:** "Your project has no automated smoke tests that run on every deploy. Use Claude Code to build a smoke pack for your app, and show how it would run in CI."

| Day | Target (2 to 2.5 hours) | Must-have for Saturday |
|---|---|---|
| Mon 30 Nov | Intake, plan and requests sent; set-up; project summary and app profile; the first read-only test running | The same; the first test may be on Conduit |
| Tue 1 Dec | App map; 6-10 smoke picks with reasons; the smoke plan (HTML); 2 UI tests passing; the end-of-Tuesday decision | 5 picks; 1 test |
| Wed 2 Dec | The rest of the UI tests, each proven to fail; one Claude mistake caught | 3 UI tests |
| Thu 3 Dec | API smoke tests; stability runs; the healer, checked | 2 API tests or 1 more UI test; 2 runs |
| Fri 4 Dec | CI at the highest level you can reach; the report; a rehearsal | CI level 1 (plan); the report |
| Sat 5 Dec | Present your report (5 minutes) | |

**By Saturday you have:** `app-profile.md`, `app-map.md`, `smoke-plan.html`, a Playwright smoke pack written by Claude (UI, and API where there is one), proof that every test can fail, a stability check, a CI workflow or plan, `report.html`, and your journal.

**What you can do by Friday:** direct Claude to automate a real app safely; choose smoke tests by risk; catch the tests that prove nothing; keep secrets out of code, chats and CI logs; explain every test in one line.
