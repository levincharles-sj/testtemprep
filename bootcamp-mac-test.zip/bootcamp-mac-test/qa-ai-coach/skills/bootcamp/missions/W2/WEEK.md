---
week: W2
title: Evals for AI agents: the go-live sign-off
saturday: 2026-12-12
---

# Week 2: Evals for AI agents: the go-live sign-off

**This week in one line:** you build the evals that decide whether an AI support agent that takes real actions is safe and good enough to go live, and you give the go-live decision with evidence.

**The brief:** "A client launches the Parcelly Support Agent next week. It answers customers and takes real actions: it looks up orders, changes addresses and issues refunds. The release candidate is v2. You are the QA engineer asked to sign off go-live. Build the evals that prove whether v2 is safe and good enough to ship, and that keep proving it after release."

**Two tracks, one rubric.** If your project has its own AI and your TL agreed in writing, you evaluate **your project's AI** from exported data (decided at the end of Monday). Everyone else evaluates the practice agent. The method is the same.

| Day | Target (2 to 2.5 hours) | Must-have for Saturday |
|---|---|---|
| Mon 7 Dec | Take the agent apart: 5 real conversations read in their traces; criteria and pass lines per part; the eval plan (HTML); the AI-project decision | Criteria for 4 parts |
| Tue 8 Dec | The golden set: 15 cases, 3 with several turns, every expected answer checked; Claude's wrong labels counted | 10 cases, 2 with several turns |
| Wed 9 Dec | Component evals: scores for v2 (the release candidate) part by part; 3 faults placed with evidence | 2 faults placed |
| Thu 10 Dec | End to end and reliability: pass rates over repeated runs; the judge checked against your own scores; cost and time; report draft | Pass rates for 5 cases |
| Fri 11 Dec | Regression and sign-off: v1 against v2; the release gate in CI; the monitoring plan; your decision | The comparison and your decision |
| Sat 12 Dec | Present your sign-off report: "Would you sign off v2?" | |

**By Saturday you have:** an eval plan, a checked golden set, component and end-to-end evals, a reliability table, a judge checked against your own scores, a release gate in CI, a monitoring plan, and a sign-off report: go, go with conditions, or no-go.

**What you can do by Friday:** take an AI agent apart into parts you can test; write criteria an engineer can check; build a golden set and check every label; tell a real fault from a judge mistake; measure "passes sometimes"; give a release decision a client can act on.
