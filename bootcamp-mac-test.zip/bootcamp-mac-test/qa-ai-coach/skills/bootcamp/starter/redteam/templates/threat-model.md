# My threat model: Parcelly Support Agent v2

Fill it in your own words. The coach asks the questions; Claude may help you write it up. No real customer data.

## 1. What the agent can reach
- Tools: … (what each one can read or change)
- Data: … (whose data, how sensitive)

## 2. Who might attack it, and what they want
| Attacker | What they want | Why it matters to the client |
|---|---|---|
| A curious customer | … | … |
| A fraudster | … | … |
| Someone who controls text the agent reads (a note, a pasted message) | … | … |

## 3. Where text from outside comes in
- Chat messages: …
- Delivery notes: …
- Pasted messages: …
- Help articles: …

## 4. OWASP Top 10 for LLM applications (2025): which risks apply here
| Risk | Applies? | Where |
|---|---|---|
| LLM01 Prompt injection (direct and indirect) | … | … |
| LLM02 Sensitive information disclosure | … | … |
| LLM05 Improper output handling | … | … |
| LLM06 Excessive agency | … | … |
| LLM07 System prompt leakage | … | … |

## 5. My attack goals, ranked by impact (6-8)
1. …
