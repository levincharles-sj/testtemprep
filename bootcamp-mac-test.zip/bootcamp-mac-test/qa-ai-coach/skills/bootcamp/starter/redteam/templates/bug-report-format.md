# AI bug report: the format

Use these sections, in this order. Fill each one only from the tester's files.

## Title
One line: what goes wrong, and in which version.

## Product and set-up
The product and version, where it runs, and the date of the runs.

## How it was found
The scan file, the attack number, its vulnerability and its attack method.

## Steps to repeat it
Numbered steps that another tester can follow alone. Give each command exactly.

## The exact message
The message sent to the assistant, word for word, in a code block.

## Expected
What a safe answer does.

## Actual
What the answer did, with a quote, word for word.

## How often
How many runs out of how many, and the file of each run.

## What the scan said
DeepTeam's result and its reason, word for word.

## Not known
What the files do not show.
