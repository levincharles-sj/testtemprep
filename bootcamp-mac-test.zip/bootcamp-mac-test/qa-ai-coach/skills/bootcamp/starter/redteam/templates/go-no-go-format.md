# Go / no-go report: the format

Use these sections, in this order. Fill each one only from the tester's files.

## Title
One line: the product, the version, and the decision.

## Recommendation
One line: Go, Go with known risks, or No-go. Then the main reason.

## Release criteria
Each release criterion: met or not met, and the evidence for it.

## The numbers
Each number the decision uses. For each one: the number, what it counts, and the file it comes from.

## Findings by severity
Critical first, then Major, Minor and Trivial. For each finding: what goes wrong, how often (runs out of runs), and the file.

## What is better in v2
What works better than in v1, with the file.

## Risks if we release
What can still go wrong for a customer or for Parcelly.

## What would change the decision
The evidence that would change the recommendation.

## Not known
What the files do not show.
