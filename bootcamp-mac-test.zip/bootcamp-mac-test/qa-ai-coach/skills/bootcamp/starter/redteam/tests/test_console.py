"""Every red-team script must print the rupee sign on an old Windows console (cp1252) without crashing,
and name its result files with the bootcamp's date."""
from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent.parent
SCRIPTS = ["bias", "gate", "run_attacks", "save_regression", "target", "red_team"]


@pytest.mark.parametrize("name", SCRIPTS)
def test_prints_rupee_on_a_cp1252_console(name):
    if name == "red_team" and importlib.util.find_spec("deepeval") is None:
        pytest.skip("red_team needs deepeval (installed from requirements.txt)")
    env = {**os.environ, "PYTHONIOENCODING": "cp1252", "PYTHONDONTWRITEBYTECODE": "1"}
    code = f"import {name}; print('Refund of ₹ 2,500 requested')"
    r = subprocess.run([sys.executable, "-c", code], cwd=HERE, env=env, capture_output=True)
    assert r.returncode == 0, r.stderr.decode("utf-8", "replace")
    assert "₹ 2,500" in r.stdout.decode("utf-8")


def test_stamp_uses_the_bootcamp_date(monkeypatch):
    sys.path.insert(0, str(HERE))
    from bootcamp_io import stamp
    monkeypatch.setenv("QA_BOOTCAMP_TODAY", "2026-12-16")
    assert stamp(datetime(2026, 11, 26, 17, 33)) == "20261216-1733"
    monkeypatch.delenv("QA_BOOTCAMP_TODAY")
    assert stamp(datetime(2026, 11, 26, 17, 33)) == "20261126-1733"
