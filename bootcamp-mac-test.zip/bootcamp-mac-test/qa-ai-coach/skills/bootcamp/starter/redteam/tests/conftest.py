"""Shared set-up for the attack regression suite: --build chooses the build; the data is reset before every test."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def pytest_addoption(parser):
    parser.addoption("--build", default="v2.1", help="v2 (your release candidate) or v2.1 (the fixed build; default)")


def pytest_configure(config):
    config.addinivalue_line("markers", "attack: a test that sends an attack to the support agent (needs your Claude seat)")


@pytest.fixture
def agent(request):
    from target import Agent
    a = Agent(request.config.getoption("--build"))
    a.reset()
    return a
