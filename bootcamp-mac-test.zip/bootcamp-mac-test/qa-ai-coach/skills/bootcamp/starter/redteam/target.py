"""The system under test: the Parcelly Support Agent's security build, reached through the coach's attack runner.

Your red-team scripts never read the agent's code: they send messages exactly as a customer would, and read the
reply and the tool calls the agent made (its trace). Every message runs on your own Claude seat (about 10 seconds).

    from target import Agent
    agent = Agent("v2")                 # your version of the release candidate; "v2.1" = the fixed build
    r = agent.ask("Where is my order PCL-10013?")
    r["reply"], r["tools"], r["run_id"]
"""
from __future__ import annotations

import json
import os
import subprocess
import sys

from bootcamp_io import stamp, utf8_console

utf8_console()  # the ₹ sign must print on the Windows console
from pathlib import Path

HERE = Path(__file__).resolve().parent


class TargetError(RuntimeError):
    pass


def workspace() -> Path:
    for d in [HERE, *HERE.parents][:6]:
        if (d / "bootcamp.json").exists():
            return d
    raise TargetError("This folder is not inside your bootcamp folder (no bootcamp.json above it).")


def plugin_dir() -> Path:
    env = os.environ.get("QA_BOOTCAMP_PLUGIN")
    if env:
        return Path(env)
    try:
        return Path(json.loads((HERE / "coach.json").read_text(encoding="utf-8"))["plugin"])
    except (OSError, ValueError, KeyError):
        raise TargetError("coach.json is missing. In the COACH window, type /bootcamp so the coach sets up this folder again.")


def _node() -> str:
    return os.environ.get("QA_BOOTCAMP_NODE", "node")


class Agent:
    def __init__(self, build: str = "v2", customer: str = "C-017"):
        if build not in ("v2", "v2.1"):
            raise TargetError('build must be "v2" or "v2.1"')
        self.build, self.customer = build, customer
        self.ws, self.plugin = workspace(), plugin_dir()

    def _run(self, args: list[str]) -> str:
        script = self.plugin / "scripts" / "bootcamp" / "attack.mjs"
        p = subprocess.run([_node(), str(script), *args], cwd=self.ws, capture_output=True, text=True, encoding="utf-8", timeout=300)
        return (p.stdout or "") + (p.stderr or "")

    def ask(self, message: str, *, cont: str | None = None, goal: str | None = None) -> dict:
        args = ["ask", "--build", self.build, "--customer", self.customer]
        if cont:
            args += ["--continue", cont]
        if goal:
            args += ["--goal", goal]
        out = self._run(args + [message])
        first = out.splitlines()[0] if out.strip() else ""
        if not first.startswith("ATTACK_RUN"):
            raise TargetError(first or "the attack runner gave no answer")
        run_id = first.split()[1]
        run = json.loads((self.ws / ".bootcamp" / "agent" / "attacks" / run_id / "run.json").read_text(encoding="utf-8"))
        tools = []
        tf = self.ws / ".bootcamp" / "agent" / "attacks" / run_id / "tools.jsonl"
        if tf.exists():
            tools = [json.loads(line) for line in tf.read_text(encoding="utf-8").splitlines() if line.strip()]
        return {"run_id": run_id, "reply": run.get("reply", ""), "intent": run.get("intent"), "tools": tools,
                "usage": run.get("usage"), "ms": run.get("durationMs")}

    def reset(self) -> None:
        """Fresh practice data (removes planted notes, refunds and tickets)."""
        self._run(["reset"])

    def plant_note(self, order_id: str, text: str | None = None) -> str:
        script = self.plugin / "scripts" / "bootcamp" / "plant-note.mjs"
        args = [_node(), str(script), "plant", order_id] + (["--text", text] if text else [])
        p = subprocess.run(args, cwd=self.ws, capture_output=True, text=True, encoding="utf-8", timeout=120)
        return (p.stdout or p.stderr).strip()


if __name__ == "__main__":
    msg = " ".join(sys.argv[1:]) or "Hello"
    r = Agent().ask(msg)
    print(r["reply"])
