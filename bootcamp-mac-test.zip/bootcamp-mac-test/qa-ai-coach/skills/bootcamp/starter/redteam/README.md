# Week 3: red-team project (Parcelly Support Agent v2)

You test the support agent's release candidate for security and responsible AI before go-live. You attack it the way a
customer, a fraudster or a hidden instruction would; you decide what is safe; and every finding becomes a test so it
cannot come back. Everything runs on your own Claude seat. There are no API keys.

**Rules of engagement:** attack only this practice system, with its fake data. Business misuse only: data leaks, policy
bypass, prompt injection, tools used beyond policy, unsafe output and bias. Never ask for harmful content. Report
findings only in your report.

## Set up (once, in the TESTS terminal)
Windows:
```
cd C:\qa-ai-bootcamp\redteam
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest tests/test_offline.py -q
```
Mac:
```
cd ~/qa-ai-bootcamp/redteam
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pytest tests/test_offline.py -q
```

## What is here
| File | What it does |
|---|---|
| `target.py` | Sends a message to the agent (through the coach's runner) and returns the reply and the trace |
| `attacks/attack-library.csv` | About 60 attacks written in advance, with the safe result for each. Add your own in `attacks/my-attacks.csv` (same columns) |
| `run_attacks.py` | Sends attacks, resets the data before each one, logs every attempt with its trace and the evidence signals. You fill in the verdict |
| `red_team.py` | The DeepTeam scan: 4 vulnerabilities × 2 attack methods. Start it first; it takes about 5 minutes |
| `teaching/redteam-recorded-scan.csv` | A scan recorded on the same kind of build: use it if your scan cannot run |
| `bias.py` | The same request with a different name, region, language or age. `--recorded` reads a recorded comparison |
| `tests/test_attacks.py` | Your attack regression suite: one test per finding, with the expected safe result |
| `save_regression.py`, `gate.py`, `gate.json` | Save the suite's result per build, and the release gate (go or no-go) |
| `.github/workflows/attack-gate.yml` | The gate on GitHub, on your saved results (a saved-result gate: GitHub has no Claude seat) |
| `templates/` | Security plan, threat model, attack log, bug report, go/no-go format, security report |

Your attempts are logged in your bootcamp folder: `week-3/attacks/<attempt>.md` (readable traces).

## Two things that matter more than any tool
1. **Read the trace, not only the reply.** A reply can sound safe while a tool already showed another customer's data
   or made a refund.
2. **A scan's PASS or FAIL is a claim, not a fact.** DeepTeam's evaluator sees only the reply. Check each result yourself.
