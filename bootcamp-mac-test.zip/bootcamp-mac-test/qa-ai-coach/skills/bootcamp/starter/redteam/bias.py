"""Bias check: the same request with a different name, region, language or age. Does the agent treat them the same?

    .\\.venv\\Scripts\\python.exe bias.py --recorded          read the recorded comparison (4 pairs, no seat use)
    .\\.venv\\Scripts\\python.exe bias.py --pairs 1,3         run 2 pairs live on your seat (about 1 minute)

A pair is two library rows that differ only in one detail (B01/B02, B03/B04, B05/B06, B07/B08). For each pair it shows
the two replies side by side, with the tools used and any refund made. YOU judge: same help and options, or not?
Saves results/bias-<date-time>.md.
"""
from __future__ import annotations

import argparse
import json
import sys

from bootcamp_io import stamp, utf8_console

utf8_console()  # the ₹ sign must print on the Windows console
from datetime import datetime, timedelta, timezone
from pathlib import Path

from run_attacks import LIBRARY, read_attacks, signals

HERE = Path(__file__).resolve().parent
RECORDED = HERE / "teaching" / "bias-recorded.json"
IST = timezone(timedelta(hours=5, minutes=30))
PAIRS = {1: ("B01", "B02"), 2: ("B03", "B04"), 3: ("B05", "B06"), 4: ("B07", "B08")}


def run_live(pairs: list[int]) -> list[dict]:
    from target import Agent
    agent = Agent("v2")
    rows = {r["id"]: r for r in read_attacks(LIBRARY)}
    out = []
    for p in pairs:
        side = []
        for rid in PAIRS[p]:
            agent.reset()
            r = agent.ask(rows[rid]["message"], goal="bias pair")
            side.append({"id": rid, "message": rows[rid]["message"], "reply": r["reply"], "tools": [t.get("tool") for t in r["tools"]],
                         "refund_made": signals(agent.customer, r["tools"], r["reply"])["refund_made"], "run_id": r["run_id"]})
        out.append({"pair": p, "a": side[0], "b": side[1]})
    return out


def markdown(pairs: list[dict], source: str) -> str:
    lines = [f"# Bias check ({source})", "", "For each pair: same help and options? Write your verdict under each pair.", ""]
    for p in pairs:
        lines.append(f"## Pair {p['pair']}")
        for side in ("a", "b"):
            s = p[side]
            lines += [f"**{s['id']}:** {s['message']}", "", f"> {s['reply']}".replace("\n", "\n> "), "",
                      f"Tools: {', '.join(s['tools']) or 'none'} · Refund made: {'yes' if s['refund_made'] else 'no'}", ""]
        lines += ["**My verdict:** same / different · why: …", ""]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="Bias check with paired requests.")
    ap.add_argument("--recorded", action="store_true", help="read the recorded comparison")
    ap.add_argument("--pairs", help="run these pairs live, for example 1,3")
    a = ap.parse_args()
    if a.recorded:
        pairs, source = json.loads(RECORDED.read_text(encoding="utf-8")), "recorded"
    elif a.pairs:
        pairs, source = run_live([int(x) for x in a.pairs.split(",") if x.strip()]), "live"
    else:
        sys.exit("Use --recorded or --pairs 1,3")
    text = markdown(pairs, source)
    print(text)
    out = HERE / "results" / f"bias-{source}-{stamp()}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(f"Saved in results/{out.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
