"""The release gate for security: reads the newest saved regression results and gate.json, and says go or no-go.

    python gate.py            (exit 0 = the gate passes, 1 = it blocks the release)

Rules (gate.json): every attack test must pass on the build being released; at least `min_tests` attack tests must
exist; and (optional) the release candidate must have shown the findings (tests failing on v2), so the tests are
known to catch them. This is a saved-result gate: it trusts the saved files. A real pipeline would run the attack
suite itself, against a test environment, with an API key the client pays for.
"""
from __future__ import annotations

import json
import sys

from bootcamp_io import stamp, utf8_console

utf8_console()  # the ₹ sign must print on the Windows console
from pathlib import Path

HERE = Path(__file__).resolve().parent


def newest(build: str) -> dict | None:
    files = sorted((HERE / "results").glob(f"regression-{build}-*.json"))
    return json.loads(files[-1].read_text(encoding="utf-8")) if files else None


def check(rules: dict) -> list[str]:
    problems = []
    rel = newest(rules["release_build"])
    if not rel:
        return [f"no saved regression result for {rules['release_build']}: run save_regression.py --build {rules['release_build']}"]
    tests = [t for t in rel["tests"] if t["result"] != "skipped"]
    if len(tests) < rules.get("min_tests", 1):
        problems.append(f"only {len(tests)} attack test(s); the gate needs at least {rules['min_tests']}")
    failed = [t["test"] for t in tests if t["result"] != "passed"]
    if failed:
        problems.append(f"{len(failed)} attack test(s) not passed on {rules['release_build']}: {', '.join(failed)}")
    if rules.get("require_candidate_failures"):
        cand = newest(rules["candidate_build"])
        if not cand:
            problems.append(f"no saved result for {rules['candidate_build']}: the gate cannot see that the tests catch the findings")
        elif not any(t["result"] == "failed" for t in cand["tests"]):
            problems.append(f"no attack test failed on {rules['candidate_build']}: are the tests checking the findings?")
    return problems


def summary(rules: dict) -> list[str]:
    """What the saved results show, per build: which tests failed on the candidate and passed on the release."""
    lines = []
    cand = newest(rules.get("candidate_build", "v2"))
    rel = newest(rules["release_build"])
    if cand:
        failed = [t["test"] for t in cand["tests"] if t["result"] == "failed"]
        lines.append(f"On {rules.get('candidate_build', 'v2')}: {len(failed)} test(s) failed, so they catch the findings: {', '.join(failed) or 'none'}")
    if rel:
        run = [t for t in rel["tests"] if t["result"] != "skipped"]
        lines.append(f"On {rules['release_build']}: {sum(t['result'] == 'passed' for t in run)} of {len(run)} test(s) passed")
    return lines


def main() -> int:
    rules = json.loads((HERE / "gate.json").read_text(encoding="utf-8"))
    problems = check(rules)
    for line in summary(rules):
        print(line)
    if problems:
        print("NO-GO: the security gate blocks the release.")
        for p in problems:
            print(f"  - {p}")
        return 1
    print(f"GO: your finding tests failed on {rules.get('candidate_build', 'v2')} and every attack test passes on {rules['release_build']}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
