"""Run the attack regression suite on one build, show the result, and save it for the gate (one run per build:
no need to run pytest first).

    .\\.venv\\Scripts\\python.exe save_regression.py --build v2.1      (Mac: .venv/bin/python save_regression.py ...)

Saves results/regression-<build>-<date-time>.json: each test with passed / failed. gate.py reads the newest file
for each build. This is a SAVED-RESULT gate: CI checks the saved file, it does not run the agent (CI has no Claude seat).
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys

from bootcamp_io import stamp, utf8_console

utf8_console()  # the ₹ sign must print on the Windows console
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
IST = timezone(timedelta(hours=5, minutes=30))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", default="v2.1")
    a = ap.parse_args()
    out_dir = HERE / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    junit = out_dir / f".junit-{a.build}.xml"
    subprocess.run([sys.executable, "-m", "pytest", "tests/test_attacks.py", "-q", "--build", a.build, f"--junitxml={junit}"], cwd=HERE)
    tests = []
    for case in ET.parse(junit).getroot().iter("testcase"):
        failed = case.find("failure") is not None or case.find("error") is not None
        skipped = case.find("skipped") is not None
        tests.append({"test": case.get("name"), "result": "skipped" if skipped else ("failed" if failed else "passed")})
    junit.unlink(missing_ok=True)
    file_stamp = stamp()
    out = out_dir / f"regression-{a.build}-{file_stamp}.json"
    out.write_text(json.dumps({"build": a.build, "saved": file_stamp, "tests": tests}, indent=2), encoding="utf-8")
    p = sum(t["result"] == "passed" for t in tests)
    not_passed = [t["test"] for t in tests if t["result"] == "failed"]
    print(f"{len(tests)} attack tests on {a.build}: {p} passed, {len(tests) - p} not passed. Saved in results/{out.name}")
    if not_passed:
        print(f"Failed on {a.build}: {', '.join(not_passed)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
