"""Two small helpers every red-team script uses.

utf8_console(): the Windows console uses an old code page that cannot print the rupee sign (₹) and crashes.
Every script calls this first, so output is always UTF-8 on Windows and Mac.

stamp(): the date and time for result file names, with the bootcamp's date: QA_BOOTCAMP_TODAY when the coach
or a rehearsal sets it, else today's date in India. The time part is the India clock time, so files keep their order.
"""
from __future__ import annotations

import os
import re
import sys
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))


def utf8_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                pass


def stamp(now: datetime | None = None) -> str:
    now = now or datetime.now(IST)
    day = os.environ.get("QA_BOOTCAMP_TODAY", "")
    ymd = day.replace("-", "") if re.fullmatch(r"\d{4}-\d{2}-\d{2}", day) else now.strftime("%Y%m%d")
    return f"{ymd}-{now.strftime('%H%M')}"
