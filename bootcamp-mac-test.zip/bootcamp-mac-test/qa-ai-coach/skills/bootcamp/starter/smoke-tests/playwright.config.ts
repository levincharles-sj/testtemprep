import { defineConfig, devices } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';

// The values (address, test account, password) come from .env. You type them there yourself; .env is never committed.
// Node reads .env itself, so no extra package is needed. In CI there is no .env: the values come from the CI secret store.
try { process.loadEnvFile('.env'); } catch { /* no .env file: CI passes the values as environment variables */ }

// AUTH=manual: you saved the login by hand (npm run login:manual), so the login step is left out.
const manualLogin = (process.env.AUTH || '').toLowerCase() === 'manual';
// CAPTCHA_TEST_KEY: the test key the dev team gave you, so tests skip the captcha on the test environment.
const captchaKey = process.env.CAPTCHA_TEST_KEY;
// A second role: on when TEST_USER_2 is set, or (with AUTH=manual) when you saved its session with npm run login:manual -- role2.
// With AUTH=manual both sessions are saved by hand, so role 2 needs ROLE2=on; otherwise it needs TEST_USER_2.
const role2 = manualLogin ? (process.env.ROLE2 || '').toLowerCase() === 'on' : !!process.env.TEST_USER_2;
// Tests written for role 2 never vanish in silence: say so when they exist but role 2 is not set up.
if (!role2) {
  const hasRole2Tests = (dir: string): boolean => {
    try {
      return fs.readdirSync(dir, { withFileTypes: true }).some((e) => e.isDirectory()
        ? hasRole2Tests(path.join(dir, e.name))
        : /\.role2\.spec\.ts$/.test(e.name) && e.name !== 'seed.role2.spec.ts');
    } catch { return false; }
  };
  // Workers load this file too: print the note once, in the main run.
  if (!process.env.SMOKE_ROLE2_NOTE && hasRole2Tests('tests')) process.env.SMOKE_ROLE2_NOTE = '1', console.warn('Note: tests for the second role (*.role2.spec.ts) are left out: TEST_USER_2 is empty in .env (or ROLE2 is not on with AUTH=manual).');
}

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  retries: 0,
  workers: 1,
  // last-run/results.json keeps the last result, so your coach can read it. The HTML report never opens by itself.
  reporter: [['list'], ['html', { open: 'never' }], ['json', { outputFile: 'last-run/results.json' }]],
  use: {
    baseURL: process.env.BASE_URL,
    // A failed test keeps a trace in test-results/ (never shared: it can hold session data).
    trace: 'retain-on-failure',
    ...(captchaKey ? { extraHTTPHeaders: { 'X-Captcha-Test-Key': captchaKey } } : {}),
  },
  projects: [
    // The login step runs once before the tests and saves the session in playwright/.auth/ (never committed).
    ...(manualLogin ? [] : [{ name: 'setup', testMatch: /auth\.setup\.ts/ }]),
    {
      name: 'chromium',
      testIgnore: [/auth\.setup\.ts/, /\.role2\.spec\.ts$/],
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/user.json' },
      dependencies: manualLogin ? [] : ['setup'],
    },
    // A second role (for example an admin or a moderator): tests named *.role2.spec.ts run signed in as TEST_USER_2.
    ...(role2 ? [{
      name: 'chromium-role2',
      testMatch: /\.role2\.spec\.ts$/,
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/role2.json' },
      dependencies: manualLogin ? [] : ['setup'],
    }] : []),
  ],
});
