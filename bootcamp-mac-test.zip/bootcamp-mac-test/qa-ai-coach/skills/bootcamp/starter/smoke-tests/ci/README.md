# CI templates for the smoke tests

Pick the file for your project's CI tool. On Friday, Claude copies it into the project repository and fits the folder;
you check that no value is in the file. Every template does the same: Node 22, `npm ci` (commit `package-lock.json`),
the browser, `npm run check-secrets` first, then the tests. It keeps only `last-run/results.json`, it is non-blocking at
first, and it runs on the branch `qa/smoke-tests` or by hand.

| CI tool | File | Where the values go (never in the file) |
|---|---|---|
| GitHub Actions | `github-actions/smoke.yml` → `.github/workflows/smoke.yml` | Settings → Secrets and variables → Actions (repository secrets) |
| GitLab CI | `gitlab-ci/.gitlab-ci.yml` → `.gitlab-ci.yml` | Settings → CI/CD → Variables, marked **Masked** and **Protected** |
| Azure Pipelines | `azure-pipelines/azure-pipelines.yml` | Pipeline secret variables, or a variable group in Pipelines → Library with the values marked secret |
| Jenkins | `jenkins/Jenkinsfile` | Manage Jenkins → Credentials, as "Secret text", used with `withCredentials` |

The names: `BASE_URL`, `TEST_USER`, `TEST_PASSWORD`, and only if you use them `TEST_TOTP_SECRET`, `CAPTCHA_TEST_KEY`,
`TEST_USER_2`, `TEST_PASSWORD_2`, `TEST_TOTP_SECRET_2`.

If you cannot add secrets yourself, the person who owns CI does: your CI plan names who. If the test environment needs a
VPN, CI cannot reach it: stay at CI level 1 (the plan) and write the network question in it. A scheduled run needs
DevOps agreement.
