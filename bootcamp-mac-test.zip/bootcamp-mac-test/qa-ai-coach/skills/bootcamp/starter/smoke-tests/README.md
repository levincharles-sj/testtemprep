# Smoke tests

Smoke tests for one app, written by Claude Code with Playwright, and checked by you. You decide what to test and you check every test. Claude writes the code.

The tests run only on a test environment, never on production. By default they only read: they do not create, change, delete, send or pay. A test that writes needs your project's agreement first (your write list).

## First time: 3 steps

1. In the TESTS terminal, in this folder, type:

   ```
   npm run setup
   ```

   It installs Playwright and its browser, sets up Playwright's test agents for Claude (planner, generator, healer), and makes your `.env` file. It is safe to run again.

2. Open `.env` in VS Code and type your values yourself: the test address, the test account and its password. Save the file.
   - Never paste a password, token or key into Claude. The coach stops the message if you do.
   - `.env` is never committed. `.env.example` holds only the names.

3. Run the tests:

   ```
   npx playwright test
   ```

   The first step logs in once (`tests/auth.setup.ts`) and saves the session. The tests then start logged in.

## When the login has MFA, a captcha or single sign-on

- **A 6-digit code (MFA):** ask your dev lead for the test account's TOTP secret. Put it in `.env` as `TEST_TOTP_SECRET`. The login step makes the code itself.
- **A captcha:** ask your dev lead to turn it off on the test environment, or for its test key. Put the key in `.env` as `CAPTCHA_TEST_KEY`.
- **Nothing solved yet:** log in by hand once:

  ```
  npm run login:manual
  ```

  Log in in the window that opens, then close it. Then set `AUTH=manual` in `.env`. Write down in your decision log that the tests start after a manual login.

## Is the pack stable?

```
npm run test:stability
```

It runs every test 3 times, then 3 times with 3 tests at once. Both results are saved in `last-run/`. A test that sometimes fails is flaky: find the cause. Never add retries to hide it.

## Before every commit

```
npm run check-secrets
```

It checks the files you would commit for passwords, tokens, keys and `.env` files. It shows the file and the line, never the value. Fix everything it finds before you commit.

## Folders

- `tests/ui/`: UI smoke tests. `tests/api/`: API smoke tests. Each smoke test has `@smoke` in its title.
- `specs/`: test plans from the Playwright planner.
- `ci/`: a CI workflow template (GitHub Actions). Claude copies it to `.github/workflows/` when you are ready.
- `last-run/`, `test-results/`, `playwright-report/`, `playwright/.auth/`: results and saved logins. Never committed or shared.

To see the last report: `npx playwright show-report`.

## A second role (for example an admin or a moderator)
1. In `.env`, type the second account: `TEST_USER_2`, `TEST_PASSWORD_2` (and `TEST_TOTP_SECRET_2` if it asks for a code).
2. Name the tests for that role `<name>.role2.spec.ts`. They run signed in as the second account; all other tests run as the first.
3. Login by hand for the second role: `npm run login:manual -- role2`, then `AUTH=manual` and `ROLE2=on` in `.env`.
