import { test as setup, expect, type Page } from '@playwright/test';
import { totp } from './helpers/totp';

// Logs in once per role and saves each session in playwright/.auth/. The tests then start already logged in.
//   Role 1 (main):   TEST_USER, TEST_PASSWORD, TEST_TOTP_SECRET   -> playwright/.auth/user.json   (tests/**/*.spec.ts)
//   Role 2 (option): TEST_USER_2, TEST_PASSWORD_2, TEST_TOTP_SECRET_2 -> playwright/.auth/role2.json (tests/**/*.role2.spec.ts)
// The values come from .env. Claude never sees them: the code only names them.
//
// These steps are written for the Conduit practice app. On your own app, Claude changes them to your app's
// login page (its labels and buttons), and you check the change.

async function logIn(page: Page, user: string | undefined, password: string | undefined, secret: string | undefined, file: string, names: string) {
  if (!user || !password) throw new Error(`${names} is empty. Open .env in VS Code and type the values there.`);

  await page.goto('/login');
  await page.getByLabel('Email').fill(user);
  await page.getByLabel('Password').fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();

  // Two-step login: only when the app asks for a code.
  const codeField = page.getByLabel('Authentication code');
  const signedIn = page.getByRole('link', { name: 'Settings' });
  const error = page.getByRole('alert');
  await expect(codeField.or(signedIn).or(error)).toBeVisible();
  if (await error.isVisible()) {
    // For example "captcha is missing or expired": ask the dev team for the captcha test key (CAPTCHA_TEST_KEY in .env).
    throw new Error(`The login page shows an error: "${(await error.innerText()).trim()}". Check the values in .env.`);
  }
  if (await codeField.isVisible()) {
    if (!secret) throw new Error(`The app asks for a code, but the TOTP secret for ${names} is empty in .env. Ask your dev lead for the test account's TOTP secret.`);
    await codeField.fill(totp(secret));
    await page.getByRole('button', { name: 'Verify' }).click();
  }

  await expect(signedIn).toBeVisible();
  await page.context().storageState({ path: file });
}

setup('log in once and save the session', async ({ page }) => {
  const e = process.env;
  await logIn(page, e.TEST_USER, e.TEST_PASSWORD, e.TEST_TOTP_SECRET, 'playwright/.auth/user.json', 'TEST_USER or TEST_PASSWORD');
});

setup('log in as role 2 and save the session', async ({ page }) => {
  const e = process.env;
  setup.skip(!e.TEST_USER_2, 'No second role in .env (TEST_USER_2 is empty).');
  await logIn(page, e.TEST_USER_2, e.TEST_PASSWORD_2, e.TEST_TOTP_SECRET_2, 'playwright/.auth/role2.json', 'TEST_USER_2 or TEST_PASSWORD_2');
});
