import { test } from '@playwright/test';

// The seed for the second role: the agents start here, signed in as TEST_USER_2, when you ask them to plan or write
// tests for that role ("use the seed tests/seed.role2.spec.ts"). It is not a smoke test.
test('seed: open the app as role 2', async ({ page }) => {
  await page.goto('/');
});
