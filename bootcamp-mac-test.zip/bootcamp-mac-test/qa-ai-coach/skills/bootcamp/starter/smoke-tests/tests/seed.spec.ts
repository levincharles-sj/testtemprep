import { test } from '@playwright/test';

// The seed: where Playwright's test agents (planner, generator, healer) start. It opens the app's home page with the
// saved login, so the agents see the app logged in. The address comes from BASE_URL in .env.
// It is not a smoke test. If your app's start page is not "/", Claude changes the path here.
test('seed: open the app', async ({ page }) => {
  await page.goto('/');
});
