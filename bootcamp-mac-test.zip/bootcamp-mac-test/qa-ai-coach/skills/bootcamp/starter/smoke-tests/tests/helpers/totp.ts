import crypto from 'node:crypto';

// The 6-digit code an authenticator app shows (RFC 6238: SHA-1, 30 seconds, 6 digits).
// Use it only with the TOTP secret of a TEST account that the dev team gave you, kept in .env as TEST_TOTP_SECRET.
const BASE32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Decode(secret: string): Buffer {
  let bits = '';
  for (const ch of secret.replace(/[\s=-]/g, '').toUpperCase()) {
    const v = BASE32.indexOf(ch);
    if (v < 0) throw new Error('TEST_TOTP_SECRET is not a valid base32 secret');
    bits += v.toString(2).padStart(5, '0');
  }
  const bytes: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

export function totp(secret: string, timeMs: number = Date.now()): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(timeMs / 30_000)));
  const h = crypto.createHmac('sha1', base32Decode(secret)).update(counter).digest();
  const offset = h[h.length - 1] & 0xf;
  return String((h.readUInt32BE(offset) & 0x7fffffff) % 1_000_000).padStart(6, '0');
}
