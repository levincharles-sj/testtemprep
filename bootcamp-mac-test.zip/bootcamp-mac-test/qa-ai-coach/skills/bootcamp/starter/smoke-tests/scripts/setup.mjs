#!/usr/bin/env node
// One-time set-up of this smoke test folder. You run it yourself in the TESTS terminal: npm run setup
// It is safe to run again: each step is skipped when it is already done.
//   1. checks Node.js 22.13 or later
//   2. npm install (only when node_modules is missing)
//   3. the Chromium browser for Playwright
//   4. Playwright's test agents for Claude Code (planner, generator, healer) and .mcp.json, made on THIS laptop
//      (Windows and Mac need different .mcp.json files), with a hidden browser (--headless)
//   5. .env from .env.example (only when .env is missing): you then type your values into .env in VS Code
//   6. .claude/settings.json: Claude may never read .env; the agents' browser and test runs are allowed
// --dry-run prints the steps and changes nothing.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DRY = process.argv.includes('--dry-run');
const isWin = process.platform === 'win32';
let failed = 0;

const ok = (msg) => console.log(`✔ ${msg}`);
const bad = (msg, fix) => { failed++; console.log(`✖ ${msg}\n  Fix: ${fix}`); };
const plan = (msg) => console.log(`- would ${msg}`);

function run(cmd, args) {
  // npm and npx are .cmd files on Windows, so they need a shell there.
  // NO_COLOR: no colour codes in the output the tester pastes or the coach reads.
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio: 'inherit', shell: isWin, env: { ...process.env, NO_COLOR: '1', FORCE_COLOR: '0' } });
  return r.status === 0;
}

export const DENY = ['Read(./.env)', 'Read(./.env.*)', 'Read(**/.env)', 'Read(**/.env.*)', 'Read(./playwright/.auth/**)'];
export const ALLOW = ['mcp__playwright-test__*', 'Bash(npx playwright test *)', 'PowerShell(npx playwright test *)'];

export function mergeSettings(s = {}) {
  const out = { ...s, permissions: { ...(s.permissions || {}) } };
  const add = (list, items) => [...(Array.isArray(list) ? list : []), ...items.filter((i) => !(list || []).includes(i))];
  out.permissions.deny = add(out.permissions.deny, DENY);
  out.permissions.allow = add(out.permissions.allow, ALLOW);
  out.enabledMcpjsonServers = add(out.enabledMcpjsonServers, ['playwright-test']);
  return out;
}

export function addHeadless(mcp) {
  const server = mcp?.mcpServers?.['playwright-test'];
  if (!server) return { mcp, changed: false };
  server.args = Array.isArray(server.args) ? server.args : [];
  if (server.args.includes('--headless')) return { mcp, changed: false };
  server.args.push('--headless');
  return { mcp, changed: true };
}

function main() {
  // 1. Node
  const [major, minor] = process.versions.node.split('.').map(Number);
  if (major > 22 || (major === 22 && minor >= 13)) ok(`Node.js ${process.versions.node}`);
  else return bad(`Node.js ${process.versions.node} is too old`, 'install Node.js 22 LTS from https://nodejs.org, close this terminal, open a new one, and run npm run setup again.');

  // 2. npm install
  if (fs.existsSync(path.join(ROOT, 'node_modules', '@playwright', 'test'))) ok('packages already installed');
  else if (DRY) plan('run npm install');
  else if (run('npm', ['install', '--no-audit', '--no-fund'])) ok('packages installed');
  else return bad('npm install did not finish', 'check your internet connection (or the company proxy), then run npm run setup again. Paste the error to your coach if it happens twice.');

  // 3. browser
  if (DRY) plan('run npx playwright install chromium');
  else if (run('npx', ['playwright', 'install', 'chromium'])) ok('Chromium browser ready');
  else bad('the Chromium download did not finish', 'run npm run setup again. Behind a company proxy, ask IT for the proxy address; your coach shows how to set it.');

  // 4. test agents and .mcp.json
  const agents = path.join(ROOT, '.claude', 'agents');
  if (fs.existsSync(path.join(agents, 'playwright-test-planner.md'))) ok('test agents already set up');
  else if (DRY) plan('run npx playwright init-agents --loop=claude');
  else if (run('npx', ['playwright', 'init-agents', '--loop=claude'])) ok('test agents set up (planner, generator, healer)');
  else bad('the test agents were not set up', 'run npm run setup again; if it fails twice, paste the error to your coach.');
  const mcpFile = path.join(ROOT, '.mcp.json');
  if (DRY) plan('add --headless to the playwright-test server in .mcp.json');
  else if (fs.existsSync(mcpFile)) {
    try {
      const { mcp, changed } = addHeadless(JSON.parse(fs.readFileSync(mcpFile, 'utf8')));
      if (changed) fs.writeFileSync(mcpFile, JSON.stringify(mcp, null, 2) + '\n');
      ok('the agents\' browser stays hidden (--headless)');
    } catch {
      bad('.mcp.json could not be read', 'delete .mcp.json and the folder .claude/agents, then run npm run setup again.');
    }
  }

  // 5. .env
  const env = path.join(ROOT, '.env');
  if (fs.existsSync(env)) ok('.env exists (you keep your values there)');
  else if (DRY) plan('copy .env.example to .env');
  else {
    fs.copyFileSync(path.join(ROOT, '.env.example'), env);
    ok('.env made from .env.example. Next: open .env in VS Code and type your values yourself. Never paste them to Claude.');
  }

  // 6. Claude Code settings for this folder
  const settingsFile = path.join(ROOT, '.claude', 'settings.json');
  if (DRY) plan('write .claude/settings.json (Claude may not read .env; the agents\' browser and test runs are allowed)');
  else {
    let s = {};
    try { if (fs.existsSync(settingsFile)) s = JSON.parse(fs.readFileSync(settingsFile, 'utf8')); } catch { s = {}; }
    fs.mkdirSync(path.dirname(settingsFile), { recursive: true });
    fs.writeFileSync(settingsFile, JSON.stringify(mergeSettings(s), null, 2) + '\n');
    ok('Claude Code settings: .env is blocked for Claude; the test agents\' browser is allowed');
  }

  console.log(failed ? `\n${failed} step(s) need a fix (see above).` : DRY ? '\nDry run: nothing was changed.' : '\nSet-up done. Next: fill in .env in VS Code, then run: npx playwright test');
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  main();
  process.exitCode = failed ? 1 : 0;
}
