#!/usr/bin/env node
// The stability check: npm run test:stability
//   Run 1: every test 3 times, one after another (--repeat-each=3).
//   Run 2: every test 3 times, 3 at the same time (--repeat-each=3 --workers=3): tests that share data or depend on
//          order often fail only here.
// Both results are kept in last-run/ (stability-serial.json and stability-parallel.json), so your coach can read them.
// A test that passes in one run and fails in another is flaky: find the cause, never add retries to hide it.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = path.join(ROOT, 'last-run');
const runs = [
  ['stability-serial.json', ['--repeat-each=3', '--workers=1']],
  ['stability-parallel.json', ['--repeat-each=3', '--workers=3']],
];
fs.mkdirSync(OUT, { recursive: true });
let bad = 0;
for (const [file, args] of runs) {
  console.log(`\n▶ npx playwright test ${args.join(' ')}`);
  const r = spawnSync('npx', ['playwright', 'test', ...args, ...process.argv.slice(2)], {
    cwd: ROOT, stdio: 'inherit', shell: process.platform === 'win32', env: process.env,
  });
  let stats = null;
  try { stats = JSON.parse(fs.readFileSync(path.join(OUT, 'results.json'), 'utf8')).stats; } catch { /* no result */ }
  if (stats) fs.copyFileSync(path.join(OUT, 'results.json'), path.join(OUT, file));
  console.log(stats ? `  passed ${stats.expected}, failed ${stats.unexpected}, flaky ${stats.flaky} (the count includes the login steps and the seed tests; each repeat counts)` : '  no result file');
  if (r.status !== 0) bad++;
}
console.log(bad ? '\n✖ Not stable yet: read the failures above.' : '\n✔ Stable: all tests passed in both runs.');
process.exitCode = bad ? 1 : 0;
