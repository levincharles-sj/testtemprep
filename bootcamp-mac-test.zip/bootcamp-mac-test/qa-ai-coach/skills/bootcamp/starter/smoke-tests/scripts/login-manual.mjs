#!/usr/bin/env node
// Log in by hand once, and save the session for the tests: npm run login:manual
// Use it when the login has MFA, a captcha or single sign-on that the dev team has not solved for the test
// environment yet. A browser window opens at BASE_URL. Log in there yourself, then close the window.
// The session is saved in playwright/.auth/user.json (never committed). Then set AUTH=manual in .env.
// Sessions end after some time: when tests start at the login page again, run this again.
// --print shows the command and opens nothing.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
try { process.loadEnvFile(path.join(ROOT, '.env')); } catch { /* no .env */ }
const url = process.env.BASE_URL;
if (!url) {
  console.log('✖ BASE_URL is empty. Open .env in VS Code, type the test environment\'s address after BASE_URL=, save, and run this again.');
  process.exit(1);
}
// npm run login:manual -- role2  saves the second role's session instead (then set ROLE2=on in .env).
const ROLE2 = process.argv.includes('role2');
const FILE = ROLE2 ? 'role2.json' : 'user.json';
export const ARGS = ['playwright', 'open', `--save-storage=playwright/.auth/${FILE}`, url];
if (process.argv.includes('--print')) {
  console.log(`npx ${ARGS.join(' ')}`);
  process.exit(0);
}
fs.mkdirSync(path.join(ROOT, 'playwright', '.auth'), { recursive: true });
console.log(ROLE2
  ? "A browser window opens. Log in there yourself with the second role's test account. Then close the window."
  : 'A browser window opens. Log in there yourself with the test account. Then close the window.');
const r = spawnSync('npx', ARGS, { cwd: ROOT, stdio: 'inherit', shell: process.platform === 'win32' });
if (r.status === 0 && fs.existsSync(path.join(ROOT, 'playwright', '.auth', FILE))) {
  console.log(ROLE2 ? '✔ Second role saved. Next: in .env, set AUTH=manual and ROLE2=on, and save.' : '✔ Session saved. Next: in .env, set AUTH=manual and save. Then run: npx playwright test');
} else {
  console.log('✖ No session was saved. Run npm run login:manual again and close the window only after you are logged in.');
  process.exitCode = 1;
}
