#!/usr/bin/env node
// Checks the files you would commit for passwords, tokens and keys. Run it before every commit: npm run check-secrets
// It looks for:
//   1. any secret value from your .env file (only values of 8+ characters whose name says it is secret, or that look random)
//   2. known key and token patterns (API keys, GitHub tokens, private keys, login tokens and more)
//   3. a .env file that git would commit, or a .gitignore that does not ignore .env
// It prints the file, the line and what it found, never the value itself. Exit code 1 when something is found.
// (Kept in step with the QA AI Coach's own guard: the same pattern names.)
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const SECRET_NAME = /(PASS|PWD|SECRET|TOKEN|API_?KEY|ACCESS_?KEY|PRIVATE|CREDENTIAL|TOTP|OTP|CLIENT_?SECRET|AUTH_?CODE|SESSION|COOKIE|SIGNING|WEBHOOK|CAPTCHA|_KEY\b)/i;
const MIN_SECRET = 6;

export function parseEnv(text) {
  const out = [];
  for (const raw of String(text || '').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2].trim();
    const q = v.match(/^(["'])(.*?)\1(?:\s+#.*)?$/);
    if (q) v = q[2];
    else v = v.replace(/#.*$/, '').trim(); // as Node's own loader does: an unquoted # starts a comment
    out.push({ name: m[1], value: v });
  }
  return out;
}
function looksRandom(v) {
  if (v.length < 16 || /\s|@/.test(v) || /^[a-z][a-z0-9+.-]*:\/\//i.test(v) || /[\\/]/.test(v)) return false;
  if (!/[0-9]/.test(v) || !/[A-Za-z]/.test(v)) return false;
  if (/[._-]/.test(v) && /(?:^|[._-])[a-z]{4,}(?=[._-]|\d|$)/i.test(v)) return false; // made of words: a name, not a key
  return new Set(v).size / v.length > 0.35;
}
export function isSecretEntry({ name, value }) {
  if (!value || value.length < MIN_SECRET) return false;
  if (/^(true|false|yes|no|on|off|manual|auto|none|null|test|staging|local)$/i.test(value)) return false;
  return SECRET_NAME.test(name) || looksRandom(value);
}
// A value that only names a secret (process.env.X, ${{ secrets.X }}, $X) is fine in code.
const isReference = (v) => /^(process\.env|import\.meta\.env|env\.|secrets\.|\$|`?\$\{|os\.environ|getenv)/i.test(String(v || ''));
function valueLike(v) {
  const raw = String(v || '');
  if (/^[([{<]/.test(raw)) return false;
  const w = raw.replace(/[`'"\])}>]+$/, '').replace(/[.,;:!?]+$/, '');
  if (isReference(w)) return false;
  if (/^[a-z]+$/i.test(w) && !/[A-Z]/.test(w.slice(1))) return false;
  if (/^[a-z0-9]+(?:[-_][a-z0-9]+)+$/.test(w)) return false;
  return w.length >= 6 && (/[0-9]/.test(w) || /[^A-Za-z]/.test(w) || /[A-Z]/.test(w.slice(1)));
}
export const LOGIN_CONTEXT = /\b(?:log\s?in|logon|sign\s?in|signin|password|passwd|pwd|pass|creds?|credentials?|user(?:name)?|account|auth\w*)\b/i;
export const SECRET_PATTERNS = [
  ["a private key", /-----BEGIN [A-Z ]*PRIVATE KEY-----/],
  ["an API key", /\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{16,}/],
  ["a GitHub token", /\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})/],
  ["a cloud key", /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b|\bAIza[0-9A-Za-z_-]{30,}/],
  ["a Slack token", /\bxox[abprs]-[A-Za-z0-9-]{10,}/],
  ["a login token (JWT)", /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/],
  ["a bearer token", /\bBearer\s+[A-Za-z0-9._~+/-]{20,}=*/i],
  ["a connection string with a password", /\b[a-z][a-z0-9+.-]*:\/\/[^\s:/@]+:[^\s@/]{4,}@/i],
  ["a login (basic auth)", /\bAuthorization:\s*Basic\s+[A-Za-z0-9+/]{8,}={0,2}/i],
  ["a session cookie", /\b(?:session(?:id)?|cookie|sid|jsessionid|connect\.sid)\s*[=:]\s*["']?([A-Za-z0-9+/_%.-]{24,})/i],
  // The same rules as the coach's prompt guard (scripts/bootcamp/lib.mjs, where each rule has examples).
  ["a password", /(?<![=:/\w-])(?:password|passwd|pwd|passcode|pass|pw)(?:\s*(?:is|=|:)\s*|\s+-\s+)["'`]?([^\s"'`]{6,})/i, valueLike, "heuristic"],
  ["a user name and password", /(?:[\w.+-]+@[\w-]+\.[\w.]+|\b(?:creds?|credentials|login|user(?:name)?)\s*[:=]?\s*\S+)\s+\/\s+["'`]?([^\s"'`]{6,})/i, valueLike, "heuristic"],
  ["a user name and password", /\buser(?:name)?\s+\S+\s+(?:and\s+)?(?:password|pwd|pass|pw)\s+["'`]?([^\s"'`]{6,})/i, valueLike, "heuristic"],
  ["an authenticator secret", /\b(?:totp|otp|2fa|mfa|authenticator)\b[^\n]{0,40}?\b([A-Z2-7]{16,}=*)(?![A-Za-z0-9])/i, (v) => /[A-Z]/.test(v) && /[2-7]/.test(v), "heuristic"],
  ["a word that looks like a password", /(?<!\S)(?<!\b(?:task|uses)\s*:\s*)([A-Za-z0-9!@#$%^*+~]{8,64})(?=[.,;:!?)]?(?:\s|$))/, (v) => /[A-Z]/.test(v) && /[a-z]/.test(v) && /\d/.test(v) && /[!@#$%^*+~]/.test(v.replace(/!$/, "")), "heuristic", LOGIN_CONTEXT],
  ["a secret or key", /\b(?:api[_-]?key|secret|access[_-]?token|client[_-]?secret|totp[_-]?secret)\s*(?:is|=|:)\s*["']?([A-Za-z0-9._~+/-]{8,})/i, valueLike, "heuristic"],
];
// Lock files hold package hashes (sha512-...), never your secrets.
const LOCK_FILE = /(^|[\\/])(package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|pnpm-lock\.yaml)$/i;

const SKIP_DIRS = /^(node_modules|\.git|playwright-report|test-results|last-run|\.playwright-mcp)$/;
const SKIP_PATH = /(^|[\\/])playwright[\\/]\.auth([\\/]|$)/;
const ENV_FILE = /^\.env(\..+)?$/i;
const SAFE_ENV = /^\.env\.(example|sample|template)$/i;
const BINARY = /\.(png|jpe?g|gif|ico|zip|gz|pdf|woff2?|ttf|exe|dll|db|sqlite)$/i;

function walk(dir, root, out) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    const rel = path.relative(root, full);
    if (e.isDirectory()) { if (!SKIP_DIRS.test(e.name) && !SKIP_PATH.test(rel)) walk(full, root, out); }
    else if (e.isFile() && !SKIP_PATH.test(rel)) out.push(rel);
  }
  return out;
}

/** The files to check, relative to `root`, and whether git chose them. */
export function filesToCheck(root) {
  const g = spawnSync('git', ['ls-files', '--cached', '--others', '--exclude-standard'], { cwd: root, encoding: 'utf8' });
  if (g.status === 0 && g.stdout !== undefined) {
    return { git: true, files: g.stdout.split(/\r?\n/).filter(Boolean).filter((f) => fs.existsSync(path.join(root, f))) };
  }
  return { git: false, files: walk(root, root, []) };
}

function gitIgnoresEnv(root, git) {
  if (git) {
    const r = spawnSync('git', ['check-ignore', '-q', '.env'], { cwd: root });
    return r.status === 0;
  }
  try {
    const lines = fs.readFileSync(path.join(root, '.gitignore'), 'utf8').split(/\r?\n/).map((l) => l.trim());
    return lines.some((l) => l === '.env' || l === '/.env' || l === '.env*');
  } catch { return false; }
}

/** Returns a list of { file, line, kind } (never the value). */
export function scan(root) {
  const findings = [];
  const values = [];
  try {
    for (const e of parseEnv(fs.readFileSync(path.join(root, '.env'), 'utf8'))) if (isSecretEntry(e)) values.push(e.value);
  } catch { /* no .env */ }
  const { git, files } = filesToCheck(root);
  const ignored = gitIgnoresEnv(root, git);
  if (!ignored) findings.push({ file: '.gitignore', line: 0, kind: '.env is not ignored: add a line .env to .gitignore' });
  for (const rel of files) {
    const base = path.basename(rel);
    // Without git, the folder walk also sees .env files that .gitignore keeps out: those are fine.
    if (!git && ignored && ENV_FILE.test(base) && !SAFE_ENV.test(base) && !rel.includes(path.sep)) continue;
    if (ENV_FILE.test(base) && !SAFE_ENV.test(base)) { findings.push({ file: rel, line: 0, kind: 'a .env file that would be committed' }); continue; }
    if (BINARY.test(rel) || LOCK_FILE.test(rel)) continue;
    let text = '';
    try { text = fs.readFileSync(path.join(root, rel), 'utf8'); } catch { continue; }
    if (text.length > 2_000_000) continue;
    text.split(/\r?\n/).forEach((line, i) => {
      if (values.some((v) => line.includes(v))) { findings.push({ file: rel, line: i + 1, kind: 'a value from your .env file' }); return; }
      for (const [kind, re, check, , context] of SECRET_PATTERNS) {
        if (context && !context.test(line)) continue;
        const gre = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
        if ([...line.matchAll(gre)].some((m) => !check || check(m[1]))) { findings.push({ file: rel, line: i + 1, kind }); return; }
      }
    });
  }
  return findings;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const root = path.resolve(process.argv[2] || path.join(path.dirname(fileURLToPath(import.meta.url)), '..'));
  const found = scan(root);
  if (!found.length) {
    console.log('✔ No passwords, tokens or keys found in the files you would commit.');
  } else {
    console.log(`✖ Found ${found.length} problem(s). Do not commit until they are fixed:`);
    for (const f of found) console.log(`  ${f.file}${f.line ? `:${f.line}` : ''}  ${f.kind}`);
    console.log('Fix: remove the value and use its name (process.env.NAME). If a real password or key was in a file, change it today.');
    process.exitCode = 1;
  }
}
