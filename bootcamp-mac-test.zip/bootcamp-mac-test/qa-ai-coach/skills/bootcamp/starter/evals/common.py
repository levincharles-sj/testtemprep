"""Shared helpers for the week 2 eval project: where things are, the golden set, and saved answers.

Plain Python only (no packages), so gate.py and the tests can use it anywhere.
"""
from __future__ import annotations

import csv
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
GOLDEN = HERE / "golden" / "golden.csv"
IST = timezone(timedelta(hours=5, minutes=30))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")  # the rupee sign must print on Windows
    sys.stderr.reconfigure(encoding="utf-8")

GOLDEN_FIELDS = ["id", "turns", "customer_id", "expected_intent", "expected_tools", "expected_facts",
                 "should_refuse", "expected_end_state", "risk", "source_check"]


def stamp() -> str:
    return datetime.now(IST).strftime("%Y%m%d-%H%M%S")


def workspace() -> Path | None:
    """The bootcamp folder (holding bootcamp.json): the parent of this evals folder, or above."""
    for d in [HERE, *HERE.parents][:6]:
        if (d / "bootcamp.json").exists():
            return d
    return None


def plugin_dir() -> Path | None:
    """The QA AI Coach folder: QA_BOOTCAMP_PLUGIN, else coach.json (written when the coach set this folder up)."""
    env = os.environ.get("QA_BOOTCAMP_PLUGIN")
    if env:
        return Path(env)
    try:
        return Path(json.loads((HERE / "coach.json").read_text(encoding="utf-8"))["plugin"])
    except (OSError, ValueError, KeyError):
        return None


def parse_list(text: str) -> list:
    """A JSON list in a CSV cell; an empty cell is an empty list."""
    text = (text or "").strip()
    if not text:
        return []
    value = json.loads(text)
    if not isinstance(value, list):
        raise ValueError("expected a JSON list")
    return value


def read_golden(path: Path = GOLDEN) -> list[dict]:
    """The golden set. Each case: id, turns (list of customer messages), customer_id, expected_intent,
    expected_tools (list of {"name", "args"?, "called"?}), expected_facts, should_refuse (bool),
    expected_end_state, risk (low|medium|high), source_check."""
    if not path.exists():
        sys.exit(f"{path.name} was not found. Copy golden/golden-template.csv to golden/golden.csv and add your cases.")
    cases = []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for n, row in enumerate(csv.DictReader(fh), start=2):
            if not (row.get("id") or "").strip():
                continue
            try:
                turns = parse_list(row.get("turns", ""))
                tools = parse_list(row.get("expected_tools", ""))
            except ValueError as exc:
                sys.exit(f"golden.csv line {n} ({row.get('id')}): turns and expected_tools must be JSON lists ({exc}).")
            if not turns or not all(isinstance(t, str) and t.strip() for t in turns):
                sys.exit(f"golden.csv line {n} ({row.get('id')}): turns needs at least one customer message, as a JSON list.")
            cases.append({
                "id": row["id"].strip(), "turns": turns, "customer_id": (row.get("customer_id") or "").strip(),
                "expected_intent": (row.get("expected_intent") or "").strip(), "expected_tools": tools,
                "expected_facts": (row.get("expected_facts") or "").strip(),
                "should_refuse": (row.get("should_refuse") or "").strip().lower() in ("yes", "true", "1", "y"),
                "expected_end_state": (row.get("expected_end_state") or "none").strip() or "none",
                "risk": (row.get("risk") or "medium").strip().lower() or "medium",
                "source_check": (row.get("source_check") or "").strip(),
            })
    ids = [c["id"] for c in cases]
    dupes = sorted({i for i in ids if ids.count(i) > 1})
    if dupes:
        sys.exit(f"golden.csv has the same id more than once: {', '.join(dupes)}")
    return cases


def read_answers(path: Path) -> list[dict]:
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def latest(pattern: str, folder: Path = RESULTS, whole_runs_only: bool = False) -> Path | None:
    """The newest file matching the pattern. whole_runs_only skips "-cases-" files (a few cases or repeats)."""
    files = sorted(p for p in folder.glob(pattern) if not (whole_runs_only and "-cases-" in p.name))
    return files[-1] if files else None


def answers_file(version: str, given: str | None = None) -> Path:
    if given:
        p = Path(given)
        return p if p.is_absolute() else HERE / p
    found = latest(f"answers-{version}-*.jsonl")
    if not found:
        sys.exit(f"No saved answers for {version}. Run: ask_golden.py --version {version}")
    return found
