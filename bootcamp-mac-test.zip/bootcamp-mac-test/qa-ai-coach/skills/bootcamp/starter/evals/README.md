# Week 2: evals for an AI agent

This folder is your eval project for week 2. You test the **Parcelly Support Agent**: it answers customers and takes real actions (looks up orders, changes addresses, issues refunds, hands over to a person). Your question all week: **would you sign off v2 for go-live?**

Everything runs on your own Claude seat: the agent and the AI judge. There is no API key and nothing to pay.

## Set up once (in the TESTS terminal, in this folder)
**Windows (PowerShell):**
```
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -c "import deepeval.utils, mcp, sklearn; print('ready')"
.\.venv\Scripts\python.exe -m pytest tests -q
```
**Mac (Terminal):**
```
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -c "import deepeval.utils, mcp, sklearn; print('ready')"
.venv/bin/python -m pytest tests -q
```
The install takes a few minutes. The import line must print **ready**. The tests need no AI: they check the scripts work on your laptop.

**Windows: "Windows Long Path support" during the install, or `No module named 'deepeval.utils'`?** Your folder path is too long for Windows (some package files have deep paths). Use a short bootcamp folder such as `C:\qa-ai-bootcamp`, or ask IT to switch on long paths. Then delete `.venv` and make it again.

## The files
| File | What it does |
|---|---|
| `golden/golden.csv` | Your golden set: the cases, with the expected intent, tools, facts, refusal and end state. 3 worked examples to start |
| `ask_golden.py` | Asks the agent every case and saves its answers (`results/answers-…jsonl`) |
| `run_metrics.py` | Scores the answers part by part: intent, tools, inputs, end state (code) and facts, policy, faithfulness (AI judge) |
| `reliability.py` | Pass rate per case over repeated runs: "passes every time" or "passes sometimes" |
| `calibration.py` | Your 8 hand scores against the judge's: how much can you trust it? |
| `compare.py` | v1 against v2, per part and per risk |
| `gate.py`, `gate.json` | The release rules, applied to your saved scores |
| `.github/workflows/quality-gate.yml` | GitHub runs `gate.py` on every push |
| `templates/` | The eval strategy, the sign-off report, the failure log, the calibration sheet, the monitoring plan |

## A normal run (Windows shown; on a Mac use `.venv/bin/python`)
```
.\.venv\Scripts\python.exe ask_golden.py --version v2
.\.venv\Scripts\python.exe run_metrics.py --version v2
.\.venv\Scripts\python.exe gate.py
```
Every conversation starts from the same practice data (`ask_golden.py` resets it first, about 2 seconds), because the agent really refunds and changes addresses: without the reset, a second run would meet the first run's refund. Start long runs first, then learn while they work. Each conversation takes about 5 to 15 seconds; the judge about 20 seconds per case.

## The golden set columns
- `turns`: the customer's messages, as a list: `["first message", "second message"]`. Several messages make one conversation.
- `expected_intent`: exactly one of the agent's labels. v2: `order_status`, `address_change`, `refund`, `cancel`, `delivery_question`, `policy_question`, `locker`, `handoff`, `other` (v1 has no `locker`).
- `expected_tools`: `[{"name": "lookup_order", "args": {"order_id": "PCL-10311"}}]`. A tool that must **not succeed**: `{"name": "change_address", "called": false}`. A call the tool refused (an error) passes; only a call that worked fails.

What changed in v2 is in `docs/release-note-v2.md`.
- `expected_end_state`: what must change on the account: `none`, `refund <order> <amount>`, `no_refund`, `address <order>`, `address_unchanged <order>`, `handoff`. Join several with ` & `.
- `risk`: `low`, `medium` or `high`. The gate is strict on high-risk cases.
- `source_check`: where you checked the expected answer (the order, the policy rule, the help article). Every expected answer is checked, never guessed.

## About the gate
`gate.py` is a **saved-score gate**: it reads the scores your laptop saved and applies `gate.json`. It does not run the agent or the judge in GitHub, because GitHub has no Claude seat. A real gate on a client project runs the judge in CI, with a key the client pays for. Your sign-off report says so.

## Your own AI project (if you evaluate your project's AI)
- Use only exported, masked data that your TL agreed in writing may go to Claude.
- Keep this folder in a **private** repository, and add `results/` to `.gitignore`: the scores hold case IDs and your project's outputs.
- Never put customer data, keys or passwords here.

## Usage
`results/usage-log.csv` keeps your own record of tokens per run (no name, no ID). It stays on your laptop.
