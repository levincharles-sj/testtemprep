"""The release gate: may this version of the agent go live?

    python gate.py                 (the version named in gate.json, "release")
    python gate.py --version v1

A saved-score gate: it reads the scores your laptop saved (results/scores-<version>-*.csv) and applies the
rules in gate.json. It runs no AI and needs no packages, so GitHub can run it on every push.
Be honest about what that means: it checks the saved scores, not the agent itself. A real gate runs the judge
in CI with a key the client pays for; your report says so.

One line per rule: PASS or FAIL. Any FAIL ends with exit code 1, so a GitHub run shows a red cross.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def newest(version: str) -> Path | None:
    # A scores file made with --cases (a few cases only) is never the gate's input.
    files = sorted(p for p in RESULTS.glob(f"scores-{version}-*.csv") if "-cases-" not in p.name)
    return files[-1] if files else None


def load(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def pass_rate(rows: list[dict], metric: str) -> tuple[int, int]:
    rs = [r for r in rows if r["metric"] == metric]
    return sum(r["result"] == "PASS" for r in rs), len(rs)


def check(config: dict, rows: list[dict], base_rows: list[dict] | None) -> list[tuple[bool, str]]:
    out = []
    errors = sum(r["result"] == "ERROR" for r in rows)
    max_errors = config.get("max_errors", 0)
    out.append((errors <= max_errors, f"Errors (runs or judge calls that gave no result): {errors}, at most {max_errors}"))
    for rule in config.get("metrics", []):
        p, n = pass_rate(rows, rule["metric"])
        if n == 0:
            out.append((False, f"{rule['metric']}: no scores (did run_metrics.py run with the judge?)"))
            continue
        need = rule["min_pass_rate"]
        out.append((p / n >= need, f"{rule['metric']}: {p}/{n} passed ({p / n:.0%}), at least {need:.0%}"))
    for rule in config.get("risk", []):
        bad = sorted({r["case"] for r in rows if r.get("risk") == rule["risk"] and r["result"] == "FAIL"})
        out.append((len(bad) <= rule["max_failed_cases"],
                    f"{rule['risk'].capitalize()}-risk cases with a failed check: {len(bad)}{' (' + ', '.join(bad) + ')' if bad else ''}, "
                    f"at most {rule['max_failed_cases']}"))
    if config.get("no_worse_than_baseline") and base_rows is not None:
        for metric in config["no_worse_than_baseline"]:
            p, n = pass_rate(rows, metric)
            bp, bn = pass_rate(base_rows, metric)
            if n and bn:
                out.append((p / n >= bp / bn, f"{metric}: {p / n:.0%} vs the baseline's {bp / bn:.0%} (must not be worse)"))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Apply the release rules in gate.json to the saved scores.")
    ap.add_argument("--version")
    ap.add_argument("--config", default=str(HERE / "gate.json"))
    ap.add_argument("--scores", help="this scores file instead of the newest whole run")
    a = ap.parse_args()
    config = json.loads(Path(a.config).read_text(encoding="utf-8"))
    version = a.version or config["release"]
    path = Path(a.scores) if a.scores else newest(version)
    if path and not path.is_absolute():
        path = HERE / path
    if not path or not path.exists():
        print(f"FAIL No scores for {version} in results/. Run ask_golden.py and run_metrics.py --version {version}, "
              "then commit the scores file.")
        return 1
    base = newest(config["baseline"]) if config.get("baseline") and config["baseline"] != version else None
    results = check(config, load(path), load(base) if base else None)
    print(f"Gate for {version} ({path.name}{', baseline ' + base.name if base else ''}):")
    for ok, text in results:
        print(f"{'PASS' if ok else 'FAIL'} {text}")
    failed = sum(not ok for ok, _ in results)
    print(f"\n{'BLOCKED' if failed else 'ALLOWED'}: {failed} rule(s) failed. This gate checks saved scores, not the agent itself.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
