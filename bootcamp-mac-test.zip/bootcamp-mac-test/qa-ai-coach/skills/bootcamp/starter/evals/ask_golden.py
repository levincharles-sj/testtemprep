"""Ask the support agent every question in your golden set, and save its answers.

    Windows: .\\.venv\\Scripts\\python.exe ask_golden.py --version v1
    Mac:     .venv/bin/python ask_golden.py --version v1

It sends each case through the coach's agent runner (the agent runs on your own Claude seat, no API key).
A case with several turns is one conversation: each next message continues the same conversation.
The answers go to results/answers-<version>-<date-time>.jsonl, one line per case (and per run with --repeat).

Options:
    --version v1|v2       which version of the agent (default v2)
    --variant A           only if the coach tells you (it normally knows your variant)
    --cases G01,G03       only these cases
    --repeat 3            ask each case 3 times (for reliability.py)
    --resume <file>       carry on a run that stopped: cases already in the file are skipped
    --keep-data           do not reset the practice data first (normally every conversation starts from the same data,
                          because the agent really refunds and changes addresses)
It prints one line per case, so you can keep working while it runs. Start it first, then learn.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

from common import HERE, RESULTS, answers_file, plugin_dir, read_answers, read_golden, stamp, workspace

TIMEOUT = 300  # seconds for one turn


def reset_data(ws: Path, agent: Path) -> str | None:
    """Fresh practice data before a conversation. The agent takes real actions (refunds, address changes): without a
    reset, the second run of a case meets the first run's refund, and "passes sometimes" would only mean "the data
    changed". About 2 seconds."""
    node = shutil.which("node")
    p = subprocess.run([node, str(agent), "reset"], cwd=str(ws), capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=120)
    return None if "DATA_READY" in p.stdout else (p.stdout + p.stderr).strip()[:300] or "the reset failed"


def run_turn(ws: Path, agent: Path, version: str, variant: str | None, customer: str, message: str, cont: str | None):
    node = shutil.which("node")
    if not node:
        return None, "Node.js was not found"
    args = [node, str(agent), "ask", "--version", version, "--customer", customer]
    if variant:
        args += ["--variant", variant]
    if cont:
        args += ["--continue", cont]
    args.append(message)
    try:
        p = subprocess.run(args, cwd=str(ws), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        return None, f"no answer within {TIMEOUT} seconds"
    m = re.search(r"^AGENT_RUN (\S+)", p.stdout, re.M)
    if not m:
        err = re.search(r"^(AGENT_\w+_ERROR .*)$", p.stdout, re.M)
        return None, (err.group(1) if err else (p.stdout + p.stderr).strip()[:300] or f"exit code {p.returncode}")
    run_id = m.group(1)
    try:
        run = json.loads((ws / ".bootcamp" / "agent" / "runs" / run_id / "run.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None, f"the run {run_id} has no run.json"
    return run, None


def main() -> int:
    ap = argparse.ArgumentParser(description="Ask the agent every golden case and save the answers.")
    ap.add_argument("--version", default="v2", choices=["v1", "v2"])
    ap.add_argument("--variant")
    ap.add_argument("--cases")
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--resume")
    ap.add_argument("--keep-data", action="store_true",
                    help="do not reset the practice data before each conversation (normally every run starts fresh)")
    ap.add_argument("--golden", default=str(HERE / "golden" / "golden.csv"))
    a = ap.parse_args()

    ws, plugin = workspace(), plugin_dir()
    if not ws:
        sys.exit("This evals folder is not inside your bootcamp folder. Ask the coach to set it up (week 2, Monday).")
    agent = plugin / "scripts" / "bootcamp" / "agent.mjs" if plugin else None
    if not agent or not agent.exists():
        sys.exit("The coach's agent runner was not found. In the COACH window, type /bootcamp: the coach sets it up again.")
    cases = read_golden(Path(a.golden))
    if a.cases:
        want = [x.strip() for x in a.cases.split(",") if x.strip()]
        unknown = sorted(set(want) - {c["id"] for c in cases})
        if unknown:
            sys.exit(f"Not in golden.csv: {', '.join(unknown)}")
        cases = [c for c in cases if c["id"] in want]

    RESULTS.mkdir(exist_ok=True)
    out = answers_file(a.version, a.resume) if a.resume else RESULTS / f"answers-{a.version}-{stamp()}.jsonl"
    done = {(r["id"], r.get("repeat", 1)) for r in read_answers(out)} if out.exists() else set()
    jobs = [(c, r) for r in range(1, a.repeat + 1) for c in cases if (c["id"], r) not in done]
    print(f"Asking {a.version}: {len(jobs)} conversation(s){f', {len(done)} already saved' if done else ''}. "
          f"About {max(1, round(len(jobs) * 12 / 60))} minute(s). Saving to results/{out.name}", flush=True)
    t_all, errors, tokens = time.monotonic(), 0, {"input": 0, "output": 0, "cacheWrite": 0, "cacheRead": 0}
    for n, (case, rep) in enumerate(jobs, start=1):
        t0, turns, err, cont, last_variant = time.monotonic(), [], None, None, None
        if not a.keep_data:
            err = reset_data(ws, agent)
        for message in ([] if err else case["turns"]):
            run, err = run_turn(ws, agent, a.version, a.variant, case["customer_id"] or "C-017", message, cont)
            if err:
                break
            cont, last_variant = run["runId"], run.get("variant")
            turns.append({"message": message, "runId": run["runId"], "reply": run.get("reply", ""),
                          "intent": run.get("intent"), "tools": run.get("tools") or [],
                          "durationMs": run.get("durationMs"), "usage": run.get("usage")})
            for k in tokens:
                tokens[k] += ((run.get("usage") or {}).get(k) or 0)
        row = {"id": case["id"], "repeat": rep, "version": a.version, "variant": last_variant or a.variant,
               "customer": case["customer_id"], "turns": turns,
               "final_reply": turns[-1]["reply"] if turns else "", "final_intent": turns[-1]["intent"] if turns else None,
               "seconds": round(time.monotonic() - t0, 1), "error": err}
        with open(out, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        errors += bool(err)
        what = f"ERROR {err}" if err else f"{len(turns)} turn(s), intent {row['final_intent'] or '-'}"
        run_no = f" run {rep}" if a.repeat > 1 else ""
        print(f"[{n}/{len(jobs)}] {case['id']}{run_no}: {what}, {row['seconds']} s", flush=True)
    mins = round((time.monotonic() - t_all) / 60, 1)
    print(f"\nDone in {mins} minute(s): {len(jobs) - errors} saved, {errors} error(s). File: results/{out.name}")
    print(f"Agent tokens: input {tokens['input']}, output {tokens['output']}, cache write {tokens['cacheWrite']}, "
          f"cache read {tokens['cacheRead']}.")
    if errors:
        print("Errors are not answers of the agent. Run the same command with --resume " + out.name + " to try them again.")
    _log_usage(a, len(jobs), errors, tokens, mins)
    return 0


def _log_usage(a, jobs: int, errors: int, tokens: dict, mins: float) -> None:
    """Your local usage log (CLAUDE.md rule 7): tokens per run, no name, no ID."""
    import csv
    from common import IST
    from datetime import datetime
    log = RESULTS / "usage-log.csv"
    new = not log.exists()
    with open(log, "a", newline="", encoding="utf-8-sig" if new else "utf-8") as fh:
        w = csv.writer(fh)
        if new:
            w.writerow(["date_time", "command", "cases", "models", "calls", "failed_calls", "input_tokens",
                        "output_tokens", "cache_write_tokens", "cache_read_tokens", "cost_usd_estimate", "minutes"])
        w.writerow([datetime.now(IST).isoformat(timespec="seconds"), f"ask_golden {a.version}", jobs, "agent",
                    jobs, errors, tokens["input"], tokens["output"], tokens["cacheWrite"], tokens["cacheRead"], "", mins])


if __name__ == "__main__":
    sys.exit(main())
