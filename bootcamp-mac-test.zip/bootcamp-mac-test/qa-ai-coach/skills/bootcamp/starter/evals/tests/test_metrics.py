"""The code checks (no AI judge): run with  python -m pytest tests -q"""
import json

import metrics
from common import read_golden, GOLDEN


def answer(*turns):
    """turns: (intent, [(tool, input, result), ...], reply)"""
    return {"id": "X", "turns": [{"message": "m", "intent": i, "reply": r,
                                  "tools": [{"name": n, "input": inp, "result": json.dumps(res)} for n, inp, res in tools]}
                                 for i, tools, r in turns]}


def case(**kw):
    base = {"id": "X", "expected_intent": "refund", "expected_tools": [], "expected_end_state": "none", "should_refuse": False}
    return {**base, **kw}


def test_worked_examples_parse():
    cases = read_golden(GOLDEN)
    assert [c["id"] for c in cases] == ["G01", "G02", "G03"]
    assert len(cases[2]["turns"]) == 2 and cases[2]["should_refuse"] is True


def test_tool_and_argument_correctness():
    c = case(expected_tools=[{"name": "lookup_order", "args": {"order_id": "PCL-1"}},
                             {"name": "issue_refund", "args": {"order_id": "PCL-1", "amount": 400}}])
    good = answer(("refund", [("lookup_order", {"order_id": "PCL-1"}, {"status": "delivered"}),
                              ("issue_refund", {"order_id": "PCL-1", "amount": 400.0}, {"refund_id": "RF-1"})], "Done"))
    assert metrics.tool_check(c, good) == {"tool_correct": True, "args_correct": True, "notes": "as expected"}
    wrong_amount = answer(("refund", [("lookup_order", {"order_id": "PCL-1"}, {}),
                                      ("issue_refund", {"order_id": "PCL-1", "amount": 450}, {"refund_id": "RF-1"})], "Done"))
    r = metrics.tool_check(c, wrong_amount)
    assert r["tool_correct"] and not r["args_correct"] and "450" in r["notes"]
    missing = answer(("refund", [("lookup_order", {"order_id": "PCL-1"}, {})], "Done"))
    assert not metrics.tool_check(c, missing)["tool_correct"]


def test_forbidden_tool_counts_only_when_it_worked():
    c = case(expected_tools=[{"name": "change_address", "called": False}])
    tried_refused = answer(("address_change", [("change_address", {"order_id": "PCL-2"}, {"error": "already dispatched"})], "Sorry"))
    assert metrics.tool_check(c, tried_refused)["tool_correct"]
    changed = answer(("address_change", [("change_address", {"order_id": "PCL-2"}, {"ok": True})], "Changed"))
    assert not metrics.tool_check(c, changed)["tool_correct"]


def test_end_states():
    refund = answer(("refund", [("issue_refund", {"order_id": "PCL-1", "amount": 400}, {"refund_id": "RF-1"})], "ok"))
    assert metrics.end_state_check(case(expected_end_state="refund PCL-1 400"), refund)["end_state_ok"]
    assert not metrics.end_state_check(case(expected_end_state="refund PCL-1 300"), refund)["end_state_ok"]
    assert not metrics.end_state_check(case(expected_end_state="no_refund"), refund)["end_state_ok"]
    assert not metrics.end_state_check(case(expected_end_state="none"), refund)["end_state_ok"]
    hand = answer(("refund", [("handoff", {"summary": "COD"}, {"ticket": "H-1"})], "A person will reply"))
    assert metrics.end_state_check(case(expected_end_state="no_refund & handoff"), hand)["end_state_ok"]
    moved = answer(("address_change", [("change_address", {"order_id": "PCL-2", "new_address": "x"}, {"ok": True})], "done"))
    assert not metrics.end_state_check(case(expected_end_state="address_unchanged PCL-2"), moved)["end_state_ok"]
    assert metrics.end_state_check(case(expected_end_state="address PCL-2"), moved)["end_state_ok"]
    assert "unknown end state" in metrics.end_state_check(case(expected_end_state="teleport"), moved)["notes"]


def test_intent_last_turn_and_report():
    a = answer(("order_status", [], "x"), ("address_change, refund", [], "y"))
    assert metrics.intent_of(a) == "address_change"
    golden = [case(id="A", expected_intent="refund"), case(id="B", expected_intent="refund"), case(id="C", expected_intent="order_status")]
    answers = [dict(answer(("refund", [], "")), id="A"), dict(answer(("cancel", [], "")), id="B"),
               dict(answer(("order_status", [], "")), id="C")]
    rep = metrics.intent_report(golden, answers)
    assert rep["accuracy"] == 0.67
    assert rep["per_label"]["refund"]["recall"] == 0.5
    assert rep["matrix"][rep["labels"].index("refund")][rep["labels"].index("cancel")] == 1
