"""The gate and reliability, from saved scores: run with  python -m pytest tests -q"""
import gate
import reliability


def rows(spec):
    """spec: [(case, repeat, metric, result, risk)]"""
    return [{"case": c, "repeat": str(r), "metric": m, "result": res, "risk": risk, "part": "", "score": "", "reason": ""}
            for c, r, m, res, risk in spec]


CONFIG = {"release": "v2", "baseline": "v1", "max_errors": 0,
          "metrics": [{"metric": "End state", "min_pass_rate": 1.0}, {"metric": "Correct facts", "min_pass_rate": 0.5}],
          "risk": [{"risk": "high", "max_failed_cases": 0}], "no_worse_than_baseline": ["End state"]}


def test_gate_passes_and_blocks():
    good = rows([("G1", 1, "End state", "PASS", "high"), ("G1", 1, "Correct facts", "PASS", "high"),
                 ("G2", 1, "End state", "PASS", "low"), ("G2", 1, "Correct facts", "FAIL", "low")])
    assert all(ok for ok, _ in gate.check(CONFIG, good, good))
    bad = rows([("G1", 1, "End state", "FAIL", "high"), ("G1", 1, "Correct facts", "PASS", "high")])
    results = gate.check(CONFIG, bad, good)
    failed = [t for ok, t in results if not ok]
    assert any(t.startswith("End state") for t in failed)
    assert any("High-risk" in t and "G1" in t for t in failed)
    assert any("baseline" in t for t in failed)
    err = rows([("G1", 1, "Run", "ERROR", "high")])
    assert not gate.check({**CONFIG, "metrics": []}, err, None)[0][0]


def test_gate_metric_without_scores_fails():
    only_code = rows([("G1", 1, "End state", "PASS", "low")])
    failed = [t for ok, t in gate.check(CONFIG, only_code, None) if not ok]
    assert any("Correct facts: no scores" in t for t in failed)


def test_reliability_labels():
    spec = []
    for rep in range(1, 6):
        spec.append(("STEADY", rep, "End state", "PASS", "high"))
        spec.append(("FLAKY", rep, "End state", "PASS" if rep != 3 else "FAIL", "high"))
        spec.append(("BROKEN", rep, "End state", "FAIL", "high"))
    rates = reliability.pass_rates(rows(spec))
    assert rates["STEADY"]["label"] == "passes every time"
    assert rates["FLAKY"] == {"runs": 5, "passed": 4, "rate": 0.8, "label": "passes sometimes", "failed_checks": ["End state"]}
    assert rates["BROKEN"]["label"] == "never passes"


def test_compare_finds_regressions():
    import compare
    old = rows([("G1", 1, "End state", "PASS", "high"), ("G2", 1, "End state", "FAIL", "low")])
    new = rows([("G1", 1, "End state", "FAIL", "high"), ("G2", 1, "End state", "FAIL", "low")])
    assert compare.regressions(old, new) == ["G1 · End state"]
    assert compare.rates(new, "risk") == {"high": (0, 1), "low": (0, 1)}


def test_calibration_agreement():
    import calibration
    judge = rows([("G1", 1, "Correct facts", "PASS", "low"), ("G2", 1, "Policy", "FAIL", "high")])
    mine = [{"case": "G1", "repeat": "1", "metric": "Correct facts", "my_result": "pass"},
            {"case": "G2", "repeat": "1", "metric": "Policy", "my_result": "PASS"},
            {"case": "G9", "repeat": "1", "metric": "Policy", "my_result": "PASS"}]
    res = calibration.agreement(mine, judge)
    assert (res["agree"], res["total"]) == (1, 3)
    assert res["rows"][2]["judge_result"] == "MISSING"


def test_gate_never_reads_a_few_cases_file(tmp_path, monkeypatch):
    monkeypatch.setattr(gate, "RESULTS", tmp_path)
    (tmp_path / "scores-v2-20261208-100000.csv").write_text("case,repeat,metric,result,risk\n", encoding="utf-8")
    (tmp_path / "scores-v2-cases-20261208-110000.csv").write_text("case,repeat,metric,result,risk\n", encoding="utf-8")
    assert gate.newest("v2").name == "scores-v2-20261208-100000.csv"


def test_compare_and_calibration_skip_partial_runs(tmp_path):
    import common
    (tmp_path / "scores-v2-20261208-100000.csv").write_text("x\n", encoding="utf-8")
    (tmp_path / "scores-v2-cases-20261209-110000.csv").write_text("x\n", encoding="utf-8")
    assert common.latest("scores-v2-*.csv", tmp_path, whole_runs_only=True).name == "scores-v2-20261208-100000.csv"
    assert common.latest("scores-v2-*.csv", tmp_path).name == "scores-v2-cases-20261209-110000.csv", "reliability reads repeats"


def test_gate_scores_option(tmp_path, monkeypatch, capsys):
    import sys
    f = tmp_path / "scores-v2-cases-20261209-110000.csv"
    f.write_text("case,repeat,part,metric,score,result,risk,reason\nG01,1,tools,Tool correctness,1,PASS,high,ok\n", encoding="utf-8")
    cfg = tmp_path / "gate.json"
    cfg.write_text('{"release": "v2", "metrics": [{"metric": "Tool correctness", "min_pass_rate": 1.0}]}', encoding="utf-8")
    monkeypatch.setattr(sys, "argv", ["gate.py", "--config", str(cfg), "--scores", str(f)])
    assert gate.main() == 0
    assert "scores-v2-cases-20261209-110000.csv" in capsys.readouterr().out
