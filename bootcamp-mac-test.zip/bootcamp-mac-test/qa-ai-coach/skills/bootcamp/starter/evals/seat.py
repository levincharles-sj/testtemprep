"""Calls Claude through your own Claude Code seat (`claude -p`). No API key.

Also keeps your local usage log: one row per run in results/usage-log.csv
(tokens, model and the cost estimate from Claude Code). No name, no ID.
"""
from __future__ import annotations

import csv
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

# DeepEval settings. They must be set before DeepEval is loaded.
os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "1")  # send no usage data to DeepEval's makers
os.environ.setdefault("DEEPEVAL_DISABLE_TIMEOUTS", "1")   # without this, slow runs lose results silently

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")  # the ₹ sign must print on Windows
    sys.stderr.reconfigure(encoding="utf-8")

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
USAGE_LOG = RESULTS / "usage-log.csv"
IST = timezone(timedelta(hours=5, minutes=30))
MAX_AT_ONCE = 2        # at most 2 Claude calls at the same time
TIMEOUT_SECONDS = 180  # one call that takes longer than this is stopped

_gate = threading.BoundedSemaphore(MAX_AT_ONCE)
_lock = threading.Lock()


class SeatError(RuntimeError):
    pass


def now_ist() -> str:
    return datetime.now(IST).isoformat(timespec="seconds")


def claude_exe() -> str:
    exe = shutil.which("claude")
    if not exe:
        raise SeatError("The 'claude' command was not found. Install Claude Code, log in, and open a new terminal.")
    return exe


class Usage:
    """Adds up the tokens of every call in one run."""

    FIELDS = ["date_time", "command", "cases", "models", "calls", "failed_calls", "input_tokens",
              "output_tokens", "cache_write_tokens", "cache_read_tokens", "cost_usd_estimate", "minutes"]

    def __init__(self):
        self.start = time.monotonic()
        self.calls = self.failed = 0
        self.tok = {"input_tokens": 0, "output_tokens": 0, "cache_write_tokens": 0, "cache_read_tokens": 0}
        self.cost = 0.0
        self.models: set[str] = set()

    def add(self, data: dict | None, failed: bool = False):
        with _lock:
            self.calls += 1
            if failed or not data:
                self.failed += 1
            if not data:
                return
            u = data.get("usage") or {}
            self.tok["input_tokens"] += u.get("input_tokens") or 0
            self.tok["output_tokens"] += u.get("output_tokens") or 0
            self.tok["cache_write_tokens"] += u.get("cache_creation_input_tokens") or 0
            self.tok["cache_read_tokens"] += u.get("cache_read_input_tokens") or 0
            self.cost += data.get("total_cost_usd") or 0
            self.models.update((data.get("modelUsage") or {}).keys())

    def row(self, command: str, cases: str) -> dict:
        return {"date_time": now_ist(), "command": command, "cases": cases,
                "models": " ".join(sorted(self.models)), "calls": self.calls, "failed_calls": self.failed,
                **self.tok, "cost_usd_estimate": round(self.cost, 4),
                "minutes": round((time.monotonic() - self.start) / 60, 1)}

    def save(self, command: str, cases: str) -> dict:
        row = self.row(command, cases)
        RESULTS.mkdir(exist_ok=True)
        new = not USAGE_LOG.exists()
        with open(USAGE_LOG, "a", newline="", encoding="utf-8-sig" if new else "utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=self.FIELDS)
            if new:
                w.writeheader()
            w.writerow(row)
        return row


USAGE = Usage()  # this run's usage


def ask_claude(prompt: str, *, system: str, model: str = "haiku", json_schema: dict | None = None) -> dict:
    """One `claude -p` call. The prompt goes in on stdin (no Windows length limit).

    Tools are off and Claude Code's own long system prompt is replaced by ours,
    so each call carries only about 600 tokens of extra text. Safe mode keeps out the tester's
    CLAUDE.md files, plugins and hooks (for example the coach's WORK-window hook): the assistant
    and the judge see only our prompt. The seat login works as normal.
    Returns Claude Code's JSON result (fields: result, structured_output, usage ...).
    """
    args = [claude_exe(), "-p", "--output-format", "json", "--model", model,
            "--tools", "", "--system-prompt", system, "--no-session-persistence",
            "--strict-mcp-config", "--disable-slash-commands", "--safe-mode"]
    if json_schema is not None:
        args += ["--json-schema", json.dumps(json_schema, separators=(",", ":"))]
    with _gate:
        try:
            proc = subprocess.run(args, input=prompt, capture_output=True, text=True, encoding="utf-8",
                                  errors="replace", timeout=TIMEOUT_SECONDS, cwd=str(HERE))
        except subprocess.TimeoutExpired as exc:
            USAGE.add(None)
            raise SeatError(f"Claude did not answer within {TIMEOUT_SECONDS} seconds.") from exc
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        USAGE.add(None)
        if "unknown option" in (proc.stderr or proc.stdout) and "--safe-mode" in (proc.stderr or proc.stdout):
            raise SeatError("Your Claude Code is too old for the judge. In this terminal, type: claude update  "
                            "Then type your command again.") from exc
        raise SeatError(f"Claude Code gave no result (exit code {proc.returncode}): "
                        f"{(proc.stderr or proc.stdout)[:300]}") from exc
    if data.get("is_error"):
        USAGE.add(data, failed=True)
        raise SeatError(f"Claude Code reported an error: {str(data.get('result'))[:300]}")
    USAGE.add(data)
    return data
