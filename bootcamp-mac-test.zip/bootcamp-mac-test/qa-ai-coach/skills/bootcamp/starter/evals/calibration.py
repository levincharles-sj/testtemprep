"""Judge calibration: does the AI judge agree with you?

    Windows: .\\.venv\\Scripts\\python.exe calibration.py
    Mac:     .venv/bin/python calibration.py

1. Fill golden/calibration.csv: 8 rows, one per judge result you score by hand. Columns: case, repeat,
   metric (Correct facts, Policy or Faithful to tools) and my_result (PASS or FAIL), plus a short why.
   Score them yourself BEFORE you look at the judge's result.
2. Run this. It finds the judge's result for each row in the newest scores file and shows where you agree.
Agreement below 75% (6 of 8) means: do not trust that metric's pass line yet. Read the disagreements.
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

from common import HERE, latest


def agreement(mine: list[dict], scores: list[dict]) -> dict:
    judge = {(r["case"], str(r["repeat"]), r["metric"]): r for r in scores}
    rows, same = [], 0
    for m in mine:
        key = (m["case"].strip(), str(m.get("repeat") or 1).strip(), m["metric"].strip())
        j = judge.get(key)
        jr = j["result"] if j else "MISSING"
        ok = jr == m["my_result"].strip().upper()
        same += ok
        rows.append({**m, "judge_result": jr, "agree": ok, "judge_reason": (j or {}).get("reason", "")})
    n = len(rows)
    return {"rows": rows, "agree": same, "total": n, "rate": round(same / n, 2) if n else None}


def main() -> int:
    ap = argparse.ArgumentParser(description="Compare your hand scores with the judge.")
    ap.add_argument("--mine", default=str(HERE / "golden" / "calibration.csv"))
    ap.add_argument("--scores")
    a = ap.parse_args()
    mine_path = Path(a.mine)
    if not mine_path.exists():
        sys.exit("golden/calibration.csv was not found. Copy golden/calibration-template.csv and fill it in.")
    with open(mine_path, newline="", encoding="utf-8-sig") as fh:
        mine = [r for r in csv.DictReader(fh) if (r.get("case") or "").strip() and (r.get("my_result") or "").strip()]
    spath = Path(a.scores) if a.scores else latest("scores-*.csv", whole_runs_only=True)
    if not spath or not spath.exists():
        sys.exit("No scores file. Run run_metrics.py first.")
    with open(spath, newline="", encoding="utf-8-sig") as fh:
        scores = list(csv.DictReader(fh))
    res = agreement(mine, scores)
    print(f"Your scores vs the judge ({spath.name}):\n")
    for r in res["rows"]:
        mark = "agree" if r["agree"] else "DISAGREE"
        print(f"{r['case']:6} run {r.get('repeat') or 1} {r['metric'][:18]:18} you {r['my_result']:5} judge {r['judge_result']:7} {mark}")
        if not r["agree"]:
            print(f"        judge's reason: {r['judge_reason'][:160]}")
    print(f"\nAgreement: {res['agree']} of {res['total']} ({res['rate']})")
    if res["rate"] is not None and res["rate"] < 0.75:
        print("Below 75%: do not trust this judge's pass line yet. Read each disagreement: who was right?")
    return 0


if __name__ == "__main__":
    sys.exit(main())
