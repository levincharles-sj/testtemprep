# Judge calibration (week 2)

The coach fills this in from your answers. Check that every line is what you saw and decided.

Agent: … · Judge: haiku, on my Claude seat · Scores file: `results/…` · Date: …

## 1. My 8 hand scores (before I looked at the judge)
| Case | Run | Metric | My result | Why |
|---|---|---|---|---|
| … | … | Correct facts / Policy / Faithful to tools | PASS / FAIL | … |

(These rows are also in `golden/calibration.csv`, for `calibration.py`.)

## 2. Agreement
- **Run:** `calibration.py` · **Agreement:** … of 8
- **Where we differ:**

| Case | Me | Judge | The judge's reason (short) | Who is right, and why |
|---|---|---|---|---|
| … | … | … | … | … |

## 3. What I conclude
- **Can I trust this judge's pass line?** … (below 6 of 8: not yet)
- **What I change:** the pass line in `gate.json` / the expected facts in `golden.csv` / nothing, because …
