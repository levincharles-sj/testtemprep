# After go-live: monitoring plan (10 minutes)

An eval before release is one look. After go-live, real customers write things the golden set never had.
Fill in each line in plain words. The coach copies it into your sign-off report.

- **What we sample:** … conversations a day (for example 50, picked at random), with personal data removed.
- **Which checks run on them:** … (for example: intent, end state from the tool log, Policy and Correct facts by the judge)
- **Who reads the results, and when:** … (role, for example the QA engineer on the project, each morning)
- **Alert when:** … (for example: Policy below 98% on a day, or any refund above the limit without a handoff)
- **What happens on an alert:** … (for example: stop refunds without a person, tell the TL, add the case to the golden set)
- **What it costs:** … judge calls a day (on whose account?)
- **How the golden set grows:** every real failure becomes a new case, so it cannot come back.
