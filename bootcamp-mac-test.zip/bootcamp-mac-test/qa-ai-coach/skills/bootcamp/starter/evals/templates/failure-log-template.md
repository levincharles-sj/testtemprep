# Failure log: the support agent, part by part (week 2)

The coach fills this in from your answers. Check that every line is what you saw and decided.

- **Agent:** Parcelly Support Agent <v1 | v2> · **Golden set:** `golden/golden.csv` · **Scores:** `results/scores-<version>-….csv` · Date: …
- **How I found each one:** the scores file, then the trace (`/bootcamp` shows it as `week-2/traces/<run>.md`), then the data (`lookup`).

## 1. Where it breaks
| Part | Failed checks |
|---|---|
| Intent (sorting the request) | … |
| Search (the help documents) | … |
| Tools (right tool, right inputs) | … |
| Reply (correct, faithful, safe) | … |
| The whole task (end state, policy) | … |

## 2. The faults I placed

### Fault 1: <part>
- **Case and run:** …
- **What the customer asked:** "…"
- **What the agent did** (from the trace): …
- **What it should have done** (source: policy rule / help article / order data): …
- **Real fault or judge mistake?** … because …

(one block per fault)

## 3. The fault I would fix first
- **Fix first:** fault …, because … (who is hurt, how often, how much money)
