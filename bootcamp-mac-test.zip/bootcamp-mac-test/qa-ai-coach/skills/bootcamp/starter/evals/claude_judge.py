"""DeepEval's AI judge, running on your own Claude seat through Claude Code.

DeepEval asks the judge many small questions and wants each answer in a fixed
JSON shape (a "schema"). We pass that shape to Claude Code with --json-schema
and read its `structured_output`. If an answer is missing or broken, we try
again, up to 3 times. This follows DeepEval's guide to custom judge models:
https://deepeval.com/guides/guides-using-custom-llms
"""
from __future__ import annotations

import asyncio
import json
import threading
from typing import Optional

from pydantic import BaseModel, ValidationError

import seat  # sets DeepEval's settings first
from deepeval.models import DeepEvalBaseLLM

JUDGE_RULES = ("You are an evaluation judge. Follow the instructions in the user message exactly. "
               "When a JSON format is requested, return only that JSON.")
TRIES = 3


class ClaudeJudge(DeepEvalBaseLLM):
    def __init__(self, model: str = "haiku", system: str = JUDGE_RULES):
        self.alias = model
        self.system = system
        self.calls = 0
        self.retries = 0
        self._lock = threading.Lock()
        super().__init__(model)

    def load_model(self):
        return self

    def get_model_name(self):
        return f"Claude Code ({self.alias})"

    def _ask(self, prompt: str, schema: Optional[type[BaseModel]]):
        shape = schema.model_json_schema() if schema is not None else None
        problem = ""
        for attempt in range(TRIES):
            with self._lock:
                self.calls += 1
                self.retries += attempt > 0
            try:
                data = seat.ask_claude(prompt, system=self.system, model=self.alias, json_schema=shape)
            except seat.SeatError as exc:
                problem = str(exc)
                continue
            if schema is None:
                return data["result"]
            found = data.get("structured_output")
            if isinstance(found, dict):
                found = _unwrap(found)
                try:
                    return schema.model_validate(found)
                except ValidationError as exc:
                    problem = f"the judge's answer did not fit the format: {exc.errors()[:1]}"
            else:
                problem = "the judge gave no answer in the format"
        raise ValueError(f"The judge gave no usable answer after {TRIES} tries: {problem}")

    def generate(self, prompt: str, schema: Optional[type[BaseModel]] = None, **kwargs):
        return self._ask(prompt, schema)

    async def a_generate(self, prompt: str, schema: Optional[type[BaseModel]] = None, **kwargs):
        return await asyncio.to_thread(self._ask, prompt, schema)


def _unwrap(found: dict) -> dict:
    """Seen in real runs: a text field sometimes holds the whole JSON again,
    for example {"reason": "{\\"reason\\": \\"The score is ...\\"}"}. Take the inner text."""
    out = dict(found)
    for key, value in found.items():
        if isinstance(value, str) and value.lstrip().startswith("{") and f'"{key}"' in value:
            try:
                inner = json.loads(value)
            except ValueError:
                continue
            if isinstance(inner, dict) and key in inner:
                out[key] = inner[key]
    return out
