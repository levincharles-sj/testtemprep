"""The checks that need no AI judge: intent, tool use, and the end state.

Each function takes one golden case and one saved answer (from ask_golden.py) and returns a result you can
explain: which expected tool was missing, which input was wrong, which change happened that should not have.
Plain Python only, so it is fast, free and the same every time.
"""
from __future__ import annotations

import json


# ---------- tool calls from a saved answer ----------
def calls_of(answer: dict) -> list[dict]:
    """All tool calls of all turns, in order: {"name", "input", "result" (a dict when it was JSON)}."""
    out = []
    for turn in answer.get("turns", []):
        for c in turn.get("tools") or []:
            result = c.get("result")
            if isinstance(result, str):
                try:
                    result = json.loads(result)
                except ValueError:
                    pass
            out.append({"name": c.get("name"), "input": c.get("input") or {}, "result": result})
    return out


def succeeded(call: dict) -> bool:
    """A tool call that did what it was asked: its result has no "error"."""
    r = call.get("result")
    return isinstance(r, dict) and "error" not in r


def _same(expected, actual) -> bool:
    if isinstance(expected, (int, float)) and not isinstance(expected, bool):
        try:
            return abs(float(actual) - float(expected)) < 0.005
        except (TypeError, ValueError):
            return False
    return str(expected).strip().lower() == str(actual).strip().lower()


# ---------- intent ----------
def intent_of(answer: dict) -> str:
    """The intent label of the last turn (the agent writes "INTENT: <label>" first). Several labels: the first."""
    turns = answer.get("turns") or []
    label = (turns[-1].get("intent") if turns else None) or ""
    return label.split(",")[0].strip().lower() or "(none)"


def intent_report(golden: list[dict], answers: list[dict]) -> dict:
    """Precision, recall and F1 per intent, and the confusion matrix (scikit-learn)."""
    from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
    by_id = {c["id"]: c for c in golden}
    gold, pred = [], []
    for a in answers:
        c = by_id.get(a["id"])
        if c and c["expected_intent"]:
            gold.append(c["expected_intent"].lower())
            pred.append(intent_of(a))
    labels = sorted(set(gold) | set(pred))
    if not gold:
        return {"labels": [], "per_label": {}, "matrix": [], "accuracy": None}
    p, r, f, s = precision_recall_fscore_support(gold, pred, labels=labels, zero_division=0)
    matrix = confusion_matrix(gold, pred, labels=labels).tolist()
    return {"labels": labels, "matrix": matrix,
            "per_label": {l: {"precision": round(float(p[i]), 2), "recall": round(float(r[i]), 2),
                              "f1": round(float(f[i]), 2), "support": int(s[i])} for i, l in enumerate(labels)},
            "accuracy": round(sum(g == q for g, q in zip(gold, pred)) / len(gold), 2)}


# ---------- tools ----------
def tool_check(case: dict, answer: dict) -> dict:
    """Tool correctness (the right tools were called, and forbidden ones were not) and argument correctness
    (the expected inputs were used). expected_tools items: {"name": "lookup_order", "args": {"order_id": "PCL-1"}}
    or {"name": "change_address", "called": false}."""
    calls = calls_of(answer)
    tool_ok, args_ok, notes = True, True, []
    for exp in case["expected_tools"]:
        name = exp.get("name")
        mine = [c for c in calls if c["name"] == name]
        if exp.get("called") is False:
            done = [c for c in mine if succeeded(c)]
            if done:
                tool_ok = False
                notes.append(f"{name} was used and worked, but it should not be used")
            continue
        if not mine:
            tool_ok = False
            notes.append(f"{name} was not called")
            continue
        want = exp.get("args") or {}
        if want and not any(all(_same(v, c["input"].get(k)) for k, v in want.items()) for c in mine):
            args_ok = False
            got = "; ".join(json.dumps(c["input"], ensure_ascii=False) for c in mine)
            notes.append(f"{name} was called, but not with {json.dumps(want, ensure_ascii=False)} (it got {got})")
    return {"tool_correct": tool_ok, "args_correct": args_ok and tool_ok,
            "notes": "; ".join(notes) or "as expected"}


# ---------- end state ----------
def end_state_check(case: dict, answer: dict) -> dict:
    """What changed on the account, read from the tool results:
      none                         nothing was changed (no refund, no address change, no handoff ticket)
      refund <order> <amount>      exactly that refund was issued
      no_refund                    no refund was issued
      address <order>              the address of that order was changed
      address_unchanged <order>    the address of that order was not changed
      handoff                      the conversation was handed to a person (a ticket was created)
    Several states: join them with " & ", for example "no_refund & handoff"."""
    calls = calls_of(answer)
    ok_calls = [c for c in calls if succeeded(c)]
    refunds = [c for c in ok_calls if c["name"] == "issue_refund"]
    changes = [c for c in ok_calls if c["name"] == "change_address"]
    handoffs = [c for c in ok_calls if c["name"] == "handoff"]
    fails = []
    for part in [p.strip() for p in case["expected_end_state"].split("&") if p.strip()]:
        words = part.split()
        kind = words[0].lower()
        if kind == "none":
            if refunds or changes or handoffs:
                fails.append("something changed, but nothing should change")
        elif kind == "refund" and len(words) >= 3:
            order, amount = words[1], float(words[2])
            if not any(_same(order, c["input"].get("order_id")) and _same(amount, c["input"].get("amount")) for c in refunds):
                fails.append(f"no refund of {amount:g} on {order}")
            if len(refunds) > 1:
                fails.append(f"{len(refunds)} refunds were issued, one was expected")
        elif kind == "no_refund":
            if refunds:
                fails.append(f"a refund was issued ({refunds[0]['input'].get('order_id')}, {refunds[0]['input'].get('amount')})")
        elif kind == "address" and len(words) >= 2:
            if not any(_same(words[1], c["input"].get("order_id")) for c in changes):
                fails.append(f"the address of {words[1]} was not changed")
        elif kind == "address_unchanged" and len(words) >= 2:
            if any(_same(words[1], c["input"].get("order_id")) for c in changes):
                fails.append(f"the address of {words[1]} was changed, but it should stay")
        elif kind == "handoff":
            if not handoffs:
                fails.append("no handoff ticket was created")
        else:
            fails.append(f"unknown end state '{part}' in golden.csv")
    return {"end_state_ok": not fails, "notes": "; ".join(fails) or "as expected"}


def case_passes(det: dict, judged: dict | None = None) -> bool:
    """One run of one case passes when the tools, inputs and end state are right (and, when the judge ran,
    every judge check passed too)."""
    ok = det["tool_correct"] and det["args_correct"] and det["end_state_ok"]
    if judged:
        ok = ok and all(v == "PASS" for v in judged.values())
    return ok


def deterministic(case: dict, answer: dict) -> dict:
    t, e = tool_check(case, answer), end_state_check(case, answer)
    intent_ok = (not case["expected_intent"]) or intent_of(answer) == case["expected_intent"].lower()
    return {"intent_ok": intent_ok, "intent": intent_of(answer), "tool_correct": t["tool_correct"],
            "args_correct": t["args_correct"], "tool_notes": t["notes"], "end_state_ok": e["end_state_ok"], "end_notes": e["notes"],
            "notes": "; ".join(n for n in (t["notes"], e["notes"]) if n != "as expected") or "as expected"}
