"""Reliability: does each case pass every time, or only sometimes?

    Windows: .\\.venv\\Scripts\\python.exe reliability.py --scores results\\scores-v2-<date-time>.csv
    Mac:     .venv/bin/python reliability.py --scores results/scores-v2-<date-time>.csv

An AI agent can answer the same message differently each time. One green run proves little.
Score a file where each case was asked several times (ask_golden.py --repeat 5, then run_metrics.py),
or the recorded reference runs the coach gives you, and this shows the pass rate per case:
  passes every time    the same result in every run
  passes sometimes     a refund that is right 4 times in 5 is a production incident
  never passes         a steady fault
A run of a case passes when every check in the scores file passed for that run.
Options: --metrics "Tool correctness,End state" (only these checks), --min-runs 3
"""
from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

from common import HERE, RESULTS, latest, stamp


def pass_rates(rows: list[dict], metrics: set[str] | None = None) -> dict:
    """{case: {"runs": n, "passed": k, "rate": k/n, "label": ..., "failed_checks": [...]}}"""
    runs = defaultdict(lambda: defaultdict(list))  # case -> repeat -> results
    failed = defaultdict(set)
    for r in rows:
        if metrics and r["metric"] not in metrics:
            continue
        runs[r["case"]][str(r["repeat"])].append(r["result"])
        if r["result"] != "PASS":
            failed[r["case"]].add(r["metric"])
    out = {}
    for case, by_rep in runs.items():
        n = len(by_rep)
        k = sum(all(x == "PASS" for x in res) for res in by_rep.values())
        label = "passes every time" if k == n else "never passes" if k == 0 else "passes sometimes"
        out[case] = {"runs": n, "passed": k, "rate": round(k / n, 2), "label": label, "failed_checks": sorted(failed[case])}
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Pass rate per case over repeated runs.")
    ap.add_argument("--scores", help="a scores CSV from run_metrics.py (default: the newest)")
    ap.add_argument("--metrics", help="only these checks, comma-separated")
    ap.add_argument("--min-runs", type=int, default=2)
    a = ap.parse_args()
    path = Path(a.scores) if a.scores else latest("scores-*.csv")
    if path and not path.is_absolute():
        path = HERE / path
    if not path or not path.exists():
        sys.exit("No scores file. Run ask_golden.py --repeat 5, then run_metrics.py, first.")
    with open(path, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))
    metrics = {m.strip() for m in a.metrics.split(",")} if a.metrics else None
    rates = pass_rates(rows, metrics)
    few = [c for c, v in rates.items() if v["runs"] < a.min_runs]
    print(f"Reliability from {path.name}{' (checks: ' + a.metrics + ')' if a.metrics else ''}\n")
    print(f"{'case':8} {'runs':>4} {'passed':>6} {'rate':>5}  verdict              failed checks")
    lines = []
    for case, v in rates.items():
        line = f"{case:8} {v['runs']:4} {v['passed']:6} {v['rate']:5.2f}  {v['label']:20} {', '.join(v['failed_checks']) or '-'}"
        print(line)
        lines.append(line)
    sometimes = [c for c, v in rates.items() if v["label"] == "passes sometimes"]
    print(f"\nPasses sometimes: {', '.join(sometimes) or 'none'}")
    if few:
        print(f"Only one run for: {', '.join(few)}. Use more runs before you call a case reliable.")
    out = RESULTS / f"reliability-{stamp()}.txt"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved: results/{out.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
