"""Regression: is v2 better everywhere, or better on average and worse where it matters?

    Windows: .\\.venv\\Scripts\\python.exe compare.py
    Mac:     .venv/bin/python compare.py

It reads the newest scores file of v1 and of v2 (or the files you name) and shows the pass rate per part,
per metric and per risk level (the "risk" column of golden.csv), and every case that passed on v1 and fails on v2.
Options: --old results/scores-v1-....csv --new results/scores-v2-....csv
"""
from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

from common import HERE, RESULTS, latest, stamp


def load(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return [r for r in csv.DictReader(fh) if r["metric"] != "Run"]


def rates(rows: list[dict], key: str) -> dict:
    agg = defaultdict(lambda: [0, 0])
    for r in rows:
        agg[r[key]][0] += r["result"] == "PASS"
        agg[r[key]][1] += 1
    return {k: (p, n) for k, (p, n) in agg.items()}


def regressions(old: list[dict], new: list[dict]) -> list[str]:
    """Checks that passed in every v1 run of a case and fail in at least one v2 run."""
    def by(rows):
        d = defaultdict(list)
        for r in rows:
            d[(r["case"], r["metric"])].append(r["result"])
        return d
    o, n = by(old), by(new)
    return sorted(f"{c} · {m}" for (c, m), res in n.items()
                  if (c, m) in o and all(x == "PASS" for x in o[(c, m)]) and any(x != "PASS" for x in res))


def main() -> int:
    ap = argparse.ArgumentParser(description="Compare v1 and v2 part by part.")
    ap.add_argument("--old")
    ap.add_argument("--new")
    a = ap.parse_args()
    old_p = Path(a.old) if a.old else latest("scores-v1-*.csv", whole_runs_only=True)
    new_p = Path(a.new) if a.new else latest("scores-v2-*.csv", whole_runs_only=True)
    if not old_p or not new_p:
        sys.exit("Score both versions first: run_metrics.py --version v1, and run_metrics.py --version v2.")
    old_p, new_p = (p if p.is_absolute() else HERE / p for p in (old_p, new_p))
    old, new = load(old_p), load(new_p)
    lines = [f"v1: {old_p.name}   v2: {new_p.name}", ""]
    for key, title in (("part", "Part"), ("metric", "Metric"), ("risk", "Risk")):
        o, n = rates(old, key), rates(new, key)
        lines.append(f"{title:22} {'v1':>9} {'v2':>9}  change")
        for k in sorted(set(o) | set(n)):
            po, no = o.get(k, (0, 0))
            pn, nn = n.get(k, (0, 0))
            ro = po / no if no else None
            rn = pn / nn if nn else None
            change = "" if ro is None or rn is None else ("worse" if rn < ro else "better" if rn > ro else "same")
            lines.append(f"{k or '-':22} {f'{po}/{no}':>9} {f'{pn}/{nn}':>9}  {change}")
        lines.append("")
    regs = regressions(old, new)
    lines.append("Passed on v1, fails on v2: " + (", ".join(regs) if regs else "none"))
    print("\n".join(lines))
    out = RESULTS / f"compare-{stamp()}.txt"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\nSaved: results/{out.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
