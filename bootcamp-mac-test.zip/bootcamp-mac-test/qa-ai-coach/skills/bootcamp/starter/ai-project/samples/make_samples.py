"""Make the synthetic sample exports (fake data, reserved email domains, no phone numbers or real-looking IDs).
Used by the tests and as the coach's worked examples. Run: python samples/make_samples.py"""
from __future__ import annotations

import csv
import json
import random
from pathlib import Path

HERE = Path(__file__).resolve().parent
rnd = random.Random(2026)


def write(folder: str, name: str, rows, mapping: dict):
    d = HERE / folder
    d.mkdir(exist_ok=True)
    if name.endswith(".csv"):
        with (d / name).open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    else:
        (d / name).write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
    (d / "mapping.json").write_text(json.dumps(mapping, indent=2) + "\n", encoding="utf-8")


# 1. Classification: support emails sorted into 4 queues; 12 emails, each run 3 times; one sometimes wrong.
CATS = ["delivery", "refund", "address_change", "complaint"]
TEXT = {"delivery": "Where is my parcel, it was due yesterday", "refund": "Please return my money for the broken lamp",
        "address_change": "I moved, deliver to my new flat instead", "complaint": "The driver was rude at the door"}
rows = []
for i in range(1, 13):
    truth = CATS[(i - 1) % 4]
    for run in (1, 2, 3):
        out = truth
        if i == 7 and run == 2:
            out = "refund"            # passes sometimes (address change read as refund on one run)
        if i == 11:
            out = "delivery"          # always wrong (address change read as delivery)
        rows.append({"ticket": f"T-{i:03d}", "run": run, "email_text": TEXT[truth], "ai_queue": out, "true_queue": truth,
                     "confidence": round(0.55 + rnd.random() * 0.44, 2), "channel": "web" if i % 2 else "email"})
write("classification", "export.csv", rows, {"type": "classification", "columns": {
    "case_id": "ticket", "run_id": "run", "input": "email_text", "output": "ai_queue", "expected": "true_queue",
    "score": "confidence", "group": "channel"}})

# 2. Extraction: invoices, Indian date and amount formats.
inv = [  # (what the document says, what the AI extracted)
    ({"invoice_no": "INV-0001", "invoice_date": "05/12/2026", "total": "₹1,23,456.50", "vendor": "Acme Traders"},
     {"invoice_no": "INV-0001", "invoice_date": "2026-12-05", "total": "123456.50", "vendor": "ACME  Traders"}),
    ({"invoice_no": "INV-0002", "invoice_date": "1st Dec 2026", "total": "1.5 lakh", "vendor": "Bharat Supplies"},
     {"invoice_no": "INV-0002", "invoice_date": "01-12-2026", "total": "Rs. 1,50,000/-", "vendor": "Bharat Supplies"}),
    ({"invoice_no": "INV-0003", "invoice_date": "02.12.2026", "total": "INR 980", "vendor": "City Stationers"},
     {"invoice_no": "INV-0003", "invoice_date": "2026-12-02", "total": "", "vendor": "City Stationers", "gstin": "INVENTED-1"}),
    ({"invoice_no": "INV-0004", "invoice_date": "December 3, 2026", "total": "₹2,000", "vendor": "Deccan Foods"},
     {"invoice_no": "INV-0004", "invoice_date": "2026-03-12", "total": "2000", "vendor": "Deccan Foods"}),
]
write("extraction", "export.jsonl",
      [{"doc_id": f"D-{i:02d}", "ai_fields": got, "true_fields": exp} for i, (exp, got) in enumerate(inv, 1)],
      {"type": "extraction", "columns": {"case_id": "doc_id", "output": "ai_fields", "expected": "true_fields"},
       "fields": {"invoice_date": "date", "total": "amount", "vendor": "name", "invoice_no": "text"}})

# 3. Validation: records checked by AI and by rules.
val = [("R-01", "valid", "valid", "valid"), ("R-02", "invalid", "invalid", "valid"), ("R-03", "invalid", "valid", "invalid"),
       ("R-04", "valid", "invalid", "valid"), ("R-05", "invalid", "invalid", "invalid"), ("R-06", "valid", "valid", "valid")]
write("validation", "export.csv",
      [{"record": r, "ai_verdict": ai, "truth": t, "rules_verdict": rules} for r, t, ai, rules in val],
      {"type": "validation", "columns": {"case_id": "record", "output": "ai_verdict", "expected": "truth", "rules": "rules_verdict"}})

# 4. RAG: questions, answers, retrieved sources.
rag = [
    {"q_id": "Q-01", "question": "Can I combine two promo codes?", "answer": "No, only one code per order.",
     "retrieved": ["promo-codes.md"], "truth": {"answer": "Only one promo code per order.", "sources": ["promo-codes.md"]}},
    {"q_id": "Q-02", "question": "How long do refunds take?", "answer": "I don't know.",
     "retrieved": ["delivery-times.md"], "truth": {"answer": "5 to 7 working days after pickup.", "sources": ["refunds.md"]}},
    {"q_id": "Q-03", "question": "Can I change my address after dispatch?", "answer": "Yes, any time.",
     "retrieved": ["address-change.md", "lockers.md"], "truth": {"answer": "Only before dispatch.", "sources": ["address-change.md"]}},
]
write("rag", "export.jsonl", rag, {"type": "rag", "columns": {"case_id": "q_id", "input": "question", "output": "answer",
                                                               "expected": "truth", "contexts": "retrieved"}})

# 5. Agent: traces with tool calls and end state.
ag = [
    {"conv": "A-01", "trace": {"tool_calls": [{"tool": "lookup_order", "args": {"order_id": "ORD-1"}},
                                              {"tool": "issue_refund", "args": {"order_id": "ORD-1", "amount": "₹300"}}],
                               "end_state": {"refund_status": "issued"}},
     "expect": {"tools": [{"tool": "lookup_order", "args": {"order_id": "ORD-1"}}, {"tool": "issue_refund", "args": {"amount": 300}}],
                "ordered": True, "end_state": {"refund_status": "issued"}}},
    {"conv": "A-02", "trace": {"tool_calls": [{"tool": "issue_refund", "args": {"order_id": "ORD-2", "amount": 5000}}],
                               "end_state": {"refund_status": "issued"}},
     "expect": {"tools": [{"tool": "handoff"}], "forbidden_tools": ["issue_refund"], "end_state": {"refund_status": "none"}}},
]
write("agent", "export.jsonl", ag, {"type": "agent", "columns": {"case_id": "conv", "output": "trace", "expected": "expect"}})

# 6. Voice: recorded test calls (scripted, not customer calls).
vo = [
    {"call": "V-01", "heard": {"transcript": "I want to change my delivery date to twelve December", "slots": {"date": "12 Dec 2026"}},
     "said": {"transcript": "I want to change my delivery date to twelfth December", "slots": {"date": "2026-12-12"}}},
    {"call": "V-02", "heard": {"transcript": "my order number is O R D five", "slots": {"order_no": "ORD-6"}},
     "said": {"transcript": "my order number is O R D five", "slots": {"order_no": "ORD-5"}}},
]
write("voice", "export.jsonl", vo, {"type": "voice", "columns": {"case_id": "call", "output": "heard", "expected": "said"}})

if __name__ == "__main__":
    print("samples written to", HERE)
