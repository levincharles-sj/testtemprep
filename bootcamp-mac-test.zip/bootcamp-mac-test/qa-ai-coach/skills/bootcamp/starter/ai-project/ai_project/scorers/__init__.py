"""Scorers, one per AI type. Each takes a Dataset's rows and returns a JSON-ready dict with:
type, n (cases scored), the metrics, failures (case ids only, never client text) and notes (limits in plain words).
Rows without an expected answer are left out; the loader warns about them."""
from __future__ import annotations

from . import agent, classification, extraction, rag, validation, voice

SCORERS = {
    "classification": classification.score,
    "extraction": extraction.score,
    "validation": validation.score,
    "rag": rag.score,
    "agent": agent.score,
    "voice": voice.score,
}

