"""Data validation: does the AI catch bad records, and how often does it flag good ones?

expected: the truth for each record ("valid" or "invalid"; also accepted: ok/bad, pass/fail, true/false, 1/0).
output: the AI's verdict, in the same words. rules (optional): the rules engine's verdict, to see where AI and rules disagree.
"""
from __future__ import annotations

from ..common import limit_note, scored_rows, share

BAD = {"invalid", "bad", "fail", "failed", "reject", "rejected", "flag", "flagged", "false", "0", "no", "error"}
GOOD = {"valid", "ok", "good", "pass", "passed", "accept", "accepted", "true", "1", "yes", "clean"}


def verdict(v) -> str | None:
    s = "" if v is None else str(v).strip().casefold()
    return "bad" if s in BAD else "good" if s in GOOD else None


def score(rows: list[dict], mapping: dict | None = None) -> dict:
    rows = scored_rows(rows)
    bad = [r for r in rows if verdict(r["expected"]) == "bad"]
    good = [r for r in rows if verdict(r["expected"]) == "good"]
    unknown = len(rows) - len(bad) - len(good)
    caught = [r for r in bad if verdict(r["output"]) == "bad"]
    false_alarms = [r for r in good if verdict(r["output"]) == "bad"]
    failures = ([{"case_id": r["case_id"], "error": "bad record not caught"} for r in bad if r not in caught]
                + [{"case_id": r["case_id"], "error": "good record flagged"} for r in false_alarms])
    out = {
        "type": "validation", "n": len(bad) + len(good),
        "bad_records": len(bad), "caught": len(caught), "catch_rate": share(len(caught), len(bad)),
        "good_records": len(good), "false_alarms": len(false_alarms), "false_alarm_rate": share(len(false_alarms), len(good)),
        "failures": failures,
        "notes": [limit_note(len(caught), len(bad), "bad records caught"),
                  limit_note(len(false_alarms), len(good), "good records flagged by mistake")],
    }
    if unknown:
        out["notes"].append(f"{unknown} row(s) have an expected verdict this tool does not know: left out. Use valid or invalid.")
    with_rules = [r for r in rows if r.get("rules") not in (None, "") and verdict(r["rules"]) and verdict(r["output"])]
    if with_rules:
        dis = [r for r in with_rules if verdict(r["rules"]) != verdict(r["output"])]
        right_ai = sum(1 for r in dis if verdict(r["output"]) == verdict(r["expected"]))
        out["rules_vs_ai"] = {"compared": len(with_rules), "disagree": len(dis), "ai_right_when_they_disagree": right_ai,
                              "rules_right_when_they_disagree": len(dis) - right_ai}
    return out
