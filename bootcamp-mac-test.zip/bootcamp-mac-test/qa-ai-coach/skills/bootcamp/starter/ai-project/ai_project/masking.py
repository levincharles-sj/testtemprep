"""Personal-data check for exported files (India's DPDP Act; client contracts).

A file is refused when it holds unmasked emails, Indian phone numbers, Aadhaar-like 12-digit numbers or PAN-like
codes. The check reports COUNTS per kind, never the values, so its output is safe to show or paste.

Allowed: emails at reserved test domains (example.com, example.org, example.net, *.test, *.example, *.invalid),
and values that are already masked (X or * in place of digits or letters, for example 98XXXXXX10 or a***@mail.com).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

EMAIL = re.compile(r"[A-Za-z0-9._%+*-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE = re.compile(r"(?<![\dXx*])(?:\+91[\s-]?|0)?[6-9][\dXx*]{4}[\s-]?[\dXx*]{5}(?![\dXx*])")
AADHAAR = re.compile(r"(?<![\dXx*])[2-9][\dXx*]{3}[\s-]?[\dXx*]{4}[\s-]?[\dXx*]{4}(?![\dXx*])")
PAN = re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")
RESERVED_EMAIL = re.compile(r"@(?:[\w.-]+\.)?(?:example\.(?:com|org|net)|[\w-]+\.(?:test|example|invalid|localhost))$", re.I)


def _masked(value: str) -> bool:
    return bool(re.search(r"[Xx*]{2,}", value))


@dataclass
class MaskReport:
    counts: dict = field(default_factory=lambda: {"email": 0, "phone": 0, "aadhaar_like": 0, "pan_like": 0})

    @property
    def ok(self) -> bool:
        return not any(self.counts.values())

    def message(self) -> str:
        if self.ok:
            return "No unmasked personal data found (emails, phone numbers, Aadhaar-like numbers, PAN-like codes)."
        found = ", ".join(f"{n} {k.replace('_', ' ')}" for k, n in self.counts.items() if n)
        return (f"Stopped: the file holds personal data that is not masked ({found}). "
                "Remove or mask those columns before you use the file (for example 98XXXXXX10, a***@mail.com), "
                "then run the check again. Values are not shown here on purpose.")


def scan_text(text: str, report: MaskReport | None = None) -> MaskReport:
    r = report or MaskReport()
    for m in EMAIL.finditer(text):
        v = m.group(0)
        if not RESERVED_EMAIL.search(v) and not _masked(v.split("@")[0]):
            r.counts["email"] += 1
    for m in PHONE.finditer(text):
        if not _masked(m.group(0)):
            r.counts["phone"] += 1
    for m in AADHAAR.finditer(text):
        digits = re.sub(r"\D", "", m.group(0))
        if not _masked(m.group(0)) and len(digits) == 12:
            r.counts["aadhaar_like"] += 1
    for _ in PAN.finditer(text):
        r.counts["pan_like"] += 1
    return r


def scan_rows(rows: list[dict]) -> MaskReport:
    r = MaskReport()
    for row in rows:
        for v in row.values():
            if v is None:
                continue
            scan_text(v if isinstance(v, str) else str(v), r)
    return r
