"""Chatbot or RAG assistant.

Answer correctness and faithfulness need a judge: this scorer writes results/rag-judge-input.jsonl (case id,
question, answer, expected answer, contexts) for the eval starter's seat judge (Claude on your own seat; the TL's
written agreement must cover sending this data to Claude). It does not judge by itself.

What it measures without a judge:
- empty answers and refusals ("I don't know", "cannot help");
- retrieval, when the export lists the sources the AI retrieved and the expected sources:
  hit rate (at least one right source), precision and recall of the retrieved sources.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..common import limit_note, scored_rows, share

REFUSAL = re.compile(r"\b(i (do not|don't) know|cannot help|can't help|not able to (help|answer)|no information)\b", re.I)


def _sources(v) -> set:
    if isinstance(v, list):
        return {str(x.get("source") if isinstance(x, dict) else x).strip() for x in v if x}
    if isinstance(v, str) and v.strip():
        return {s.strip() for s in re.split(r"[;|,]", v) if s.strip()}
    return set()


def score(rows: list[dict], mapping: dict | None = None, out_dir: str | Path = "results") -> dict:
    rows = scored_rows(rows)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    judge = out_dir / "rag-judge-input.jsonl"
    with judge.open("w", encoding="utf-8") as fh:
        for r in rows:
            exp = r["expected"]
            fh.write(json.dumps({
                "case_id": r["case_id"], "question": r.get("input"), "answer": r.get("output"),
                "expected": exp.get("answer") if isinstance(exp, dict) else exp,
                "contexts": r.get("contexts") if isinstance(r.get("contexts"), list) else ([r["contexts"]] if r.get("contexts") else []),
            }, ensure_ascii=False) + "\n")
    empty = [r for r in rows if not str(r.get("output") or "").strip()]
    refusals = [r for r in rows if REFUSAL.search(str(r.get("output") or ""))]
    out = {"type": "rag", "n": len(rows), "empty_answers": len(empty), "refusals": len(refusals),
           "judge_input": str(judge), "failures": [{"case_id": r["case_id"], "error": "empty answer"} for r in empty],
           "notes": ["Correctness and faithfulness: run the eval starter's judge on " + judge.name + ", then check 8 judge "
                     "results by hand before you trust the judge.",
                     f"{len(refusals)} of {len(rows)} answers are refusals: check whether each should have been one."]}
    with_src = [r for r in rows if isinstance(r["expected"], dict) and r["expected"].get("sources") and r.get("contexts")]
    if with_src:
        hits = tp = retrieved = relevant = 0
        for r in with_src:
            got, want = _sources(r["contexts"]), _sources(r["expected"]["sources"])
            hits += bool(got & want)
            tp += len(got & want)
            retrieved += len(got)
            relevant += len(want)
        out["retrieval"] = {"cases": len(with_src), "hit_rate": share(hits, len(with_src)),
                            "precision": share(tp, retrieved), "recall": share(tp, relevant)}
        out["notes"].append(limit_note(hits, len(with_src), "questions where at least one right source was retrieved"))
    return out
