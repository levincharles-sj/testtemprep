"""Reliability: the same input, run several times. Does the AI give the same, right answer every time?

Needs the same inputs run 3 or more times (a run id per repeat). For each case: how many runs were right (pass rate),
whether all runs agreed, and whether it "passes sometimes" (right in some runs, wrong in others: in production that
is an incident waiting to happen). With one output per input, reliability cannot be measured: the result says so
instead of giving a number.
"""
from __future__ import annotations

from .common import limit_note, scored_rows, share
from .normalize import norm_text
from .scorers import agent, extraction, voice
from .scorers.validation import verdict


def _correct(kind: str, r: dict):
    if kind == "classification":
        return norm_text(r["output"]) == norm_text(r["expected"])
    if kind == "validation":
        return verdict(r["output"]) is not None and verdict(r["output"]) == verdict(r["expected"])
    if kind == "extraction":
        return extraction.score([r]).get("documents_all_right") == 1
    if kind == "agent":
        return agent.score([r]).get("task_completion") == 1.0
    if kind == "voice":
        s = voice.score([r])
        return (s["slot_accuracy"] in (None, 1.0)) and s["wer"] in (0, 0.0, None)
    return None  # rag: correctness needs the judge


def _answer_key(r: dict) -> str:
    v = r["output"]
    return norm_text(v if isinstance(v, str) else repr(v)) or ""


def check(rows: list[dict], kind: str) -> dict:
    rows = scored_rows(rows, latest_run_only=False)
    cases: dict = {}
    for r in rows:
        cases.setdefault((r.get("build") or "all", r["case_id"]), []).append(r)
    most = max((len(v) for v in cases.values()), default=0)
    if most < 2:
        return {"type": "reliability", "measured": False, "runs_per_case": most,
                "notes": ["Reliability cannot be measured from one run per input. Ask for the same inputs run 3 times "
                          "(a run id on each repeat). Until then, the report states this limit."]}
    per_case, sometimes, always, never, agree = [], [], 0, 0, 0
    for (build, cid), runs in sorted(cases.items()):
        oks = [_correct(kind, r) for r in runs]
        same = len({_answer_key(r) for r in runs}) == 1
        agree += same
        row = {"build": build, "case_id": cid, "runs": len(runs), "agree": same}
        if None not in oks:
            k = sum(oks)
            row.update(passed=k, pass_rate=share(k, len(runs)))
            if k == len(runs):
                always += 1
            elif k == 0:
                never += 1
            else:
                sometimes.append(cid)
        per_case.append(row)
    n = len(cases)
    notes = [limit_note(agree, n, "cases gave the same answer on every run")]
    if kind == "rag":
        notes.append("Right or wrong per run needs the judge; this shows only whether the answers stayed the same.")
    else:
        notes.append(limit_note(always, n, "cases right on every run"))
        if sometimes:
            notes.append(f"Passes sometimes: {len(sometimes)} case(s). Right in some runs and wrong in others: treat each as a production risk.")
    few = [c for c in per_case if c["runs"] < 3]
    if few:
        notes.append(f"{len(few)} case(s) have fewer than 3 runs: their pass rates are very rough.")
    return {"type": "reliability", "measured": True, "cases": n, "runs_per_case": most, "always_right": always,
            "never_right": never, "passes_sometimes": sometimes, "all_runs_agree": agree,
            "agreement_rate": share(agree, n), "per_case": per_case, "notes": notes}
