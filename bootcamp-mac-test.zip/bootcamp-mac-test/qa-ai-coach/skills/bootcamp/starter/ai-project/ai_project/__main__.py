"""Command line: python -m ai_project <check|score|reliability|report> [--data FILE --mapping mapping.json] [--results DIR]

Output lines (for the coach): AIP_OK ..., AIP_WARN ..., AIP_ERROR <plain reason>, AIP_RESULT <file>. Never prints client text.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import reliability, report
from .load import LoadError, load
from .scorers import SCORERS


def main(argv=None) -> int:
    try:  # Windows consoles default to a code page that cannot print ₹
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(prog="python -m ai_project")
    ap.add_argument("command", choices=["check", "score", "reliability", "report"])
    ap.add_argument("--data")
    ap.add_argument("--mapping", default="mapping.json")
    ap.add_argument("--results", default="results")
    a = ap.parse_args(argv)
    out = Path(a.results)
    if a.command == "report":
        print(f"AIP_RESULT {report.write(out)}")
        return 0
    if not a.data:
        print("AIP_ERROR give the export file: --data <file>")
        return 2
    try:
        ds = load(a.data, a.mapping)
    except LoadError as e:
        print(f"AIP_ERROR {e}")
        return 1
    for w in ds.warnings:
        print(f"AIP_WARN {w}")
    if a.command == "check":
        print(f"AIP_OK {len(ds.rows)} rows, type {ds.type}, up to {ds.runs_per_case} run(s) per case. {ds.mask.message()}")
        return 0
    out.mkdir(parents=True, exist_ok=True)
    if a.command == "score":
        kwargs = {"out_dir": out} if ds.type == "rag" else {}
        result = SCORERS[ds.type](ds.rows, ds.mapping, **kwargs)
        name = "score.json"
    else:
        result = reliability.check(ds.rows, ds.type)
        name = "reliability.json"
    (out / name).write_text(json.dumps(result, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    for n in result.get("notes", []):
        print(f"AIP_OK {n}")
    print(f"AIP_RESULT {out / name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
