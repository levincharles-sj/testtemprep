"""Load an exported file (CSV, JSON or JSONL) with a column mapping, check it, and return clean rows.

mapping.json (example; only "type", "columns.case_id", "columns.output" and "columns.expected" are required):
{
  "type": "classification",              # classification | extraction | validation | rag | agent | voice
  "columns": {
    "case_id": "ticket_id",              # one id per input (the same id on every run of the same input)
    "input": "email_text",
    "output": "ai_category",             # what the AI said
    "expected": "true_category",         # the right answer (checked by a person)
    "run_id": "run",                     # optional: 1, 2, 3 for repeated runs of the same input
    "build": "build",                    # optional: the AI build or version (for comparing two builds)
    "score": "confidence",               # optional (classification): the AI's confidence, 0 to 1
    "group": "channel",                  # optional: results per group (for example customer type)
    "contexts": "retrieved_chunks",      # optional (rag): what the AI looked at
    "rules": "rules_verdict"             # optional (validation): the rules engine's verdict
  },
  "fields": {"invoice_date": "date", "total": "amount", "vendor": "name"}   # optional (extraction): field types
}
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path

from .masking import MaskReport, scan_rows

TYPES = {"classification", "extraction", "validation", "rag", "agent", "voice"}
REQUIRED = ("case_id", "output", "expected")


class LoadError(Exception):
    """A problem with the export or the mapping, in plain English."""


@dataclass
class Dataset:
    type: str
    rows: list[dict]          # each row: case_id, output, expected, and the optional keys that were mapped
    mapping: dict
    mask: MaskReport
    warnings: list[str]

    @property
    def runs_per_case(self) -> int:
        counts: dict = {}
        for r in self.rows:
            counts[(r.get("build"), r["case_id"])] = counts.get((r.get("build"), r["case_id"]), 0) + 1
        return max(counts.values()) if counts else 0


def read_mapping(path: str | Path) -> dict:
    try:
        m = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        raise LoadError(f"The mapping file {path} was not found.") from None
    except json.JSONDecodeError as e:
        raise LoadError(f"The mapping file is not valid JSON (line {e.lineno}): check commas and quotes.") from None
    return validate_mapping(m)


def validate_mapping(m: dict) -> dict:
    if not isinstance(m, dict):
        raise LoadError("mapping.json must be one JSON object.")
    if m.get("type") not in TYPES:
        raise LoadError(f'mapping.json "type" must be one of: {", ".join(sorted(TYPES))}.')
    cols = m.get("columns") or {}
    missing = [k for k in REQUIRED if not cols.get(k)]
    if missing:
        raise LoadError(f'mapping.json "columns" needs: {", ".join(missing)}.')
    return m


def _read_raw(path: Path) -> list[dict]:
    if not path.exists():
        raise LoadError(f"The export {path} was not found.")
    text = path.read_text(encoding="utf-8-sig")
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return list(csv.DictReader(text.splitlines()))
    if suffix == ".jsonl":
        rows = []
        for i, line in enumerate(text.splitlines(), 1):
            if line.strip():
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    raise LoadError(f"Line {i} of {path.name} is not valid JSON.") from None
        return rows
    if suffix == ".json":
        data = json.loads(text)
        if isinstance(data, dict):
            data = data.get("rows") or data.get("data") or []
        if not isinstance(data, list):
            raise LoadError(f"{path.name} must hold a list of records.")
        return data
    raise LoadError(f"{path.name}: use a .csv, .json or .jsonl export.")


def _maybe_json(v):
    if isinstance(v, str) and v.strip()[:1] in "{[":
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            return v
    return v


def load(data_path: str | Path, mapping: dict | str | Path) -> Dataset:
    """Read, map, validate and mask-check an export. Raises LoadError with a plain reason."""
    m = validate_mapping(mapping) if isinstance(mapping, dict) else read_mapping(mapping)
    cols = m["columns"]
    raw = _read_raw(Path(data_path))
    if not raw:
        raise LoadError("The export has no rows.")
    mask = scan_rows(raw)
    if not mask.ok:
        raise LoadError(mask.message())
    present = set().union(*(r.keys() for r in raw))
    absent = [f"{k} → '{c}'" for k, c in cols.items() if c and c not in present]
    if absent:
        raise LoadError(f"These mapped columns are not in the export: {', '.join(absent)}. Check the column names in mapping.json.")
    rows, warnings, seen, empty = [], [], set(), 0
    for i, r in enumerate(raw, 1):
        row = {k: _maybe_json(r.get(c)) for k, c in cols.items() if c}
        row["case_id"] = str(row["case_id"]).strip()
        if not row["case_id"]:
            raise LoadError(f"Row {i} has no case id.")
        for k in ("run_id", "build"):
            if k in row and row[k] is not None:
                row[k] = str(row[k]).strip()
        key = (row.get("build"), row["case_id"], row.get("run_id"))
        if key in seen:
            raise LoadError(f"Case {row['case_id']} appears twice for the same run and build (row {i}). Give each repeat a run id.")
        seen.add(key)
        if row["output"] in (None, "", [], {}):
            empty += 1
        rows.append(row)
    if empty:
        warnings.append(f"{empty} row(s) have an empty AI output. They count as wrong, not as skipped.")
    no_expected = sum(1 for r in rows if r["expected"] in (None, ""))
    if no_expected:
        warnings.append(f"{no_expected} row(s) have no expected answer. They are left out of the scores.")
    return Dataset(type=m["type"], rows=rows, mapping=m, mask=mask, warnings=warnings)
