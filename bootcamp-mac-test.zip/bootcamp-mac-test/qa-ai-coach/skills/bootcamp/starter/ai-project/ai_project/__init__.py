"""AI-project track (QA AI bootcamps, weeks 2 and 3): evaluate your project's own AI offline.

You export real inputs and the AI's outputs from the TEST environment (personal data removed), describe the
columns in mapping.json, and these tools score them. Nothing here calls your client's AI.

    python -m ai_project check  --data export.csv --mapping mapping.json
    python -m ai_project score  --data export.csv --mapping mapping.json
    python -m ai_project reliability --data export.csv --mapping mapping.json
    python -m ai_project report
"""

__all__ = ["load", "masking", "reliability", "report", "scorers"]
