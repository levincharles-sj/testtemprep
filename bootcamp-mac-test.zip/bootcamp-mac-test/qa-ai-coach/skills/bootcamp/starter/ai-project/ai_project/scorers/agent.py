"""An agent that takes actions: right tools, right arguments, right end state, from exported traces.

output (what the agent did), one JSON object per case:
  {"tool_calls": [{"tool": "issue_refund", "args": {"order_id": "ORD-1", "amount": 300}}], "end_state": {"refund_status": "issued"}}
expected (what it should do):
  {"tools": [{"tool": "lookup_order", "args": {"order_id": "ORD-1"}}, {"tool": "issue_refund", "args": {"amount": 300}}],
   "forbidden_tools": ["handoff"], "ordered": true, "end_state": {"refund_status": "issued"}}
Expected args are a SUBSET: only the arguments that matter are checked (amounts and dates are normalised).
"""
from __future__ import annotations

from ..common import limit_note, scored_rows, share
from ..normalize import NORMALISERS, guess_kind


def _same(field: str, e, g) -> bool:
    if e == g or str(e).strip() == str(g).strip():
        return True
    norm = NORMALISERS[guess_kind(field)]
    return norm(e) is not None and norm(e) == norm(g)


def _args_ok(expected: dict, got: dict) -> bool:
    return all(k in got and _same(k, v, got[k]) for k, v in (expected or {}).items())


def _in_order(expected: list, calls: list) -> bool:
    i = 0
    for c in calls:
        if i < len(expected) and c.get("tool") == expected[i].get("tool"):
            i += 1
    return i == len(expected)


def score(rows: list[dict], mapping: dict | None = None) -> dict:
    rows = [r for r in scored_rows(rows) if isinstance(r["expected"], dict)]
    tools_ok = args_ok = order_ok = state_ok = state_n = task_ok = forbidden_hits = 0
    failures = []
    for r in rows:
        exp, got = r["expected"], r["output"] if isinstance(r["output"], dict) else {}
        calls = got.get("tool_calls") or []
        want = exp.get("tools") or []
        called = {c.get("tool") for c in calls}
        t_ok = all(w.get("tool") in called for w in want)
        a_ok = all(any(c.get("tool") == w.get("tool") and _args_ok(w.get("args"), c.get("args") or {}) for c in calls) for w in want)
        o_ok = _in_order(want, calls) if exp.get("ordered") else True
        bad = sorted(called & set(exp.get("forbidden_tools") or []))
        s_ok = True
        if exp.get("end_state"):
            state_n += 1
            s_ok = all(_same(k, v, (got.get("end_state") or {}).get(k)) for k, v in exp["end_state"].items())
            state_ok += s_ok
        tools_ok += t_ok
        args_ok += a_ok
        order_ok += o_ok
        forbidden_hits += bool(bad)
        ok = t_ok and a_ok and o_ok and s_ok and not bad
        task_ok += ok
        if not ok:
            why = [w for w, f in (("missing tool", not t_ok), ("wrong arguments", not a_ok), ("wrong order", not o_ok),
                                   ("wrong end state", not s_ok), ("forbidden tool used", bool(bad))) if f]
            failures.append({"case_id": r["case_id"], "errors": why})
    n = len(rows)
    return {"type": "agent", "n": n, "tool_correctness": share(tools_ok, n), "argument_correctness": share(args_ok, n),
            "order_correctness": share(order_ok, n), "end_state_correctness": share(state_ok, state_n),
            "forbidden_tool_cases": forbidden_hits, "task_completion": share(task_ok, n), "failures": failures,
            "notes": [limit_note(task_ok, n, "tasks done fully right (tools, arguments, order, end state, nothing forbidden)"),
                      "A forbidden tool (for example a refund above the limit instead of a hand-off) is a policy failure even when the reply reads well."]}
