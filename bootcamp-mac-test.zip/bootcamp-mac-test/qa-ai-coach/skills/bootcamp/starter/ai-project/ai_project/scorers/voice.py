"""Voice agent, offline: word error rate (WER) between what was said (expected transcript) and what the system heard
(output transcript), and slot accuracy (the details the call must capture: name, date, order number...).

Rows: expected and output are either plain transcripts, or objects {"transcript": "...", "slots": {"date": "..."}}.
WER uses the jiwer package when it is installed (pip install jiwer); otherwise the same word-level count is computed
here, and the result says so. Text is compared in lower case without punctuation.
"""
from __future__ import annotations

import re

from ..common import limit_note, scored_rows, share
from ..normalize import NORMALISERS, guess_kind

try:  # optional
    import jiwer  # type: ignore
except ImportError:  # pragma: no cover - depends on the laptop
    jiwer = None


def _words(t) -> list[str]:
    return re.sub(r"[^\w\s]", " ", str(t or "").casefold()).split()


def _edits(ref: list[str], hyp: list[str]) -> int:
    prev = list(range(len(hyp) + 1))
    for i, r in enumerate(ref, 1):
        cur = [i] + [0] * len(hyp)
        for j, h in enumerate(hyp, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (r != h))
        prev = cur
    return prev[-1]


def _parts(v):
    if isinstance(v, dict):
        return v.get("transcript"), v.get("slots") or {}
    return v, {}


def score(rows: list[dict], mapping: dict | None = None) -> dict:
    rows = scored_rows(rows)
    errors = words = slot_n = slot_ok = 0
    failures, refs, hyps = [], [], []
    for r in rows:
        (et, es), (gt, gs) = _parts(r["expected"]), _parts(r["output"])
        ref, hyp = _words(et), _words(gt)
        refs.append(" ".join(ref))
        hyps.append(" ".join(hyp))
        errors += _edits(ref, hyp)
        words += len(ref)
        for k, v in es.items():
            slot_n += 1
            g = gs.get(k)
            norm = NORMALISERS[guess_kind(k)]
            good = g is not None and (str(v).strip().casefold() == str(g).strip().casefold() or (norm(v) is not None and norm(v) == norm(g)))
            slot_ok += good
            if not good:
                failures.append({"case_id": r["case_id"], "slot": k, "error": "missing" if g is None else "wrong value"})
    if jiwer is not None and words:
        wer, how = round(float(jiwer.wer(refs, hyps)), 4), "jiwer"
    else:
        wer, how = (round(errors / words, 4) if words else None), "built-in word count (jiwer not installed)"
    return {"type": "voice", "n": len(rows), "wer": wer, "wer_method": how, "reference_words": words,
            "slot_accuracy": share(slot_ok, slot_n), "slots_checked": slot_n, "failures": failures,
            "notes": [f"Word error rate {wer} over {words} words in {len(rows)} calls ({how}). Lower is better; 0.10 means about 1 word in 10 is wrong.",
                      limit_note(slot_ok, slot_n, "details captured right"),
                      "Recorded test calls only: never customer recordings."]}
