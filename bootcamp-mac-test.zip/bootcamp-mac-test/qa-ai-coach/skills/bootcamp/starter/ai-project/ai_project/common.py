"""Small helpers shared by the scorers and the report."""
from __future__ import annotations

ROUGH = 30  # below this many cases, a share is a rough signal, not a rate


def scored_rows(rows: list[dict], *, latest_run_only: bool = True) -> list[dict]:
    """Rows with an expected answer. With repeated runs, the scorers use run 1 of each case and build;
    reliability.py looks at all runs."""
    rows = [r for r in rows if r.get("expected") not in (None, "")]
    if not latest_run_only:
        return rows
    first: dict = {}
    for r in rows:
        key = (r.get("build"), r["case_id"])
        if key not in first or str(r.get("run_id") or "") < str(first[key].get("run_id") or ""):
            first[key] = r
    return list(first.values())


def by_build(rows: list[dict]) -> dict:
    out: dict = {}
    for r in rows:
        out.setdefault(r.get("build") or "all", []).append(r)
    return out


def share(k: int, n: int) -> float | None:
    return round(k / n, 4) if n else None


def limit_note(k: int, n: int, what: str = "correct") -> str:
    """'11 of 12 correct; with 12 samples this is a rough signal, not a rate.'"""
    if n == 0:
        return f"No cases with an expected answer: nothing to score."
    if n < ROUGH:
        return f"{k} of {n} {what}; with {n} samples this is a rough signal, not a rate."
    return f"{k} of {n} {what} ({k / n:.0%})."


def prf(tp: int, fp: int, fn: int) -> dict:
    p = tp / (tp + fp) if tp + fp else None
    r = tp / (tp + fn) if tp + fn else None
    f = 2 * p * r / (p + r) if p and r else (0.0 if p is not None and r is not None else None)
    rnd = lambda x: None if x is None else round(x, 4)
    return {"precision": rnd(p), "recall": rnd(r), "f1": rnd(f), "support": tp + fn}
