"""Normalising values before comparing them: Indian date and amount formats, names, plain text.

Dates are read day-first (Indian style): 05/12/2026 is 5 December 2026. An ISO date (2026-12-05) is read as written.
Amounts accept ₹, Rs, Rs., INR, Indian commas (1,23,456), "/-", lakh and crore.
"""
from __future__ import annotations

import re
from datetime import date
from decimal import Decimal, InvalidOperation

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


def _year(y: str) -> int:
    n = int(y)
    return n + 2000 if n < 100 else n


def norm_date(value) -> str | None:
    """Return YYYY-MM-DD, or None when the text is not a date this reader knows."""
    if value is None:
        return None
    s = str(value).strip().lower().replace(",", " ")
    s = re.sub(r"(\d)(st|nd|rd|th)\b", r"\1", s)
    s = re.sub(r"\s+", " ", s)
    try:
        m = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s)
        if m:
            return date(int(m[1]), int(m[2]), int(m[3])).isoformat()
        m = re.fullmatch(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2}|\d{4})", s)
        if m:
            return date(_year(m[3]), int(m[2]), int(m[1])).isoformat()
        m = re.fullmatch(r"(\d{1,2})[- ]([a-z]{3})[a-z]*[- ](\d{2}|\d{4})", s)
        if m and m[2] in MONTHS:
            return date(_year(m[3]), MONTHS[m[2]], int(m[1])).isoformat()
        m = re.fullmatch(r"([a-z]{3})[a-z]* (\d{1,2}) (\d{4})", s)
        if m and m[1] in MONTHS:
            return date(int(m[3]), MONTHS[m[1]], int(m[2])).isoformat()
    except ValueError:
        return None
    return None


def norm_amount(value) -> Decimal | None:
    """Return the amount as a Decimal in rupees, or None."""
    if value is None:
        return None
    if isinstance(value, (int, float, Decimal)):
        return Decimal(str(value))
    s = str(value).strip().lower()
    s = re.sub(r"₹|/-|\binr\b|\brs\b\.?", " ", s)
    mult = Decimal(1)
    if re.search(r"\b(lakh|lakhs|lac|lacs)\b", s):
        mult, s = Decimal(100000), re.sub(r"\b(lakh|lakhs|lac|lacs)\b", " ", s)
    elif re.search(r"\b(crore|crores|cr)\b", s):
        mult, s = Decimal(10000000), re.sub(r"\b(crore|crores|cr)\b", " ", s)
    s = s.replace(",", "").strip()
    if not re.fullmatch(r"-?\d+(\.\d+)?", s):
        return None
    try:
        return (Decimal(s) * mult).normalize()
    except InvalidOperation:
        return None


def norm_name(value) -> str | None:
    if value is None:
        return None
    s = re.sub(r"[.,]", " ", str(value)).casefold()
    s = re.sub(r"\b(mr|mrs|ms|dr|shri|smt|m/s)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip() or None


def norm_text(value) -> str | None:
    if value is None:
        return None
    s = re.sub(r"\s+", " ", str(value)).strip().casefold()
    return s or None


NORMALISERS = {"date": norm_date, "amount": norm_amount, "name": norm_name, "text": norm_text}


def guess_kind(field: str) -> str:
    f = field.lower()
    if "date" in f or f.endswith("_on") or f in {"dob", "due", "expiry"}:
        return "date"
    if any(w in f for w in ("amount", "total", "price", "tax", "gst", "fee", "balance")):
        return "amount"
    if "name" in f or f in {"vendor", "customer", "payee"}:
        return "name"
    return "text"
