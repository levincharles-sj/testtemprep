"""Write results/ai-project-summary.md from the saved results (results/score.json, results/reliability.json).

Only numbers, sample sizes, case ids and the plain-English limits go in: never inputs, outputs or other client text.
"""
from __future__ import annotations

import json
from pathlib import Path

TITLES = {"classification": "Classification", "extraction": "Extraction", "validation": "Data validation",
          "rag": "Chatbot or RAG assistant", "agent": "Agent actions", "voice": "Voice agent"}


def _pct(v) -> str:
    return "n/a" if v is None else f"{v:.0%}"


def _metrics(s: dict) -> list[str]:
    t = s.get("type")
    out = []
    if t == "classification":
        out.append(f"- Accuracy: {_pct(s['accuracy'])} ({s['correct']} of {s['n']}); macro F1: {s.get('macro_f1')}")
        out += [f"- {c}: precision {m['precision']}, recall {m['recall']}, F1 {m['f1']} (support {m['support']})" for c, m in s["per_class"].items()]
        for t_ in s.get("thresholds", []):
            out.append(f"- At confidence ≥ {t_['threshold']}: answers {t_['answered']} ({_pct(t_['coverage'])}), accuracy {_pct(t_['accuracy'])}")
        for g, m in (s.get("per_group") or {}).items():
            out.append(f"- Group {g}: {m['correct']} of {m['n']} ({_pct(m['accuracy'])})")
    elif t == "extraction":
        out.append(f"- Documents with every field right: {s['documents_all_right']} of {s['n']}")
        for f, m in s["fields"].items():
            out.append(f"- {f} ({m['kind']}): exact {_pct(m['exact_accuracy'])}, normalised {_pct(m['normalised_accuracy'])}, "
                       f"missing {m['missing']}, invented {m['invented']}, wrong {m['wrong']} (of {m['n']})")
    elif t == "validation":
        out.append(f"- Catch rate: {s['caught']} of {s['bad_records']} bad records ({_pct(s['catch_rate'])})")
        out.append(f"- False alarms: {s['false_alarms']} of {s['good_records']} good records ({_pct(s['false_alarm_rate'])})")
        if s.get("rules_vs_ai"):
            r = s["rules_vs_ai"]
            out.append(f"- Rules vs AI: {r['disagree']} disagreements in {r['compared']}; AI right in {r['ai_right_when_they_disagree']}")
    elif t == "rag":
        out.append(f"- Empty answers: {s['empty_answers']}; refusals: {s['refusals']} (of {s['n']})")
        if s.get("retrieval"):
            r = s["retrieval"]
            out.append(f"- Retrieval: hit rate {_pct(r['hit_rate'])}, precision {_pct(r['precision'])}, recall {_pct(r['recall'])} ({r['cases']} questions)")
        out.append(f"- Correctness and faithfulness: judge input written to `{Path(s['judge_input']).name}`")
    elif t == "agent":
        out.append(f"- Task completion: {_pct(s['task_completion'])}; tools {_pct(s['tool_correctness'])}; arguments "
                   f"{_pct(s['argument_correctness'])}; order {_pct(s['order_correctness'])}; end state {_pct(s['end_state_correctness'])}")
        out.append(f"- Cases with a forbidden tool: {s['forbidden_tool_cases']}")
    elif t == "voice":
        out.append(f"- Word error rate: {s['wer']} over {s['reference_words']} words ({s['wer_method']})")
        out.append(f"- Slot accuracy: {_pct(s['slot_accuracy'])} of {s['slots_checked']} details")
    return out


def write(results_dir: str | Path = "results") -> Path:
    d = Path(results_dir)
    score = json.loads((d / "score.json").read_text(encoding="utf-8")) if (d / "score.json").exists() else None
    rel = json.loads((d / "reliability.json").read_text(encoding="utf-8")) if (d / "reliability.json").exists() else None
    lines = ["# AI project evaluation: summary", "",
             "Offline evaluation of exported inputs and outputs from the test environment. Case ids only; no client text.", ""]
    if score:
        lines += [f"## {TITLES.get(score['type'], score['type'])}: {score['n']} cases", ""] + _metrics(score) + [""]
        lines += ["**Limits:**"] + [f"- {n}" for n in score.get("notes", [])] + [""]
        if score.get("failures"):
            ids = sorted({f["case_id"] for f in score["failures"]})
            lines += [f"**Cases to look at ({len(ids)}):** " + ", ".join(ids[:40]) + (" …" if len(ids) > 40 else ""), ""]
    lines += ["## Reliability", ""]
    if rel and rel.get("measured"):
        lines += [f"- {rel['cases']} cases, up to {rel['runs_per_case']} runs each",
                  f"- Same answer on every run: {rel['all_runs_agree']} of {rel['cases']}"]
        if "always_right" in rel:
            lines.append(f"- Right on every run: {rel['always_right']}; never right: {rel['never_right']}; "
                         f"passes sometimes: {len(rel['passes_sometimes'])}" + (f" ({', '.join(rel['passes_sometimes'][:20])})" if rel['passes_sometimes'] else ""))
    lines += [f"- {n}" for n in (rel or {"notes": ["Not run yet: python -m ai_project reliability ..."]}).get("notes", [])]
    out = d / "ai-project-summary.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out
