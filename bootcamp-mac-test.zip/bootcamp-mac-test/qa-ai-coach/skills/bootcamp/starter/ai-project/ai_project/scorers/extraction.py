"""Extraction from documents: field by field, exact match and normalised match (Indian dates and amounts, names,
spacing and case), and the two errors that matter most: a MISSING field (the document has it, the AI gave nothing)
and an INVENTED field (the AI gave a value the document does not have).

Each row's output and expected are JSON objects of fields, for example {"invoice_no": "INV-0042", "total": "₹1,250"}.
Field kinds come from mapping.json "fields" ({"total": "amount"}), or are guessed from the field name.
"""
from __future__ import annotations

from ..common import limit_note, scored_rows, share
from ..normalize import NORMALISERS, guess_kind


def _empty(v) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


def _as_dict(v) -> dict:
    return v if isinstance(v, dict) else {}


def score(rows: list[dict], mapping: dict | None = None) -> dict:
    rows = scored_rows(rows)
    kinds = dict((mapping or {}).get("fields") or {})
    fields: dict = {}
    docs_all_right, failures, bad_rows = 0, [], 0
    for r in rows:
        exp, got = _as_dict(r["expected"]), _as_dict(r["output"])
        if not isinstance(r["expected"], dict):
            bad_rows += 1
            continue
        all_right = True
        for f in sorted(set(exp) | set(got)):
            kind = kinds.get(f) or guess_kind(f)
            norm = NORMALISERS.get(kind, NORMALISERS["text"])
            s = fields.setdefault(f, {"kind": kind, "n": 0, "exact": 0, "normalised": 0, "missing": 0, "invented": 0, "wrong": 0})
            e, g = exp.get(f), got.get(f)
            if _empty(e) and _empty(g):
                continue
            if _empty(e):
                s["invented"] += 1
                all_right = False
                failures.append({"case_id": r["case_id"], "field": f, "error": "invented"})
                continue
            s["n"] += 1
            if _empty(g):
                s["missing"] += 1
                all_right = False
                failures.append({"case_id": r["case_id"], "field": f, "error": "missing"})
            elif str(e).strip() == str(g).strip():
                s["exact"] += 1
                s["normalised"] += 1
            elif norm(e) is not None and norm(e) == norm(g):
                s["normalised"] += 1
            else:
                s["wrong"] += 1
                all_right = False
                failures.append({"case_id": r["case_id"], "field": f, "error": "wrong value"})
        docs_all_right += all_right
    for s in fields.values():
        s["exact_accuracy"] = share(s["exact"], s["n"])
        s["normalised_accuracy"] = share(s["normalised"], s["n"])
    n = len(rows) - bad_rows
    notes = [limit_note(docs_all_right, n, "documents with every field right"),
             "Normalised match counts '05/12/2026' and '5 Dec 2026', or '₹1,23,456' and '1.23 lakh', as the same value. "
             "Report both: exact match matters when another system reads the value as text."]
    if bad_rows:
        notes.append(f"{bad_rows} row(s) have an expected value that is not a set of fields: left out. Check the export.")
    return {"type": "extraction", "n": n, "documents_all_right": docs_all_right, "fields": fields,
            "failures": failures, "notes": notes}
