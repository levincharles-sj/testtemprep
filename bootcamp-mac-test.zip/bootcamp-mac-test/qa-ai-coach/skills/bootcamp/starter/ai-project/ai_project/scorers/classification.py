"""Classification or sorting: precision, recall and F1 per class, a confusion matrix, accuracy at confidence
thresholds (when the export has the AI's confidence), and results per group (when a group column is mapped)."""
from __future__ import annotations

from ..common import limit_note, prf, scored_rows, share

THRESHOLDS = (0.5, 0.6, 0.7, 0.8, 0.9)


def _label(v) -> str:
    return "" if v is None else str(v).strip().casefold()


def score(rows: list[dict], mapping: dict | None = None) -> dict:
    rows = scored_rows(rows)
    n = len(rows)
    labels = sorted({_label(r["expected"]) for r in rows} | {_label(r["output"]) for r in rows} - {""})
    matrix = {e: {o: 0 for o in labels + ["(empty)"]} for e in labels}
    correct, failures = 0, []
    for r in rows:
        e, o = _label(r["expected"]), _label(r["output"]) or "(empty)"
        matrix[e][o] += 1
        if e == o:
            correct += 1
        else:
            failures.append({"case_id": r["case_id"], "expected": e, "got": o})
    per_class = {}
    for c in labels:
        tp = matrix.get(c, {}).get(c, 0)
        fp = sum(matrix[e].get(c, 0) for e in matrix if e != c)
        fn = sum(v for o, v in matrix.get(c, {}).items() if o != c)
        per_class[c] = prf(tp, fp, fn)
    f1s = [m["f1"] for m in per_class.values() if m["f1"] is not None]
    out = {
        "type": "classification", "n": n, "correct": correct, "accuracy": share(correct, n),
        "macro_f1": round(sum(f1s) / len(f1s), 4) if f1s else None,
        "per_class": per_class, "confusion_matrix": matrix,
        "failures": failures, "notes": [limit_note(correct, n)],
    }
    if any(r.get("score") not in (None, "") for r in rows):
        table = []
        for t in THRESHOLDS:
            kept = [r for r in rows if r.get("score") not in (None, "") and float(r["score"]) >= t]
            ok = sum(1 for r in kept if _label(r["expected"]) == _label(r["output"]))
            table.append({"threshold": t, "answered": len(kept), "coverage": share(len(kept), n), "accuracy": share(ok, len(kept))})
        out["thresholds"] = table
        out["notes"].append("Thresholds: below the threshold the AI's answer is treated as 'send to a person'. Higher thresholds trade coverage for accuracy.")
    if any(r.get("group") not in (None, "") for r in rows):
        groups: dict = {}
        for r in rows:
            g = str(r.get("group") or "(none)")
            k, m = groups.get(g, (0, 0))
            groups[g] = (k + (_label(r["expected"]) == _label(r["output"])), m + 1)
        out["per_group"] = {g: {"correct": k, "n": m, "accuracy": share(k, m)} for g, (k, m) in sorted(groups.items())}
        out["notes"].append("Per group: a big gap between groups can be a fairness problem; small groups are rough signals.")
    return out
