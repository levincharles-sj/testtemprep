# AI project track: evaluate your project's own AI (offline)

This folder is for testers whose project has its own AI (weeks 2 and 3 of the QA AI bootcamps). You evaluate the
AI **from exported data**: real inputs and the AI's real outputs from the **test environment**, with personal data
removed. Nothing here calls your client's AI, so it costs the client nothing and needs no new access.

## Before you start (the rules)
1. **Your TL agrees in writing** that the exported data may be used, and may be sent to Claude (including Claude as the judge in week 2).
2. **Test environment only.** Never production data.
3. **No personal data.** Remove or mask names, emails, phone numbers, Aadhaar and PAN numbers, addresses. The `check` step refuses a file that still has emails, phone numbers, Aadhaar-like or PAN-like values (it shows counts, never the values).
4. **Stays on your laptop** (or the project's private storage). Never in a public repository, never on the Saturday screen. Results show case ids and numbers only.
5. **Paid AI services:** offline evaluation of exported outputs is the default. Live calls only within a budget your TL agrees.

## What to ask your project for
- 20 to 50 inputs with the AI's outputs, and the **right answer** for each (checked by a person).
- If you can: the **same inputs run 3 times** (for reliability) and outputs from **two builds** (for regression).
- One row per input and run. Columns can have any names: you describe them in `mapping.json`.

## Three steps
In the WORK window terminal, in your `evals` folder (Windows: `.venv\Scripts\python`; Mac: `.venv/bin/python`):

```
python -m ai_project check --data exports/my-export.csv --mapping mapping.json
python -m ai_project score --data exports/my-export.csv --mapping mapping.json
python -m ai_project reliability --data exports/my-export.csv --mapping mapping.json
python -m ai_project report
```
The summary is `results/ai-project-summary.md`: numbers, sample sizes and honest limits, with case ids only.

## mapping.json
```json
{
  "type": "classification",
  "columns": {"case_id": "ticket_id", "input": "email_text", "output": "ai_category", "expected": "true_category",
              "run_id": "run", "build": "build", "score": "confidence", "group": "channel"}
}
```
`type` is one of: `classification`, `extraction`, `validation`, `rag`, `agent`, `voice`. Required columns: `case_id`,
`output`, `expected`. The `samples/` folder has a working example for each type (fake data).

| Your AI does | type | What you get |
|---|---|---|
| Sorting or classifying | classification | Precision, recall and F1 per class, confusion matrix, accuracy at confidence thresholds, results per group |
| Pulling data out of documents | extraction | Per field: exact and normalised match (Indian dates and amounts), missing and invented fields |
| Checking data | validation | Catch rate on bad records, false alarms on good records, rules vs AI |
| Chatbot or RAG | rag | Empty answers, refusals, retrieval hit rate; a judge input file for correctness and faithfulness |
| An agent that takes actions | agent | Tool, argument, order and end-state correctness; forbidden tools; task completion |
| Voice | voice | Word error rate on transcripts (`pip install jiwer` for the standard tool), slot accuracy |

**Small samples are honest samples:** with 12 cases the summary says "11 of 12 correct; with 12 samples this is a
rough signal, not a rate". With one run per input it says reliability cannot be measured. Put these limits in your report.
