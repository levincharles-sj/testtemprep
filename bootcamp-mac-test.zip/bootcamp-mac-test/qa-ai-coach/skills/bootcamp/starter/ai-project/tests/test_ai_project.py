"""Tests for the AI-project track tools. Run from the ai-project folder: python -m pytest tests -q"""
from __future__ import annotations

import json
import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ai_project import reliability, report  # noqa: E402
from ai_project.load import LoadError, load  # noqa: E402
from ai_project.masking import scan_text  # noqa: E402
from ai_project.normalize import norm_amount, norm_date, norm_name  # noqa: E402
from ai_project.scorers import SCORERS  # noqa: E402

S = ROOT / "samples"


def sample(kind):
    data = next((S / kind).glob("export.*"))
    return load(data, S / kind / "mapping.json")


# ---------- normalising ----------
@pytest.mark.parametrize("raw", ["05/12/2026", "5-12-2026", "05.12.2026", "2026-12-05", "5 Dec 2026", "05-Dec-26",
                                 "December 5, 2026", "5th December 2026", "05/12/26"])
def test_indian_dates_are_day_first(raw):
    assert norm_date(raw) == "2026-12-05"


def test_bad_dates_give_none():
    assert norm_date("31/02/2026") is None
    assert norm_date("next Tuesday") is None


@pytest.mark.parametrize("raw,value", [("₹1,23,456.50", "123456.5"), ("Rs. 1,50,000/-", "150000"), ("INR 980", "980"),
                                       ("1.5 lakh", "150000"), ("2 crore", "20000000"), ("12,000", "12000"),
                                       (2000, "2000"), ("rs 75", "75")])
def test_indian_amounts(raw, value):
    assert norm_amount(raw) == Decimal(value)


def test_amount_text_is_not_a_number():
    assert norm_amount("about two thousand") is None


def test_names_ignore_case_spacing_and_titles():
    assert norm_name("Mr. RAVI  Kumar") == norm_name("ravi kumar")


# ---------- masking ----------
def test_masking_refuses_personal_data_and_never_shows_it(tmp_path):
    bad = tmp_path / "x.csv"
    bad.write_text("id,text,out,exp\n1,mail ravi.k@gmail.com or call 9876543210,a,a\n2,Aadhaar 2345 6789 0123 PAN ABCDE1234F,a,a\n", encoding="utf-8")
    mapping = {"type": "classification", "columns": {"case_id": "id", "input": "text", "output": "out", "expected": "exp"}}
    with pytest.raises(LoadError) as e:
        load(bad, mapping)
    msg = str(e.value)
    assert "1 email" in msg and "1 phone" in msg and "1 aadhaar like" in msg and "1 pan like" in msg
    for v in ("ravi.k@gmail.com", "9876543210", "2345 6789 0123", "ABCDE1234F"):
        assert v not in msg


def test_masking_allows_reserved_and_masked_values():
    r = scan_text("a@example.com b@shop.test c***@gmail.com call 98XXXXXX10 Aadhaar XXXX XXXX 1234")
    assert r.ok, r.counts


# ---------- loading ----------
def test_load_errors_are_plain(tmp_path):
    f = tmp_path / "e.csv"
    f.write_text("id,out\n1,a\n", encoding="utf-8")
    with pytest.raises(LoadError, match="not in the export"):
        load(f, {"type": "classification", "columns": {"case_id": "id", "output": "out", "expected": "truth"}})
    with pytest.raises(LoadError, match="must be one of"):
        load(f, {"type": "sentiment", "columns": {"case_id": "id", "output": "out", "expected": "out"}})
    d = tmp_path / "d.csv"
    d.write_text("id,out,exp\n1,a,a\n1,b,a\n", encoding="utf-8")
    with pytest.raises(LoadError, match="appears twice"):
        load(d, {"type": "classification", "columns": {"case_id": "id", "output": "out", "expected": "exp"}})


def test_empty_outputs_warn(tmp_path):
    f = tmp_path / "w.csv"
    f.write_text("id,out,exp\n1,,a\n2,a,a\n", encoding="utf-8")
    ds = load(f, {"type": "classification", "columns": {"case_id": "id", "output": "out", "expected": "exp"}})
    assert any("empty AI output" in w for w in ds.warnings)


# ---------- scorers on the samples ----------
def test_classification_sample():
    ds = sample("classification")
    s = SCORERS["classification"](ds.rows, ds.mapping)
    assert (s["n"], s["correct"]) == (12, 11)
    assert s["failures"] == [{"case_id": "T-011", "expected": "address_change", "got": "delivery"}]
    assert s["per_class"]["address_change"]["recall"] == pytest.approx(2 / 3, abs=1e-3)
    assert "rough signal" in s["notes"][0]
    assert s["thresholds"] and s["per_group"]


def test_extraction_sample_counts_missing_invented_and_normalised():
    ds = sample("extraction")
    s = SCORERS["extraction"](ds.rows, ds.mapping)
    assert s["documents_all_right"] == 2
    assert s["fields"]["total"]["missing"] == 1
    assert s["fields"]["gstin"]["invented"] == 1
    assert s["fields"]["invoice_date"]["wrong"] == 1
    assert s["fields"]["total"]["normalised"] == 3 and s["fields"]["total"]["exact"] == 0


def test_validation_sample():
    ds = sample("validation")
    s = SCORERS["validation"](ds.rows, ds.mapping)
    assert (s["bad_records"], s["caught"], s["good_records"], s["false_alarms"]) == (3, 2, 3, 1)
    assert s["rules_vs_ai"]["disagree"] == 3


def test_rag_sample_writes_judge_input(tmp_path):
    ds = sample("rag")
    s = SCORERS["rag"](ds.rows, ds.mapping, out_dir=tmp_path)
    lines = (tmp_path / "rag-judge-input.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 3 and json.loads(lines[0])["case_id"] == "Q-01"
    assert s["refusals"] == 1
    assert s["retrieval"]["hit_rate"] == pytest.approx(2 / 3, abs=1e-3)


def test_agent_sample():
    ds = sample("agent")
    s = SCORERS["agent"](ds.rows, ds.mapping)
    assert s["task_completion"] == 0.5
    assert s["forbidden_tool_cases"] == 1
    assert s["failures"][0]["case_id"] == "A-02"


def test_voice_sample():
    ds = sample("voice")
    s = SCORERS["voice"](ds.rows, ds.mapping)
    assert s["wer"] == pytest.approx(1 / 18, abs=1e-3)
    assert s["slot_accuracy"] == 0.5


# ---------- reliability ----------
def test_reliability_finds_passes_sometimes():
    ds = sample("classification")
    r = reliability.check(ds.rows, "classification")
    assert r["measured"] and r["runs_per_case"] == 3
    assert r["passes_sometimes"] == ["T-007"]
    assert r["never_right"] == 1 and r["always_right"] == 10


def test_reliability_states_the_limit_with_one_run():
    ds = sample("validation")
    r = reliability.check(ds.rows, "validation")
    assert r["measured"] is False
    assert "cannot be measured from one run per input" in r["notes"][0]


# ---------- report and command line ----------
def test_report_has_numbers_and_no_client_text(tmp_path):
    ds = sample("classification")
    (tmp_path / "score.json").write_text(json.dumps(SCORERS["classification"](ds.rows, ds.mapping)), encoding="utf-8")
    (tmp_path / "reliability.json").write_text(json.dumps(reliability.check(ds.rows, "classification")), encoding="utf-8")
    md = report.write(tmp_path).read_text(encoding="utf-8")
    assert "11 of 12" in md and "T-011" in md and "T-007" in md
    for text in ("Where is my parcel", "return my money", "driver was rude"):
        assert text not in md


def test_cli_check_and_refusal(tmp_path):
    env = {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONIOENCODING": "utf-8", "SYSTEMROOT": __import__("os").environ.get("SYSTEMROOT", "")}
    ok = subprocess.run([sys.executable, "-m", "ai_project", "check", "--data", str(S / "classification" / "export.csv"),
                         "--mapping", str(S / "classification" / "mapping.json")], cwd=ROOT, capture_output=True, text=True, env=env)
    assert ok.returncode == 0 and ok.stdout.startswith("AIP_OK 36 rows")
    bad = tmp_path / "b.csv"
    bad.write_text("id,out,exp\n1,call 9876543210,a\n", encoding="utf-8")
    m = tmp_path / "m.json"
    m.write_text(json.dumps({"type": "classification", "columns": {"case_id": "id", "output": "out", "expected": "exp"}}), encoding="utf-8")
    no = subprocess.run([sys.executable, "-m", "ai_project", "check", "--data", str(bad), "--mapping", str(m)],
                        cwd=ROOT, capture_output=True, text=True, env=env)
    assert no.returncode == 1 and no.stdout.startswith("AIP_ERROR Stopped") and "9876543210" not in no.stdout
