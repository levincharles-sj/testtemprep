# The intake interview (all three weeks, once)

**When:** the first `/bootcamp` run, Monday 30 November first thing (or before). About 30 minutes; about 20 when the tester pastes their kick-off answers. Monday is 2 to 2.5 hours with the intake. Keep every message to about 12 lines of your own text.
**Why (say it in the first message, in your own short words):** "Waiting starts the moment you need something you did not ask for. So today we find everything the three weeks need, and you ask for it this morning. Then we start building."
**What it makes:** `intake.json`, `my-bootcamp-plan.html` (opens in the browser), drafted messages in `requests/`, and the first entries in `decisions.md`.

## How to run it
- Heading on every message: `## 📍 Intake · <section> · <n> of 5` with a bar of 5 blocks for the 5 sections: **You**, **Your app**, **Access and blockers**, **Weeks 2 and 3**, **Your plan**.
- **One question per message.** Each question has a one-line "why" and a short example answer (an example, not a format). Accept any form of answer. A missing piece: ask once, naturally.
- **The kick-off reply first.** Message 1 asks: "Did you answer the 8 questions in the kick-off message? If yes, paste your answers here. I take what I can from them and ask only what is missing." Use everything it answers, mark those questions as answered, and **never ask them again**. If they did not answer it: "No problem. We do it together now."
- **Roles, never names.** Save "the dev lead", "the DM", "DevOps", "the TL". If the tester types a person's name, use the role in the files. The project gets a **code name** the tester chooses (no client name if the project is under NDA; when unsure, use a code name).
- **"I do not know" is a fine answer.** Save it as `unknown`, add a readiness item, and move on.
- **Save as you go:** write `intake.json` (status `in-progress`) after each section, so a tester who stops can carry on. On return: "Welcome back. We were on <section>." and the next unanswered question.
- **Teach in the reaction:** when an answer creates a blocker or a request, say so in one line ("A captcha stops automated tests. We ask the dev lead for the test key. I add it to your requests.").
- **Never say "fallback" as a failure.** Conduit is the practice app: "You start on Conduit today. You switch to your app the moment access arrives."

## Section 1: You (2 questions)
1. **First name** (for your report; nothing else is stored): save to `bootcamp.json` `firstName` (keep the other fields).
2. **Laptop:** `plan.mjs --init` found it. Confirm: "Your laptop is Windows. Right?" (or Mac). Save `os` in `bootcamp.json` if they correct it.

## Section 2: Your app (week 1)
3. **Project code name** and **what the app does**, in one or two lines. Example: "Project Orion: a portal where clinics book lab tests and see results."
4. **What kind of app?** web app · mobile web · mobile app only · desktop app · backend only (APIs, no screens).
   - mobile app only or desktop app → "Playwright tests web pages. Week 1 then uses: the API (if there is one) on your project, and Conduit for the screens." Track: `conduit` for UI.
   - backend only → API smoke tests on the project, Conduit for any screens.
5. **The channel map**, one message each (teach first with the Conduit example: "In Conduit, people type in screens, and the result shows on a screen."):
   - 5a. How does work get **into** your app? (people type in screens · emails arrive · files are uploaded · another system calls its API · imports run on a schedule · calls · chat)
   - 5b. How do you **see the result**? (on a screen · an email the app sends · a record in another system · a file or report)
   - 5c. How long does it take? (instant · seconds · minutes · hours)
   Save to `project.channels`. Pick the matching recipes from `reference/recipes.md` (save their ids to `project.recipes`). Each recipe's "ask the dev team for" lines become readiness items and request lines.
6. **Existing automation** on the project? (none · Cypress · Selenium · Playwright · other) and where. If some: "We add the smoke tests in the same framework and style, if the dev lead prefers. I add this question to the dev lead's message."
7. **Where may the tests live?** in the project repository (own folder or branch) · on my laptop · not sure → readiness item "Repository permission" (owner: DM), default `laptop` until agreed.

## Section 3: Access and blockers (week 1)
8. **Test environment:** can you open a test or staging environment from your laptop? (yes · yes, with VPN · no · not sure). Never ask for the address in the chat; they type it into `.env` later.
9. **Test account:** do you have one for automation (not your personal login)? (yes · asked · no)
9b. **Roles:** how many user roles see different screens? (for example: 2, clinic user and admin)
10. **Login blockers:** does the test login have MFA or an OTP, a captcha, single sign-on only, or email or SMS verification? Each one becomes a readiness item with the ask from `reference/recipes.md` ("Login blockers"). Teach the three workarounds in one line each: a TOTP secret in `.env`, a captcha test key, or logging in by hand once and saving the session.
11. **API:** which fits your app? no API · an API without docs · an API with docs (Swagger, OpenAPI or Postman)
12. **AI tools on the project:** does the client allow them? Tip: "If your developers already use Claude, Copilot or Cursor on it, the answer is usually yes. If not sure, ask your DM." (yes · not sure · no) → no: week 1 runs on Conduit, recorded in `decisions.md`.
13. **Project context:** (only when question 12 is **yes**; otherwise say: "We wait for your DM's yes before Claude reads anything from your project" and add the readiness item `project-context` as open) which of these can you put in `project-context/` today? requirements or feature documents · existing test cases · a ticket export (CSV) · API docs. Rules, said once: stays on this laptop, never in git; remove customer names, emails and phone numbers from exports first; no passwords.
14. **Shared environment:** do developers or other testers use the same test environment? → yes: "Your tests will tag what they make and clean up."
14b. **Real data:** does the test environment show real customer data (real names, phone numbers)? → yes or not sure: readiness item "Anonymised data" (owner: DM); Claude does not explore pages with personal data until the DM answers.
15. **CI:** who looks after CI/CD (role), and which tool? (GitHub Actions · GitLab · Azure DevOps · Jenkins · none · not sure)

## Section 4: Weeks 2 and 3 (short)
16. **Is your project an AI project?** If yes: what does the AI do? (sort or classify · pull data out of documents · check data · chatbot or RAG · agent that takes actions · voice agent · other). If no: "Weeks 2 and 3 use our practice support agent. Nothing to ask your team." Skip to 20.
17. **Data for evals:** can the project export real inputs and the AI's outputs from the test environment, with personal data removed? About how many? Do they have known right answers? Say what week 2 needs: the same 20-50 inputs run 3 times, outputs from two builds if possible, masked data, and the TL's written agreement that the data may go to Claude (including the judge).
18. **Paid AI:** is the AI an external service that costs money per call (for example Google Document AI)? → yes: readiness item "Call budget" (owner: TL); offline evaluation of exported outputs is the default.
19. **Week 3 attacks:** attacks on the real AI need the **TL's written agreement**, the test environment only, and agreed limits. Who would agree (role)? Any client security rules? → default: practice agent for the attacks; a threat model and attack plan for their own AI as "On my project".
20. **Test data per week** (one message, teach first with `reference/test-data.md` in two lines): week 1 test accounts and data; week 2 data (AI project) or none; week 3 none. Save a one-line plan per week to `testData`.

## Section 5: Your plan (finish)
21. **Tracks, proposed and confirmed.** Propose each week's track with the reason, in 3 lines:
   - Week 1: `real` when environment, account, context and AI-tools permission are all yes; `conduit-for-now` when any is missing but asked (start on Conduit today, switch when access arrives, decision at end of Tuesday); `conduit` when the app is not testable or AI tools are not allowed.
   - Week 2: `ai-project` (data and TL agreement asked; decision at end of Monday 7 Dec) or `practice`.
   - Week 3: `ai-project` only with the TL's written agreement; else `practice`.
   Ask: "Is this right for you? Type **`yes`**, or tell me what to change." Save to `tracks` and write each choice to `decisions.md` (format in SKILL.md, "Decisions and blockers").
22. **Requests.** Draft every message now, **grouped by person**, in `requests/` (one file each, numbered): `01-dev-lead.md` (week 1 access, login blockers, enablers from the recipes, existing automation, journeys that break most), `02-dm.md` (AI-tools permission if unsure, where tests may live, the write list for tests that change data, anonymised data), `03-devops.md` (the CI questions: tool, what starts a deploy, can a smoke job run after deploy, where secrets live and who adds them, a test account for CI, can GitHub reach the test environment, who approves pipeline changes, where results go), `04-tl.md` (only for AI projects: data export, written agreement for evals and for attacks, call budget). Start from the templates in `reference/requests.md`. If the tester already forwarded the kick-off's dev lead request, `01-dev-lead.md` is a short follow-up that asks for a date. Each file: who it is for, the message in plain words (no passwords, no client data), and which readiness items it serves.
23. **Write `intake.json`** (status still `in-progress`; schema below) and run exactly `node "${CLAUDE_PLUGIN_ROOT}/scripts/bootcamp/plan-page.mjs" --open` from the workspace. `PLAN_PAGE <path> opened|ready`: "Your plan is open in the browser: `my-bootcamp-plan.html`. It updates every day." `PLAN_PAGE_ERROR <reason>`: fix the field it names in `intake.json`, run it again once, else say the plan will come at the end of the day.
24. **Send now, all of them** (decision P5: the DevOps CI questions too; answers are needed by Thursday). "Now we send the messages. Type `/bootcamp send-draft 1`." Go through each one (send-draft shows it; the tester sends it and types `sent`).
25. **A short summary for the programme manager.** Show it in a ```text block for the tester to send as their reply to the kick-off message. No names, no client data:
    ```
    Bootcamp plan, <first name>: week 1 <track>, week 2 <track>, week 3 <track>.
    Open blockers: <readiness items not ready, by role, or none>.
    Waiting on: <requests sent, by role>.
    ```
26. **Then:** set `intake.json` status to `done`. If `TODAY` is Monday 30 November or later: "Requests sent. Now we start building." and continue with W1D1, Part 1. Before Monday: "Your plan is ready and your requests are on their way. Week 1 starts on Monday 30 November: type `/bootcamp` then."

## `intake.json` schema
```json
{
  "version": 1,
  "status": "in-progress | done",
  "updatedAt": "2026-11-30T09:10:00+05:30",
  "answeredFromKickoff": [1, 2, 3],
  "project": {
    "codeName": "Orion", "about": "Clinic lab-test booking portal",
    "appType": "web | mobile-web | mobile-only | desktop | backend",
    "channels": { "in": ["screens"], "out": ["screen", "email"], "time": "instant | seconds | minutes | hours" },
    "recipes": ["forms-roles", "notifications-otp"],
    "existingAutomation": "none | cypress | selenium | playwright | other",
    "codeLocation": "project-repo | laptop | unknown",
    "environment": "yes | vpn | no | unknown",
    "account": "yes | asked | no",
    "roles": 2,
    "loginBlockers": ["mfa", "captcha", "sso", "verification"],
    "api": "docs | no-docs | none | unknown",
    "aiTools": "yes | unknown | no",
    "context": ["documents", "test-cases", "tickets", "api-docs"],
    "sharedEnvironment": true,
    "realDataSeen": false,
    "ci": { "owner": "DevOps", "tool": "github | gitlab | azure | jenkins | none | unknown" }
  },
  "aiProject": { "isAi": false, "type": null, "data": null, "groundTruth": null, "paidService": false, "attackAgreement": "none | asked | yes" },
  "testData": { "W1": "Test accounts per role; read-only checks on seeded records", "W2": "Practice agent data", "W3": "Practice agent data" },
  "tracks": {
    "W1": { "track": "real | conduit-for-now | conduit", "reason": "Account asked; start on Conduit, switch when it arrives" },
    "W2": { "track": "ai-project | practice", "reason": "..." },
    "W3": { "track": "ai-project | practice", "reason": "..." }
  },
  "readiness": [
    { "id": "test-account", "week": "W1", "item": "Test account for automation", "owner": "dev lead", "state": "ready | asked | open | blocked | not-needed", "neededBy": "2026-11-30", "since": "2026-11-30", "request": 1, "note": "" }
  ],
  "requests": [
    { "n": 1, "to": "dev lead", "file": "requests/01-dev-lead.md", "serves": ["test-account", "mfa"], "sentOn": null, "answer": null }
  ]
}
```
Readiness ids in use: `test-environment`, `test-account`, `roles`, `mfa`, `captcha`, `sso`, `verification`, `api-docs`, `ai-tools`, `project-context`, `repository`, `write-list`, `anonymised-data`, `ci-answers`, `ci-secrets`, `test-mailbox` and the other enablers from the recipes, `w2-data`, `w2-agreement`, `call-budget`, `w3-agreement`. `neededBy`: Monday 30 Nov for week 1 must-haves, Tuesday 1 Dec for blockers, Thursday 3 Dec for CI answers, Monday 7 Dec for week 2, Monday 14 Dec for week 3.

## Coach notes (for Claude only)
- The interview is long. Keep the pace: one line of why, one question, an example. Group nothing.
- Testers who answered the kick-off usually finish in about 20 minutes.
- A tester with no project, or on leave from their project: week 1 `conduit`, week 2 and 3 `practice`, no requests except to the DM (time agreement). Say it kindly: the method is the skill.
- Never promise what the dev team will do. Never draft a message that blames anyone.
- Worked example for the channel map and recipes: Conduit (screens in, screen out, instant; recipes `forms-roles`), and one more from `reference/recipes.md` ("email in") so the tester sees a different shape.
