# Test data: choosing it with the tester (from the plan, section 2c)

Teach it in two lines in the intake (question 20); use the rest when a tester's data question comes up.

Test data decides whether an eval means anything. The coach helps each tester choose, week by week, and records the choice and the reason in `decisions.md` and the plan.

**Questions the coach asks:**
1. What does the system need as input (screens, emails, documents, ID cards, audio, records)?
2. Will synthetic data work? It will not when the system checks against real-world rules or registries. Examples:
   - an ID scan that checks real ID formats, checksums or security features
   - an address check against a real postal database
   - a payment that needs real card networks (use the provider's test cards instead)
3. Does the project already have approved test data (a vendor's sample documents, a QA data set, test IDs from the provider)?
4. How much is there, and does each item have a known right answer (ground truth)?
5. What are the privacy rules (DPDP Act; Aadhaar copies must not be stored; client contract)?

**Options, in order of preference:**

| Option | When | Example |
|---|---|---|
| Synthetic data with known answers | Most UI, workflow, email and classification tests | Generated emails with expected category and fields |
| The provider's or vendor's sample data and test modes | External AI or payment services | Specimen documents from the vendor, test cards, sandbox accounts |
| The project's approved test data | The project already has a QA data set or test IDs | A set of test ID images the client approved for testing |
| Recorded inputs and outputs from the test environment, with personal data removed | Evaluating an AI without calling it again | Exported document-scan results with the ID numbers masked |
| A mock of the external AI, plus a small real sample | Testing the app's logic around the AI separately from the AI's accuracy | Mock "scan result" responses for error handling; 15 approved real samples for accuracy |
| Out of scope, with a reason | No lawful or approved data | Accuracy not tested; app-side handling tested; written in the report |

**When the data is limited (for example only 12 approved ID images):**
- **What it can still show:** functional and negative tests (blurred, cut-off, expired, wrong document type, glare) and the error handling.
- **Accuracy:** reported with an honest limit: "11 of 12 correct; with 12 samples this is a rough signal, not a rate".
- **Reuse:** the same samples are reused for regression between versions.
- **More data:** the report asks for more, if accuracy matters for go-live.
- **Never:** pad the set with made-up "real-looking" IDs, or use colleagues' personal documents.

**Data rules:**
- Test data stays on the laptop or the project's approved storage, never in git, and never in reports or on the Saturday screen.
- It is deleted or returned after the bootcamp, as the project requires.

**Paid AI services (for example Google Document AI, OpenAI, speech services):**
- Every call costs the client money.
- The coach asks the tester to agree a call budget with the TL first.
- Offline evaluation of recorded outputs is preferred, and repeat runs stay small.

