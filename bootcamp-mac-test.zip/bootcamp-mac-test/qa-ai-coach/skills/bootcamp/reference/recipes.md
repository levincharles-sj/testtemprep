# App-pattern recipes (coach reference)

Use: pick the recipes that match the tester's channel map (intake question 5). Each recipe says what to test, how, and what to **ask the dev team for**. The "ask" lines become readiness items and lines in the drafted requests. Claude builds anything a recipe needs in the WORK window, with the same safety rules (test environment only, read-only by default, run tags, clean-up, an allow-list of hosts and recipients). Kit pieces (email sender, inbox reader, data generator, poller, scorer, clean-up, environment guard) arrive with release R2 (Wednesday evening) for testers who need them.

| id | Pattern | Smoke test idea | Ask the dev team for |
|---|---|---|---|
| `forms-roles` | Screens, forms and workflows with roles | Each role signs in and reaches its main pages; a key list shows records; a form opens and validates; the UI reaches the confirm step (no submit unless on the write list) | A test account per role; which roles see what; a way to reset test data |
| `email-in` | Emails arrive and the app sorts, flags, extracts or fills a form | Read-only first: the inbox or queue page loads, processed items show with category and fields. With a write list: send 5-10 generated emails with known answers to the test inbound address, poll until processed, check category and fields, clean up by run tag | The test inbound address; a test sender mailbox (SMTP or Microsoft Graph); the expected processing time; read access to the results (UI, API or a read-only database view) |
| `documents` | Files or scans are uploaded and data is pulled out | The upload page loads and lists allowed types; earlier results open. With a write list: upload 3 generated documents with known fields, check the extracted fields | Upload limits and formats; where results appear; approved sample documents (never real ID documents) |
| `api-in` | Another system calls the app's API or sends webhooks | API smoke: health or version, login gives a token, 2-3 key GET calls return the right shape and status, one error case (401 or 404) | API docs (OpenAPI, Swagger or Postman); test API keys; rate limits |
| `imports` | Scheduled imports (CSV, Excel, SFTP, cloud storage) | The import history page loads; the last run shows counts and the error report | Job trigger or schedule; access to the drop location in test; a sample file |
| `notifications-otp` | The app sends emails or SMS (confirmations, alerts, OTP codes) | Read-only: the notification settings page loads. With a write list: trigger one event, read the test inbox, check the content and the link | A test mailbox; an SMS sandbox; fixed OTP codes on test |
| `integrations` | Payments, CRM or other providers | The page that starts the provider flow loads and reaches the provider's sandbox page | Sandbox accounts and test keys; test cards |
| `reports` | Reports and dashboards | Known seed data shows the right totals; filters change the numbers as expected | Seed data or a read-only database view |
| `time-rules` | SLAs, reminders, expiry | The page that shows due dates loads with the right state for seeded items | A configurable timer or a way to move the clock in test |
| `chatbot` | A chatbot or RAG assistant (week 2 topic) | Week 1: the chat page loads and answers a fixed greeting; real evaluation is week 2 | Test chat access; the knowledge source list |
| `agent` | An AI agent that takes actions (week 2-3 topic) | Week 1: the page that starts the agent loads; nothing that makes it act | Logs or traces of actions; a sandbox for side effects |
| `voice` | Phone or voice calls | Week 1: any web admin pages only | A test number or an upload path for audio; call logs |

## Login blockers (every app)

| Blocker | Workaround in the tests | Ask the dev team for |
|---|---|---|
| MFA or OTP by an authenticator app | The login step makes the 6-digit code from `TEST_TOTP_SECRET` in `.env` (the starter's helper) | The TOTP secret of the test account, or a test account without MFA, or a fixed test OTP |
| Captcha | The starter sends `CAPTCHA_TEST_KEY` from `.env` as a header when the dev team gives a test key | Captcha off on the test environment, or the provider's test keys |
| Single sign-on only | Log in by hand once and save the session: `npm run login:manual`, then `AUTH=manual` in `.env`. Refresh it when it expires | A local test login, or a test identity on the SSO test tenant |
| Email or SMS verification | Pre-verified test accounts | Pre-verified accounts, a fixed code, or a sandbox inbox |
| VPN or IP allow-list | Tests run on the laptop with the VPN on; CI stays at level 1 (plan) with the network question | The CI runner's address allowed, or "CI must run inside the network" |
| Rate limits or bot protection | Fewer runs; no parallel workers against it | A bypass for the test account on the test environment |

**Never:** solve a captcha with AI, type a real person's OTP, or switch off a security control on a shared environment without the dev lead's agreement.

## Worked example for testers (Conduit)
Channel map: people type in screens → results show on screens → instant. Recipe `forms-roles`. Two roles: member and moderator. Smoke ideas: each role signs in and reaches its main pages; the global feed lists articles with page links; an article opens with its comments; the moderator sees reported comments; a member is refused the moderation page; the API lists tags and articles; a wrong token gets 401. Ask the dev team for: a test account per role (done: smoke-member and smoke-moderator), and a way to reset data (`/bootcamp app reset`).
