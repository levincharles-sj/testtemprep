# Jetrix (read-only, off by default)

- **Exports first.** Most testers never need Jetrix: ticket exports (CSV), documents and API docs in `project-context/` are the default.
- **When Jetrix helps:** open issues, dependencies or upcoming milestones that the exports do not show, to find risks and smoke candidates.
- **Ask first, every time it is switched on:** "Your project is in Jetrix. I can read its status report, issues and milestones. I can only read, never change anything. Shall I? If not, an export is fine." Only after **yes**: `bootcamp.json` `jetrix` = `{"mode": "read", "project": "<name the tester gave>"}`. `/bootcamp jetrix off` sets `{"mode": "off"}`.
- **What it can read:** projects the tester can already see; a project's status report (health, issues, dependencies, action items, milestone progress); milestones; sprints; lists. It cannot read individual tasks or tickets (descriptions, acceptance criteria): those still come from exports.
- **Read-only in three layers:** the coach's tool guard allows only read tools while Jetrix is on and denies every create, update, delete, complete, bulk-update, health-update and `assess_intent` tool always; Jetrix's own permissions; and the rule that you never ask for a write.
- **One project only.** Never copy Jetrix content into reports word for word. Never name people from it.
- **Testers in another Claude organisation** do not have the connector: exports only.
