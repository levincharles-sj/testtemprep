# Real situations and what the coach does (from the playbook, section 4)

Source of truth: docs/uplift/bootcamp/build-and-run-playbook.md section 4 (copied here for the coach; keep the two the same).

| Situation | What the coach does |
|---|---|
| **No project context shared** (documents, test cases, ticket exports) | On Monday the coach asks for it once more and says why: "Without your project's documents I can only guess, and your tests will be weaker." If nothing arrives by the end of Monday, it suggests the fallback app. A tester can switch back on Tuesday if the context arrives |
| A ticket export holds customer names, emails or phone numbers | The coach asks the tester to remove those columns and save it again before it reads further. Reports never name people from the export |
| No test environment or account by Monday | Moves the tester to the fallback app at once, so they lose nothing. Adds a note for the report: "I asked X; access pending". Switches to the real app if access arrives by Tuesday |
| Login has MFA, OTP or a captcha | Should already be flagged: the tester forwarded the dev lead request (kick-off) or sent the drafted request on Monday morning. The readiness board (`/bootcamp status`) shows its state. If the dev team gave a TOTP secret, Claude's login step generates the code from `.env`. If nothing is solved yet: the tester logs in by hand once, Claude saves the session, and the smoke tests start after login. The report states the limit. Still blocked at the end of Tuesday, or the dev team's date is later: practice app, recorded in the decision log |
| A tester on Conduit wants to practise MFA or a captcha | The coach turns on Conduit's TOTP or captcha switch and teaches the workaround: the TOTP secret in `.env` and a code generated at run time, or the test bypass |
| Any other automation blocker (SSO only, email or SMS verification, IP allow-list, rate limits, no test data) | The blocker request covers it. The coach tracks it as "open" in `app-profile.md` and gives the workaround for each (section 3.4 of the plan) |
| The app needs a VPN | Tests run on the laptop with the VPN on. CI goes to level 1 with the network question in the CI plan |
| The test environment is down or very slow | Moves to planning, the app map and the CI plan, and retries later. "The environment was down twice this week" is a real smoke finding, and goes in the report |
| The test environment shows real client data | Stops exploration. The tester asks the DM whether the data is anonymised. If not, Claude does not explore pages with personal data; the tester describes those pages instead |
| The client does not allow AI tools on the project | Fallback app for week 1; the report shows the approach. This must be known on Monday (decision D-11) |
| Claude writes a test that passes but checks nothing | The "break it on purpose" check catches it. The coach shows the weak check side by side with a strong one and asks the tester to direct Claude to fix it. It goes in the journal as an AI mistake caught |
| Claude invents a page, a button or a feature | The tester runs the test in the TESTS terminal with `--headed` once, or reads the page in the trace. The coach asks "did you see this on screen?" and has the tester correct Claude with the app map |
| Flaky tests | `--repeat-each=3` plus one run with several workers, then the healer. The healer may change locators and waits only; a change to an expected value is rejected. The coach explains each healer change in plain words. The tester accepts or rejects it. No retries that hide a real fault |
| The tester accepts everything Claude says | Checkpoints need the tester's own decision with a reason. If the tester has caught no AI mistake by Wednesday, the coach runs a "find the flaw" step on their own tests (a weak check, a missing negative case, a hard-coded value) |
| The tester asks the coach to just do it | The coach declines kindly and gives the prompt pattern to use in the WORK window |
| The tester pastes a password, token or key | The guard stops the message. If one got through anyway, the coach runs the secret-slipped steps |
| The tester is far behind on Thursday | The must-have path only. The coach tells them what Saturday needs and helps them get there |
| A senior tester is bored | Go further: Delivery OS `/qa:audit` and `/qa:setup` on the project repo, more journeys, a contract test, or reviewing a buddy's plan |
| Claude Code usage limit reached | Long runs go in the background with a smaller model as the judge. The coach moves to tasks that need less Claude (reading results, planning, writing the report) |
| Claude or the network is down | Saturday is not affected. The coach gives the day's offline work (planning, the report, the CI questions) |
| The project lead agrees to the tests in the repo | Work on a branch; the tester never pushes to main. Claude drafts a pull request description for the dev lead's review. The CI job starts as non-blocking |
| A tester finds a real bug in the project app | Logged through the project's own bug process. The report mentions it in general terms, without client data |
| A planted fault does not show up for a tester (weeks 2–3) | Never say a fault exists. The tester reports what the evidence shows. A clean, well-evidenced result is a valid finding |
| Judge scores jump between runs | This is part of the lesson: repeat runs, the judge checked against human scores, thresholds with a margin |
| A tester is absent on Saturday | Saturday is the deadline: the PM decides; there are no late recordings |
| **The project already has test automation** (Cypress, Selenium, an older Playwright suite) | The coach asks the dev lead's preference on Monday. Default: build the smoke pack inside the existing framework and follow its conventions, with Claude writing code in the same style. If the team does not want that, use a separate Playwright folder. Never duplicate or break their suite |
| The project repo has code rules (lint, review, commit format) | Claude follows them. The tester runs the repo's own lint before asking for review. The coach reminds: the dev lead reviews before merge |
| Mac tester, Windows instructions (or the opposite) | The coach uses the laptop type saved in `bootcamp.json` by the first run (`plan.mjs --init`). If unknown, it asks once: "Windows or Mac?" |
| AI project, but no test environment or permission | Practice track for that week; the "On my project" part plans evals for their real AI in general terms |
| AI project with a voice agent | Offline: recorded test calls (no customer recordings), word error rate and slot accuracy, response times from logs. Live calls only with the TL's agreement |
| AI project where calling the AI costs the client money | Offline evaluation of exported inputs and outputs by default; live calls only within limits the TL agrees |
| An AI-project tester's real findings are sensitive | The report gives findings in general terms. Details go only to the project team through their normal process. No client names on the Saturday screen if the project is under NDA (use a code name) |
| Week 3 attack on a real client AI without written agreement | The coach stops the attack steps and switches to the practice agent. No exceptions |
| A tester's project changes, or they go on leave mid-week | They keep their work, switch to the fallback or practice target, and present what they have on Saturday; the PM decides on fairness |
| The coach update fails mid-week | The daily two-command update line; if a new version breaks something, the previous version is restored the same day (each release is tagged). From Thu 17 Dec the coach is frozen: no releases; the cover person uses the fallbacks |
| The tester is nervous about presenting in English | `/bootcamp rehearse` twice; the report template carries the structure; showing the run counts as much as speaking. Feedback after Saturday is private |
| Saturday: a report will not open, a laptop fails, or the call drops | Each tester posts `report.html` in the meeting chat at the start, as a backup; the host can open it. A presenter who drops rejoins at the end of the round |
| A presenter runs over 5 minutes | The host gives a 1-minute warning; at 6 minutes the host moves on; questions go to the chat |
| A reviewer asks something the tester cannot answer | Fine: "I will check and come back" is a valid answer; it goes in the feedback, not as a fail |
| Leadership asks for numbers at the end of a Saturday | The PM has a one-page summary drafted on Saturday morning from the testers' replies and the rubric sheet |

