# Keeping credentials safe (coach reference; taught on Monday, used every day)

**The rule:** passwords, tokens, keys and TOTP secrets live only in `.env` on the laptop and in the CI tool's secret store. Claude only ever sees their **names**, never their values.

| Where | How it is kept safe |
|---|---|
| `.env` | The tester types the values in VS Code. `.env` is in `.gitignore`. `.env.example` (committed) lists the names with no values |
| Test code | Reads `process.env.TEST_PASSWORD`; `playwright.config.ts` loads `.env` with Node's own `process.loadEnvFile` |
| Claude Code | The starter's `.claude/settings.json` denies reading `.env`. The coach's guard stops a message or a tool call that holds a secret, and any tool that names `.env` |
| Claude exploring the app | The saved login (`playwright/.auth/user.json`) opens the app signed in. If a login page appears anyway, the tester logs in by hand in that window. Claude never types a password |
| Login in tests | `tests/auth.setup.ts` logs in once from `.env` and saves the session to `playwright/.auth/` (git-ignored) |
| API tests | Get a fresh token at run time by calling the login API with the `.env` values. A token is never pasted anywhere |
| Reports and traces | `test-results/`, `playwright-report/` and `last-run/` are git-ignored. Traces can hold typed values: never share them. `report.html` shows no tokens, passwords or client data |
| Before every commit | `npm run check-secrets` |
| CI (Friday) | Values go in the CI tool's secret store; the workflow uses names only |
| Test account | A dedicated automation account with the lowest access that runs the smoke tests; never a person's own login; never production |

**CI secret stores, by tool:**
- GitHub Actions: repository secrets (Settings → Secrets and variables → Actions), used as `${{ secrets.TEST_PASSWORD }}` and passed in as environment variables.
- GitLab CI: CI/CD variables, masked and protected.
- Azure Pipelines: secret variables or a variable group (marked secret).
- Jenkins: Credentials, used with `withCredentials`.
- In every tool: logs never print a secret. If the tester cannot add secrets, they ask the CI owner, and the CI plan names who adds them.

**What the guard does and does not do (say it honestly if asked):** it stops a message before it reaches Claude, but the text stays in this laptop's message history; it stops Claude's tools from reading `.env` or using a value, but it is not a wall against every possible command. The habits matter more: values only in `.env`, names everywhere else.

## If a secret slips out
(pasted into a chat, committed, shown in a report or on screen)
1. Tell the account owner (the dev lead or whoever gave it) today.
2. Change the password, or revoke the token or key.
3. Remove it from the files. If it was committed: remove it from the git history too (the dev lead helps; never force-push a shared branch without them).
4. Note it in the journal and in `decisions.md`, without the value.

A secret that has been seen is a secret to change. Say it without blame: "This happens. Changing it today makes it safe again."
