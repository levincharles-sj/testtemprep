# Locked-down laptops (coach reference for `/bootcamp check` IT lines)

| Problem | What the tester can try first | When IT is needed |
|---|---|---|
| No admin rights to install Node.js | Windows: the Node.js "Windows Installer (.msi)" can still need admin; ask IT, or use the "Standalone Binary (.zip)" unzipped into a folder in your user folder and added to your user PATH. Mac: the nodejs.org installer needs an admin password; ask IT | Always, if the tester cannot add Node 22 to their PATH |
| Company proxy | Ask IT for the proxy address. Then `npm config set proxy http://<proxy>:<port>` and `npm config set https-proxy http://<proxy>:<port>`; Playwright uses `HTTPS_PROXY` when downloading browsers | When the proxy needs a login or is unknown |
| SSL inspection (errors with "certificate", "SELF_SIGNED", "UNABLE_TO_VERIFY") | Ask IT for the company root certificate file (.pem or .crt). Set `NODE_EXTRA_CA_CERTS` to its path (Windows: in System → Environment variables, for your user; Mac: in `~/.zshrc`) and open a new terminal | Always: the certificate comes from IT |
| Antivirus blocks the browser download or start | Try once more; note the antivirus message | When the message names a blocked file in `ms-playwright` |
| Not enough disk space (under 3 GB) | Empty the recycle bin; delete old downloads | When the laptop has no more space to free |

**IT request (ready to copy):**
```
Hello IT team,

I am in the Techjays QA AI bootcamp from 30 November. I need these tools working on my laptop for test automation:
- Node.js 22 LTS (from nodejs.org), npm and git
- Playwright's Chromium browser download (from playwright.azureedge.net and cdn.playwright.dev)
- npm packages from registry.npmjs.org
[The check found: PROBLEM]
Could you help today? If there is a company proxy or root certificate, please send me the settings for npm and Node.js.

Thank you,
[YOUR NAME]
```

**Still blocked:** a buddy's laptop for the day, and the IT request stays open. The tester does the planning steps (app profile, smoke picks, the CI questions) meanwhile.
