# Request templates (coach reference for the intake's drafted messages)

Rules for every drafted message:
- Plain, polite, short. One message per person. Numbered asks. A date: "by end of Tuesday 1 December" for week 1 blockers, "by Thursday 3 December" for CI answers, "by Friday 4 December" for week 2 data.
- Roles in the files ("the dev lead"); the tester adds the person's name when they send it. Put `[NAME]` where the name goes.
- Never a password, token or client data in a message. Ask for secrets to be shared through the project's password manager.
- Include only the asks that apply to this tester (from the intake and the recipes). Each ask names the readiness item it serves (for `intake.json`).
- If the tester already forwarded the kick-off dev lead request, `01-dev-lead.md` is a follow-up: "Thank you for looking at my request on Friday. Could you tell me when you expect …?"

## 01 Dev lead (week 1 access and blockers)
```
Hello [NAME],

From Monday 30 November I am building automated smoke tests for [APP] in the QA AI bootcamp, with Claude Code and Playwright. They run only on the test environment, never on production, and by default they only read data.

Could you tell me by end of Tuesday 1 December which of these you can give me, and when?
1. [test-account] A test account for automation (not a person's login)[, one per role: ROLES].
2. [mfa/captcha/sso/verification] A way past the login check on the test environment: [the matching line from the recipes' "Login blockers"].
3. [api-docs] The API docs (OpenAPI, Swagger or Postman), if there is an API.
4. [enablers] [the "ask the dev team for" lines of the tester's recipes].
5. Which user journeys break most often?
6. [existing automation] Should I add the smoke tests to the existing [FRAMEWORK] tests, in the same style?

Please share passwords and secrets through the project's password manager, not in chat or email.

Thank you,
[YOUR NAME]
```

## 02 DM (permissions)
```
Hello [NAME],

This week I am in the QA AI bootcamp: I build automated smoke tests for [APP] with Claude Code, 2 to 2.5 hours a day. Could you confirm by end of Tuesday 1 December:
1. [ai-tools] The client allows AI tools on this project (the developers use [TOOL], so I think yes).
2. [repository] I may keep the tests in the project repository, in their own folder on a branch, reviewed by the dev lead. If not, they stay on my laptop.
3. [write-list] By default the tests only read. These tests would change data on the test environment, and I would clean up after them: [LIST, or "none"]. Is that OK?
4. [anonymised-data] The test environment shows customer-like data. Is it anonymised test data?

Thank you,
[YOUR NAME]
```

## 03 DevOps or CI owner (CI questions)
```
Hello [NAME],

I am building a small automated smoke test pack for [APP] (Playwright, read-only, test environment only). On Friday I plan how it runs in CI. Could you answer these by Thursday 3 December?
1. Which CI tool does the project use, and what starts a deploy to the test environment?
2. Could a smoke job run after each deploy to the test environment?
3. Where do secrets live, and who can add the smoke tests' secrets (a test account's password) to the CI secret store?
4. Is there an account for automation, not a person's own login?
5. Can GitHub (or the CI runners) reach the test environment, or must CI run inside the network?
6. Who approves pipeline changes, and where should results go (chat, email)?

Thank you,
[YOUR NAME]
```

## 04 TL (AI project only, weeks 2 and 3)
```
Hello [NAME],

In the QA AI bootcamp, week 2 (7-11 December) is about evaluating AI features, and week 3 (14-18 December) about their security. I would like to use our [AI FEATURE] if you agree. Could you tell me by Friday 4 December:
1. [w2-data] Can we export 20-50 real inputs and the AI's outputs from the test environment, with personal data removed? Ideally the same inputs run 3 times, and from two builds.
2. [w2-agreement] Do you agree in writing that this masked data may be sent to Claude (including Claude as the judge), on my own Claude seat?
3. [call-budget] (Paid AI service only) A call budget, if I need to call the service live on the test environment.
4. [w3-agreement] For week 3: do you agree in writing to hand-made attack tests (prompt injection, data leaks) on the test environment only, within limits you set? Without this I use our practice agent, which is fine.

Thank you,
[YOUR NAME]
```
