# AI project track (coach reference, weeks 2 and 3)

**Who:** testers whose project has its own AI, with the TL's written agreement and usable data. Everyone else uses the
practice support agent. Same rubric and readiness criteria for both tracks (plan §4); AI-project work is noted as
real-project evidence for January staffing.

**Default: offline.** The tester evaluates exported inputs and outputs from the test environment with the tools in
`evals/ai_project/` (starter `ai-project/`). No calls to the client's AI unless the TL agrees, in writing, with a budget.

## Decision point (end of Monday 7 December)
AI-project track only if **all** are true; otherwise the practice agent, recorded in `decisions.md`:
1. The TL's written agreement (see the checklist below) is in hand.
2. An export exists with at least 20 inputs, the AI's outputs and a checked right answer for each.
3. The export passes `python -m ai_project check` (no unmasked personal data).
The tester can still write "On my project": an eval plan for their AI in general terms.

## TL agreement checklist (the tester asks for each line, in one message; drafted in `requests/04-tl.md`)
- The data may be exported from the **test environment** and used for evaluation in the bootcamp.
- The masked data may be **sent to Claude**, including Claude as the **judge** (week 2).
- What must be removed or masked first (names, emails, phones, Aadhaar, PAN, addresses, account numbers, free-text notes).
- Where the data may be kept (the tester's laptop or the project's private storage), and when it is deleted or returned.
- Live calls to the AI: allowed or not; if allowed, the environment, a call budget and limits (rate, times of day).
- Week 3 only: attack tests on the AI: allowed or not, on the test environment only, within limits the TL sets.
No written agreement → no client data, no live calls, no attacks. No exceptions.

## Per AI type: what to ask for, which metrics, how to say the limits
| AI type | Ask the project for | Metrics (tool output) | Typical limits wording |
|---|---|---|---|
| Classification or sorting | Inputs, AI label, true label; confidence if the AI gives one; a group column (customer type, channel) if fairness matters | Precision, recall, F1 per class; macro F1; confusion matrix; accuracy and coverage at thresholds; per group | "11 of 12 correct; with 12 samples this is a rough signal, not a rate." Classes with under 5 examples: "too few to judge" |
| Extraction from documents | The extracted fields and the true fields per document (JSON); field types (date, amount, name) | Per field: exact and normalised accuracy, missing, invented, wrong; documents with every field right | "Normalised match treats '05/12/2026' and '5 Dec 2026' as the same date. Exact match matters when another system reads the text." |
| Data validation | Records with the AI's verdict and the true verdict (valid or invalid); the rules engine's verdict if there is one | Catch rate on bad records, false-alarm rate on good records, rules vs AI disagreements | State both numbers: a high catch rate with many false alarms still costs people time |
| Chatbot or RAG | Questions, answers, expected answers; the sources the AI retrieved and the right sources, if the export has them | Empty answers, refusals, retrieval hit rate, precision, recall; correctness and faithfulness by the seat judge (week 2 eval starter) on `results/rag-judge-input.jsonl` | "Judge scores were checked by hand on 8 cases; agreement was N of 8." |
| Agent that takes actions | Traces: tool calls with arguments and the end state; the expected tools, key arguments, forbidden tools and end state | Tool, argument, order and end-state correctness; forbidden-tool cases; task completion | A forbidden tool is a policy failure even when the reply reads well |
| Voice agent | Recorded **test** calls (never customer calls): the true transcript and slots, and what the system heard | Word error rate (jiwer when installed), slot accuracy | "WER over N words in M calls; scripted calls, not real traffic." Live calls only with the TL's agreement |

## Reliability (week 2, Thursday)
- Ask early (intake, week 0) for **the same inputs run 3 times** and, if possible, **two builds**.
- `python -m ai_project reliability` gives per-case pass rates, cases that agree on every run, and the "passes sometimes" list.
- **One run per input:** the tool says "Reliability cannot be measured from one run per input". The report states this limit; the readiness criteria accept it for the AI-project track (audit 2.2).

## Privacy and safety rules (say them once, kindly, and hold them)
- India's DPDP Act and the client contract apply. Aadhaar numbers must not be stored. Never generate real-looking ID numbers (Aadhaar-format numbers with valid checksums, PAN-format codes): use masked data or the vendor's specimen documents.
- The `check` step refuses unmasked emails, phone numbers, Aadhaar-like and PAN-like values. It shows counts only. Never ask the tester to paste the values to you.
- Exports, results with case-level detail, and judge inputs stay on the laptop or in the project's private repository: never in a public repository (the week 2 saved-score gate uses case ids and scores only).
- Reports and the Saturday screen show numbers, case ids and the project's code name. Real findings go to the project team through its own process, in general terms in the report.

## Worked examples
Use `samples/` (fake data) for every worked example: classification (12 emails × 3 runs, one "passes sometimes", one always wrong), extraction (4 invoices with Indian dates and amounts: a missing total, an invented GSTIN field, a day-month swap), validation (6 records, rules vs AI), RAG (3 questions, a refusal, a missed source), agent (a refund done right; a 5,000 refund that should have been a hand-off), voice (2 scripted calls: "twelve" vs "twelfth", a wrong order number). Never use the tester's own data as a worked example for someone else.
