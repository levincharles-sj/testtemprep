# Conduit practice app (week 1)

Conduit is a blogging app that runs on the tester's own laptop. It is the **practice app** for testers who cannot use their project's app yet, and the app every worked example uses. Testers treat it like a client's test environment: through its pages, its API and its API docs, never through its code (the guard keeps the coach's files out of the WORK window).

## For the tester (show these parts)
- **Start it:** in the COACH window, type `/bootcamp app start`. It keeps running in the background. Address: http://127.0.0.1:4310
- **Fresh data:** `/bootcamp app reset` (deletes everything you changed and starts again).
- **API docs:** http://127.0.0.1:4310/openapi.yaml (OpenAPI). The API is at http://127.0.0.1:4310/api
- **Test accounts for automation** (the "dev team" gave you these; type them into `.env` yourself, never in the chat):

| Role | Email (TEST_USER) | Sees |
|---|---|---|
| member | smoke-member@conduit.test | home, feeds, articles, comments, own settings |
| moderator | smoke-moderator@conduit.test | the same, plus the Moderation page (reported comments, users) |

  The password, the TOTP secrets and the captcha test key are in `conduit-practice-note.txt` in the bootcamp folder (the start script writes it). The tester opens it in VS Code and types the values into `.env`. The coach never shows them in the chat.
- **Other users** (people in the app, not for automation): practice-author, practice-reader, practice-editor and eight more authors.
- **Data:** 48 articles over 5 pages in the feed, 14 tags, 25 comments, some reported to the moderators. Every reset gives the same data.
- **Practice blockers** (to try the workarounds you need on real projects):
  - `/bootcamp app start mfa`: the test accounts need a 6-digit code from an authenticator app after the password. The "dev team" gives you the TOTP secret (in the note) for `.env`.
  - `/bootcamp app start captcha`: the sign-in form shows a captcha. The "dev team" gives you a captcha test key (in the note) for `.env`.
  - `/bootcamp app start`: both off again. Your data stays.

**Practice app note:** `conduit-practice-note.txt` (same values as `NOTE` in `scripts/bootcamp/practice-app.mjs`).

## Read-only smoke candidates (for worked examples; testers choose their own)
1. A member signs in and reaches the home page (Your Feed and Global Feed tabs).
2. The Global Feed lists 10 articles and 5 page links.
3. A tag filter shows only articles with that tag.
4. An article page shows its body, tags and comments.
5. An author's profile lists their articles.
6. Settings shows the signed-in user's own details (read only: no Update).
7. The moderator sees Moderation with reported comments and the users list.
8. A member who opens /moderation gets "You do not have access to this page."
9. API: GET /api/tags returns the tags; GET /api/articles?limit=5 returns 5 articles and articlesCount 48.
10. API: GET /api/moderation/reports with a member's token returns 403; without a token, 401.
11. API: sign in through POST /api/users/login with the `.env` values gives a token (never printed).

Writes (on a write list only, and cleaned up): post a comment, favourite an article, follow an author, report a comment, update the bio.

## For the coach only
- The coach runs `node "${CLAUDE_PLUGIN_ROOT}/scripts/bootcamp/practice-app.mjs" start|reset|stop|status [mfa] [captcha]`. Data: `.bootcamp/practice-app/conduit.db` in the bootcamp folder. Port 4310.
- Node 22.13 or later is needed (`node:sqlite`). On Node 20 the script prints `APP failed Node 22.13 or later is needed`.
- **MFA practice and `/bootcamp stuck`:** if the set-up step fails with "TEST_TOTP_SECRET is empty", ask first whether they meant to practise MFA. Yes: they type the TOTP secret from the note into `.env` and run the set-up step again. No: `/bootcamp app start` (both switches off).
- Known traps that make good "what the AI got wrong" catches: `getByRole('link', { name: 'Moderation' })` also matches the article "Moderation guidelines" (not exact); `getByText('Report')` also matches "How to write a good bug report"; tests that hard-code the article count (48) break after a write test adds one; the planner suggests "update bio" (a write) for the settings page.
