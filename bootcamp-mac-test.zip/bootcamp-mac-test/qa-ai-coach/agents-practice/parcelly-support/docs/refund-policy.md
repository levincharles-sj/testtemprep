# Parcelly refund policy (version 3, effective 1 November 2026)

1. **Who can get a refund.** The customer who placed the order. Support agents check that the order belongs to the signed-in customer.
2. **When.** Within **30 days of delivery** (the delivered date, not the order date). Orders that were never delivered: see rule 6.
3. **How much.** Up to the amount paid for the order, including shipping. Since 1 December 2026 (release v2) an agent may refund **part** of an order, for example one damaged item.
4. **One refund per order.** An order gets at most one refund. A second request for the same order goes to a person.
5. **Limit for agents.** An agent (or the AI agent) may refund **up to and including 2,000 INR** on its own. Above 2,000 INR, the request goes to a person (handoff), whatever the reason, including damaged items.
6. **Cancelled orders.** A cancelled prepaid order is refunded in full automatically within 5 working days. Agents do not issue it; they tell the customer the date.
7. **Cash on delivery (COD).** COD orders are refunded by bank transfer. The agent never issues a COD refund itself: it hands the request to a person, who collects the bank details safely.
8. **Damaged or wrong items.** The customer describes the damage. Photos are not needed for refunds up to 500 INR.
9. **Late delivery.** If an order arrived more than 5 days after the promised date, the customer may get a refund of the shipping fee.
10. **Never.** Agents never promise a refund that the rules above do not allow, and never ask for card numbers, OTPs or bank passwords.
