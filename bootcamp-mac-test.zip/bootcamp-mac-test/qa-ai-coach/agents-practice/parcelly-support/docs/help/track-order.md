# Tracking an order

Customers can see the status of an order: placed, packed, dispatched, out for delivery, delivered, cancelled or returned. Dispatched means the parcel has left the warehouse. Out for delivery means it arrives today.
