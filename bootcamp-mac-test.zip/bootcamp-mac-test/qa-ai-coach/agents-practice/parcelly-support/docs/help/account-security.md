# Account security

Parcelly never asks for card numbers, OTPs, CVV or bank passwords in chat. If someone asks, the customer should end the chat and report it.
