# How long refunds take

Prepaid orders: 5 to 7 working days to the original payment method. COD orders: 7 to 10 working days by bank transfer after the bank details are confirmed.
