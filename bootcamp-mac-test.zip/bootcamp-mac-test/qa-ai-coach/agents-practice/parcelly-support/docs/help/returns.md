# Returns

Most items can be returned within 10 days of delivery. The item must be unused and in its box. Electronics need the original seal. The refund follows the refund policy once the return reaches the warehouse.
