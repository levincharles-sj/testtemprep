# Delivery times

Metro cities: 2 to 4 working days. Other cities: 4 to 7 working days. The promised date is shown on the order page. Orders placed after 4 pm leave the next working day. Sundays and public holidays are not working days.
