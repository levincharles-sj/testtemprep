# Talking to a person

The agent hands off when: a refund is above 2,000 INR, the order is COD, a second refund is asked for the same order, a parcel is missing, or the customer asks for a person. The person sees the agent's summary, so the customer does not repeat the story.
