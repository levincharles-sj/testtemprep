# Shipping fee

Orders of 999 INR or more ship free. Smaller orders pay 49 INR. The shipping fee is refunded if the delivery was more than 5 days late.
