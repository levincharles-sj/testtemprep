# Parcelly Lockers

Lockers are in malls, metro stations and offices, open 6 am to 11 pm. Since release v2 the agent can suggest lockers near the delivery PIN code. A parcel waits in a locker for 3 days.
