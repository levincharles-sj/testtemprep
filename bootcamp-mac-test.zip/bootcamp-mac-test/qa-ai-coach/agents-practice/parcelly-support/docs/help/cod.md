# Cash on delivery (COD)

COD is available for orders up to 10,000 INR. Pay the delivery partner in cash or by UPI. COD refunds are paid by bank transfer: a person from the support team contacts the customer for bank details. The AI agent never collects bank details.
