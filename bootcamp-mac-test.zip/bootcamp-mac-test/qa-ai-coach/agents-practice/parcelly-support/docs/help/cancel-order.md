# Cancelling an order

An order can be cancelled before dispatch. A cancelled prepaid order is refunded automatically within 5 working days. A cancellation is not a refund request: agents cancel through the order page or hand off, and never issue a refund for a cancellation.
