# Festive sale orders

Orders from the festive sale (1 to 15 October) follow the same refund policy. Delivery can take 2 extra days.
