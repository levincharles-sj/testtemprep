# Invoices

Invoices are on the order page after dispatch. Business customers can add a GST number before dispatch. Gift orders can hide the price.
