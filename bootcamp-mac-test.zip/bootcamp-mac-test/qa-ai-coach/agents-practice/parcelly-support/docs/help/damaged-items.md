# Damaged or wrong items

If an item arrived damaged or is the wrong item, the customer can ask for a refund for that item. Up to 500 INR no photo is needed. Above 2,000 INR the request goes to a person.
