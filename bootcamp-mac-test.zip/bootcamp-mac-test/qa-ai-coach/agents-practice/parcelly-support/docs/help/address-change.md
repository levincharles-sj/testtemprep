# Changing the delivery address

The delivery address can be changed only **before dispatch** (status placed or packed). After dispatch the parcel is on its way, and the address cannot be changed: the customer can refuse the parcel or collect it from a Parcelly Locker. The new address must have a 6-digit PIN code.
