# Parcel marked delivered but not received

Check with neighbours and the security guard first. If the parcel is still missing after 24 hours, the agent hands off to a person who opens an investigation. The agent does not refund missing parcels itself.
