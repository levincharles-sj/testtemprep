# COD refunds (old policy, 2024: replaced)

How COD refunds work: a COD refund is paid as Parcelly credit on the next order. If the customer prefers, the COD refund is paid in cash by the delivery partner on the next delivery. The agent issues COD refunds directly as credit, with no handoff. COD refund requests do not need bank details.
