"""Parcelly Support Agent tools (QA AI bootcamps, week 2): an MCP stdio server for `claude -p`.

Started only by the coach's runner (scripts/bootcamp/agent.mjs), never by testers or the WORK window.
Settings come from the environment, set by the runner (the model never chooses them):
  PARCELLY_DB        the tester's own database copy (.bootcamp/agent/parcelly.db)
  PARCELLY_CUSTOMER  the signed-in customer (for example C-017)
  PARCELLY_VERSION   v1 or v2
  PARCELLY_VARIANT   the build variant of v2 (A, B, C, D) or "clean"
  PARCELLY_TRACE     JSONL file: one line per tool call (tool, args, result, ms)
  PARCELLY_TODAY     the date the agent works on (default 2026-12-08)
Needs the MCP Python SDK 2.x: pip install "mcp==2.3.0".
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import threading
import time
from functools import wraps
from datetime import date
from pathlib import Path

from mcp.server.mcpserver import MCPServer

import data as store
from bm25 import BM25

HERE = Path(__file__).resolve().parent
DB = Path(os.environ.get("PARCELLY_DB", HERE / "parcelly.db"))
CUSTOMER = os.environ.get("PARCELLY_CUSTOMER", "C-017")
VERSION = os.environ.get("PARCELLY_VERSION", "v2")
VARIANT = os.environ.get("PARCELLY_VARIANT", "clean").upper()
TRACE = os.environ.get("PARCELLY_TRACE")
TODAY = date.fromisoformat(os.environ.get("PARCELLY_TODAY", "2026-12-08"))
LIMIT = 2000.0

# Build behaviour per variant (codes only; what each code does is in the build notes kept with the programme).
_B = {
    "A": {"f1", "f2"},
    "B": {"f3", "f4", "f5"},
    "C": {"f6", "f7"},
    "D": {"f8", "f9", "f10"},
}
BEHAVIOUR = _B.get(VARIANT, set()) if VERSION == "v2" else set()

mcp = MCPServer("parcelly")
conn = store.connect(DB)
LOCK = threading.Lock()


def serial(fn):
    """One tool call at a time against the database (tools may run in worker threads)."""
    @wraps(fn)
    def run(*a, **k):
        with LOCK:
            return fn(*a, **k)
    return run


def _docs():
    docs = {"refund-policy": (store.DOCS / "refund-policy.md").read_text(encoding="utf-8")}
    for p in sorted((store.DOCS / "help").glob("*.md")):
        docs[p.stem] = p.read_text(encoding="utf-8")
    if "f3" in BEHAVIOUR:
        for p in sorted((store.DOCS / "archive").glob("*.md")):
            docs[p.stem] = p.read_text(encoding="utf-8")
    return docs


DOCS = _docs()
INDEX = BM25(DOCS)


def _trace(tool: str, args: dict, result, started: float) -> None:
    if not TRACE:
        return
    with open(TRACE, "a", encoding="utf-8") as f:
        f.write(json.dumps({"tool": tool, "args": args, "result": result, "ms": round((time.perf_counter() - started) * 1000)}) + "\n")


def _order(order_id: str):
    return conn.execute("SELECT * FROM orders WHERE id = ? AND customer_id = ?", (order_id.strip().upper(), CUSTOMER)).fetchone()


def _public(o: sqlite3.Row) -> dict:
    refunds = conn.execute("SELECT id, amount, reason, method FROM refunds WHERE order_id = ?", (o["id"],)).fetchall()
    return {"order_id": o["id"], "order_date": o["order_date"], "status": o["status"], "payment": o["payment"],
            "items": json.loads(o["items"]), "shipping_fee": o["shipping_fee"], "total": o["total"], "address": o["address"],
            "dispatched_date": o["dispatched_date"], "delivered_date": o["delivered_date"],
            "refunds": [dict(r) for r in refunds]}


@mcp.tool()
@serial
def lookup_order(order_id: str) -> dict:
    """Look up one order of the signed-in customer by its order ID (for example PCL-10011)."""
    t = time.perf_counter()
    o = _order(order_id)
    r = _public(o) if o else {"error": "No order with that ID for this customer."}
    _trace("lookup_order", {"order_id": order_id}, r, t)
    return r


@mcp.tool()
@serial
def list_orders() -> dict:
    """List the signed-in customer's orders, newest first (up to 20)."""
    t = time.perf_counter()
    if "f7" in BEHAVIOUR:
        rows = conn.execute("SELECT * FROM orders WHERE customer_id = ? ORDER BY order_date ASC, id ASC LIMIT 5", (CUSTOMER,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM orders WHERE customer_id = ? ORDER BY order_date DESC, id DESC LIMIT 20", (CUSTOMER,)).fetchall()
    r = {"orders": [{"order_id": o["id"], "order_date": o["order_date"], "status": o["status"], "total": o["total"]} for o in rows]}
    _trace("list_orders", {}, r, t)
    return r


@mcp.tool()
@serial
def change_address(order_id: str, new_address: str) -> dict:
    """Change the delivery address of an order. Allowed only before dispatch. The address needs a 6-digit PIN code."""
    t = time.perf_counter()
    o = _order(order_id)
    allowed = {"placed", "packed"} | ({"dispatched"} if "f2" in BEHAVIOUR else set())
    if not o:
        r = {"error": "No order with that ID for this customer."}
    elif o["status"] not in allowed:
        r = {"error": f"The order is {o['status']}: the address can be changed only before dispatch."}
    elif "f8" not in BEHAVIOUR and not re.search(r"(?<!\d)\d{6}(?!\d)", new_address or ""):
        r = {"error": "The new address needs a 6-digit PIN code."}
    else:
        conn.execute("INSERT INTO address_changes VALUES (?,?,?,?)", (o["id"], o["address"], new_address, str(TODAY)))
        conn.execute("UPDATE orders SET address = ? WHERE id = ?", (new_address, o["id"]))
        conn.commit()
        r = {"ok": True, "order_id": o["id"], "new_address": new_address}
    _trace("change_address", {"order_id": order_id, "new_address": new_address}, r, t)
    return r


@mcp.tool()
@serial
def issue_refund(order_id: str, amount: float, reason: str) -> dict:
    """Refund an order of the signed-in customer, following the refund policy. Returns the refund, or why not."""
    t = time.perf_counter()
    o = _order(order_id)
    err = None
    if not o:
        err = "No order with that ID for this customer."
    elif o["status"] == "cancelled":
        err = "Cancelled orders are refunded automatically within 5 working days (policy rule 6). Do not issue a refund."
    elif o["payment"] == "COD" and "f9" not in BEHAVIOUR:
        err = "COD orders are refunded by bank transfer by a person: hand off (policy rule 7)."
    elif o["status"] != "delivered":
        err = f"The order is {o['status']}: only delivered orders can be refunded."
    else:
        start = o["order_date"] if "f6" in BEHAVIOUR else o["delivered_date"]
        if (TODAY - date.fromisoformat(start)).days > 30:
            err = "More than 30 days since delivery: no refund (policy rule 2)."
        elif "f5" not in BEHAVIOUR and conn.execute("SELECT 1 FROM refunds WHERE order_id = ?", (o["id"],)).fetchone():
            err = "This order already has a refund: hand off (policy rule 4)."
        elif amount <= 0 or amount > o["total"]:
            err = f"The amount must be more than 0 and at most the order total ({o['total']:.0f} INR)."
        elif VERSION == "v1" and abs(amount - o["total"]) > 0.5:
            err = "Only full refunds are possible in this version."
        elif amount > LIMIT and not ("f1" in BEHAVIOUR and "damag" in (reason or "").lower()):
            err = "Above 2,000 INR: hand off to a person (policy rule 5)."
    if err:
        r = {"error": err}
    else:
        rid = f"RF-{9001 + conn.execute('SELECT COUNT(*) FROM refunds').fetchone()[0]}"
        method = "original payment" if o["payment"] == "prepaid" else "bank transfer"
        conn.execute("INSERT INTO refunds VALUES (?,?,?,?,?,?)", (rid, o["id"], float(amount), reason, str(TODAY), method))
        conn.commit()
        r = {"refund_id": rid, "order_id": o["id"], "amount": float(amount), "method": method}
    _trace("issue_refund", {"order_id": order_id, "amount": amount, "reason": reason}, r, t)
    return r


@mcp.tool()
@serial
def handoff(summary: str) -> dict:
    """Hand the conversation to a person. Give a short summary so the customer does not repeat the story."""
    t = time.perf_counter()
    n = conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0]
    tid = f"H-{1001 + n}"
    kept = "" if "f4" in BEHAVIOUR else summary
    conn.execute("INSERT INTO tickets VALUES (?,?,?,?)", (tid, CUSTOMER, kept, str(TODAY)))
    conn.commit()
    r = {"ticket": tid, "message": "A person from the support team will reply within 24 hours."}
    _trace("handoff", {"summary": summary}, r, t)
    return r


@mcp.tool()
@serial
def search_help(query: str) -> dict:
    """Search Parcelly's help articles and refund policy. Returns the 3 best matching articles."""
    t = time.perf_counter()
    hits = INDEX.search(query, 3)
    r = {"results": [{"article": k, "text": DOCS[k]} for k, _ in hits]}
    _trace("search_help", {"query": query}, {"articles": [k for k, _ in hits]}, t)
    return r


if VERSION == "v2":
    @mcp.tool()
    @serial
    def find_lockers(pincode: str) -> dict:
        """Suggest Parcelly Lockers near a 6-digit PIN code (new in v2)."""
        t = time.perf_counter()
        city = None
        if "f10" in BEHAVIOUR:
            c = conn.execute("SELECT city FROM customers WHERE id = ?", (CUSTOMER,)).fetchone()
            city = c["city"] if c else None
        else:
            for name, pre in store.CITIES:
                if str(pincode).strip().startswith(pre):
                    city = name
        rows = conn.execute("SELECT * FROM lockers WHERE city = ? ORDER BY id", (city,)).fetchall() if city else []
        r = {"lockers": [dict(x) for x in rows]} if rows else {"error": "No lockers found near that PIN code."}
        _trace("find_lockers", {"pincode": pincode}, r, t)
        return r


if __name__ == "__main__":
    mcp.run()
