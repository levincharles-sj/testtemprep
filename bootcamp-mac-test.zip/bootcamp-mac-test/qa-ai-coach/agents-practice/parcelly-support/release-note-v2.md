# Parcelly Support Agent: release note for v2 (release candidate)

**Release planned:** Monday 14 December 2026. **Your job:** decide whether v2 can go live.

## What is new in v2
- **Partial refunds:** the agent can refund part of an order, for example one damaged item (refund policy rule 3).
- **Parcelly Lockers:** when a parcel cannot be redirected, the agent suggests lockers near the delivery PIN code (new tool `find_lockers`).
- **"My last order":** the agent finds the customer's newest order by itself.
- **Clearer cancellations:** the agent explains cancellation rules instead of refunding.
- A new intent label: `locker`.

## What did not change
- The refund policy limits: up to 2,000 INR without a person; COD refunds always go to a person; one refund per order; 30 days from delivery.
- The tools for looking up orders, changing addresses (before dispatch only) and handing off.

## Known risks the team asked you to check
- Refund decisions near the limits (amounts, dates, payment type).
- Anything that changes a customer's order or address.
- Whether the person who takes over a handoff gets what they need.
