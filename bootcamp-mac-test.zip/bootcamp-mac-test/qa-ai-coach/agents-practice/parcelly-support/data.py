"""Parcelly Support Agent (QA AI bootcamps, week 2): the practice data and a read-only lookup.

Data is made up, deterministic (the same on every laptop) and written into the tester's own bootcamp folder
(`.bootcamp/agent/parcelly.db`), never inside the coach. Names are invented; emails use example.com; phone numbers
use the made-up range +91 90000 0xxxx.

  python data.py --db <file> --ensure            create the database if it does not exist
  python data.py --db <file> --reset             delete and create it again (fresh data)
  python data.py --db <file> lookup order PCL-10001
  python data.py --db <file> lookup customer C-017
  python data.py --db <file> lookup orders C-017
  python data.py --db <file> lookup ticket H-1001
  python data.py --db <file> lookup policy
  python data.py --db <file> lookup help <topic words>
"""
from __future__ import annotations

import argparse
import json
import random
import sqlite3
import sys
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
DOCS = HERE / "docs"
SEED = 20261207
TODAY = date(2026, 12, 8)

FIRST = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Krishna", "Ishaan", "Rohan", "Ananya", "Diya",
         "Saanvi", "Aadhya", "Kavya", "Meera", "Priya", "Nisha", "Pooja", "Lakshmi", "Farhan", "Imran", "Zoya", "Sana",
         "Gurpreet", "Harleen", "Joseph", "Mary", "Thomas", "Anita", "Rahul", "Sneha", "Vikram", "Deepa", "Manoj", "Divya"]
LAST = ["Sharma", "Verma", "Iyer", "Nair", "Reddy", "Rao", "Patel", "Shah", "Mehta", "Gupta", "Khan", "Siddiqui",
        "Singh", "Kaur", "Das", "Bose", "Menon", "Pillai", "Joshi", "Kulkarni", "Fernandes", "D'Souza", "Chatterjee", "Mishra"]
CITIES = [("Bengaluru", "5600"), ("Mumbai", "4000"), ("Pune", "4110"), ("Chennai", "6000"), ("Hyderabad", "5000"),
          ("Delhi", "1100"), ("Kolkata", "7000"), ("Kochi", "6820"), ("Ahmedabad", "3800"), ("Jaipur", "3020")]
STREETS = ["MG Road", "Park Street", "Anna Salai", "Linking Road", "FC Road", "Brigade Road", "Banjara Hills Road 12",
           "Sector 18 Main Road", "CG Road", "MI Road", "Marine Drive", "Residency Road", "Lal Bagh Road", "Hill Road"]
ITEMS = [("Bluetooth earphones", 1499), ("Cotton kurta", 899), ("Steel water bottle", 449), ("Pressure cooker 3L", 1899),
         ("Running shoes", 2799), ("School bag", 1199), ("LED desk lamp", 999), ("Yoga mat", 699), ("Phone cover", 299),
         ("Mixer grinder", 3499), ("Bedsheet set", 1299), ("Wall clock", 549), ("Smart watch", 4999), ("Saree", 2299),
         ("Notebook pack", 249), ("Air fryer", 5999), ("Ceiling fan", 2599), ("Umbrella", 399)]
NOTES = ["", "", "", "", "Leave with the security guard", "Call before delivery", "Gift: do not include the invoice",
         "Deliver after 6 pm", "Fragile: glass inside", "Office address: deliver on weekdays"]


def build(conn: sqlite3.Connection) -> None:
    rnd = random.Random(SEED)
    c = conn.cursor()
    c.executescript("""
    CREATE TABLE customers (id TEXT PRIMARY KEY, name TEXT, email TEXT, phone TEXT, city TEXT, pincode TEXT, joined TEXT);
    CREATE TABLE orders (id TEXT PRIMARY KEY, customer_id TEXT, order_date TEXT, status TEXT, payment TEXT, items TEXT,
      total REAL, shipping_fee REAL, address TEXT, pincode TEXT, city TEXT, dispatched_date TEXT, delivered_date TEXT, notes TEXT);
    CREATE TABLE refunds (id TEXT PRIMARY KEY, order_id TEXT, amount REAL, reason TEXT, created TEXT, method TEXT);
    CREATE TABLE tickets (id TEXT PRIMARY KEY, customer_id TEXT, summary TEXT, created TEXT);
    CREATE TABLE lockers (id TEXT PRIMARY KEY, name TEXT, city TEXT, pincode TEXT, open_hours TEXT);
    CREATE TABLE address_changes (order_id TEXT, old_address TEXT, new_address TEXT, created TEXT);
    """)
    customers = []
    for i in range(1, 201):
        fn, ln = rnd.choice(FIRST), rnd.choice(LAST)
        city, pre = rnd.choice(CITIES)
        cid = f"C-{i:03d}"
        email = f"{fn.lower()}.{ln.lower().replace(chr(39), '')}{i}@example.com"
        customers.append((cid, f"{fn} {ln}", email, f"+91 90000 {i:05d}", city, f"{pre}{rnd.randint(10, 99)}",
                          str(date(2025, 1, 1) + timedelta(days=rnd.randint(0, 600)))))
    c.executemany("INSERT INTO customers VALUES (?,?,?,?,?,?,?)", customers)
    # Some customers order a lot, most a few times.
    weights = [8 if i % 17 == 0 else 3 if i % 5 == 0 else 1 for i in range(200)]
    statuses = ["delivered"] * 55 + ["out_for_delivery"] * 8 + ["dispatched"] * 10 + ["packed"] * 7 + ["placed"] * 8 + ["cancelled"] * 7 + ["returned"] * 5
    orders = []
    for n in range(1000):
        cust = rnd.choices(customers, weights=weights)[0]
        od = date(2026, 9, 1) + timedelta(days=rnd.randint(0, 97))
        status = rnd.choice(statuses)
        if od > TODAY - timedelta(days=2) and status in ("delivered", "returned"):
            status = "dispatched"
        k = rnd.choice([1, 1, 1, 2, 2, 3])
        items = [rnd.choice(ITEMS) for _ in range(k)]
        total = float(sum(p for _, p in items))
        fee = 0.0 if total >= 999 else 49.0
        city, pin = (cust[4], cust[5]) if rnd.random() < 0.85 else (lambda cp: (cp[0], f"{cp[1]}{rnd.randint(10, 99)}"))(rnd.choice(CITIES))
        addr = f"{rnd.randint(1, 240)}, {rnd.choice(STREETS)}, {city} {pin}"
        disp = str(od + timedelta(days=1)) if status in ("dispatched", "out_for_delivery", "delivered", "returned") else None
        deliv = str(od + timedelta(days=rnd.randint(2, 9))) if status in ("delivered", "returned") else None
        if deliv and deliv > str(TODAY):  # nothing is delivered after the agent's "today"
            status, deliv = "out_for_delivery", None
        orders.append([f"PCL-{10001 + n}", cust[0], str(od), status, "COD" if rnd.random() < 0.3 else "prepaid",
                       json.dumps([{"item": a, "price": p} for a, p in items]), total + fee, fee, addr, pin, city, disp, deliv,
                       rnd.choice(NOTES)])
    # Edge cases the golden set can use: two orders on the same day; a late delivery; a cancelled prepaid order.
    orders[10][1], orders[11][1] = "C-017", "C-017"
    orders[10][2] = orders[11][2] = "2026-11-28"
    orders[10][3], orders[11][3] = "delivered", "dispatched"
    orders[10][12], orders[11][12] = "2026-11-30", None
    orders[10][11], orders[11][11] = "2026-11-29", "2026-11-29"
    orders[12][1], orders[12][2], orders[12][3], orders[12][11], orders[12][12] = "C-017", "2026-10-20", "delivered", "2026-10-21", "2026-11-25"
    orders[12][4] = "prepaid"
    orders[13][1], orders[13][3], orders[13][4] = "C-017", "cancelled", "prepaid"
    c.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [tuple(o) for o in orders])
    refunds = []
    for n, o in enumerate(orders):
        if o[3] == "returned" or (o[3] == "delivered" and rnd.random() < 0.06):
            amt = o[6] if o[3] == "returned" else round(o[6] * rnd.choice([0.25, 0.5]), 0)
            refunds.append((f"RF-{5001 + len(refunds)}", o[0], amt, rnd.choice(["damaged", "late", "returned", "wrong item"]),
                            o[12], "original payment" if o[4] == "prepaid" else "bank transfer"))
    c.executemany("INSERT INTO refunds VALUES (?,?,?,?,?,?)", refunds)
    lockers = []
    for city, pre in CITIES:
        for j in range(3):
            lockers.append((f"LK-{city[:3].upper()}-{j + 1}", f"Parcelly Locker {city} {['Central', 'Metro', 'Mall'][j]}",
                            city, f"{pre}{rnd.randint(10, 99)}", "6 am to 11 pm"))
    c.executemany("INSERT INTO lockers VALUES (?,?,?,?,?)", lockers)
    conn.commit()


def ensure(db: Path, reset: bool = False) -> Path:
    db.parent.mkdir(parents=True, exist_ok=True)
    if reset and db.exists():
        db.unlink()
    if not db.exists():
        conn = sqlite3.connect(db)
        build(conn)
        conn.close()
    return db


def connect(db: Path) -> sqlite3.Connection:
    # The MCP server runs tool calls in worker threads: allow that (the server serialises its own calls).
    conn = sqlite3.connect(ensure(db), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _order_text(o: sqlite3.Row, refunds: list) -> str:
    items = ", ".join(f"{i['item']} ({i['price']:.0f})" for i in json.loads(o["items"]))
    lines = [f"Order {o['id']} · customer {o['customer_id']} · ordered {o['order_date']} · status {o['status']} · {o['payment']}",
             f"  Items: {items} · shipping {o['shipping_fee']:.0f} · total {o['total']:.0f} INR",
             f"  Delivery address: {o['address']}",
             f"  Dispatched: {o['dispatched_date'] or '-'} · delivered: {o['delivered_date'] or '-'}"]
    if o["notes"]:
        lines.append(f"  Notes: {o['notes']}")
    for r in refunds:
        lines.append(f"  Refund {r['id']}: {r['amount']:.0f} INR, {r['reason']}, {r['created'] or '-'}, by {r['method']}")
    return "\n".join(lines)


STATUS_WORDS = {"delivered": "delivered", "dispatched": "dispatched", "out": "out_for_delivery", "packed": "packed",
                "placed": "placed", "cancelled": "cancelled", "canceled": "cancelled", "returned": "returned"}


def find_orders(conn, words: str) -> str:
    """Read-only search across all customers, for building golden cases: words such as
    'delivered prepaid over 2000', 'cod under 500', 'dispatched'. At most 20 orders."""
    w = words.lower().replace(",", " ").split()
    where, args = [], []
    statuses = sorted({STATUS_WORDS[x] for x in w if x in STATUS_WORDS})
    if statuses:
        where.append(f"status IN ({','.join('?' * len(statuses))})")
        args += statuses
    if "prepaid" in w:
        where.append("payment = 'prepaid'")
    if "cod" in w:
        where.append("payment = 'COD'")
    for i, x in enumerate(w[:-1]):
        try:
            n = float(w[i + 1])
        except ValueError:
            continue
        if x in ("over", "above", "min"):
            where.append("total > ?"); args.append(n)
        if x in ("under", "below", "max"):
            where.append("total < ?"); args.append(n)
    sql = "SELECT * FROM orders" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id LIMIT 20"
    rows = conn.execute(sql, args).fetchall()
    if not rows:
        return "No orders match."
    head = f"Orders that match ({len(rows)} shown, at most 20):"
    return head + "\n" + "\n".join(f"{o['id']} · customer {o['customer_id']} · {o['status']} · {o['payment']} · {o['total']:.0f} INR · delivered {o['delivered_date'] or '-'}" for o in rows)


def lookup(db: Path, what: str, arg: str | None) -> str:
    conn = connect(db)
    if what == "order":
        o = conn.execute("SELECT * FROM orders WHERE id = ?", (arg,)).fetchone()
        if not o:
            return f"No order {arg}."
        return _order_text(o, conn.execute("SELECT * FROM refunds WHERE order_id = ?", (arg,)).fetchall())
    if what == "customer":
        c = conn.execute("SELECT * FROM customers WHERE id = ?", (arg,)).fetchone()
        if not c:
            return f"No customer {arg}."
        n = conn.execute("SELECT COUNT(*) FROM orders WHERE customer_id = ?", (arg,)).fetchone()[0]
        return f"Customer {c['id']}: {c['name']} · {c['email']} · {c['phone']} · {c['city']} {c['pincode']} · joined {c['joined']} · {n} orders"
    if what == "orders":
        rows = conn.execute("SELECT * FROM orders WHERE customer_id = ? ORDER BY order_date DESC, id DESC", (arg,)).fetchall()
        return "\n".join(f"{o['id']} · {o['order_date']} · {o['status']} · {o['payment']} · {o['total']:.0f} INR" for o in rows) or f"No orders for {arg}."
    if what == "find":
        return find_orders(conn, arg or "")
    if what == "ticket":
        t = conn.execute("SELECT * FROM tickets WHERE id = ?", (arg,)).fetchone()
        return f"Ticket {t['id']} · customer {t['customer_id']} · {t['created']}\n  Summary: {t['summary'] or '(empty)'}" if t else f"No ticket {arg}."
    if what == "lockers":
        rows = conn.execute("SELECT * FROM lockers WHERE city = ? ORDER BY id", (arg,)).fetchall()
        return "\n".join(f"{r['id']} · {r['name']} · PIN {r['pincode']} · {r['open_hours']}" for r in rows) or f"No lockers in {arg}."
    if what == "policy":
        return (DOCS / "refund-policy.md").read_text(encoding="utf-8")
    if what == "help":
        words = (arg or "").lower().split()
        hits = [p for p in sorted((DOCS / "help").glob("*.md")) if all(w in p.read_text(encoding="utf-8").lower() for w in words)]
        if not words:
            return "Help articles:\n" + "\n".join(f"- {p.stem}" for p in sorted((DOCS / "help").glob("*.md")))
        return "\n\n---\n\n".join(p.read_text(encoding="utf-8") for p in hits[:3]) or "No help article matches."
    return f"Unknown lookup '{what}'. Use: order, customer, orders, find, ticket, lockers, policy, help."


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--ensure", action="store_true")
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("rest", nargs="*")
    a = ap.parse_args()
    db = Path(a.db)
    if a.reset or a.ensure:
        ensure(db, reset=a.reset)
        print(f"DATA_READY {db}")
    if a.rest and a.rest[0] == "lookup":
        what = a.rest[1] if len(a.rest) > 1 else ""
        arg = " ".join(a.rest[2:]) if len(a.rest) > 2 else None
        sys.stdout.reconfigure(encoding="utf-8")
        print(lookup(db, what, arg))


if __name__ == "__main__":
    main()
