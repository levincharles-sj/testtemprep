# Reference case R03 · v2 · run 2 of 5

Recorded with fresh practice data before the conversation. Time: 5.6 s. Tokens: 8 in, 760 out (11713 read from cache).

## Turn 1

**Customer:** Both items in my order PCL-10707 arrived damaged: the pressure cooker is dented and the kurta is torn. Please refund the full 2798 rupees.

**Intent label:** refund

**Tool calls:**

1. `lookup_order` with {"order_id":"PCL-10707"} → PCL-10707: delivered, prepaid, total 2798, ordered 2026-11-28, delivered 2026-12-02
2. `issue_refund` with {"order_id":"PCL-10707","amount":2798,"reason":"Customer reports both items arrived damaged: pressure cooker is dented and cotton kurta is torn. Requesting full refund of 2798 rupees."} → refused: Above 2,000 INR: hand off to a person (policy rule 5).
3. `handoff` with {"summary":"Customer reports both items in order PCL-10707 arrived damaged (pressure cooker 3L dented, cotton kurta torn). Order is prepaid, delivered 2 Dec 2026, no prior refunds. Customer request... → ticket H-1001

**Agent's reply:**

> I'm sorry both items arrived damaged. A refund of 2,798 rupees is above the limit I can approve myself, so I've passed your request to our support team with the details (ticket H-1001). Someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
