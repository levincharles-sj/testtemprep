# Reference case R06 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 4 s. Tokens: 4 in, 482 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"return refund cash on delivery credit or cash"} → articles: cod-refunds-2024, cod, returns

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details, so please don't share them in this chat. Most items can be returned within 10 days of delivery, unused and in their box, and the refund is processed once the return reaches our warehouse.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
