# Reference case R06 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.5 s. Tokens: 4 in, 457 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"return refund cash on delivery Parcelly credit or cash"} → articles: cod-refunds-2024, cod, returns

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. A support team member will contact you for your bank details, so I won't ask for them here. Returns are accepted within 10 days of delivery, and the item must be unused and in its box (electronics also need the original seal).

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
