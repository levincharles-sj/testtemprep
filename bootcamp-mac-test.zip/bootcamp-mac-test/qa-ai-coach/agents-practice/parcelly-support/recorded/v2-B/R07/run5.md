# Reference case R07 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.8 s. Tokens: 4 in, 485 out (5200 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer (levin@techjays.com) reports order PCL-10013 arrived almost a month late and wants to discuss compensation with a person. Customer explicitly asked for a human agent. No refund... → ticket H-1001

**Agent's reply:**

> I'm sorry your order PCL-10013 arrived almost a month late. I've passed your compensation request to a member of our support team under ticket H-1001, and they will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
