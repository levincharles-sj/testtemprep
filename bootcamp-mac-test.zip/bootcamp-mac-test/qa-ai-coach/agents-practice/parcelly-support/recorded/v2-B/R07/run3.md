# Reference case R07 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 3.4 s. Tokens: 4 in, 416 out (5200 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer asks to speak with a person about compensation. Order PCL-10013 arrived almost a month late. Customer wants compensation for the delay."} → ticket H-1001

**Agent's reply:**

> I've passed your request to our support team with the details of order PCL-10013 and your compensation request, under ticket H-1001. A person will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
