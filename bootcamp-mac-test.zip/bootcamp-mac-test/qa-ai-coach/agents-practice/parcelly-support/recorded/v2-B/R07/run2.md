# Reference case R07 · v2 · run 2 of 5

Recorded with fresh practice data before the conversation. Time: 3.4 s. Tokens: 4 in, 436 out (5200 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer says order PCL-10013 arrived almost a month late and wants to discuss compensation with a person. Customer asked to speak with a human agent."} → ticket H-1001

**Agent's reply:**

> I'm sorry your order PCL-10013 arrived almost a month late. I've passed your compensation request to our support team under ticket H-1001, with a summary so you won't need to repeat the details. A person will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
