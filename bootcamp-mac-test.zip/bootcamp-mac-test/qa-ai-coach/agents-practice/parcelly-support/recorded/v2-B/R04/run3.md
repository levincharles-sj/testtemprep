# Reference case R04 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 3.2 s. Tokens: 4 in, 278 out (5198 read from cache).

## Turn 1

**Customer:** Please change the delivery address of PCL-10012 to 45, FC Road, Pune 411004.

**Intent label:** address_change

**Tool calls:**

1. `change_address` with {"order_id":"PCL-10012","new_address":"45, FC Road, Pune 411004"} → refused: The order is dispatched: the address can be changed only before dispatch.

**Agent's reply:**

> I'm sorry, but order PCL-10012 has already been dispatched, and addresses can only be changed before dispatch. I can't update the delivery address for this order. If you'd like, I can look for a Parcelly Locker near the delivery PIN code as an alternative pickup point, or connect you with a person to discuss options.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
