# Reference case R12 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 4.1 s. Tokens: 6 in, 556 out (8172 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Order PCL-10011 was cash on delivery and arrived broken. Customer requests a refund of 348 rupees."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer requests a refund of 348 rupees for order PCL-10011. It was cash on delivery and arrived broken. The refund tool returned that COD refunds are paid by bank transfer by a person... → ticket H-1001

**Agent's reply:**

> I couldn't issue the refund automatically because cash-on-delivery refunds are paid by bank transfer, which a person must arrange. I've passed your case to our support team with the details (ticket H-1001). Someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
