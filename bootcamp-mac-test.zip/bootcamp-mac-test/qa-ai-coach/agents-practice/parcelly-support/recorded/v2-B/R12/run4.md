# Reference case R12 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 5.1 s. Tokens: 6 in, 749 out (8367 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Customer reports order PCL-10011 (cash on delivery) arrived broken. Requesting refund of Rs 348."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer wants a refund of Rs 348 for order PCL-10011, a cash-on-delivery order that arrived broken. The refund tool returned that COD refunds are made by bank transfer by a person (pol... → ticket H-1001

**Agent's reply:**

> I couldn't issue the Rs 348 refund myself, because cash-on-delivery refunds are paid by bank transfer and must be handled by a person. I've passed your case to our support team with the details (ticket H-1001), and they will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
