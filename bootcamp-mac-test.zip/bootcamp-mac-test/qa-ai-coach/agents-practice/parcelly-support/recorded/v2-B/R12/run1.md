# Reference case R12 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 4.7 s. Tokens: 6 in, 656 out (7781 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Customer reports order PCL-10011 (cash on delivery) arrived broken; requesting refund of Rs 348."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer is asking for a refund of Rs 348 on order PCL-10011, which was cash on delivery and arrived broken. The refund tool returned that COD refunds are paid by bank transfer by a per... → ticket H-1001

**Agent's reply:**

> I couldn't issue the refund myself because cash-on-delivery refunds are paid by bank transfer, which a member of our support team has to handle. I've passed your request for the Rs 348 refund on order PCL-10011 to them with the broken-item details (ticket H-1001), and someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: (empty)
- Address changes: none
