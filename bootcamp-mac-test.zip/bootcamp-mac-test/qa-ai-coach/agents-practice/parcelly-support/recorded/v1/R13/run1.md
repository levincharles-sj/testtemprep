# Reference case R13 · v1 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.9 s. Tokens: 4 in, 520 out (3951 read from cache).

## Turn 1

**Customer:** I am in Bengaluru for a month. Which Parcelly Lockers are near PIN 560001?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers locations near PIN 560001 Bengaluru"} → articles: lockers, address-change, account-security

**Agent's reply:**

> I couldn't find a list of Parcelly Lockers near PIN 560001 in our help articles. Lockers are generally in malls, metro stations and offices, open 6 am to 11 pm, and hold a parcel for 3 days. If you tell me the order you want sent to a locker, I can check its details, or I can connect you with a person who can look up nearby locker locations.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
