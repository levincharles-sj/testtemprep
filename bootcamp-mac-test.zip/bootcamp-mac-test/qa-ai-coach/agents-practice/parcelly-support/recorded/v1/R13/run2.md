# Reference case R13 · v1 · run 2 of 5

Recorded with fresh practice data before the conversation. Time: 4.1 s. Tokens: 4 in, 550 out (4700 read from cache).

## Turn 1

**Customer:** I am in Bengaluru for a month. Which Parcelly Lockers are near PIN 560001?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers near PIN 560001 Bengaluru"} → articles: lockers, address-change, account-security

**Agent's reply:**

> I couldn't find a list of specific Parcelly Lockers near PIN 560001 in our help articles, so I won't guess a location. Lockers are generally in malls, metro stations and offices, open 6 am to 11 pm, and a parcel waits there for 3 days. If you tell me which order you want to collect from a locker, I can check its details, or I can hand you to a person who can look up nearby lockers.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
