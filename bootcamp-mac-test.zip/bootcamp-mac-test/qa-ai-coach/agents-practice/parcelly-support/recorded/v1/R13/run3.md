# Reference case R13 · v1 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 3.8 s. Tokens: 4 in, 520 out (4700 read from cache).

## Turn 1

**Customer:** I am in Bengaluru for a month. Which Parcelly Lockers are near PIN 560001?

**Intent label:** other

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers near PIN 560001 Bengaluru"} → articles: lockers, address-change, account-security
2. `search_help` with {"query":"Parcelly locker locations"} → articles: lockers, address-change, account-security

**Agent's reply:**

> I'm sorry, I couldn't find a list of Parcelly Lockers near PIN 560001 in our help articles, and I don't have a locker-search tool. Lockers are generally in malls, metro stations and offices, open 6 am to 11 pm, and a parcel waits there for 3 days. If you tell me which order you want sent to a locker, I can check its status, or I can hand you to a person who can look up nearby lockers.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
