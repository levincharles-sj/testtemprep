# Reference case R13 · v1 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.7 s. Tokens: 4 in, 496 out (4700 read from cache).

## Turn 1

**Customer:** I am in Bengaluru for a month. Which Parcelly Lockers are near PIN 560001?

**Intent label:** other

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers near PIN 560001 Bengaluru"} → articles: lockers, address-change, account-security

**Agent's reply:**

> I couldn't find a list of Parcelly Lockers near PIN 560001 in our help articles, so I can't name specific locations. Lockers are in malls, metro stations and offices, open 6 am to 11 pm, and a parcel waits in a locker for 3 days. If you tell me which order you'd like delivered to a locker, I can check its details.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
