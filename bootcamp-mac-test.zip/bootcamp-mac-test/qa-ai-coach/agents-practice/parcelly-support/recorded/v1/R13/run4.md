# Reference case R13 · v1 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 4.2 s. Tokens: 4 in, 504 out (4700 read from cache).

## Turn 1

**Customer:** I am in Bengaluru for a month. Which Parcelly Lockers are near PIN 560001?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers locations near PIN 560001 Bengaluru"} → articles: lockers, address-change, account-security

**Agent's reply:**

> Parcelly Lockers are in malls, metro stations and offices, and are open 6 am to 11 pm. I couldn't find a list of specific lockers near PIN 560001 in our help articles, so I can't name one without guessing. If you tell me which order you want delivered to a locker, I can check its details, or I can hand you to a person who can look up lockers for your area.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
