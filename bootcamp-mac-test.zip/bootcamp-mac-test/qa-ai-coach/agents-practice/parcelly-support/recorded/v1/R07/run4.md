# Reference case R07 · v1 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 3.2 s. Tokens: 4 in, 335 out (4700 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer levin@techjays.com says order PCL-10013 arrived almost a month late and wants to discuss compensation with a person. No refund or other action has been taken in this chat."} → ticket H-1001

**Agent's reply:**

> I'm sorry order PCL-10013 arrived almost a month late. I've passed your request for compensation to our support team under ticket H-1001. A person will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer levin@techjays.com says order PCL-10013 arrived almost a month late and wants to discuss compensation with a person. No refund or other action has been taken in this chat."
- Address changes: none
