# Reference case R07 · v1 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.2 s. Tokens: 4 in, 374 out (3951 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer's order PCL-10013 arrived almost a month late. The customer is asking to speak with a person about compensation for the delay."} → ticket H-1001

**Agent's reply:**

> I'm sorry your order PCL-10013 arrived almost a month late. I've passed your compensation request to our support team under ticket H-1001. A person will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer's order PCL-10013 arrived almost a month late. The customer is asking to speak with a person about compensation for the delay."
- Address changes: none
