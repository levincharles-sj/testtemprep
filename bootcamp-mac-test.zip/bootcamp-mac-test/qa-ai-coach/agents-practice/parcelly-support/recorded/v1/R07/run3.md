# Reference case R07 · v1 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 4.1 s. Tokens: 6 in, 491 out (7502 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `lookup_order` with {"order_id":"PCL-10013"} → PCL-10013: delivered, prepaid, total 1199, ordered 2026-10-20, delivered 2026-11-25
2. `handoff` with {"summary":"Customer asks for a person about compensation for order PCL-10013 (school bag, Rs 1199, prepaid, order date 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25). Customer says it ar... → ticket H-1001

**Agent's reply:**

> I've passed your request to our support team about compensation for order PCL-10013, which was delivered on 25 November after a long delay. Your reference is H-1001, and a person will reply within 24 hours. You don't need to repeat your story.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer asks for a person about compensation for order PCL-10013 (school bag, Rs 1199, prepaid, order date 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25). Customer says it arrived almost a month late. No refunds issued so far. Customer requested a human agent to discuss compensation."
- Address changes: none
