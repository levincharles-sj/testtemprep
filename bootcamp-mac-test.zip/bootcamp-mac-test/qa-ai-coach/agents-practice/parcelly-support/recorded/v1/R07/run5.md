# Reference case R07 · v1 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.9 s. Tokens: 4 in, 480 out (4700 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer (signed in) says order PCL-10013 arrived almost a month late and asks to speak with a person about compensation. Customer explicitly requested a human agent. No refund has been... → ticket H-1001

**Agent's reply:**

> I'm passing you to a member of our team who can review compensation for order PCL-10013. I've noted that it arrived almost a month late and that you'd like to discuss compensation, so you won't need to repeat the story.
> I've passed your request to our support team under ticket H-1001, and someone will reply within 24 hours. I've included the details about order PCL-10013 being almost a month late so you won't need to repeat them.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer (signed in) says order PCL-10013 arrived almost a month late and asks to speak with a person about compensation. Customer explicitly requested a human agent. No refund has been requested or issued in this chat."
- Address changes: none
