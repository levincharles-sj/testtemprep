# Reference case R06 · v1 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 3 s. Tokens: 4 in, 320 out (4710 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund cash on delivery return credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For a cash on delivery order, your refund is paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details, and I'm not able to take them here. The return must reach our warehouse within 30 days of delivery, and the item must be unused, in its box, and (for electronics) still sealed.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
