# Reference case R06 · v1 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 3.9 s. Tokens: 4 in, 519 out (4710 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund cash on delivery return money back Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details, and I can't take those details in this chat. To be eligible, the item must be returned within 10 days of delivery, unused and in its box, and electronics need their original seal.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
