# Reference case R06 · v1 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3 s. Tokens: 4 in, 313 out (3956 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"cash on delivery return refund credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For a cash on delivery order, the refund goes to your bank account by bank transfer, not as Parcelly credit. A support team member will contact you to collect your bank details, and I can't take them myself. Returns must be made within 10 days of delivery, and the item must be unused and in its box; electronics also need the original seal.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
