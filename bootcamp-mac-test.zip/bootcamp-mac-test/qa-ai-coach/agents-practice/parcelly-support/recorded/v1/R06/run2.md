# Reference case R06 · v1 · run 2 of 5

Recorded with fresh practice data before the conversation. Time: 4.8 s. Tokens: 4 in, 622 out (4710 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"return refund cash on delivery Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. A person from our support team will contact you for your bank details, so please don't share them in this chat. Items can be returned within 10 days of delivery if they're unused and in their box (electronics need the original seal), and the refund is issued once the return reaches our warehouse.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
