# Reference case R06 · v1 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.2 s. Tokens: 4 in, 342 out (4710 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"return refund cash on delivery COD Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For a cash on delivery order, your refund is paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details securely; I can't take those details myself. Returns must be made within 10 days of delivery, and the refund follows the refund policy once the return reaches our warehouse.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
