# Reference case R02 · v1 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 4.2 s. Tokens: 4 in, 510 out (3940 read from cache).

## Turn 1

**Customer:** Which Parcelly Lockers are near my home PIN 411026?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers locations near PIN code 411026"} → articles: lockers, address-change, account-security

**Agent's reply:**

> I couldn't find a list of Parcelly Lockers for PIN 411026 in our help articles, so I can't name specific locations. In general, lockers are in malls, metro stations and offices, open 6 am to 11 pm, and a parcel waits in a locker for 3 days. If you tell me which order you want sent to a locker, I can check its details for you.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
