# Reference case R02 · v1 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 3.6 s. Tokens: 4 in, 484 out (4678 read from cache).

## Turn 1

**Customer:** Which Parcelly Lockers are near my home PIN 411026?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"Parcelly Lockers near PIN 411026"} → articles: lockers, address-change, account-security

**Agent's reply:**

> I couldn't find a list of Parcelly Lockers near PIN 411026 in our help articles, and I don't have a tool that searches locker locations. Lockers are generally in malls, metro stations and offices, open 6 am to 11 pm, and a parcel waits there for 3 days. If you tell me which order you want sent to a locker, I can check its status, or I can hand you to a person who can look up nearby lockers.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
