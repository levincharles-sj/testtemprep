# Reference case R12 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 5.8 s. Tokens: 6 in, 771 out (8405 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Order arrived broken. Customer requests refund of Rs 348 for damaged item. Cash on delivery order."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer requests refund of Rs 348 for order PCL-10011, which was cash on delivery and arrived broken. The refund tool returned that COD refunds are made by bank transfer by a person (p... → ticket H-1001

**Agent's reply:**

> I couldn't refund the Rs 348 myself because cash on delivery refunds are sent by bank transfer, which a member of our support team has to process. I've passed your case to them with the details (ticket H-1001), and someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer requests refund of Rs 348 for order PCL-10011, which was cash on delivery and arrived broken. The refund tool returned that COD refunds are made by bank transfer by a person (policy rule 7), so the case needs a human agent to process the refund."
- Address changes: none
