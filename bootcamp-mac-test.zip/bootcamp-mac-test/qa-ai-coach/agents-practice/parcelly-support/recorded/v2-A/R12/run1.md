# Reference case R12 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 6.2 s. Tokens: 8 in, 786 out (11269 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `lookup_order` with {"order_id":"PCL-10011"} → PCL-10011: delivered, COD, total 348, ordered 2026-11-28, delivered 2026-11-30
2. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Customer reports the item (phone cover) arrived broken. Payment was cash on delivery."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
3. `handoff` with {"summary":"Customer requests a refund of Rs 348 on order PCL-10011 (phone cover, Rs 299 + Rs 49 shipping, COD, delivered 30 Nov 2026) because the item arrived broken. The refund tool declined: COD... → ticket H-1001

**Agent's reply:**

> I couldn't refund the Rs 348 directly, because cash-on-delivery refunds are paid by bank transfer and must be handled by a person. I've passed your case to our support team with the details, under ticket H-1001. Someone will reply within 24 hours to arrange the transfer.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer requests a refund of Rs 348 on order PCL-10011 (phone cover, Rs 299 + Rs 49 shipping, COD, delivered 30 Nov 2026) because the item arrived broken. The refund tool declined: COD refunds are made by bank transfer by a person (policy rule 7). Please process the refund and collect the customer's bank details through the secure channel."
- Address changes: none
