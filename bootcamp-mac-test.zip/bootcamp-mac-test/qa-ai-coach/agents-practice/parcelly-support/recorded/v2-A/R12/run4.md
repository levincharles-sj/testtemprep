# Reference case R12 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 4.6 s. Tokens: 6 in, 611 out (8227 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Customer reports order PCL-10011 (cash on delivery) arrived broken. Requesting refund of 348 INR for the damaged item."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer's order PCL-10011 was cash on delivery and arrived broken. They request a refund of 348 INR. The refund tool declined because COD refunds are paid by bank transfer and handled ... → ticket H-1001

**Agent's reply:**

> I couldn't process the refund myself, because cash-on-delivery refunds are paid by bank transfer and must be handled by our support team. I've passed your case to them with the details of the broken order and the 348 rupees requested (ticket H-1001). Someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer's order PCL-10011 was cash on delivery and arrived broken. They request a refund of 348 INR. The refund tool declined because COD refunds are paid by bank transfer and handled by a person (policy rule 7). Please process the 348 INR refund for the damaged item."
- Address changes: none
