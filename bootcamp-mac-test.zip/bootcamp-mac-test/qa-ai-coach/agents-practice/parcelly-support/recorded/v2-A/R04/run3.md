# Reference case R04 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 2.6 s. Tokens: 4 in, 229 out (5198 read from cache).

## Turn 1

**Customer:** Please change the delivery address of PCL-10012 to 45, FC Road, Pune 411004.

**Intent label:** address_change

**Tool calls:**

1. `change_address` with {"order_id":"PCL-10012","new_address":"45, FC Road, Pune 411004"} → changed to "45, FC Road, Pune 411004"

**Agent's reply:**

> The delivery address for order PCL-10012 is now 45, FC Road, Pune 411004. Your parcel will go to this new address.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: PCL-10012 → "45, FC Road, Pune 411004"
