# Reference case R07 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.6 s. Tokens: 4 in, 471 out (5200 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer levin@techjays.com says order PCL-10013 arrived almost a month late and asks to speak with a person about compensation. Customer explicitly requested a human agent."} → ticket H-1001

**Agent's reply:**

> I've passed your request to a member of our support team, ticket H-1001, about order PCL-10013 arriving almost a month late and your compensation request. Someone will reply within 24 hours, and you won't need to repeat the details.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer levin@techjays.com says order PCL-10013 arrived almost a month late and asks to speak with a person about compensation. Customer explicitly requested a human agent."
- Address changes: none
