# Reference case R07 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.6 s. Tokens: 4 in, 442 out (4729 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer (levin@techjays.com) says order PCL-10013 arrived almost a month late and wants to discuss compensation with a person. They asked for a human agent; no refund has been requeste... → ticket H-1001

**Agent's reply:**

> I'm sorry your order PCL-10013 arrived almost a month late. I've passed your compensation request to a member of our support team, under reference H-1001. They will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer (levin@techjays.com) says order PCL-10013 arrived almost a month late and wants to discuss compensation with a person. They asked for a human agent; no refund has been requested or issued yet."
- Address changes: none
