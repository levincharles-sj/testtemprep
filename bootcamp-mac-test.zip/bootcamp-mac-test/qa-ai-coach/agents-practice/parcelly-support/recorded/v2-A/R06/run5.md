# Reference case R06 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.7 s. Tokens: 4 in, 430 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"return refund cash on delivery COD Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For a cash on delivery order, your refund is paid by bank transfer, not as Parcelly credit. Our support team will contact you to collect your bank details securely; please do not share them in this chat. Returns must be made within 10 days of delivery, and the item must be unused and in its box (electronics need the original seal).

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
