# Reference case R06 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 3.1 s. Tokens: 4 in, 310 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund cash on delivery return money back Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For a cash on delivery order, the refund is paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details securely; I will never ask for them in chat. Returns are accepted within 10 days of delivery, and the item must be unused and in its box.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
