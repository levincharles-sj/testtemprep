# Reference case R06 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 3.1 s. Tokens: 4 in, 302 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund for cash on delivery orders returns credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> COD refunds are paid by bank transfer, not as Parcelly credit. Our team needs your bank details to send it, and our support staff will contact you for them directly; I will never ask you for them in this chat. Returns are accepted within 10 days of delivery, and the item must be unused and in its box (electronics also need the original seal).

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
