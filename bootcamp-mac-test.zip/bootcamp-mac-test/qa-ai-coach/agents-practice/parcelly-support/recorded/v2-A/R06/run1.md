# Reference case R06 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 4 s. Tokens: 4 in, 492 out (4739 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"cash on delivery return refund credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds go to your bank account by bank transfer, not as Parcelly credit. Returns must be unused, in the original box (electronics also need the original seal), and sent back within 10 days of delivery. A support team member will contact you for bank details, and I can pass your request to them if you tell me which order it is.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
