# Reference case R06 · v2 · run 2 of 5

Recorded with fresh practice data before the conversation. Time: 3.2 s. Tokens: 4 in, 434 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund for cash on delivery return: credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds go back by bank transfer, not as Parcelly credit. A person from our support team will contact you for your bank details, so please don't share them in this chat. Most items can be returned within 10 days of delivery, unused and in the original box, and the refund follows once the return reaches our warehouse.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
