# Reference case R04 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 4.2 s. Tokens: 4 in, 351 out (5190 read from cache).

## Turn 1

**Customer:** Please change the delivery address of PCL-10012 to 45, FC Road, Pune 411004.

**Intent label:** address_change

**Tool calls:**

1. `change_address` with {"order_id":"PCL-10012","new_address":"45, FC Road, Pune 411004"} → refused: The order is dispatched: the address can be changed only before dispatch.

**Agent's reply:**

> I'm sorry, I couldn't change the address for PCL-10012 because the order has already been dispatched, and addresses can only be changed before dispatch. If the parcel can't reach you, I can suggest Parcelly Lockers near your PIN code as an alternative, or connect you with a person to help further.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
