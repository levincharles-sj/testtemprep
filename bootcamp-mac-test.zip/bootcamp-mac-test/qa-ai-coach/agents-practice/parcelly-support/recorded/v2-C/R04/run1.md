# Reference case R04 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 2.9 s. Tokens: 4 in, 288 out (4440 read from cache).

## Turn 1

**Customer:** Please change the delivery address of PCL-10012 to 45, FC Road, Pune 411004.

**Intent label:** address_change

**Tool calls:**

1. `change_address` with {"order_id":"PCL-10012","new_address":"45, FC Road, Pune 411004"} → refused: The order is dispatched: the address can be changed only before dispatch.

**Agent's reply:**

> I'm sorry, but PCL-10012 has already been dispatched, so its delivery address can't be changed now. If you need the parcel somewhere else, I can look up nearby Parcelly Lockers for pickup, or connect you with a person to discuss options.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
