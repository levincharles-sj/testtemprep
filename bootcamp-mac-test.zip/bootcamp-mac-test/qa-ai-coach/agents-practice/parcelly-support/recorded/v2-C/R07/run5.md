# Reference case R07 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.6 s. Tokens: 4 in, 415 out (5192 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer on order PCL-10013 says the parcel arrived almost a month late and wants compensation. The customer asked to speak with a person. No refund has been issued yet."} → ticket H-1001

**Agent's reply:**

> I've passed your request to a person on our support team, with a summary of your late delivery on order PCL-10013. Ticket H-1001 is open, and someone will reply within 24 hours. Thank you for your patience.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer on order PCL-10013 says the parcel arrived almost a month late and wants compensation. The customer asked to speak with a person. No refund has been issued yet."
- Address changes: none
