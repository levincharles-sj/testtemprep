# Reference case R07 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.7 s. Tokens: 4 in, 411 out (4441 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `handoff` with {"summary":"Customer asks for a person to discuss compensation. Order PCL-10013 arrived almost a month late. No refund or address change was requested in this chat."} → ticket H-1001

**Agent's reply:**

> I'm sorry your order PCL-10013 arrived almost a month late. I've passed your request for compensation to our support team under ticket H-1001. A person will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer asks for a person to discuss compensation. Order PCL-10013 arrived almost a month late. No refund or address change was requested in this chat."
- Address changes: none
