# Reference case R07 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 4.3 s. Tokens: 6 in, 569 out (8333 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `lookup_order` with {"order_id":"PCL-10013"} → PCL-10013: delivered, prepaid, total 1199, ordered 2026-10-20, delivered 2026-11-25
2. `handoff` with {"summary":"Customer asks for compensation for order PCL-10013 (school bag, Rs 1199, prepaid, shipping fee 0), which arrived almost a month late. Ordered 2026-10-20, dispatched 2026-10-21, delivere... → ticket H-1001

**Agent's reply:**

> I'll pull up order PCL-10013 so the person you speak with has the details.
> I've passed your request to a member of our support team, along with the details of order PCL-10013. Ticket H-1001 has been opened, and someone will reply within 24 hours. You won't need to repeat the story.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer asks for compensation for order PCL-10013 (school bag, Rs 1199, prepaid, shipping fee 0), which arrived almost a month late. Ordered 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25. No refunds issued so far. Customer asked to speak with a person about compensation."
- Address changes: none
