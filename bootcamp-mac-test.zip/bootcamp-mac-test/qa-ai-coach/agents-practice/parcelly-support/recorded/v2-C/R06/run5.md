# Reference case R06 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 4 s. Tokens: 4 in, 494 out (5202 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"cash on delivery return refund credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds go to your bank account by bank transfer, not as Parcelly credit. A support team member will contact you for your bank details, so please don't share them in this chat. Returns must be unused, in the original box, and sent back within 10 days of delivery. If you tell me the order ID, I can start the refund request.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
