# Reference case R06 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.6 s. Tokens: 4 in, 472 out (4446 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"return refund cash on delivery COD Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. A support team member will contact you to collect your bank details, and I can't collect them here. Most items can be returned within 10 days of delivery if they are unused and in their box (electronics need the original seal), and the refund is processed once the return reaches our warehouse.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
