# Reference case R06 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 4.1 s. Tokens: 4 in, 558 out (5202 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"cash on delivery return refund Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For a cash on delivery order, the refund is paid by bank transfer, not as Parcelly credit. A member of the support team will contact you for your bank details, so please don't share them with me. Returns are accepted within 10 days of delivery if the item is unused and in its box (electronics need the original seal), and the refund starts once the return reaches the warehouse.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
