# Reference case R06 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 4.1 s. Tokens: 4 in, 537 out (5202 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund for cash on delivery orders returns Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, the refund is paid by bank transfer, not as Parcelly credit. Returns must be within 10 days of delivery, unused, in the original box (electronics also need the original seal), and the refund starts once the return reaches our warehouse. A member of our support team will contact you for your bank details, since I can't collect them. If you tell me which order you want to return, I can pass your request to them.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
