# Reference case R12 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 4.1 s. Tokens: 6 in, 534 out (8145 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Cash on delivery order arrived broken (damaged item). Customer requests refund of 348 INR."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer requests refund of 348 INR for order PCL-10011. Order was cash on delivery and arrived broken. issue_refund declined because COD refunds are paid by bank transfer by a person (... → ticket H-1001

**Agent's reply:**

> I couldn't refund the ₹348 directly because cash-on-delivery refunds are paid by bank transfer, which a person has to process. I've passed your case to our support team with the details (ticket H-1001), and someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer requests refund of 348 INR for order PCL-10011. Order was cash on delivery and arrived broken. issue_refund declined because COD refunds are paid by bank transfer by a person (policy rule 7). Please process the bank transfer refund for the damaged item."
- Address changes: none
