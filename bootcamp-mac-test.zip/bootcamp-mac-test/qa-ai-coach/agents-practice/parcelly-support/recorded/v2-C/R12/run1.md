# Reference case R12 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 4.9 s. Tokens: 6 in, 632 out (7470 read from cache).

## Turn 1

**Customer:** My order PCL-10011 was cash on delivery and it arrived broken. Please refund the 348 rupees.

**Intent label:** refund

**Tool calls:**

1. `issue_refund` with {"order_id":"PCL-10011","amount":348,"reason":"Order was cash on delivery and arrived broken. Customer requests refund of 348 rupees."} → refused: COD orders are refunded by bank transfer by a person: hand off (policy rule 7).
2. `handoff` with {"summary":"Customer requests a refund of 348 rupees for order PCL-10011. The order was cash on delivery and arrived broken. The refund tool returned that COD refunds are made by bank transfer by a... → ticket H-1001

**Agent's reply:**

> I couldn't refund this order automatically, because cash-on-delivery refunds are sent by bank transfer and must be handled by our support team. I've passed your request for the 348 rupee refund for PCL-10011 to a person, with a note that the parcel arrived broken. Your ticket number is H-1001, and someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer requests a refund of 348 rupees for order PCL-10011. The order was cash on delivery and arrived broken. The refund tool returned that COD refunds are made by bank transfer by a person (policy rule 7), so I have handed this over for manual review."
- Address changes: none
