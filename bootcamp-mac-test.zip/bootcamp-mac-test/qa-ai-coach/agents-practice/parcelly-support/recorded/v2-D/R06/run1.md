# Reference case R06 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.9 s. Tokens: 4 in, 503 out (4739 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"cash on delivery return refund Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, your refund is paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details, and I can't take them myself. Returns must be made within 10 days of delivery, with the item unused and in its box (electronics also need the original seal). If you'd like to start a return or refund, tell me the order ID and I'll pass it to our team.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
