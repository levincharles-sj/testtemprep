# Reference case R06 · v2 · run 5 of 5

Recorded with fresh practice data before the conversation. Time: 3.8 s. Tokens: 4 in, 511 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"refund cash on delivery return Parcelly credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. A member of our support team will contact you to collect your bank details, and I can't collect them here. To return an item, it must be unused and in its box (electronics need the original seal), and you must return it within 10 days of delivery. If you tell me the order ID, I can check it and start the refund request.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
