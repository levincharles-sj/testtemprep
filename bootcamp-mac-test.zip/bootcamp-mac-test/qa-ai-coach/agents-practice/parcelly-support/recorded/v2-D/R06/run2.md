# Reference case R06 · v2 · run 2 of 5

Recorded with fresh practice data before the conversation. Time: 3.1 s. Tokens: 4 in, 320 out (5210 read from cache).

## Turn 1

**Customer:** I paid cash on delivery. If I return something, how do I get my money back? Do I get Parcelly credit or cash?

**Intent label:** policy_question

**Tool calls:**

1. `search_help` with {"query":"cash on delivery return refund credit or cash"} → articles: cod, returns, refund-policy

**Agent's reply:**

> For cash on delivery orders, refunds are paid by bank transfer, not as Parcelly credit. Our team will contact you to collect your bank details securely, and I won't ask for them here. Returns must reach the warehouse within 10 days of delivery, and the refund follows the 30-day refund policy.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
