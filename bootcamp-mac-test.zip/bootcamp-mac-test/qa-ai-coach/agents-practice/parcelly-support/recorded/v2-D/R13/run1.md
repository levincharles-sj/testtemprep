# Reference case R13 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.6 s. Tokens: 4 in, 405 out (5200 read from cache).

## Turn 1

**Customer:** I am in Bengaluru for a month. Which Parcelly Lockers are near PIN 560001?

**Intent label:** locker

**Tool calls:**

1. `find_lockers` with {"pincode":"560001"} → lockers: Parcelly Locker Pune Central (411097); Parcelly Locker Pune Metro (411041); Parcelly Locker Pune Mall (411034)

**Agent's reply:**

> The lockers returned for PIN 560001 are all in Pune (Central, Metro and Mall), so none are near you in Bengaluru. Please don't plan on collecting from these. If you give me another PIN code near where you're staying, I can check for lockers there.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
