# Reference case R04 · v2 · run 1 of 5

Recorded with fresh practice data before the conversation. Time: 3.7 s. Tokens: 4 in, 426 out (4727 read from cache).

## Turn 1

**Customer:** Please change the delivery address of PCL-10012 to 45, FC Road, Pune 411004.

**Intent label:** address_change

**Tool calls:**

1. `change_address` with {"order_id":"PCL-10012","new_address":"45, FC Road, Pune 411004"} → refused: The order is dispatched: the address can be changed only before dispatch.

**Agent's reply:**

> I'm sorry, but I can't change the delivery address for PCL-10012 because the order has already been dispatched. Address changes are only possible before dispatch. If you'd like, I can look for Parcelly Lockers near PIN code 411004 as a pickup option, or connect you with a person to discuss the delivery.

## After the conversation (what is stored)

- Refunds: none
- Tickets: none
- Address changes: none
