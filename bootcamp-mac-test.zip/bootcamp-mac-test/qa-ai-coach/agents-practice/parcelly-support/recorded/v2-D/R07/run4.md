# Reference case R07 · v2 · run 4 of 5

Recorded with fresh practice data before the conversation. Time: 3.8 s. Tokens: 6 in, 502 out (8261 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `lookup_order` with {"order_id":"PCL-10013"} → PCL-10013: delivered, prepaid, total 1199, ordered 2026-10-20, delivered 2026-11-25
2. `handoff` with {"summary":"Customer asks to speak with a person about compensation for order PCL-10013 (school bag, Rs 1199, prepaid). Ordered 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25, almost a mon... → ticket H-1001

**Agent's reply:**

> I'm sorry your order PCL-10013 arrived so late. I've passed your compensation request to our support team with the order details, so you won't need to repeat the story. Ticket H-1001 has been opened, and someone will reply within 24 hours.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer asks to speak with a person about compensation for order PCL-10013 (school bag, Rs 1199, prepaid). Ordered 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25, almost a month late. No refunds issued so far. Delivery address: 220, Brigade Road, Hyderabad 500089."
- Address changes: none
