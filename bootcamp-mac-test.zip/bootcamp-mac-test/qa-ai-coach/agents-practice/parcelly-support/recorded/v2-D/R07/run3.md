# Reference case R07 · v2 · run 3 of 5

Recorded with fresh practice data before the conversation. Time: 4.5 s. Tokens: 6 in, 619 out (8391 read from cache).

## Turn 1

**Customer:** My order PCL-10013 arrived almost a month late. I want to talk to a person about compensation, please.

**Intent label:** handoff

**Tool calls:**

1. `lookup_order` with {"order_id":"PCL-10013"} → PCL-10013: delivered, prepaid, total 1199, ordered 2026-10-20, delivered 2026-11-25
2. `handoff` with {"summary":"Customer (signed in) reports order PCL-10013 (school bag, Rs 1199, prepaid, placed 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25) arrived almost a month late. Customer request... → ticket H-1001

**Agent's reply:**

> I'll pull up order PCL-10013 so the person you speak with has the details.
> I've passed your request to our support team under ticket H-1001, with the details of order PCL-10013 (placed 20 October, delivered 25 November). A person will reply within 24 hours to discuss compensation. You don't need to repeat the story.

## After the conversation (what is stored)

- Refunds: none
- Tickets: H-1001, summary: "Customer (signed in) reports order PCL-10013 (school bag, Rs 1199, prepaid, placed 2026-10-20, dispatched 2026-10-21, delivered 2026-11-25) arrived almost a month late. Customer requests compensation and asks to speak with a person. No refunds issued on this order."
- Address changes: none
