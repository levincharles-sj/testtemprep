# Reference set (week 2)

Thirteen fixed customer conversations, the same for every tester. Each one was run **5 times** on **v1** and on the release candidate **v2**, with fresh practice data before each conversation. The recorded answers and traces are in `../recorded/`.

Use them on Thursday (reliability): does a case pass every time, sometimes, or never? Your own cases run live; the reference set saves your Claude seat from running 65 conversations per version.

`reference-cases.csv` uses the same columns as your golden set (`golden/golden.csv`). The expected answers follow the refund policy, the help articles and the practice data (check them with `lookup.mjs`). Read your recorded runs with `node reference.mjs list` and `node reference.mjs show R03` (the coach gives you the exact command).
