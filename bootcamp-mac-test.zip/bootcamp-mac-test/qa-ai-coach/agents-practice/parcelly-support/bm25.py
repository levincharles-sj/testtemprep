"""A small BM25 keyword search (no embeddings, no network), for the help articles."""
from __future__ import annotations

import math
import re
from collections import Counter

STOP = set("a an and are as at be by can do for from has have how i if in is it its my of on or the to was what when where which who will with you your this that not no".split())


def tokens(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP]


class BM25:
    def __init__(self, docs: dict[str, str], k1: float = 1.5, b: float = 0.75):
        self.keys = list(docs)
        self.tf = [Counter(tokens(docs[k])) for k in self.keys]
        self.len = [sum(c.values()) for c in self.tf]
        self.avg = sum(self.len) / max(len(self.len), 1)
        df = Counter(w for c in self.tf for w in c)
        n = len(self.keys)
        self.idf = {w: math.log(1 + (n - f + 0.5) / (f + 0.5)) for w, f in df.items()}
        self.k1, self.b = k1, b

    def search(self, query: str, k: int = 3) -> list[tuple[str, float]]:
        q = tokens(query)
        scores = []
        for i, c in enumerate(self.tf):
            s = 0.0
            for w in q:
                f = c.get(w, 0)
                if f:
                    s += self.idf[w] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * self.len[i] / self.avg))
            scores.append((self.keys[i], round(s, 4)))
        return sorted([x for x in scores if x[1] > 0], key=lambda x: -x[1])[:k]
