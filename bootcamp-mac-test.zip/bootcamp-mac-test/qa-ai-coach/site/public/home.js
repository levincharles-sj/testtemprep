// Home page: rooms, the availability search, the date pickers and the contact form.
(function () {
  const { icon, ymd, dmy, parseDmy, esc, frame } = window.SM;
  const form = document.getElementById("availability");
  const inIn = form.elements.checkin, inOut = form.elements.checkout;
  const today = new Date();
  const tomorrow = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
  inIn.value = dmy(today);
  inOut.value = dmy(tomorrow);
  let lastGood = { checkin: today, checkout: tomorrow };

  // The dates the boxes hold now (a box that cannot be read keeps its last good date).
  function dates() {
    const ci = parseDmy(inIn.value), co = parseDmy(inOut.value);
    if (ci) lastGood.checkin = ci;
    if (co) lastGood.checkout = co;
    return { checkin: ymd(lastGood.checkin), checkout: ymd(lastGood.checkout) };
  }

  function renderRooms(rooms) {
    const list = document.getElementById("room-list");
    // The page shows at most 3 rooms.
    const shown = rooms.slice(0, 3);
    if (!shown.length) { list.innerHTML = '<p class="no-rooms">No rooms are free for these dates.</p>'; return; }
    list.innerHTML = shown.map((r) => `
      <div class="room-card">
        <img src="${esc(r.image)}" alt="Single Room">
        <div class="card-body">
          <h5>${esc(r.type)}</h5>
          <p class="card-text">${esc(r.description)}</p>
          <div class="chips">${r.features.map((f) => `<span class="chip">${icon(f, 12)} ${esc(f)}</span>`).join("")}</div>
        </div>
        <div class="card-footer">
          <div class="price">£${r.roomPrice} <small>per night</small></div>
          <a class="btn btn-primary book-now" data-room="${r.roomid}" href="/reservation/${r.roomid}">Book now</a>
        </div>
      </div>`).join("");
  }

  document.getElementById("room-list").addEventListener("click", (e) => {
    const a = e.target.closest("a.book-now");
    if (!a) return;
    const d = dates();
    a.href = `/reservation/${a.dataset.room}?checkin=${d.checkin}&checkout=${d.checkout}`;
  });

  async function loadRooms(query) {
    const res = await fetch("/api/room" + (query || ""));
    const data = await res.json();
    renderRooms(data.rooms);
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const d = dates();
    await loadRooms(`?checkin=${d.checkin}&checkout=${d.checkout}`);
    document.getElementById("rooms").scrollIntoView();
  });

  // --- date pickers: past days are not blocked ---
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  function picker(input) {
    const box = input.parentElement.querySelector(".datepicker");
    let view = parseDmy(input.value) || today;
    view = new Date(view.getFullYear(), view.getMonth(), 1);
    function draw() {
      const sel = parseDmy(input.value);
      const first = new Date(view.getFullYear(), view.getMonth(), 1);
      const days = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
      let cells = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => `<span>${d}</span>`).join("");
      for (let i = 0; i < first.getDay(); i++) cells += "<span></span>";
      for (let d = 1; d <= days; d++) {
        const on = sel && sel.getFullYear() === view.getFullYear() && sel.getMonth() === view.getMonth() && sel.getDate() === d;
        cells += `<button type="button" tabindex="-1" data-day="${d}" class="${on ? "sel" : ""}">${d}</button>`;
      }
      box.innerHTML = `<div class="dp-head"><button type="button" tabindex="-1" data-move="-1">&lsaquo;</button><span>${MONTHS[view.getMonth()]} ${view.getFullYear()}</span><button type="button" tabindex="-1" data-move="1">&rsaquo;</button></div><div class="dp-grid">${cells}</div>`;
    }
    box.addEventListener("mousedown", (e) => {
      e.preventDefault();
      const b = e.target.closest("button");
      if (!b) return;
      if (b.dataset.move) { view = new Date(view.getFullYear(), view.getMonth() + Number(b.dataset.move), 1); draw(); return; }
      input.value = dmy(new Date(view.getFullYear(), view.getMonth(), Number(b.dataset.day)));
      box.hidden = true;
    });
    input.addEventListener("focus", () => { const d = parseDmy(input.value); if (d) view = new Date(d.getFullYear(), d.getMonth(), 1); draw(); box.hidden = false; });
    input.addEventListener("blur", () => { box.hidden = true; });
    input.addEventListener("input", () => { const d = parseDmy(input.value); if (d) { view = new Date(d.getFullYear(), d.getMonth(), 1); draw(); } });
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); box.hidden = true; } if (e.key === "Escape") box.hidden = true; });
  }
  picker(inIn);
  picker(inOut);

  // --- contact form ---
  const cform = document.getElementById("contact-form");
  cform.addEventListener("submit", async (e) => {
    e.preventDefault();
    const body = { name: cform.elements.name.value, email: cform.elements.email.value, phone: cform.elements.phone.value, subject: cform.elements.subject.value, description: cform.elements.description.value };
    const res = await fetch("/api/message", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json();
    if (res.ok) {
      document.getElementById("contact-body").innerHTML = `<div class="contact-thanks"><h3>Thanks for getting in touch ${esc(body.name)}!</h3><p>We'll get back to you about <strong>${esc(body.subject)}</strong> as soon as possible.</p></div>`;
      return;
    }
    document.getElementById("contact-errors").innerHTML = `<div class="alert alert-danger">${data.map((m) => `<p>${esc(m)}</p>`).join("")}</div>`;
  });

  frame().then((b) => {
    const a = b.address || {};
    document.getElementById("contact-lines").innerHTML = `
      <p><strong>Address</strong></p><p>${esc(a.line1 || "")}, ${esc(a.line2 || "")}<br>${esc(a.postTown || "")}, ${esc(a.county || "")}<br>${esc(a.postCode || "")}</p>
      <p style="margin-top:.75rem"><strong>Phone</strong></p><p>${esc((b.contact || {}).phone || "")}</p>
      <p style="margin-top:.75rem"><strong>Email</strong></p><p>${esc((b.contact || {}).email || "")}</p>
      <p style="margin-top:.75rem"><strong>Getting here</strong></p><p>${esc(b.directions || "")}</p>`;
  });
  loadRooms("");
})();
