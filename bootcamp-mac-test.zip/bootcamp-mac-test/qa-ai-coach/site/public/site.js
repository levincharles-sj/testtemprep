// Shared parts of the Shady Meadows B&B practice site: menu, footer, icons, dates, the crash page.
(function () {
  const svg = (inner, size = 16) => `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
  const ICONS = {
    TV: '<rect x="1.5" y="3" width="13" height="8.5" rx="1"/><path d="M5.5 14h5"/>',
    WiFi: '<path d="M1.5 6.5a9.5 9.5 0 0 1 13 0"/><path d="M3.7 8.8a6.3 6.3 0 0 1 8.6 0"/><path d="M5.9 11a3.2 3.2 0 0 1 4.2 0"/><circle cx="8" cy="13" r=".6" fill="currentColor"/>',
    Safe: '<rect x="1.5" y="2" width="13" height="12" rx="1"/><circle cx="8" cy="8" r="2.5"/><path d="M8 5.5v1M8 9.5v1M5.5 8h1M9.5 8h1"/>',
    Radio: '<rect x="3.5" y="1.5" width="9" height="13" rx="1"/><circle cx="8" cy="10" r="2.3"/><circle cx="8" cy="4.6" r="1"/>',
    Views: '<path d="M1 12l4-5 3 3 2-2 5 4z"/><circle cx="11.5" cy="4.5" r="1.3"/>',
    Refreshments: '<path d="M3 4h8v5a4 4 0 0 1-8 0z"/><path d="M11 5h1.5a1.5 1.5 0 0 1 0 3H11"/>',
    user: '<circle cx="8" cy="5" r="3"/><path d="M2.5 14.5c.6-3 2.8-4.5 5.5-4.5s4.9 1.5 5.5 4.5"/>',
    people: '<circle cx="5.5" cy="5" r="2.3" fill="currentColor"/><circle cx="11" cy="5.5" r="2" fill="currentColor"/><path d="M1 13c.4-2.6 2-3.8 4.5-3.8S9.6 10.4 10 13z" fill="currentColor"/><path d="M10.8 9.4c2.2 0 3.6 1.1 4 3.6h-3.4" fill="currentColor"/>',
    clock: '<circle cx="8" cy="8" r="6.5"/><path d="M8 4.5V8l2.5 1.5"/>',
    info: '<circle cx="8" cy="8" r="6.5"/><path d="M8 7.2v4"/><circle cx="8" cy="5" r=".5" fill="currentColor"/>',
    no: '<circle cx="8" cy="8" r="6.5"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5"/>',
    maybe: '<circle cx="8" cy="8" r="6.5"/><path d="M6.2 6.2a1.9 1.9 0 1 1 2.6 1.8c-.5.2-.8.6-.8 1.1v.4"/><circle cx="8" cy="11.6" r=".5" fill="currentColor"/>',
    card: '<rect x="1" y="3" width="14" height="10" rx="1" fill="currentColor"/><rect x="3" y="6" width="4" height="3.5" fill="#fff" stroke="none"/><path d="M9 6.5h4M9 9h3" stroke="#fff"/>',
    mail: '<rect x="1" y="3" width="14" height="10" rx="1" fill="currentColor"/><path d="M1.5 3.5L8 9l6.5-5.5" stroke="#fff"/>',
    phone: '<path d="M4 1.5l2 3-1.3 1.5a8 8 0 0 0 5.3 5.3L11.5 10l3 2-1 2.5C7 14.5 1.5 9 1.5 2.5z" fill="currentColor"/>',
    pin: '<path d="M8 15s5-5 5-8.5a5 5 0 0 0-10 0C3 10 8 15 8 15z"/><circle cx="8" cy="6.5" r="1.8"/>',
    globe: '<circle cx="8" cy="8" r="6"/><path d="M2 8h12M8 2c2 2 2 10 0 12M8 2c-2 2-2 10 0 12"/>',
    camera: '<rect x="2" y="4" width="12" height="9" rx="2"/><circle cx="8" cy="8.5" r="2.3"/><path d="M5.5 4l1-1.5h3l1 1.5"/>',
    share: '<circle cx="4" cy="8" r="1.8"/><circle cx="12" cy="4" r="1.8"/><circle cx="12" cy="12" r="1.8"/><path d="M5.6 7.2l4.8-2.4M5.6 8.8l4.8 2.4"/>',
  };
  const icon = (name, size) => svg(ICONS[name] || ICONS.info, size);

  const pad = (n) => String(n).padStart(2, "0");
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const dmy = (d) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
  const parseYmd = (s) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ""); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
  const parseDmy = (s) => { const m = /^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*$/.exec(s || ""); if (!m) return null; const d = new Date(+m[3], +m[2] - 1, +m[1]); return d.getMonth() === +m[2] - 1 ? d : null; };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function navbar() {
    const links = [["Rooms", "/#rooms"], ["Booking", "/#booking"], ["Amenities", "/#amenities"], ["Location", "/#location"], ["Contact", "/#contact"], ["Admin", "/admin"]];
    return `<nav class="navbar"><div class="container">
      <a class="navbar-brand" href="/">Shady Meadows B&amp;B</a>
      <button class="navbar-toggler" type="button"><span>&#9776;</span></button>
      <div class="navbar-collapse"><ul class="navbar-nav">${links.map(([t, h]) => `<li class="nav-item"><a class="nav-link" href="${h}">${t}</a></li>`).join("")}</ul></div>
    </div></nav>`;
  }

  function footer(b) {
    const a = b.address;
    return `<footer><div class="container">
      <div class="footer-grid">
        <div><h5>${esc(b.name)}</h5><p>${esc(b.description)}</p>
          <div class="socials"><a href="#" class="btn rounded-circle">${icon("globe", 14)}</a><a href="#" class="btn rounded-circle">${icon("camera", 14)}</a><a href="#" class="btn rounded-circle">${icon("share", 14)}</a></div></div>
        <div><h5>Contact Us</h5><div class="contact-lines">
          <div>${icon("pin")}<span>${esc(a.line1)}, ${esc(a.line2)}, ${esc(a.postTown)}, ${esc(a.county)}, ${esc(a.postCode)}</span></div>
          <div>${icon("phone")}<span>${esc(b.contact.phone)}</span></div>
          <div>${icon("mail")}<span>${esc(b.contact.email)}</span></div></div></div>
        <div class="quick"><h5>Quick Links</h5><ul><li><a href="#">Home</a></li><li><a href="#">Rooms</a></li><li><a href="#">Booking</a></li><li><a href="#">Contact</a></li></ul></div>
      </div>
      <div class="footer-bottom">
        <p class="credit">Practice copy for the QA AI Programme, modelled on the Restful Booker Platform practice site</p>
        <p>restful-booker-platform v2.2 - &copy; 2019-26 <a href="/cookie">Cookie-Policy</a> - <a href="/privacy">Privacy-Policy</a> - <a href="/admin">Admin panel</a></p>
      </div>
    </div></footer>`;
  }

  // Fallback branding, so the frame draws even before /api/branding answers.
  const BRANDING = { name: "Shady Meadows B&B", description: "", contact: { phone: "", email: "" }, address: { line1: "", line2: "", postTown: "", county: "", postCode: "" } };

  async function frame() {
    document.getElementById("nav").innerHTML = navbar();
    const t = document.querySelector(".navbar-toggler");
    t.addEventListener("click", () => document.querySelector(".navbar-collapse").classList.toggle("show"));
    let b = BRANDING;
    try { b = await (await fetch("/api/branding")).json(); } catch (e) { /* keep fallback */ }
    document.getElementById("foot").innerHTML = footer(b);
    return b;
  }

  // When the page's own code throws, the whole page is replaced by this (like the original site's error page).
  function crashPage() {
    document.title = "Shady Meadows B&B";
    document.body.className = "";
    document.body.innerHTML = `<div class="crash"><div class="crash-box">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#171717" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
      <h2>This page couldn’t load</h2>
      <p>Reload to try again, or go back.</p>
      <button class="dark" type="button" onclick="location.reload()">Reload</button><button type="button" onclick="history.back()">Back</button>
    </div></div>`;
  }
  window.addEventListener("error", () => { if (!document.querySelector(".crash")) crashPage(); });

  window.SM = { icon, ymd, dmy, parseYmd, parseDmy, esc, frame };
})();
