// Room page: room details, the calendar, the Price Summary, the booking form and Similar Rooms.
(function () {
  const { icon, ymd, parseYmd, esc, frame } = window.SM;
  const roomId = decodeURIComponent(location.pathname.split("/")[2] || "");
  const params = new URLSearchParams(location.search);
  const DAY = 24 * 60 * 60 * 1000;
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  const state = {
    room: null,
    checkin: params.get("checkin"),
    checkout: params.get("checkout"),
    mode: "summary", // summary | form | confirmed
    errors: [],
    month: new Date(new Date().getFullYear(), new Date().getMonth(), 1), // the calendar always opens on this month
    picked: null,
    form: { firstname: "", lastname: "", email: "", phone: "" },
  };

  const nights = () => Math.round((parseYmd(state.checkout) - parseYmd(state.checkin)) / DAY);

  function renderMain(room) {
    document.getElementById("crumb").textContent = `${room.type} Room`;
    document.getElementById("room-main").innerHTML = `
      <h1 class="room-title">${esc(room.type)} Room</h1>
      <div class="badges">${room.accessible ? '<span class="badge-green">Accessible</span>' : ""}<span>${icon("people")} Max 2 Guests</span></div>
      <img class="room-hero" src="${esc(room.image)}" alt="${esc(room.type)} Room">
      <h2>Room Description</h2>
      <p>${esc(room.description)}</p>
      <h2>Room Features</h2>
      <div class="features">${room.features.map((f) => `<div class="feature"><span class="icon">${icon(f, 22)}</span>${esc(f)}</div>`).join("")}</div>
      <h2>Room Policies</h2>
      <div class="policies">
        <div class="policy"><h3>Check-in &amp; Check-out</h3>
          <p>${icon("clock")}<span><strong>Check-in:</strong> 3:00 PM - 8:00 PM</span></p>
          <p>${icon("clock")}<span><strong>Check-out:</strong> By 11:00 AM</span></p>
          <p>${icon("info")}<span><strong>Early/Late:</strong> By arrangement</span></p></div>
        <div class="policy"><h3>House Rules</h3>
          <p style="color:#dc3545">${icon("no")}<span style="color:#212529">No smoking</span></p>
          <p style="color:#dc3545">${icon("no")}<span style="color:#212529">No parties or events</span></p>
          <p style="color:#ffc107">${icon("maybe")}<span style="color:#212529">Pets allowed (restrictions apply)</span></p></div>
      </div>`;
  }

  function calendar() {
    const m = state.month;
    const start = new Date(m.getFullYear(), m.getMonth(), 1 - m.getDay());
    const last = new Date(m.getFullYear(), m.getMonth() + 1, 0);
    const weeks = Math.ceil((m.getDay() + last.getDate()) / 7);
    const todayKey = ymd(new Date());
    let html = '<div class="cal-head">' + ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => `<div>${d}</div>`).join("") + "</div>";
    for (let w = 0; w < weeks; w++) {
      html += '<div class="cal-week">';
      for (let i = 0; i < 7; i++) {
        const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + w * 7 + i);
        const key = ymd(d);
        const cls = [d.getMonth() !== m.getMonth() ? "off" : "", key === todayKey ? "today" : "", state.picked && key >= state.picked[0] && key <= state.picked[1] ? "picked" : ""].filter(Boolean).join(" ");
        html += `<button type="button" class="${cls}" data-date="${key}">${String(d.getDate()).padStart(2, "0")}</button>`;
      }
      html += "</div>";
    }
    return `<div class="cal-toolbar"><span class="btn-group"><button type="button" data-cal="today">Today</button><button type="button" data-cal="back">Back</button><button type="button" data-cal="next">Next</button></span><span class="cal-label">${MONTHS[m.getMonth()]} ${m.getFullYear()}</span></div><div class="calendar">${html}</div>`;
  }

  function summary() {
    const p = state.room.roomPrice, n = nights();
    return `<div class="summary"><h3>Price Summary</h3>
      <div class="line"><span>£${p} x ${n} nights</span><span>£${p * n}</span></div>
      <div class="line"><span>Cleaning fee</span><span>£25</span></div>
      <div class="line"><span>Service fee</span><span>£15</span></div>
      <hr><div class="line total"><span>Total</span><span>£${p * n + 25 + 15}</span></div></div>`;
  }

  function field(name, label, kind, type) {
    return `<div class="input-group"><span class="input-group-text">${icon(kind)}</span><input type="${type}" class="form-control room-${name}" name="${name}" placeholder="${label}" aria-label="${label}" value="${esc(state.form[name])}"></div>`;
  }

  function renderPanel() {
    const body = document.getElementById("book-body");
    const room = state.room;
    const price = `<div class="book-price">£${room.roomPrice} <small>per night</small></div>`;
    if (!state.checkin || !state.checkout) { body.innerHTML = price + '<div class="spinner" role="status"></div>'; return; }
    if (state.mode === "confirmed") {
      body.innerHTML = `<div class="confirmed"><h3>Booking Confirmed</h3><p>Your booking has been confirmed for the following dates:</p><p><strong>${esc(state.checkin)} - ${esc(state.checkout)}</strong></p><a class="btn btn-primary w-100" href="/">Return home</a></div>`;
      return;
    }
    if (state.mode === "form") {
      const errorBox = state.errors.length ? `<div class="alert alert-danger" role="alert"><ul>${state.errors.map((e) => `<li>${esc(e)}</li>`).join("")}</ul></div>` : "";
      body.innerHTML = price + errorBox + field("firstname", "Firstname", "card", "text") + field("lastname", "Lastname", "card", "text") + field("email", "Email", "mail", "email") + field("phone", "Phone", "phone", "tel") + summary() +
        '<button type="button" class="btn btn-primary" id="doReservation">Reserve Now</button><button type="button" class="btn btn-secondary" id="cancel">Cancel</button>';
      return;
    }
    body.innerHTML = price + calendar() + summary() + '<button type="button" class="btn btn-primary" id="doReservation">Reserve Now</button>';
  }

  function renderSimilar(rooms) {
    const others = rooms.filter((r) => String(r.roomid) !== String(roomId)).slice(0, 3);
    const q = state.checkin && state.checkout ? `?checkin=${state.checkin}&checkout=${state.checkout}` : "";
    document.getElementById("similar").innerHTML = others.map((r) => `
      <div class="room-card"><img src="${esc(r.image)}" alt="${esc(r.type)} Room">
        <div class="card-body"><h5>${esc(r.type)}</h5>
          <div class="meta"><span>${icon("user", 13)} 2 Guests</span><span><strong>£${r.roomPrice}</strong>/night</span></div>
          <p class="card-text">${esc(r.description)}</p>
          <a class="btn btn-outline-primary" href="/reservation/${r.roomid}${q}">View Details</a></div></div>`).join("");
  }

  // --- events on the booking panel ---
  const card = document.getElementById("book-card");
  card.addEventListener("input", (e) => { if (e.target.name in state.form) state.form[e.target.name] = e.target.value; });
  card.addEventListener("click", (e) => {
    const cal = e.target.closest("[data-cal]");
    if (cal) {
      const m = state.month;
      if (cal.dataset.cal === "today") state.month = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
      else state.month = new Date(m.getFullYear(), m.getMonth() + (cal.dataset.cal === "next" ? 1 : -1), 1);
      renderPanel();
      return;
    }
    if (e.target.id === "cancel") { state.mode = "summary"; state.errors = []; renderPanel(); return; }
    if (e.target.id !== "doReservation") return;
    if (state.mode === "summary") { state.mode = "form"; renderPanel(); return; }
    book();
  });

  // Days on the calendar can only be chosen by dragging with the mouse (Enter on a day does nothing).
  let dragFrom = null;
  card.addEventListener("mousedown", (e) => { const b = e.target.closest("[data-date]"); if (b) { dragFrom = b.dataset.date; e.preventDefault(); } });
  document.addEventListener("mouseup", (e) => {
    if (!dragFrom) return;
    const b = e.target.closest && e.target.closest("[data-date]");
    const to = b ? b.dataset.date : dragFrom;
    const [a, z] = [dragFrom, to].sort();
    dragFrom = null;
    const end = parseYmd(z);
    state.picked = [a, z];
    state.checkin = a;
    state.checkout = ymd(new Date(end.getFullYear(), end.getMonth(), end.getDate() + 1));
    renderPanel();
  });

  async function book() {
    const payload = { roomid: Number(roomId), firstname: state.form.firstname, lastname: state.form.lastname, depositpaid: false, bookingdates: { checkin: state.checkin, checkout: state.checkout }, email: state.form.email, phone: state.form.phone };
    const res = await fetch("/api/booking", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const data = await res.json();
    setTimeout(() => {
      if (res.status === 201) { state.mode = "confirmed"; renderPanel(); return; }
      state.errors = data.errors;
      renderPanel();
    });
  }

  // --- load ---
  frame();
  fetch(`/api/room/${encodeURIComponent(roomId)}`).then((r) => r.json()).then((room) => {
    setTimeout(() => {
      state.room = room;
      renderMain(room);
      renderPanel();
    });
  });
  // The booked days come back here, but the calendar does not show them.
  fetch(`/api/report/room/${encodeURIComponent(roomId)}`).then((r) => r.json()).then((data) => { state.report = data.report; });
  fetch("/api/room").then((r) => r.json()).then((data) => renderSimilar(data.rooms));
})();
