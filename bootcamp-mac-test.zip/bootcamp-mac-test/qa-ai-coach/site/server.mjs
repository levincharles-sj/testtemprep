#!/usr/bin/env node
// Shady Meadows B&B: the week 2 practice site, run on the tester's own laptop.
// A small practice copy, modelled on the public Restful Booker Platform practice site (written from scratch for the
// QA AI Programme; no code copied). Its practice bugs are deliberate: they are what week 2 teaches.
//
// Usage: node server.mjs            (http://127.0.0.1:3080; PORT=<n> to change the port)
// - Node built-ins only, one process, binds 127.0.0.1 only.
// - All data is in memory. Every start gives fresh seed data; nothing is written to disk.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(HERE, "public");
export const DEFAULT_PORT = 3080;
export const SITE_ID = "qa-ai-coach-shady-meadows";

// ---------- dates (local calendar days, YYYY-MM-DD) ----------
const pad = (n) => String(n).padStart(2, "0");
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

// ---------- seed data (fresh on every start) ----------
const ROOM_TEXT = {
  Single: "A quiet single room at the back of the house, with a desk by the window and a view of the garden. Breakfast is served downstairs.",
  Double: "A bright double room on the first floor, with a large bed, a reading chair and a view over the meadow at the front of the house.",
  Suite: "Our largest room: a suite with a king-size bed, a sitting area and its own small balcony. Good for longer stays.",
};

export function seed(now = new Date()) {
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const rooms = [
    { roomid: 1, roomName: "101", type: "Single", accessible: true, image: "/images/room1.svg", description: ROOM_TEXT.Single, features: ["TV", "WiFi", "Safe"], roomPrice: 100 },
    { roomid: 2, roomName: "102", type: "Double", accessible: true, image: "/images/room2.svg", description: ROOM_TEXT.Double, features: ["TV", "Radio", "Safe"], roomPrice: 150 },
    { roomid: 3, roomName: "103", type: "Suite", accessible: true, image: "/images/room3.svg", description: ROOM_TEXT.Suite, features: ["Radio", "WiFi", "Safe"], roomPrice: 225 },
  ];
  // Made-up guests. The first three are fixed dates; the last three sit a few days from today, so the
  // room report (GET /api/report/room/{id}) always has a booked range near the month the calendar opens on.
  const near = (a, b) => ({ checkin: ymd(addDays(today, a)), checkout: ymd(addDays(today, b)) });
  const bookings = [
    { roomid: 1, firstname: "James", lastname: "Dean", bookingdates: { checkin: "2026-02-01", checkout: "2026-02-05" } },
    { roomid: 2, firstname: "Erica", lastname: "Bowthorpe", bookingdates: { checkin: "2026-02-02", checkout: "2026-02-04" } },
    { roomid: 3, firstname: "Timothy", lastname: "Barrow", bookingdates: { checkin: "2026-03-01", checkout: "2026-03-05" } },
    { roomid: 1, firstname: "Priya", lastname: "Sample", bookingdates: near(2, 4) },
    { roomid: 2, firstname: "Ravi", lastname: "Example", bookingdates: near(3, 5) },
    { roomid: 3, firstname: "Meera", lastname: "Placeholder", bookingdates: near(5, 7) },
  ].map((b, i) => ({ bookingid: i + 1, depositpaid: true, email: `${b.firstname.toLowerCase()}@example.com`, phone: "01234567890", ...b }));
  const messages = [
    { messageid: 1, name: "James Dean", email: "james.dean@example.com", phone: "01402619211", subject: "Booking enquiry", description: "I would like to book a room at your place for two nights next spring. Is that possible?", read: false },
  ];
  return { rooms, bookings, messages, nextBooking: bookings.length + 1, nextMessage: messages.length + 1 };
}

// ---------- validation (the practice bugs live here on purpose) ----------
/** Booking checks. The messages name no field and come back in a random order (practice bug). */
export function bookingErrors(b) {
  const errs = [];
  const s = (v) => (typeof v === "string" ? v : v == null ? "" : String(v));
  const first = s(b.firstname), last = s(b.lastname), email = s(b.email), phone = s(b.phone);
  if (!first.trim()) errs.push("Firstname should not be blank");
  if (first.length < 3 || first.length > 18) errs.push("size must be between 3 and 18");
  if (!last.trim()) errs.push("Lastname should not be blank");
  if (last.length < 3 || last.length > 30) errs.push("size must be between 3 and 30");
  if (!email) errs.push("must not be empty");
  else if (!/^[^\s@]+@[^\s@]+$/.test(email)) errs.push("must be a well-formed email address");
  if (!phone) errs.push("must not be empty");
  if (phone.length < 11 || phone.length > 21) errs.push("size must be between 11 and 21");
  return shuffle(errs);
}

/** Contact form checks: named messages, random order. */
export function messageErrors(m) {
  const errs = [];
  const s = (v) => (typeof v === "string" ? v : v == null ? "" : String(v));
  const name = s(m.name), email = s(m.email), phone = s(m.phone), subject = s(m.subject), text = s(m.description);
  if (!name.trim()) errs.push("Name may not be blank");
  if (!email.trim()) errs.push("Email may not be blank");
  else if (!/^[^\s@]+@[^\s@]+$/.test(email)) errs.push("must be a well-formed email address");
  if (!phone.trim()) errs.push("Phone may not be blank");
  if (phone.length < 11 || phone.length > 21) errs.push("Phone must be between 11 and 21 characters.");
  if (!subject.trim()) errs.push("Subject may not be blank");
  if (subject.length < 5 || subject.length > 100) errs.push("Subject must be between 5 and 100 characters.");
  if (!text.trim()) errs.push("Message may not be blank");
  if (text.length < 20 || text.length > 2000) errs.push("Message must be between 20 and 2000 characters.");
  return shuffle(errs);
}

function shuffle(list) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  // A list of 2 or more always comes back in a new order compared with the last reply of the same size.
  const key = a.length;
  if (a.length > 1 && shuffle.last[key] === a.join("|")) a.push(a.shift());
  shuffle.last[key] = a.join("|");
  return a;
}
shuffle.last = {};

/** Availability search: a room is hidden only when a booking lies wholly inside the searched dates (practice bug). */
export function freeRooms(db, checkin, checkout) {
  return db.rooms.filter((r) => !db.bookings.some((b) => b.roomid === r.roomid && b.bookingdates.checkin >= checkin && b.bookingdates.checkout <= checkout));
}

/** The server does refuse a clash; it also answers 409 for check-out on or before check-in. */
function clashes(db, roomid, checkin, checkout) {
  if (!(checkout > checkin)) return true;
  return db.bookings.some((b) => b.roomid === roomid && checkin < b.bookingdates.checkout && b.bookingdates.checkin < checkout);
}

// ---------- HTTP helpers ----------
// Status lines carry no reason phrase (like the HTTP/2 site), so the browser Console says "status of 409 ()".
function send(res, status, body, type = "application/json") {
  const data = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, "", { "Content-Type": `${type}; charset=utf-8`, "Cache-Control": "no-store", "X-Practice-Site": SITE_ID, "X-Practice-Site-Root": encodeURIComponent(HERE) });
  res.end(data);
}
const json = (res, status, body) => send(res, status, body);

function readBody(req, limit = 100_000) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) { reject(new Error("too large")); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

const MIME = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon" };

function serveFile(res, rel, status = 200) {
  const file = path.join(PUBLIC, rel);
  if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return false;
  const type = MIME[path.extname(file)] || "application/octet-stream";
  res.writeHead(status, { "Content-Type": type + (type.startsWith("text/") || type.endsWith("xml") ? "; charset=utf-8" : ""), "Cache-Control": "no-store" });
  res.end(fs.readFileSync(file));
  return true;
}

const PLAIN_PAGE = (title, text) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${title}</title><link rel="stylesheet" href="/style.css"></head><body class="plain-page"><main class="container plain"><h1>${title}</h1>${text}<p><a href="/">Back to Shady Meadows B&amp;B</a></p></main></body></html>`;

const BRANDING = {
  name: "Shady Meadows B&B",
  map: { latitude: 52.6351, longitude: 1.2988 },
  logoUrl: "/images/logo.svg",
  description: "Welcome to Shady Meadows, a small bed and breakfast in a quiet valley. Every room has a comfortable bed, and breakfast is made each morning with food from the farm down the road.",
  directions: "From the village green, follow Meadow Lane for half a mile. The house is on the left, after the old mill.",
  contact: { name: "Shady Meadows B&B", phone: "012345678901", email: "fake@fakeemail.com" },
  address: { line1: "Shady Meadows B&B", line2: "Shadows valley", postTown: "Newingtonfordburyshire", county: "Dilbery", postCode: "N1 1AA" },
};

// ---------- the app ----------
export function createApp({ now = () => new Date() } = {}) {
  const db = seed(now());

  async function api(req, res, url) {
    const p = url.pathname.replace(/^\/api/, "") || "/";
    const m = req.method;
    let mm;
    if (p === "/branding" && m === "GET") return json(res, 200, BRANDING);
    if (p === "/room" && m === "GET") {
      const ci = url.searchParams.get("checkin"), co = url.searchParams.get("checkout");
      const list = ci && co ? freeRooms(db, ci, co) : db.rooms;
      return json(res, 200, { rooms: list });
    }
    if ((mm = p.match(/^\/room\/([^/]+)$/)) && m === "GET") {
      const room = db.rooms.find((r) => String(r.roomid) === mm[1]);
      if (!room) return json(res, 500, { timestamp: new Date().toISOString().replace("Z", "+00:00"), status: 500, error: "Internal Server Error", path: `/room/${mm[1]}` });
      return json(res, 200, room);
    }
    if ((mm = p.match(/^\/report\/room\/([^/]+)$/)) && m === "GET") {
      const report = db.bookings.filter((b) => String(b.roomid) === mm[1]).map((b) => ({ start: b.bookingdates.checkin, end: b.bookingdates.checkout, title: "Unavailable" }));
      return json(res, 200, { report });
    }
    if (p === "/booking" && m === "GET") return json(res, 401, { error: "Authentication required" });
    if (p === "/booking" && m === "POST") {
      let b;
      try { b = JSON.parse(await readBody(req)); } catch { return json(res, 400, { errors: ["Request body could not be read"] }); }
      if (!b || typeof b !== "object") b = {};
      const errors = bookingErrors(b);
      if (errors.length) return json(res, 400, { errors });
      const roomid = Number(b.roomid);
      const ci = b.bookingdates && b.bookingdates.checkin, co = b.bookingdates && b.bookingdates.checkout;
      if (!db.rooms.some((r) => r.roomid === roomid) || !ISO_DAY.test(String(ci)) || !ISO_DAY.test(String(co)) || clashes(db, roomid, ci, co)) {
        return json(res, 409, { error: "Failed to create booking" });
      }
      const booking = { bookingid: db.nextBooking++, roomid, firstname: String(b.firstname), lastname: String(b.lastname), depositpaid: Boolean(b.depositpaid), email: String(b.email), phone: String(b.phone), bookingdates: { checkin: ci, checkout: co } };
      db.bookings.push(booking);
      return json(res, 201, booking);
    }
    if (p === "/message" && m === "POST") {
      let msg;
      try { msg = JSON.parse(await readBody(req)); } catch { return json(res, 400, ["Request body could not be read"]); }
      if (!msg || typeof msg !== "object") msg = {};
      const errors = messageErrors(msg);
      if (errors.length) return json(res, 400, errors);
      db.messages.push({ messageid: db.nextMessage++, name: String(msg.name), email: String(msg.email), phone: String(msg.phone), subject: String(msg.subject), description: String(msg.description), read: false });
      return json(res, 200, { success: true });
    }
    // Guest messages are open to anyone, without a login (practice bug).
    if (p === "/message" && m === "GET") return json(res, 200, { messages: db.messages.map(({ messageid, name, subject, read }) => ({ id: messageid, name, subject, read })) });
    if (p === "/message/count" && m === "GET") return json(res, 200, { count: db.messages.filter((x) => !x.read).length });
    if ((mm = p.match(/^\/message\/(\d+)$/)) && m === "GET") {
      const msg = db.messages.find((x) => String(x.messageid) === mm[1]);
      if (!msg) return json(res, 404, { error: "Message not found" });
      const { read, ...rest } = msg;
      return json(res, 200, rest);
    }
    return json(res, 404, { error: "Not found" });
  }

  async function handle(req, res) {
    const url = new URL(req.url, "http://127.0.0.1");
    const p = url.pathname;
    try {
      if (p === "/api" || p.startsWith("/api/")) return await api(req, res, url);
      if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Method not allowed", "text/plain");
      if (p === "/" || p === "/index.html") return serveFile(res, "index.html");
      if (/^\/reservation\/[^/]+\/?$/.test(p)) return serveFile(res, "reservation.html");
      if (p === "/admin" || p.startsWith("/admin/")) return send(res, 200, PLAIN_PAGE("Admin", "<p>The admin pages are not part of this course.</p>"), "text/html");
      if (p === "/cookie") return send(res, 200, PLAIN_PAGE("Cookie policy", "<p>This practice site uses no cookies.</p>"), "text/html");
      if (p === "/privacy") return send(res, 200, PLAIN_PAGE("Privacy policy", "<p>This practice site runs on your own laptop. Everything you type stays in its memory and is deleted when it stops. Use made-up names, emails and phone numbers only.</p>"), "text/html");
      if (serveFile(res, p.replace(/^\/+/, ""))) return;
      return send(res, 404, PLAIN_PAGE("Page not found", "<p>This page could not be found.</p>"), "text/html");
    } catch (e) {
      if (!res.headersSent) json(res, e.message === "too large" ? 413 : 500, { error: "Server error" });
    }
  }
  return { db, handle };
}

export function startServer(port = Number(process.env.PORT) || DEFAULT_PORT, host = "127.0.0.1") {
  const app = createApp();
  const server = http.createServer((req, res) => {
    // The coach stops an old copy (for example after a coach update moved the plugin folder), then starts the new one.
    if (req.method === "POST" && req.url === "/__coach/stop") {
      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end("stopping");
      server.close();
      setTimeout(() => process.exit(0), 100);
      return;
    }
    app.handle(req, res);
  });
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => resolve({ server, app, port: server.address().port }));
  });
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  startServer().then(
    ({ port }) => console.log(`Shady Meadows B&B practice site: http://127.0.0.1:${port}`),
    (e) => { console.error(`The practice site could not start: ${e.code === "EADDRINUSE" ? "the port is used by another program" : e.message}`); process.exit(1); },
  );
}
