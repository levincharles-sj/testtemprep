// Conduit practice app, bootcamp edition: the week 1 fallback app of the QA AI bootcamps.
// A blogging app with two roles (member, moderator), an OpenAPI description, and optional login blockers (TOTP, captcha)
// so testers practise the same workarounds they need on real projects.
// The API follows the RealWorld "Conduit" API spec (https://docs.realworld.show, MIT, Thinkster), plus this app's own parts.
// Node 22.13 or later. No npm packages: only Node's own modules.
// Testers never start this file themselves: the coach script scripts/bootcamp/practice-app.mjs does.
//
//   PORT=4310                 the port (default 4310)
//   CONDUIT_DB=<file>         where the data lives (default: next to this file)
//   KEEP_DATA=1               keep the data from the last run (without it: fresh data)
//   CONDUIT_MFA=totp          test accounts must enter a 6-digit code from an authenticator app after the password
//   CONDUIT_CAPTCHA=on        the sign-in form shows a captcha; requests with the captcha test key skip it
//   CONDUIT_CAPTCHA_TEST_KEY  the captcha test key (default below; the dev team "gives" it in the app guide)
//   CONDUIT_FAULT=<id>        switch on one fault from CONDUIT_FAULTS (a JSON list of faults)
//   CONDUIT_FAULTS=<file>     the fault file
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { DatabaseSync } from 'node:sqlite';

const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT) || 4310;
const HERE = import.meta.dirname;
const PUBLIC = path.join(HERE, 'public');
const DB_FILE = process.env.CONDUIT_DB ? path.resolve(process.env.CONDUIT_DB) : path.join(HERE, 'conduit.db');
const SECRET = process.env.JWT_SECRET || 'conduit-practice-app-not-a-real-secret';
const MFA_ON = process.env.CONDUIT_MFA === 'totp';
const CAPTCHA_ON = process.env.CONDUIT_CAPTCHA === 'on';
const CAPTCHA_TEST_KEY = process.env.CONDUIT_CAPTCHA_TEST_KEY || 'conduit-captcha-test-key-2026';
const STARTED_AT = new Date().toISOString();
const PAGE_LIMIT = 20;
const MAX_BODY = 100_000;

// ---------- faults (for fault-injection practice) ----------
// A fault is data: { id, title, method?, path (regex), status?, delayMs?, body?, remove?: ["a.b"], set?: {"a.b": value} }.
// "body" answers without running the real handler. "remove" and "set" change the real answer. "status" changes the code.
function loadFault() {
  const id = process.env.CONDUIT_FAULT;
  if (!id) return null;
  const file = process.env.CONDUIT_FAULTS;
  if (!file) { console.error('CONDUIT_FAULT needs CONDUIT_FAULTS (the fault file).'); process.exit(1); }
  let list;
  try {
    list = JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''));
  } catch (e) {
    console.error(`Cannot read the fault file ${file}: ${e.message}`);
    process.exit(1);
  }
  const fault = (Array.isArray(list) ? list : list.faults || []).find((f) => f.id === id);
  if (!fault) {
    console.error(`Fault "${id}" is not in ${file}. To switch faults off, clear CONDUIT_FAULT.`);
    process.exit(1);
  }
  return { ...fault, re: new RegExp(fault.path) };
}
const FAULT = loadFault();

const pathParts = (p) => p.split('.');
function removeAt(obj, parts) {
  if (obj === null || typeof obj !== 'object') return;
  const [head, ...rest] = parts;
  if (head === '*') { if (Array.isArray(obj)) obj.forEach((o) => (rest.length ? removeAt(o, rest) : null)); return; }
  if (!rest.length) delete obj[head]; else removeAt(obj[head], rest);
}
function setAt(obj, parts, value) {
  if (obj === null || typeof obj !== 'object') return;
  const [head, ...rest] = parts;
  if (head === '*') { if (Array.isArray(obj)) obj.forEach((o, i) => (rest.length ? setAt(o, rest, value) : (obj[i] = value))); return; }
  if (!rest.length) obj[head] = structuredClone(value); else setAt(obj[head], rest, value);
}

// ---------- database: fresh on every start unless KEEP_DATA ----------
if (!process.env.KEEP_DATA) {
  try {
    fs.rmSync(DB_FILE, { force: true });
  } catch {
    console.error('Cannot reset the data. Is the app already running in another window? Close it, then try again.');
    process.exit(1);
  }
}
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
const db = new DatabaseSync(DB_FILE);
db.exec(`
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL, bio TEXT, image TEXT, role TEXT NOT NULL DEFAULT 'member', mfa_secret TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, comment_id INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
  reporter_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, reason TEXT NOT NULL, created_at TEXT NOT NULL,
  UNIQUE (comment_id, reporter_id));
CREATE TABLE IF NOT EXISTS articles (id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, title TEXT NOT NULL,
  description TEXT NOT NULL, body TEXT NOT NULL, author_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tags (article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE, name TEXT NOT NULL, position INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY, article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  author_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS favorites (user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE, PRIMARY KEY (user_id, article_id));
CREATE TABLE IF NOT EXISTS follows (follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  followed_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY (follower_id, followed_id));`);
const all = (sql, ...a) => db.prepare(sql).all(...a);
const one = (sql, ...a) => db.prepare(sql).get(...a);
const run = (sql, ...a) => db.prepare(sql).run(...a);

// ---------- helpers ----------
class HttpError extends Error {
  constructor(status, errors) { super(`HTTP ${status}`); this.status = status; this.body = { errors }; }
}
const fail = (status, field, message) => new HttpError(status, { [field]: [message] });
const invalid = (errors) => new HttpError(422, errors);
let lastTime = '';
const now = () => {
  let t = new Date().toISOString();
  if (t <= lastTime) t = new Date(Date.parse(lastTime) + 1).toISOString();
  return (lastTime = t);
};
const text = (v) => (typeof v === 'string' ? v.trim() : '');
const isEmail = (v) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);

const hashPassword = (p) => { const salt = crypto.randomBytes(16).toString('hex'); return `${salt}:${crypto.scryptSync(p, salt, 32).toString('hex')}`; };
const checkPassword = (p, stored) => { const [salt, h] = stored.split(':'); return crypto.timingSafeEqual(Buffer.from(h, 'hex'), crypto.scryptSync(p, salt, 32)); };
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
function signToken(id) {
  const iat = Math.floor(Date.now() / 1000);
  const data = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ user: { id }, iat, exp: iat + 60 * 24 * 3600 })}`;
  return `${data}.${crypto.createHmac('sha256', SECRET).update(data).digest('base64url')}`;
}
function readToken(token) {
  try {
    const [h, p, s] = token.split('.');
    if (s !== crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url')) return null;
    const payload = JSON.parse(Buffer.from(p, 'base64url'));
    return payload.exp > Date.now() / 1000 ? payload.user?.id : null;
  } catch { return null; }
}
// Returns the signed-in user's id, or null. A missing token is fine when "required" is false; a wrong token never is.
function auth(req, required) {
  const header = req.headers.authorization;
  if (!header) { if (required) throw fail(401, 'token', 'is missing'); return null; }
  const [scheme, token] = header.split(' ');
  const id = scheme === 'Token' && token ? readToken(token) : null;
  if (!id || !one('SELECT id FROM users WHERE id = ?', id)) throw fail(401, 'token', 'is invalid');
  return id;
}

const userById = (id) => one('SELECT * FROM users WHERE id = ?', id);
const userJson = (u) => ({ email: u.email, token: signToken(u.id), username: u.username, bio: u.bio, image: u.image, role: u.role });
function requireModerator(req) {
  const me = auth(req, true);
  if (userById(me).role !== 'moderator') throw fail(403, 'moderation', 'forbidden');
  return me;
}

// ---------- TOTP (RFC 6238: SHA-1, 30 seconds, 6 digits), for CONDUIT_MFA=totp ----------
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Decode(s) {
  let bits = '';
  for (const ch of s.replace(/[\s=]/g, '').toUpperCase()) {
    const v = B32.indexOf(ch);
    if (v < 0) return null;
    bits += v.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}
function totp(secret, step) {
  const key = base32Decode(secret);
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const h = crypto.createHmac('sha1', key).update(counter).digest();
  const o = h[h.length - 1] & 0xf;
  return String((h.readUInt32BE(o) & 0x7fffffff) % 1_000_000).padStart(6, '0');
}
// One step before or after is accepted, for clocks that are a little out.
const totpOk = (secret, code) => {
  const step = Math.floor(Date.now() / 30_000);
  return /^\d{6}$/.test(String(code)) && [-1, 0, 1].some((d) => totp(secret, step + d) === String(code));
};
// The sign-in challenge after a right password: valid for 5 minutes, for one user.
function signChallenge(id) {
  const data = b64({ mfa: id, exp: Math.floor(Date.now() / 1000) + 300 });
  return `${data}.${crypto.createHmac('sha256', SECRET).update(`mfa.${data}`).digest('base64url')}`;
}
function readChallenge(token) {
  try {
    const [data, s] = String(token).split('.');
    if (s !== crypto.createHmac('sha256', SECRET).update(`mfa.${data}`).digest('base64url')) return null;
    const p = JSON.parse(Buffer.from(data, 'base64url'));
    return p.exp > Date.now() / 1000 ? p.mfa : null;
  } catch { return null; }
}

// ---------- captcha, for CONDUIT_CAPTCHA=on: a PNG with 5 characters, drawn here ----------
const GLYPHS = { // 5 x 7 pixel letters; no 0/O, 1/I/L, 5/S, 8/B
  A: '01110100011000111111100011000110001', C: '01111100001000010000100001000001111', D: '11110100011000110001100011000111110',
  E: '11111100001000011110100001000011111', F: '11111100001000011110100001000010000', G: '01111100001000010011100011000101111',
  H: '10001100011000111111100011000110001', J: '00111000100001000010000101001001100', K: '10001100101010011000101001001010001',
  M: '10001110111010110101100011000110001', N: '10001110011010110011100011000110001', P: '11110100011000111110100001000010000',
  R: '11110100011000111110101001001010001', T: '11111001000010000100001000010000100', U: '10001100011000110001100011000101110',
  V: '10001100011000110001100010101000100', W: '10001100011000110101101011101110001', X: '10001100010101000100010101000110001',
  Y: '10001100010101000100001000010000100', Z: '11111000010001000100010001000011111', 2: '01110100010000100010001000100011111',
  3: '11110000010000101110000010000111110', 4: '00010001100101010010111110001000010', 6: '01110100001000011110100011000101110',
  7: '11111000010001000100010000100001000', 9: '01110100011000101111000010000101110',
};
const captchas = new Map(); // id -> { answer, exp }
function pngFromPixels(w, h, pixel) {
  const rows = [];
  for (let y = 0; y < h; y++) {
    const row = Buffer.alloc(1 + w * 3);
    for (let x = 0; x < w; x++) row.set(pixel(x, y), 1 + x * 3);
    rows.push(row);
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(body));
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(Buffer.concat(rows))), chunk('IEND', Buffer.alloc(0))]);
}
function newCaptcha() {
  const chars = Object.keys(GLYPHS);
  const answer = Array.from({ length: 5 }, () => chars[crypto.randomInt(chars.length)]).join('');
  const id = crypto.randomUUID();
  for (const [k, v] of captchas) if (v.exp < Date.now()) captchas.delete(k);
  captchas.set(id, { answer, exp: Date.now() + 5 * 60_000 });
  const S = 4, W = 5 * 8 * S + 16, H = 7 * S + 24;
  const offsets = Array.from({ length: 5 }, () => crypto.randomInt(-6, 7));
  const noise = new Set(Array.from({ length: 260 }, () => crypto.randomInt(W * H)));
  const png = pngFromPixels(W, H, (x, y) => {
    if (noise.has(y * W + x)) return [120, 120, 120];
    const i = Math.floor((x - 8) / (8 * S));
    if (i >= 0 && i < 5) {
      const gx = Math.floor(((x - 8) % (8 * S)) / S), gy = Math.floor((y - 12 - offsets[i]) / S);
      if (gx < 5 && gy >= 0 && gy < 7 && GLYPHS[answer[i]][gy * 5 + gx] === '1') return [40, 40, 90];
    }
    return [235, 238, 245];
  });
  return { id, image: `data:image/png;base64,${png.toString('base64')}` };
}
// The captcha test key works like a provider's test keys: for automation on the test environment only.
function checkCaptcha(req, given) {
  if (!CAPTCHA_ON) return;
  if (req.headers['x-captcha-test-key'] === CAPTCHA_TEST_KEY) return;
  const c = given && typeof given === 'object' ? captchas.get(String(given.id)) : null;
  if (!c || c.exp < Date.now()) throw fail(422, 'captcha', 'is missing or expired');
  captchas.delete(String(given.id));
  if (String(given.answer || '').trim().toUpperCase() !== c.answer) throw fail(422, 'captcha', 'is wrong');
}
const following = (me, id) => !!(me && one('SELECT 1 FROM follows WHERE follower_id = ? AND followed_id = ?', me, id));
const profileJson = (u, me) => ({ username: u.username, bio: u.bio, image: u.image, following: following(me, u.id) });
const tagsOf = (articleId) => all('SELECT name FROM tags WHERE article_id = ? ORDER BY position', articleId).map((t) => t.name);
function articleJson(a, me, withBody = true) {
  const out = { slug: a.slug, title: a.title, description: a.description };
  if (withBody) out.body = a.body;
  return Object.assign(out, {
    tagList: tagsOf(a.id),
    createdAt: a.created_at,
    updatedAt: a.updated_at,
    favorited: !!(me && one('SELECT 1 FROM favorites WHERE user_id = ? AND article_id = ?', me, a.id)),
    favoritesCount: one('SELECT COUNT(*) AS n FROM favorites WHERE article_id = ?', a.id).n,
    author: profileJson(userById(a.author_id), me),
  });
}
const commentJson = (c, me) => ({ id: c.id, createdAt: c.created_at, updatedAt: c.updated_at, body: c.body, author: profileJson(userById(c.author_id), me) });
function findArticle(slug) {
  const a = one('SELECT * FROM articles WHERE slug = ?', slug);
  if (!a) throw fail(404, 'article', 'not found');
  return a;
}
function findUser(username) {
  const u = one('SELECT * FROM users WHERE username = ?', username);
  if (!u) throw fail(404, 'profile', 'not found');
  return u;
}
function uniqueSlug(title, exceptId = 0) {
  const base = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'article';
  let slug = base;
  for (let i = 2; one('SELECT 1 FROM articles WHERE slug = ? AND id != ?', slug, exceptId); i++) slug = `${base}-${i}`;
  return slug;
}
function cleanTags(list) {
  if (!Array.isArray(list) || list.some((t) => typeof t !== 'string')) throw invalid({ tagList: ['must be a list of text values'] });
  return [...new Set(list.map((t) => t.trim()).filter(Boolean))];
}
function saveTags(articleId, tags) {
  run('DELETE FROM tags WHERE article_id = ?', articleId);
  tags.forEach((t, i) => run('INSERT INTO tags (article_id, name, position) VALUES (?, ?, ?)', articleId, t, i));
}
function paging(s) {
  const errors = {};
  const limit = s.has('limit') ? Number(s.get('limit')) : PAGE_LIMIT;
  const offset = s.has('offset') ? Number(s.get('offset')) : 0;
  if (!Number.isInteger(limit) || limit < 1) errors.limit = ['must be a whole number of 1 or more'];
  if (!Number.isInteger(offset) || offset < 0) errors.offset = ['must be a whole number of 0 or more'];
  if (Object.keys(errors).length) throw invalid(errors);
  return { limit, offset };
}
function articleList(me, where, args, s) {
  const { limit, offset } = paging(s);
  const from = `FROM articles a JOIN users u ON u.id = a.author_id${where.length ? ` WHERE ${where.join(' AND ')}` : ''}`;
  const rows = all(`SELECT a.* ${from} ORDER BY a.created_at DESC, a.id DESC LIMIT ? OFFSET ?`, ...args, limit, offset);
  return { articles: rows.map((a) => articleJson(a, me, false)), articlesCount: one(`SELECT COUNT(*) AS n ${from}`, ...args).n };
}

// ---------- routes ----------
const routes = [];
const route = (method, pattern, fn) => routes.push({ method, re: new RegExp(`^${pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)')}$`), fn });

route('POST', '/api/users', ({ body }) => {
  const u = body.user || {};
  const username = text(u.username), email = text(u.email).toLowerCase(), password = typeof u.password === 'string' ? u.password : '';
  const errors = {};
  if (!username) errors.username = ["can't be blank"];
  if (!email) errors.email = ["can't be blank"]; else if (!isEmail(email)) errors.email = ['is invalid'];
  if (!password) errors.password = ["can't be blank"]; else if (password.length < 8) errors.password = ['is too short (minimum is 8 characters)'];
  if (Object.keys(errors).length) throw invalid(errors);
  const taken = {};
  if (one('SELECT 1 FROM users WHERE username = ?', username)) taken.username = ['has already been taken'];
  if (one('SELECT 1 FROM users WHERE email = ?', email)) taken.email = ['has already been taken'];
  if (Object.keys(taken).length) throw new HttpError(409, taken);
  const { lastInsertRowid } = run('INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, ?)', username, email, hashPassword(password), now());
  return [201, { user: userJson(userById(lastInsertRowid)) }];
});

route('POST', '/api/users/login', ({ req, body }) => {
  const u = body.user || {};
  const email = text(u.email).toLowerCase(), password = typeof u.password === 'string' ? u.password : '';
  const errors = {};
  if (!email) errors.email = ["can't be blank"];
  if (!password) errors.password = ["can't be blank"];
  if (Object.keys(errors).length) throw invalid(errors);
  checkCaptcha(req, u.captcha);
  const user = one('SELECT * FROM users WHERE email = ?', email);
  if (!user || !checkPassword(password, user.password)) throw fail(401, 'credentials', 'invalid');
  // With MFA on, accounts that have an authenticator secret need a second step.
  if (MFA_ON && user.mfa_secret) return [200, { mfa: { required: true, token: signChallenge(user.id) } }];
  return [200, { user: userJson(user) }];
});

route('POST', '/api/users/login/mfa', ({ body }) => {
  const m = body.mfa && typeof body.mfa === 'object' ? body.mfa : {};
  const id = readChallenge(m.token);
  if (!id) throw fail(401, 'mfa', 'sign-in step expired; sign in again');
  const user = userById(id);
  if (!user || !user.mfa_secret || !totpOk(user.mfa_secret, m.code)) throw fail(401, 'code', 'is invalid');
  return [200, { user: userJson(user) }];
});

route('GET', '/api/captcha', () => [200, CAPTCHA_ON ? { enabled: true, ...newCaptcha() } : { enabled: false }]);

// What this test environment has switched on (the sign-in page reads it).
route('GET', '/api/environment', () => [200, { environment: 'test', mfa: MFA_ON ? 'totp' : 'off', captcha: CAPTCHA_ON ? 'on' : 'off', startedAt: STARTED_AT }]);

route('GET', '/api/user', ({ req }) => [200, { user: userJson(userById(auth(req, true))) }]);

route('PUT', '/api/user', ({ req, body }) => {
  const me = auth(req, true), u = body.user && typeof body.user === 'object' ? body.user : {};
  const errors = {}, taken = {}, changes = {};
  for (const f of ['username', 'email']) {
    if (!(f in u)) continue;
    const v = f === 'email' ? text(u[f]).toLowerCase() : text(u[f]);
    if (!v) errors[f] = ["can't be blank"];
    else if (f === 'email' && !isEmail(v)) errors[f] = ['is invalid'];
    else if (one(`SELECT 1 FROM users WHERE ${f} = ? AND id != ?`, v, me)) taken[f] = ['has already been taken'];
    else changes[f] = v;
  }
  if ('password' in u) {
    if (typeof u.password !== 'string' || !u.password) errors.password = ["can't be blank"];
    else if (u.password.length < 8) errors.password = ['is too short (minimum is 8 characters)'];
    else changes.password = hashPassword(u.password);
  }
  for (const f of ['bio', 'image']) if (f in u) changes[f] = text(u[f]) || null;
  if (!Object.keys(u).length) errors.user = ['must have at least one field'];
  if (Object.keys(errors).length) throw invalid(errors);
  if (Object.keys(taken).length) throw new HttpError(409, taken);
  for (const [f, v] of Object.entries(changes)) run(`UPDATE users SET ${f} = ? WHERE id = ?`, v, me);
  return [200, { user: userJson(userById(me)) }];
});

route('GET', '/api/profiles/:username', ({ req, p }) => {
  const me = auth(req, false), u = findUser(p.username);
  return [200, { profile: { ...profileJson(u, me), email: u.email } }];
});
route('POST', '/api/profiles/:username/follow', ({ req, p }) => {
  const me = auth(req, true), u = findUser(p.username);
  if (u.id !== me) run('INSERT OR IGNORE INTO follows (follower_id, followed_id) VALUES (?, ?)', me, u.id);
  return [200, { profile: profileJson(u, me) }];
});
route('DELETE', '/api/profiles/:username/follow', ({ req, p }) => {
  const me = auth(req, true), u = findUser(p.username);
  run('DELETE FROM follows WHERE follower_id = ? AND followed_id = ?', me, u.id);
  return [200, { profile: profileJson(u, me) }];
});

route('GET', '/api/articles', ({ req, url }) => {
  const me = auth(req, false), s = url.searchParams, where = [], args = [];
  if (s.has('tag')) { where.push('a.id IN (SELECT article_id FROM tags WHERE name = ?)'); args.push(s.get('tag')); }
  if (s.has('author')) { where.push('u.username = ?'); args.push(s.get('author')); }
  if (s.has('favorited')) {
    where.push('a.id IN (SELECT f.article_id FROM favorites f JOIN users fu ON fu.id = f.user_id WHERE fu.username = ?)');
    args.push(s.get('favorited'));
  }
  return [200, articleList(me, where, args, s)];
});
route('GET', '/api/articles/feed', ({ req, url }) => {
  const me = auth(req, true);
  return [200, articleList(me, ['a.author_id IN (SELECT followed_id FROM follows WHERE follower_id = ?)'], [me], url.searchParams)];
});
route('POST', '/api/articles', ({ req, body }) => {
  const me = auth(req, true), a = body.article && typeof body.article === 'object' ? body.article : {};
  const errors = {};
  for (const f of ['title', 'description', 'body']) if (!text(a[f])) errors[f] = ["can't be blank"];
  if (Object.keys(errors).length) throw invalid(errors);
  const tags = 'tagList' in a ? cleanTags(a.tagList) : [];
  const t = now();
  const { lastInsertRowid } = run('INSERT INTO articles (slug, title, description, body, author_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    uniqueSlug(text(a.title)), text(a.title), text(a.description), a.body, me, t, t);
  saveTags(lastInsertRowid, tags);
  return [201, { article: articleJson(one('SELECT * FROM articles WHERE id = ?', lastInsertRowid), me) }];
});
route('GET', '/api/articles/:slug', ({ req, p }) => [200, { article: articleJson(findArticle(p.slug), auth(req, false)) }]);
route('PUT', '/api/articles/:slug', ({ req, p, body }) => {
  const me = auth(req, true), a = findArticle(p.slug), c = body.article && typeof body.article === 'object' ? body.article : {};
  if (a.author_id !== me) throw fail(403, 'article', 'forbidden');
  const errors = {};
  for (const f of ['title', 'description', 'body']) if (f in c && !text(c[f])) errors[f] = ["can't be blank"];
  if (Object.keys(errors).length) throw invalid(errors);
  const tags = cleanTags('tagList' in c ? c.tagList : []);
  const title = 'title' in c ? text(c.title) : a.title;
  const slug = title === a.title ? a.slug : uniqueSlug(title, a.id);
  run('UPDATE articles SET slug = ?, title = ?, description = ?, body = ?, updated_at = ? WHERE id = ?',
    slug, title, 'description' in c ? text(c.description) : a.description, 'body' in c ? c.body : a.body, now(), a.id);
  saveTags(a.id, tags);
  return [200, { article: articleJson(one('SELECT * FROM articles WHERE id = ?', a.id), me) }];
});
route('DELETE', '/api/articles/:slug', ({ req, p }) => {
  const me = auth(req, true), a = findArticle(p.slug);
  if (a.author_id !== me) throw fail(403, 'article', 'forbidden');
  run('DELETE FROM articles WHERE id = ?', a.id);
  return [204, null];
});
route('POST', '/api/articles/:slug/favorite', ({ req, p }) => {
  const me = auth(req, true), a = findArticle(p.slug);
  run('INSERT OR IGNORE INTO favorites (user_id, article_id) VALUES (?, ?)', me, a.id);
  return [200, { article: articleJson(a, me) }];
});
route('DELETE', '/api/articles/:slug/favorite', ({ req, p }) => {
  const me = auth(req, true), a = findArticle(p.slug);
  run('DELETE FROM favorites WHERE user_id = ? AND article_id = ?', me, a.id);
  return [200, { article: articleJson(a, me) }];
});

route('GET', '/api/articles/:slug/comments', ({ req, p }) => {
  const me = auth(req, false), a = findArticle(p.slug);
  return [200, { comments: all('SELECT * FROM comments WHERE article_id = ? ORDER BY id', a.id).map((c) => commentJson(c, me)) }];
});
route('POST', '/api/articles/:slug/comments', ({ req, p, body }) => {
  const me = auth(req, true), a = findArticle(p.slug), c = body.comment && typeof body.comment === 'object' ? body.comment : {};
  if (c.body === undefined || c.body === null) throw invalid({ body: ["can't be blank"] });
  const t = now();
  const { lastInsertRowid } = run('INSERT INTO comments (article_id, author_id, body, created_at, updated_at) VALUES (?, ?, ?, ?, ?)', a.id, me, String(c.body), t, t);
  return [201, { comment: commentJson(one('SELECT * FROM comments WHERE id = ?', lastInsertRowid), me) }];
});
route('DELETE', '/api/articles/:slug/comments/:id', ({ req, p }) => {
  const me = auth(req, true), a = findArticle(p.slug);
  const c = one('SELECT * FROM comments WHERE id = ? AND article_id = ?', Number(p.id), a.id);
  if (!c) throw fail(404, 'comment', 'not found');
  if (c.author_id !== me) throw fail(403, 'comment', 'forbidden');
  run('DELETE FROM comments WHERE id = ?', c.id);
  return [204, null];
});

route('POST', '/api/articles/:slug/comments/:id/report', ({ req, p, body }) => {
  const me = auth(req, true), a = findArticle(p.slug);
  const c = one('SELECT * FROM comments WHERE id = ? AND article_id = ?', Number(p.id), a.id);
  if (!c) throw fail(404, 'comment', 'not found');
  const reason = text(body.report?.reason);
  if (!['spam', 'rude', 'off-topic', 'other'].includes(reason)) throw invalid({ reason: ['must be one of spam, rude, off-topic, other'] });
  run('INSERT OR IGNORE INTO reports (comment_id, reporter_id, reason, created_at) VALUES (?, ?, ?, ?)', c.id, me, reason, now());
  return [201, { report: { commentId: c.id, reason } }];
});

// ---------- moderation: moderators only ----------
route('GET', '/api/moderation/reports', ({ req }) => {
  requireModerator(req);
  const rows = all(`SELECT c.id AS commentId, c.body, a.slug, a.title, cu.username AS commentAuthor,
      COUNT(r.id) AS reports, GROUP_CONCAT(DISTINCT r.reason) AS reasons, MAX(r.created_at) AS lastReportedAt
    FROM reports r JOIN comments c ON c.id = r.comment_id JOIN articles a ON a.id = c.article_id JOIN users cu ON cu.id = c.author_id
    GROUP BY c.id ORDER BY reports DESC, lastReportedAt DESC`);
  return [200, { reports: rows.map((r) => ({ ...r, reasons: String(r.reasons).split(',').sort() })), reportsCount: rows.length }];
});
route('GET', '/api/moderation/users', ({ req }) => {
  requireModerator(req);
  const rows = all(`SELECT u.username, u.role, u.created_at AS joinedAt, (SELECT COUNT(*) FROM articles a WHERE a.author_id = u.id) AS articlesCount,
    (SELECT COUNT(*) FROM comments c WHERE c.author_id = u.id) AS commentsCount FROM users u ORDER BY u.username`);
  return [200, { users: rows, usersCount: rows.length }];
});

route('GET', '/api/tags', () => [200, {
  tags: all('SELECT name, COUNT(*) AS n FROM tags GROUP BY name ORDER BY n DESC, name').map((t) => t.name),
}]);

// ---------- seed data (made up; the same on every fresh start) ----------
// Users 1-3: practice users (password Practice123). 4-11: authors. 12-13: the automation test accounts (password Smoke-Pass-2026),
// one per role, each with an authenticator secret that is used only when CONDUIT_MFA=totp.
const TEST_ACCOUNTS = [
  { username: 'smoke-member', email: 'smoke-member@conduit.test', role: 'member', totpSecret: 'ONWW623FFVWWK3LCMVZC25DPORYC22ZR' },
  { username: 'smoke-moderator', email: 'smoke-moderator@conduit.test', role: 'moderator', totpSecret: 'ONWW623FFVWW6ZDFOJQXI33SFV2G65DQ' },
];
const PRACTICE_PASSWORD = 'Practice123';
const TEST_PASSWORD = 'Smoke-Pass-2026';
function seed() {
  const users = [
    ['practice-author', 'practice-author@example.com', 'I write about testing and quality.', 'member'],
    ['practice-reader', 'practice-reader@example.com', null, 'member'],
    ['practice-editor', 'practice-editor@example.com', 'Editor. I like short, clear articles.', 'moderator'],
    ['lena-writes', 'lena@example.com', 'Release manager. Checklists and calm releases.', 'member'],
    ['tom-tests', 'tom@example.com', 'Test lead on a payments team.', 'member'],
    ['priya-ops', 'priya@example.com', 'Platform engineer. CI, logs and alerts.', 'member'],
    ['sam-api', 'sam@example.com', 'Backend developer. Contracts first.', 'member'],
    ['noor-ux', 'noor@example.com', 'Designer who reads bug reports.', 'member'],
    ['kofi-data', 'kofi@example.com', 'Data engineer. Pipelines and checks.', 'member'],
    ['mei-ci', 'mei@example.com', null, 'member'],
    ['arjun-sec', 'arjun@example.com', 'Application security. Threat models over coffee.', 'member'],
  ];
  users.forEach(([username, email, bio, role], i) => run('INSERT INTO users (username, email, password, bio, role, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    username, email, hashPassword(PRACTICE_PASSWORD), bio, role, new Date(Date.UTC(2025, 8, 1 + i * 5, 9)).toISOString()));
  TEST_ACCOUNTS.forEach((a, i) => run('INSERT INTO users (username, email, password, bio, role, mfa_secret, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    a.username, a.email, hashPassword(TEST_PASSWORD), 'Automation test account. Do not use for people.', a.role, a.totpSecret,
    new Date(Date.UTC(2025, 10, 20 + i, 9)).toISOString()));
  const articles = [
    [1, 'How to write a good bug report', 'Steps, expected result, actual result', 'A good bug report lets someone else see the bug without asking you.\n\nWrite the steps, what you expected and what happened. Add the version and the data you used.', ['testing', 'bugs']],
    [1, 'Five checks before a release', 'A short list for the last day', 'Check the main journeys, the payments, the emails, the logs and the rollback plan.', ['testing', 'quality']],
    [3, 'What an API test should check', 'Status, body, shape and errors', 'An API test checks the status code, the important values in the body, the shape of the answer and what happens with bad input.', ['api', 'testing']],
    [1, 'Why tests become flaky', 'Timing, shared data and order', 'Most flaky tests wait for a fixed time, share data with other tests, or depend on the order they run in.', ['automation', 'playwright']],
    [3, 'Reading a failed CI run', 'Start from the first red step', 'Open the failed job, find the first red step and read the error message before you change any code.', ['ci', 'automation']],
    [1, 'Exploratory testing in 30 minutes', 'A charter, a timer and notes', 'Write one charter, set a timer for 30 minutes and take notes as you go. Report what you found and what you did not test.', ['testing']],
    [3, 'Test data that cleans up after itself', 'Create it, use it, delete it', 'Each test creates the data it needs and deletes it at the end, so tests do not depend on each other.', ['automation', 'api']],
    [1, 'Accessible names and locators', 'Find elements the way users do', 'A button with a clear name is easier to use and easier to test. Prefer role and label locators.', ['playwright', 'accessibility']],
    [3, 'When to automate a test', 'Repeat, risk and cost', 'Automate checks you repeat often, checks on high-risk areas and checks that are slow by hand.', ['automation', 'quality']],
    [1, 'Boundary values in practice', 'Test at the edges', 'If a field accepts 1 to 100, test 0, 1, 100 and 101. Bugs like to live at the edges.', ['testing', 'quality']],
    [3, 'Contract tests in plain words', 'Does the answer still have the agreed shape?', 'A contract test fails when an answer no longer has the fields and types that were agreed.', ['api', 'ci']],
    [1, 'Your first end-to-end test', 'Set up by API, check in the browser', 'Create the data through the API, run the journey in the browser and check the result through the API.', ['playwright', 'api']],
    [4, 'A release checklist that people actually use', 'Short, owned and kept up to date', 'Keep the list to one screen. Every line has an owner. Remove lines nobody checks.', ['release', 'quality']],
    [5, 'Testing refunds without real money', 'Sandbox accounts and test cards', 'Use the payment provider\'s sandbox and its test cards. Check both your app and the provider\'s dashboard.', ['payments', 'testing']],
    [6, 'Alerts that wake the right person', 'Fewer alerts, better alerts', 'An alert should say what broke, how bad it is and who owns it. Delete alerts nobody acts on.', ['ci', 'monitoring']],
    [7, 'Versioning a public API', 'Add fields, never rename them', 'Adding a field is safe. Renaming or removing one breaks clients. Announce changes and keep the old version for a while.', ['api']],
    [8, 'Error messages users can act on', 'Say what happened and what to do', 'A good error message names the problem in the user\'s words and gives one next step.', ['accessibility', 'quality']],
    [9, 'Checking a data import', 'Counts, rejects and the error report', 'Compare the row counts, check the rejected rows have a reason and read the error report before you trust the import.', ['data', 'testing']],
    [10, 'Caching your CI dependencies', 'Faster runs, same results', 'Cache the package folder by the lock file. A changed lock file means a fresh install.', ['ci', 'automation']],
    [11, 'Threat modelling a login page', 'What could go wrong, and who would try', 'List what an attacker wants, where input comes in and what the page can reach. Rank by impact.', ['security', 'testing']],
    [4, 'Rollback plans that work', 'Practise the rollback before you need it', 'A rollback plan nobody has tried is a guess. Run it on the test environment once a month.', ['release']],
    [5, 'Risk-based test selection', 'Test what hurts most first', 'Rank features by how often they break and how bad a failure is. Start with the top of the list.', ['testing', 'quality']],
    [6, 'Reading application logs', 'Find the first error, then the cause', 'Search by request id. The first error is usually closer to the cause than the last one.', ['monitoring']],
    [7, 'Pagination bugs to look for', 'Off by one, duplicates and missing rows', 'Check the last page, a page past the end, and that no item shows on two pages.', ['api', 'testing']],
    [8, 'Keyboard-only testing', 'Can you finish the journey without a mouse?', 'Tab through the page. Every control should be reachable, visible when focused and usable with Enter or Space.', ['accessibility']],
    [9, 'Data quality checks in a pipeline', 'Schema, nulls, ranges and duplicates', 'Check the schema first, then nulls in required fields, values in range and duplicate keys.', ['data']],
    [10, 'Running tests in parallel safely', 'No shared state, no fixed order', 'Each test makes its own data and cleans up. Never depend on another test having run first.', ['automation', 'playwright']],
    [11, 'Secrets in CI', 'Names in the file, values in the store', 'Keep secret values in the CI tool\'s secret store and refer to them by name. Never print them in logs.', ['security', 'ci']],
    [4, 'Feature flags and testing', 'Know which flags are on', 'Ask which flags are on in the test environment and check the flag state before you trust a result.', ['release', 'testing']],
    [5, 'Writing acceptance criteria testers can use', 'Given, when, then, with numbers', 'Each criterion names the start state, the action and a result you can check, with real values.', ['testing']],
    [6, 'Health checks for a test environment', 'Is it up before you test?', 'A small health check before the run saves an hour of reading red tests caused by a down environment.', ['monitoring', 'automation']],
    [7, 'Idempotent API requests', 'Safe to send twice', 'A retried request should not create two orders. Use an idempotency key for requests that create things.', ['api']],
    [8, 'Colour contrast in practice', 'Check the text, not the logo', 'Body text needs enough contrast against its background. Check buttons and links in every state.', ['accessibility']],
    [9, 'Reconciling two systems', 'Totals first, then samples', 'Compare totals between source and target, then check a random sample row by row.', ['data', 'testing']],
    [10, 'Short pipelines, fast feedback', 'Smoke tests first', 'Run a short smoke pack on every deploy and the long suite at night. Fail fast on the basics.', ['ci', 'quality']],
    [11, 'Rate limits and brute force', 'How many tries before a lock?', 'Check what happens after many wrong passwords: a delay, a lock or a captcha, and a clear message.', ['security']],
    [1, 'Pair testing with a developer', 'Two views of one feature', 'One person drives, one takes notes and asks questions. Swap after 20 minutes.', ['testing']],
    [3, 'Mocking a third-party service', 'Test your side without theirs', 'A mock lets you test errors and slow answers from a service you do not control. Keep one real check too.', ['api', 'automation']],
    [4, 'Release notes for testers', 'What changed and what to retest', 'Good release notes list the changes, the risk areas and what was not tested.', ['release']],
    [5, 'Testing time zones', 'Midnight is a different time for everyone', 'Test dates around midnight, month ends and daylight saving changes in more than one time zone.', ['testing', 'quality']],
    [6, 'Dashboards nobody reads', 'One question per chart', 'Each chart should answer one question someone asks every week. Remove the rest.', ['monitoring']],
    [7, 'Errors as data', 'Status codes and error bodies', 'Return the right status code and a body that names the field. Clients should never parse error text.', ['api']],
    [8, 'Testing forms on small screens', 'Labels, zoom and the keyboard', 'Check that labels stay visible, the page zooms and the right keyboard opens for each field.', ['accessibility', 'testing']],
    [9, 'Masking personal data in test copies', 'Real shape, fake values', 'Keep the format and the spread of values, but replace names, emails and numbers before data leaves production.', ['data', 'security']],
    [10, 'Retrying flaky steps is not a fix', 'Find the cause', 'A retry hides the problem. Find the wait, the shared data or the order that makes the test flaky.', ['automation', 'quality']],
    [11, 'Session timeouts', 'What happens after 30 minutes?', 'Leave a signed-in page open past the timeout and act. The app should ask you to sign in again without losing the form.', ['security', 'testing']],
    [12, 'Smoke account check', 'This account exists for automated smoke tests', 'This article belongs to the automation test account. It is read by smoke tests and never changed.', ['automation']],
    [13, 'Moderation guidelines', 'How we handle reported comments', 'Moderators review reported comments every day. Spam is removed, rude comments get a warning, and off-topic comments are moved.', ['community']],
  ];
  articles.forEach(([author, title, description, body, tags], i) => {
    const t = new Date(Date.UTC(2026, 0, 5 + i * 2, 12)).toISOString();
    const { lastInsertRowid } = run('INSERT INTO articles (slug, title, description, body, author_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      uniqueSlug(title), title, description, body, author, t, t);
    saveTags(lastInsertRowid, tags);
  });
  const comments = [
    [12, 2, 'Clear steps. I will try this on my project.'], [12, 3, 'Nice and short.'], [11, 2, 'Can you give an example of a changed answer?'],
    [1, 3, 'Please add the browser version too.'], [14, 6, 'Which provider do you use for the sandbox?'], [14, 7, 'Do not forget partial refunds.'],
    [16, 5, 'We broke a client once by renaming a field. Never again.'], [18, 4, 'The error report is the part people skip.'],
    [20, 9, 'Ranking by impact helped us a lot.'], [22, 8, 'Request ids saved me hours last week.'],
    [24, 5, 'Page past the end returned page 1 for us. Good catch.'], [27, 10, 'Separate data per test fixed our flaky suite.'],
    [28, 11, 'Also rotate them after someone leaves.'], [31, 6, 'We run the health check as the first CI step now.'],
    [33, 9, 'Is this the same as WCAG AA?'], [35, 7, 'Fail fast on the basics, yes.'], [36, 4, 'Ours locks after 5 tries.'],
    [12, 9, 'BUY CHEAP FOLLOWERS NOW at followers-shop.example'], [5, 10, 'This is useless, who writes this.'],
    [20, 8, 'Anyone watching the match tonight?'], [3, 11, 'Visit my site for free test tools!!! tools-free.example'],
    [24, 6, 'Great list. Bookmarked.'], [40, 5, 'Daylight saving broke our scheduler twice.'], [45, 8, 'Masking is harder than it looks.'],
    [47, 2, 'Thanks, clear rules.'],
  ];
  comments.forEach(([article, author, body], i) => {
    const t = new Date(Date.UTC(2026, 1, 1 + i, 12)).toISOString();
    run('INSERT INTO comments (article_id, author_id, body, created_at, updated_at) VALUES (?, ?, ?, ?, ?)', article, author, body, t, t);
  });
  const reports = [[18, 2, 'spam'], [18, 4, 'spam'], [18, 6, 'spam'], [19, 1, 'rude'], [19, 5, 'rude'], [20, 4, 'off-topic'], [21, 2, 'spam'], [21, 7, 'other']];
  reports.forEach(([comment, reporter, reason], i) => run('INSERT INTO reports (comment_id, reporter_id, reason, created_at) VALUES (?, ?, ?, ?)',
    comment, reporter, reason, new Date(Date.UTC(2026, 2, 1 + i, 10)).toISOString()));
  const favorites = [[2, 12], [2, 11], [2, 1], [3, 12], [3, 10], [4, 14], [5, 14], [6, 20], [7, 16], [8, 25], [9, 18], [10, 27], [11, 28], [4, 35], [5, 2], [6, 2], [12, 1], [12, 3]];
  for (const [user, article] of favorites) run('INSERT INTO favorites (user_id, article_id) VALUES (?, ?)', user, article);
  for (const [a, b] of [[2, 1], [2, 4], [12, 1], [12, 5], [4, 6], [5, 7], [13, 3]]) run('INSERT INTO follows (follower_id, followed_id) VALUES (?, ?)', a, b);
}
if (!one('SELECT 1 FROM users')) seed();

// ---------- server ----------
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml' };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function readBody(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > MAX_BODY) throw fail(413, 'body', 'is too large');
  }
  if (!raw.trim()) return {};
  try {
    const body = JSON.parse(raw);
    return body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  } catch {
    throw fail(422, 'body', 'is not valid JSON');
  }
}

async function handleApi(req, url) {
  try {
    const body = await readBody(req);
    const pathname = url.pathname.length > 1 ? url.pathname.replace(/\/$/, '') : url.pathname;
    for (const r of routes) {
      const m = r.method === req.method && pathname.match(r.re);
      if (m) {
        const params = Object.fromEntries(Object.entries(m.groups || {}).map(([k, v]) => [k, decodeURIComponent(v)]));
        return r.fn({ req, url, body, p: params });
      }
    }
    return [404, { errors: { path: ['not found'] } }];
  } catch (e) {
    if (e instanceof HttpError) return [e.status, e.body];
    console.error(e);
    return [500, { errors: { server: ['unexpected error'] } }];
  }
}

const OPTIONS = `mfa=${MFA_ON ? 'totp' : 'off'};captcha=${CAPTCHA_ON ? 'on' : 'off'}`;
const OPENAPI = path.join(HERE, 'openapi.yaml');
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}`);
  // The coach script finds this app (and which copy and options) by these headers.
  res.setHeader('X-Practice-App', 'qa-ai-bootcamp-conduit');
  res.setHeader('X-Practice-App-Root', encodeURIComponent(HERE));
  res.setHeader('X-Practice-App-Options', OPTIONS);
  // Only the coach script stops it: a custom header, which a web page from another site cannot send without asking.
  if (url.pathname === '/__coach/stop' && req.method === 'POST' && req.headers['x-coach-stop'] === '1') {
    res.writeHead(204); res.end();
    return setTimeout(stop, 50);
  }
  if (url.pathname === '/openapi.yaml' || url.pathname === '/api-docs') {
    res.writeHead(200, { 'Content-Type': 'application/yaml; charset=utf-8', 'Cache-Control': 'no-store' });
    return fs.createReadStream(OPENAPI).pipe(res);
  }
  if (url.pathname.startsWith('/api/')) {
    const fault = FAULT && (!FAULT.method || FAULT.method === req.method) && FAULT.re.test(url.pathname) ? FAULT : null;
    let status, out;
    if (fault && 'body' in fault) {
      for await (const _ of req); // read and ignore the request body
      [status, out] = [fault.status ?? 200, fault.body];
    } else {
      [status, out] = await handleApi(req, url);
      if (fault) {
        if (out && typeof out === 'object') {
          out = structuredClone(out);
          for (const p of fault.remove || []) removeAt(out, pathParts(p));
          for (const [p, v] of Object.entries(fault.set || {})) setAt(out, pathParts(p), v);
        }
        if (fault.status) status = fault.status;
      }
    }
    if (fault?.delayMs) await wait(fault.delayMs);
    const empty = out === null || out === undefined;
    res.writeHead(status, empty ? {} : { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(empty ? '' : JSON.stringify(out));
  }
  const file = path.join(PUBLIC, path.normalize(decodeURIComponent(url.pathname)).replace(/^[/\\]+/, ''));
  const target = file.startsWith(PUBLIC + path.sep) && fs.existsSync(file) && fs.statSync(file).isFile() ? file : path.join(PUBLIC, 'index.html');
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(target)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(target).pipe(res);
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`Port ${PORT} is busy. Is the app already running in another window? Close it, or set another PORT.`);
  else console.error(e.message);
  process.exit(1);
});
server.listen(PORT, HOST, () => {
  console.log(`Conduit practice app: http://${HOST}:${PORT}  (${process.env.KEEP_DATA ? 'kept data' : 'fresh data'}; ${OPTIONS})`);
  if (FAULT) console.log(`Fault switched on: ${FAULT.id} - ${FAULT.title}`);
});
const stop = () => { server.close(); db.close(); process.exit(0); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
