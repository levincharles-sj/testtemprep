// Parcelly support chat page (QA AI bootcamps, week 3): the web page customers use to talk to the support agent.
// It sends each message to the agent's security build on the tester's own Claude seat (scripts/bootcamp/attack.mjs)
// and shows the reply and the order details the agent looked up.
// Started only by the coach script scripts/bootcamp/chat-page.mjs (detached). Node 22.13 or later, no packages.
//   PORT=4370            the port
//   CHAT_WS=<folder>     the tester's bootcamp folder (where the practice data and attempts are saved)
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 4370;
const WS = process.env.CHAT_WS ? path.resolve(process.env.CHAT_WS) : null;
const { askSec } = await import(pathToFileURL(path.join(HERE, "..", "..", "scripts", "bootcamp", "attack.mjs")).href);

// The order card's front-end code differs between builds, as it would in a real release: some builds put the
// customer's delivery note into the page as HTML (unsafe output), the fixed build escapes it.
const UNSAFE_NOTES = new Set(["A", "D"]);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

export function orderCard(order, build) {
  if (!order || order.error) return "";
  const items = (order.items || []).map((i) => `${esc(i.item)} (${esc(i.price)} INR)`).join(", ");
  const note = order.delivery_note ? (UNSAFE_NOTES.has(build) ? order.delivery_note : esc(order.delivery_note)) : "";
  const contact = order.delivery_contact ? `<p><b>Delivery contact:</b> ${esc(order.delivery_contact.name)} · ${esc(order.delivery_contact.phone)}</p>` : "";
  return `<article class="card"><h3>Order ${esc(order.order_id)}</h3><p><b>Status:</b> ${esc(order.status)} · <b>Total:</b> ${esc(order.total)} INR</p>`
    + `<p><b>Items:</b> ${items}</p><p><b>Address:</b> ${esc(order.address)}</p>${contact}`
    + (note ? `<p class="note"><b>Delivery note:</b> ${note}</p>` : "") + "</article>";
}

export function profileCard(p) {
  if (!p || p.error) return "";
  return `<article class="card"><h3>Customer ${esc(p.id)}</h3><p>${esc(p.name)} · ${esc(p.email)} · ${esc(p.phone)} · ${esc(p.city)}</p></article>`;
}

async function body(req) {
  let raw = "";
  for await (const c of req) { raw += c; if (raw.length > 20000) break; }
  try { return JSON.parse(raw || "{}"); } catch { return {}; }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  res.setHeader("X-Practice-App", "qa-ai-bootcamp-chat");
  res.setHeader("X-Practice-App-Root", encodeURIComponent(HERE));
  if (url.pathname === "/__coach/stop" && req.method === "POST" && req.headers["x-coach-stop"] === "1") {
    res.writeHead(204); res.end(); return setTimeout(() => process.exit(0), 50);
  }
  if (url.pathname === "/api/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ ok: true, workspace: !!WS }));
  }
  if (url.pathname === "/api/ask" && req.method === "POST") {
    const b = await body(req);
    const message = String(b.message || "").trim().slice(0, 2000);
    if (!message || !WS) { res.writeHead(400, { "Content-Type": "application/json" }); return res.end(JSON.stringify({ error: "No message." })); }
    const r = askSec(WS, { message, build: b.build === "v2.1" ? "v2.1" : "v2", cont: b.cont || undefined, goal: b.goal || undefined });
    let build = null;
    try { build = JSON.parse(fs.readFileSync(path.join(WS, ".bootcamp", "agent", "attacks", r.runId, "run.json"), "utf8")).build; } catch { /* no run */ }
    const cards = (r.tools || []).map((t) => t.tool === "lookup_order" ? orderCard(t.result, build) : t.tool === "view_customer_profile" ? profileCard(t.result) : "").filter(Boolean);
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    return res.end(JSON.stringify({ runId: r.runId || null, status: r.line.split(" ")[0], reply: r.reply ?? r.line, cards }));
  }
  const file = url.pathname === "/" ? "index.html" : url.pathname.replace(/^\/+/, "");
  const full = path.join(HERE, "public", path.normalize(file));
  if (!full.startsWith(path.join(HERE, "public")) || !fs.existsSync(full)) { res.writeHead(404); return res.end("Not found"); }
  const type = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8" }[path.extname(full)] || "text/plain";
  res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store" });
  fs.createReadStream(full).pipe(res);
});

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  server.on("error", (e) => { console.error(e.code === "EADDRINUSE" ? `Port ${PORT} is busy.` : e.message); process.exit(1); });
  server.listen(PORT, "127.0.0.1", () => console.log(`Parcelly support chat: http://127.0.0.1:${PORT}`));
}
