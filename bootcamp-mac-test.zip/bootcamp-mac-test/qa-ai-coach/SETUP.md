# Set-up

The set-up guide is now in the QA AI Training Portal, on the **Start here** page:
https://claude.ai/artifact/1iq8fKEGLY2vdGSGfAzoKe
