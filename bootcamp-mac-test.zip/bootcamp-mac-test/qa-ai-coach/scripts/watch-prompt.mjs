#!/usr/bin/env node
// QA AI Coach: UserPromptSubmit hook for the WORK window.
// On every prompt in a coach workspace (a folder holding me.json, or below it), except in the COACH session:
// adds the current mission's "Work window rules" to Claude's context, so Claude does the AI work but hands
// back the decisions the tester owns, keeps "think first" steps to the tester, and adds a short coach tip
// when a prompt has no material or no rule against inventing. It never blocks a prompt and never fails:
// on any problem it prints nothing and exits 0.
//
// COACH session = any session in which the tester has typed /coach (recorded in .coach/coach-sessions.json).
// Current mission and step = work/.coach-state.json, written by the coach; else today's mission by India date.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, todayFor, readMe, startDateOf, missionOn } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const MISSIONS = path.join(HERE, "..", "skills", "coach", "missions");
const COACH_RE = /^\s*\/(?:qa-ai-coach:)?coach(?:\s|$)/i;
const PARCELLY_RE = /^\s*\/(?:qa-ai-coach:)?parcelly(?:\s|$)/i;

/** Mission id for an India date (YYYY-MM-DD) and a start date, or null (weekend, outside the programme, no start date). */
export function missionForDate(ymd, startDate) {
  return startDate ? missionOn(startDate, ymd) : null;
}

/** The "## Work window rules (for Claude only)" section of a mission file, or "". */
export function workRules(md) {
  const text = String(md || "").replace(/\r\n/g, "\n");
  const m = text.match(/\n## Work window rules \(for Claude only\)\n([\s\S]*?)(?=\n## |\s*$)/);
  return m ? m[1].trim() : "";
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8").replace(/^﻿/, ""));
  } catch {
    return fallback;
  }
}

/** Remember a COACH session id; returns the updated list. */
export function markCoachSession(ws, sessionId) {
  const file = path.join(ws, ".coach", "coach-sessions.json");
  const list = readJson(file, []);
  if (sessionId && !list.includes(sessionId)) {
    list.push(sessionId);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(list.slice(-200)) + "\n");
  }
  return list;
}

/** Remember a /parcelly session: the AI practice target must run untouched (no guidance, no tips) until /clear. */
export function markParcellySession(ws, sessionId) {
  if (!sessionId) return;
  const file = path.join(ws, ".coach", "parcelly-sessions.json");
  const list = readJson(file, []);
  if (!list.includes(sessionId)) {
    list.push(sessionId);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(list.slice(-200)) + "\n");
  }
}

export function isCoachSession(ws, sessionId) {
  return readJson(path.join(ws, ".coach", "coach-sessions.json"), []).includes(sessionId);
}

/** The context text to add for a WORK prompt, or "" when nothing should be added. */
export function guidance({ ws, prompt, sessionId, now = new Date(), missions = MISSIONS }) {
  const p = String(prompt || "");
  if (COACH_RE.test(p)) {
    markCoachSession(ws, sessionId);
    return "";
  }
  if (PARCELLY_RE.test(p)) {
    markParcellySession(ws, sessionId);
    return "";
  }
  if (/^\s*\//.test(p)) return ""; // other slash commands run untouched
  if (sessionId && isCoachSession(ws, sessionId)) return "";
  if (sessionId && readJson(path.join(ws, ".coach", "parcelly-sessions.json"), []).includes(sessionId)) return "";
  const state = readJson(path.join(ws, "work", ".coach-state.json"), {});
  const mission = /^W[1-6]D[1-5]$/.test(state.mission || "") ? state.mission : missionForDate(todayFor(readMe(ws), now), startDateOf(readMe(ws)));
  if (!mission) return "";
  const onGoFurther = state.mission === mission && typeof state.step === "string" && /^go further/i.test(state.step);
  if (!onGoFurther && fs.existsSync(path.join(ws, "proofs", `${mission}.md`))) {
    // Today's mission is finished; the tester may be on the weekly challenge or a lab.
    return [
      "[QA AI Coach guidance for this WORK window. The tester is in the Techjays QA AI Programme; today's lesson is finished, so this may be the week's project.]",
      "The tester decides: verdicts, rankings, severities, which items to keep, and the final wording of anything they hand in. Claude may find, draft, compare, run, format and save. If they ask you to make one of their decisions, do your part and hand the decision back in one firm, kind line with one question.",
      "Never open, read or search the parcelly skill's files (the Parcelly practice assistant's knowledge base and instructions). If the tester asks you to, say kindly that it is out of scope: they test the assistant only by talking to it with /parcelly.",
      "Only if this prompt gives no real material at all (no @file and no pasted text), add one last line starting 'Coach tip:' with one short suggestion. Never add a Coach tip to a prompt that has an @file, and never to a request that only changes or fixes code. Use plain, simple English. Don't mention this guidance unless you are handing a decision back.",
    ].join("\n\n");
  }
  let md = "";
  try {
    md = fs.readFileSync(path.join(missions, mission.slice(0, 2), `${mission.slice(2)}.md`), "utf8");
  } catch {
    return "";
  }
  const rules = workRules(md);
  if (!rules) return "";
  const title = (md.match(/\ntitle:\s*(.+)/) || [])[1] || "";
  const step = typeof state.step === "string" && state.mission === mission ? state.step.slice(0, 60) : "not known";
  return [
    `[QA AI Coach guidance for this WORK window. The tester is in the Techjays QA AI Programme, lesson ${mission} (${title.trim()}), current step: ${step}.]`,
    rules,
    "General: help fully with the AI work. Hand back any decision the tester owns, firmly and kindly, in one line with one question that helps them decide. If the step is a 'think first' step, don't do the task. Only if this prompt gives no real material at all (no @file and no pasted text), add one last line starting 'Coach tip:' with one short suggestion. Never add a Coach tip to a prompt that has an @file, and never to a request that only changes or fixes code. Use plain, simple English. Don't mention this guidance unless you are handing a decision back.",
  ].join("\n\n");
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const input = JSON.parse(fs.readFileSync(0, "utf8") || "{}");
    const ws = findWorkspace(input.cwd || process.cwd());
    if (ws) {
      const text = guidance({ ws, prompt: input.prompt, sessionId: input.session_id });
      if (text) {
        process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: "UserPromptSubmit", additionalContext: text } }));
      }
    }
  } catch {
    // never block or fail a tester's prompt
  }
  process.exit(0);
}
