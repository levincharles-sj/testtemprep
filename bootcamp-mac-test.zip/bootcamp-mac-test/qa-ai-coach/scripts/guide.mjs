// QA AI Coach: the lesson page. A readable page (work/W<n>/D<d>-guide.html) made from the tester sections of a
// lesson and its week file, so testers can read the whole lesson in the browser while they work.
// Only the sections testers are meant to see are copied (TESTER_SECTIONS). The sections for Claude only
// (Done check, Work window rules, Coach notes) are never written to the page.
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

/** Lesson sections copied to the page. Everything else stays out. */
export const TESTER_SECTIONS = [
  "Today at a glance", "Where we are", "Yesterday you learned", "New words", "The work problem", "What you will make",
  "Learning notes", "Learn", "Your turn", "Finish", "Go further (optional)", "Learn more",
];
/** Week file sections copied to the page. */
export const WEEK_SECTIONS = ["This week in one line", "Day by day", "What you hand in this week", "By Friday you can"];

/** Split Markdown into {front, sections: Map(heading -> body)} on "## " headings. */
export function splitSections(md) {
  const text = String(md).replace(/\r\n/g, "\n");
  const fm = text.match(/^---\n([\s\S]*?)\n---\n/);
  const front = {};
  if (fm) for (const line of fm[1].split("\n")) {
    const m = line.match(/^(\w+):\s*(.*)$/);
    if (m) front[m[1]] = m[2].trim();
  }
  const body = fm ? text.slice(fm[0].length) : text;
  const sections = new Map();
  let head = null;
  let buf = [];
  let fence = false;
  for (const line of body.split("\n")) {
    if (/^```/.test(line)) fence = !fence;
    if (!fence && /^## /.test(line)) {
      if (head) sections.set(head, buf.join("\n").trim());
      head = line.slice(3).trim();
      buf = [];
    } else if (head) buf.push(line);
  }
  if (head) sections.set(head, buf.join("\n").trim());
  return { front, sections };
}

/** Split a section body on "### " headings: [{title, body}], with any text before the first heading as {title: ""}. */
export function splitParts(body) {
  const parts = [];
  let cur = { title: "", lines: [] };
  let fence = false;
  for (const line of String(body).split("\n")) {
    if (/^```/.test(line)) fence = !fence;
    if (!fence && /^### /.test(line)) {
      if (cur.title || cur.lines.join("").trim()) parts.push(cur);
      cur = { title: line.slice(4).trim(), lines: [] };
    } else cur.lines.push(line);
  }
  if (cur.title || cur.lines.join("").trim()) parts.push(cur);
  return parts.map((p) => ({ title: p.title, body: p.lines.join("\n").trim() }));
}

const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** Inline Markdown: code, bold, italic, links. Text is escaped first. */
export function inline(s) {
  const codes = [];
  let out = String(s).replace(/`([^`]+)`/g, (_, c) => `\u0000${codes.push(c) - 1}\u0000`);
  out = esc(out);
  out = out.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, (_, t, u) => `<a href="${u}" target="_blank" rel="noopener">${t}</a>`);
  out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  out = out.replace(/(^|[^*\w])\*([^*\s][^*]*?)\*(?!\w)/g, "$1<em>$2</em>");
  return out.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[Number(i)])}</code>`);
}

/** Paragraphs that open with these bold labels become coloured boxes, so the reader sees at once what each one is. */
const CALLOUTS = [
  [/^\*\*Your turn[:.]?\*\*/i, "turn", "Your turn"],
  [/^\*\*Quick check[:.]?\*\*/i, "check", "Quick check"],
  [/^\*\*Why this matters[:.]?\*\*/i, "why", "Why this matters"],
  [/^\*\*What you do and why[:.]?\*\*/i, "why", "What you do and why"],
  [/^\*\*Example/i, "example", ""],
  [/^\*\*This is how to/i, "example", ""],
  [/^\*\*Where[:.]?\*\*/i, "where", "Where"],
  [/^\*\*You should see[:.]?\*\*/i, "see", "You should see"],
  [/^\*\*What this means for testers[:.]?\*\*/i, "why", ""],
];

let copyId = 0;
let flowId = 0;

/**
 * A ```flow block: one step per line, "Name | note". A line "# Title" starts a new column, so two flows can be
 * compared side by side (for example "Without the file" and "With the file"). The diagram is still: boxes and arrows.
 */
export function flowHtml(lines) {
  const cols = [];
  let cur = null;
  for (const raw of lines) {
    const t = raw.trim();
    if (!t) continue;
    if (t.startsWith("# ")) { cur = { title: t.slice(2).trim(), steps: [] }; cols.push(cur); continue; }
    if (!cur) { cur = { title: "", steps: [] }; cols.push(cur); }
    const [name, ...note] = t.split("|");
    cur.steps.push({ name: name.trim(), note: note.join("|").trim() });
  }
  const id = `f${++flowId}`;
  const body = cols.map((c) => `<div class="flow-col">${c.title ? `<div class="flow-title">${inline(c.title)}</div>` : ""}${c.steps.map((st, k) =>
    `${k ? '<div class="flow-arrow" aria-hidden="true">↓</div>' : ""}<div class="flow-step"><b>${inline(st.name)}</b>${st.note ? `<span>${inline(st.note)}</span>` : ""}</div>`).join("")}</div>`).join("");
  return `<div class="flow" id="${id}" role="img" aria-label="${esc(cols.map((c) => (c.title ? c.title + ": " : "") + c.steps.map((x) => x.name).join(", then ")).join(". "))}">${body}</div>`;
}

/** Block Markdown to HTML: headings, paragraphs, lists, check boxes, quotes, code blocks (with a Copy button) and tables. */
export function mdToHtml(md) {
  const lines = String(md).replace(/\r\n/g, "\n").split("\n");
  const out = [];
  let i = 0;
  const isTableRow = (l) => /^\s*\|.*\|\s*$/.test(l);
  const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { i++; continue; }
    if (/^```/.test(line)) {
      const lang = line.slice(3).trim().toLowerCase();
      const code = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) code.push(lines[i++]);
      i++;
      if (lang === "flow") { out.push(flowHtml(code)); continue; }
      // Copy buttons only on what a tester types (a run: prompt, a coach command, a shell command), never on examples.
      const typed = /^(cmd|powershell|bash|shell|command)$/.test(lang) || /^\s*(run:|\/coach|claude\b|cd |npx |mkdir |!)/i.test(code[0] || "");
      const id = `c${++copyId}`;
      out.push(typed
        ? `<div class="code"><button type="button" class="copy" data-for="${id}">Copy</button><pre id="${id}"><code>${esc(code.join("\n"))}</code></pre></div>`
        : `<div class="code example-code"><pre><code>${esc(code.join("\n"))}</code></pre></div>`);
      continue;
    }
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) {
      const level = Math.min(h[1].length + 1, 5);
      out.push(`<h${level}>${inline(h[2])}</h${level}>`);
      i++;
      continue;
    }
    if (isTableRow(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
      const head = cells(line);
      i += 2;
      const rows = [];
      while (i < lines.length && isTableRow(lines[i])) rows.push(cells(lines[i++]));
      out.push(`<div class="table"><table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`);
      continue;
    }
    if (/^>\s?/.test(line)) {
      const q = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) q.push(lines[i++].replace(/^>\s?/, ""));
      out.push(`<blockquote>${mdToHtml(q.join("\n"))}</blockquote>`);
      continue;
    }
    const li = line.match(/^\s*([-*]|\d+\.)\s+(.*)$/);
    if (li) {
      const ordered = /\d/.test(li[1]);
      const items = [];
      while (i < lines.length) {
        const m = lines[i].match(/^\s*([-*]|\d+\.)\s+(.*)$/);
        if (m && /\d/.test(m[1]) === ordered && !/^\s{2,}/.test(lines[i])) { items.push(m[2]); i++; continue; }
        // An indented line (a sub-point or a wrapped line) belongs to the item above.
        if (items.length && /^\s{2,}\S/.test(lines[i])) { items[items.length - 1] += "\n" + lines[i].trim(); i++; continue; }
        break;
      }
      const tag = ordered ? "ol" : "ul";
      out.push(`<${tag}>${items.map((t) => {
        const [first, ...rest] = t.split("\n");
        const box = first.match(/^\[( |x)\]\s+(.*)$/i);
        const head = box ? `<span class="box">${box[1].trim() ? "☑" : "☐"}</span> ${inline(box[2])}` : inline(first);
        const sub = rest.length ? `<div class="sub">${rest.map((r) => inline(r.replace(/^[-*]\s+/, "• "))).join("<br>")}</div>` : "";
        return `<li${box ? ' class="check"' : ""}>${head}${sub}</li>`;
      }).join("")}</${tag}>`);
      continue;
    }
    const para = [];
    while (i < lines.length && lines[i].trim() && !/^(```|#{1,4}\s|>\s?|\s*([-*]|\d+\.)\s)/.test(lines[i]) && !isTableRow(lines[i])) para.push(lines[i++].trim());
    if (!para.length) { i++; continue; }
    const hit = CALLOUTS.find(([re]) => re.test(para[0]));
    const htmlText = para.map(inline).join("<br>");
    out.push(hit ? `<div class="callout ${hit[1]}"><p>${htmlText}</p></div>` : `<p>${htmlText}</p>`);
  }
  return out.join("\n");
}

const slug = (s) => String(s).toLowerCase().replace(/\(.*?\)/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

const STYLE = `
:root{--bg:#f4f6fb;--card:#ffffff;--fg:#1b2130;--muted:#566074;--line:#dde2ec;--accent:#3f48c8;--accent-soft:#eceefe;
--turn:#fff7e0;--turn-line:#e6a700;--check:#eaf6ff;--check-line:#2b86d1;--why:#f2f4f8;--example:#eef8f1;--example-line:#2f9a5b;--code:#f1f3f8}
@media (prefers-color-scheme:dark){:root{--bg:#12161f;--card:#1b2130;--fg:#e9ecf3;--muted:#a6aec0;--line:#2f3647;--accent:#9aa5ff;--accent-soft:#252c47;
--turn:#3a3016;--turn-line:#e6b53a;--check:#16303f;--check-line:#5fb1ee;--why:#222937;--example:#18301f;--example-line:#62c48a;--code:#232a3b;color-scheme:dark}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:18px/1.7 "Segoe UI",system-ui,-apple-system,Arial,sans-serif}
.wrap{max-width:820px;margin:0 auto;padding:20px 16px 72px}
header{padding:12px 0 8px}
.kicker{font-size:14px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}
h1{font-size:32px;line-height:1.25;margin:6px 0 14px;text-wrap:balance}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--accent-soft);color:var(--accent);border-radius:999px;padding:4px 14px;font-size:15px;font-weight:600}
.steps{position:sticky;top:0;z-index:5;background:var(--bg);display:flex;gap:6px;flex-wrap:wrap;padding:12px 0;margin:6px 0 10px;border-bottom:1px solid var(--line)}
.steps a{display:flex;align-items:center;gap:8px;text-decoration:none;color:var(--fg);background:var(--card);border:1px solid var(--line);border-radius:999px;padding:4px 12px 4px 4px;font-size:15px}
.steps a b{display:inline-grid;place-items:center;width:26px;height:26px;border-radius:50%;background:var(--accent);color:#fff;font-size:14px}
section.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:22px 26px;margin:0 0 18px}
section.card>h2{font-size:24px;margin:0 0 10px}
section.glance{border:2px solid var(--accent)}
.part-head{display:flex;align-items:center;gap:14px;margin:0 0 8px}
.part-num{flex:none;display:grid;place-items:center;width:44px;height:44px;border-radius:50%;background:var(--accent);color:#fff;font-size:22px;font-weight:700}
.part-head h2{font-size:24px;margin:0;line-height:1.3}
.part-time{color:var(--muted);font-size:15px}
h3{font-size:20px;margin:22px 0 8px}
h4,h5{font-size:18px;margin:16px 0 6px}
p{margin:10px 0}
ul,ol{margin:10px 0;padding-left:28px}
li{margin:6px 0}
li .sub{color:var(--muted);font-size:16px;margin-top:2px}
li.check{list-style:none;margin-left:-24px}
.box{color:var(--example-line)}
code{background:var(--code);border-radius:6px;padding:1px 6px;font:16px Consolas,"Cascadia Mono",Menlo,monospace}
.code{position:relative;margin:12px 0}
pre{background:var(--code);border-radius:12px;padding:16px 84px 16px 16px;overflow-x:auto;margin:0}
pre code{background:none;padding:0;white-space:pre-wrap;word-break:break-word;font-size:16px}
.copy{position:absolute;top:8px;right:8px;font:600 14px "Segoe UI",system-ui,sans-serif;background:var(--card);color:var(--accent);border:1px solid var(--line);border-radius:8px;padding:4px 12px;cursor:pointer}
blockquote{margin:12px 0;padding:8px 16px;border-left:4px solid var(--accent);background:var(--accent-soft);border-radius:0 10px 10px 0}
.callout{border-radius:12px;padding:6px 16px;margin:14px 0;border-left:5px solid transparent}
.callout p{margin:8px 0}
.callout.turn{background:var(--turn);border-left-color:var(--turn-line)}
.callout.check{background:var(--check);border-left-color:var(--check-line)}
.callout.why{background:var(--why);border-left-color:var(--line)}
.callout.example{background:var(--example);border-left-color:var(--example-line)}
.callout.where,.callout.see{background:var(--accent-soft);border-left-color:var(--accent)}
.table{overflow-x:auto;margin:12px 0}
table{border-collapse:collapse;width:100%;font-size:16px}
th,td{border:1px solid var(--line);padding:8px 12px;text-align:left;vertical-align:top}
th{background:var(--accent-soft)}
a{color:var(--accent)}
.words{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;margin-top:8px}
.word{border:1px solid var(--line);border-radius:12px;padding:12px 14px;background:var(--bg)}
.word b{display:block;font-size:18px;margin-bottom:4px}
.word span{font-size:16px}
.windows{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
.windows div{border:1px solid var(--line);border-radius:12px;padding:12px 14px;font-size:16px}
.windows b{display:block;font-size:17px}
details{margin:6px 0}
summary{cursor:pointer;font-weight:600;font-size:19px}
footer{color:var(--muted);font-size:15px;margin-top:28px}
.lead{font-size:19px;margin:14px 0 4px}
.example-code pre{padding:16px;border-left:5px solid var(--example-line)}
.flow{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:18px;margin:16px 0}
.flow-col{display:flex;flex-direction:column;align-items:stretch}
.flow-title{font-weight:700;margin:0 0 8px;color:var(--accent)}
.flow-step{border:2px solid var(--line);border-radius:12px;padding:10px 14px;background:var(--bg)}
.flow-step b{display:block;font-size:17px}
.flow-step span{display:block;color:var(--muted);font-size:15px;line-height:1.5}
.flow-arrow{text-align:center;color:var(--muted);font-size:20px;line-height:1.4}
.path{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 4px;padding:0;list-style:none}
.path li{display:flex;align-items:center;gap:8px;background:var(--bg);border:1px solid var(--line);border-radius:999px;padding:4px 14px 4px 4px;font-size:15px;margin:0}
.path li b{display:inline-grid;place-items:center;width:26px;height:26px;border-radius:50%;background:var(--accent);color:#fff;font-size:14px}
`;

const SCRIPT = `document.addEventListener('click',function(e){var b=e.target.closest('.copy');if(!b)return;var t=document.getElementById(b.dataset.for).innerText;
function ok(){b.textContent='Copied';setTimeout(function(){b.textContent='Copy'},1500)}
function sel(){var r=document.createRange();r.selectNodeContents(document.getElementById(b.dataset.for));var s=getSelection();s.removeAllRanges();s.addRange(r);try{document.execCommand('copy');ok()}catch(x){b.textContent='Press Ctrl+C'}}
if(navigator.clipboard){navigator.clipboard.writeText(t).then(ok,sel)}else sel()});`;

/** "New words" as small cards: one card per "- **Word:** meaning" line. */
export function wordCards(body) {
  const items = [...String(body).matchAll(/^\s*[-*]\s+\*\*([^*]+?):?\*\*:?\s*(.*)$/gm)];
  if (!items.length) return mdToHtml(body);
  return `<div class="words">${items.map((m) => `<div class="word"><b>${inline(m[1].replace(/:$/, ""))}</b><span>${inline(m[2]).replace("<em>In testing:</em>", "<br><em>In testing:</em>")}</span></div>`).join("")}</div>`;
}

/**
 * Build the lesson page: learning notes for the day. It never repeats what the coach shows in the terminal
 * (the start message, the parts, the examples, the finish steps). It says how to follow the coach, then gives
 * only what the coach does not: why the topic matters, the learning notes with diagrams, the words, optional links.
 * `mission` and `week` are Markdown texts (week may be ""). `info` = {id, date}.
 */
export function buildGuide(mission, week, info = {}) {
  copyId = 0;
  flowId = 0;
  const m = splitSections(mission);
  const w = splitSections(week || "");
  const id = m.front.id || info.id || "";
  const weekNo = Number((id.match(/^W(\d)/) || [0, 0])[1]);
  const title = m.front.title || "";
  const minutes = (m.front.minutes || "").replace("-", "–");
  const project = (m.front.project || "").trim();
  const chips = [info.date, minutes && `about ${minutes} minutes`, project && `Project ${project}`].filter(Boolean);
  const sec = (name) => m.sections.get(name);
  const html = [];
  const learn = (String(sec("Today at a glance") || "").match(/\*\*Today you learn:\*\*\s*(.+)/) || [])[1];

  // 1. How to do today's lesson: follow the coach. The part names only, no instructions.
  const names = [];
  for (const name of ["Learn", "Your turn"]) {
    for (const part of splitParts(sec(name) || "")) {
      const pm = part.title.match(/^(?:Part|Round|Step)\s+(\d+)\s*:\s*(.*?)(?:\s*\(about[^)]*\))?$/i);
      if (pm) names.push([pm[1], pm[2].split(":")[0].trim()]);
    }
  }
  const oneWindow = weekNo && weekNo <= 2;
  html.push(`<section id="how" class="card glance"><h2>How to do today's lesson</h2>
<p>The coach takes you through the whole lesson, one small step at a time. Follow the coach. You do not need this page to do the lesson.</p>
<ol>
<li>Open your <b>COACH</b> window: PowerShell, then <code>cd C:\\qa-ai-coach</code>, then <code>claude</code>.</li>
<li>Type <code>/coach</code> and press <b>Enter</b>. Then type <b><code>ready</code></b> and press <b>Enter</b>. (The very first time only, type <code>/coach</code> with your name, work email and start date, as the portal's <b>Start here</b> shows.)</li>
<li>Do what the coach asks, one part at a time.${oneWindow ? " When the coach asks you to use Claude, type <code>run:</code> and then your prompt." : " When the coach asks you to use Claude for the work, use your <b>WORK</b> window (<code>C:\\qa-ai-coach\\portfolio</code>)."}</li>
<li>At the end, type <code>/coach done</code>. Save your code on the portal's <b>Today</b> page. You are finished only when the portal shows <b>Saved</b>.</li>
</ol>
${names.length ? `<p class="part-time">Today's parts:</p><ol class="path">${names.map(([n, t]) => `<li><b>${esc(n)}</b>${esc(t)}</li>`).join("")}</ol>` : ""}
<p class="part-time">Lost? Type <code>/coach</code> again. The coach tells you where you are.</p></section>`);

  // 2. Why it matters, and what you make (one line: the coach explains the details).
  const make = String(sec("What you will make") || "").split("\n").find((l) => l.trim()) || "";
  const why = [sec("The work problem") && mdToHtml(sec("The work problem")), make && `<p><b>What you make today:</b> ${inline(make.replace(/^One file:\s*/i, ""))}</p>`].filter(Boolean).join("");
  if (why) html.push(`<section id="why" class="card"><h2>Why this matters</h2>${why}</section>`);

  // 3. Learning notes: the topic explained, with diagrams. Only on this page.
  if (sec("Learning notes")) html.push(`<section id="learning-notes" class="card"><h2>Learning notes</h2>${mdToHtml(sec("Learning notes"))}</section>`);

  // 4. Words used today: folded, for those who want them.
  if (sec("New words")) {
    const words = [...sec("New words").matchAll(/^\s*[-*]\s+\*\*([^*]+?):?\*\*/gm)].map((x) => x[1].replace(/:$/, ""));
    html.push(`<section id="new-words" class="card"><details><summary>Words used today${words.length ? `: ${esc(words.join(" · "))}` : ""} <span class="part-time">(open if you need them)</span></summary>${wordCards(sec("New words"))}</details></section>`);
  }

  // 5. Optional extras, then the week.
  // Go further: only what it is (the text before its first step). The steps are the coach's script.
  const further = sec("Go further (optional)") && sec("Go further (optional)").split(/^####\s/m)[0].trim();
  const furtherHtml = further && (/^####\s/m.test(sec("Go further (optional)"))
    ? `${mdToHtml(further)}<p>After you finish the lesson, type <b><code>/coach Go further</code></b> in your COACH window. The coach takes you through it step by step.</p>`
    : mdToHtml(sec("Go further (optional)")));
  const extra = [furtherHtml && `<details><summary>Go further (optional)</summary>${furtherHtml}</details>`, sec("Learn more") && `<h3>Learn more (optional)</h3>${mdToHtml(sec("Learn more"))}`].filter(Boolean).join("");
  if (extra) html.push(`<section id="more" class="card"><h2>More, if you want it</h2>${extra}</section>`);
  const weekBody = WEEK_SECTIONS.filter((s) => w.sections.has(s)).map((s) => `### ${s}\n${w.sections.get(s)}`).join("\n\n");
  if (weekBody) html.push(`<section id="this-week" class="card"><details><summary>This week</summary>${mdToHtml(weekBody)}</details></section>`);

  return `<!doctype html>
<html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(id)} · ${esc(title)}</title><style>${STYLE}</style></head>
<body><div class="wrap">
<header><div class="kicker">QA AI Coach · learning notes · ${esc(id)}</div><h1>${esc(title)}</h1>
<div class="chips">${chips.map((c) => `<span class="chip">${inline(c)}</span>`).join("")}</div>
${learn ? `<p class="lead"><b>Today you learn:</b> ${inline(learn)}</p>` : ""}</header>
${html.join("\n")}
<footer>These are your notes for the lesson. The lesson itself happens with the coach: type <code>/coach</code> in your COACH window.</footer>
</div><script>${SCRIPT}</script></body></html>
`;
}

/** Write work/W<n>/D<d>-guide.html. Returns {rel, abs, changed}. */
export function writeGuide(mission, workspace, missionsDir, info = {}) {
  const file = path.join(missionsDir, mission.week, `${mission.day}.md`);
  if (!fs.existsSync(file)) return null;
  const weekFile = path.join(missionsDir, mission.week, "WEEK.md");
  const html = buildGuide(fs.readFileSync(file, "utf8"), fs.existsSync(weekFile) ? fs.readFileSync(weekFile, "utf8") : "", { id: mission.id, ...info });
  const to = path.join(workspace, "work", mission.week, `${mission.day}-guide.html`);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  const created = !fs.existsSync(to);
  const changed = created || fs.readFileSync(to, "utf8") !== html;
  if (changed) fs.writeFileSync(to, html);
  return { rel: path.relative(workspace, to).split(path.sep).join("/"), abs: to, changed, created };
}

/** Open a file in the default browser. Never throws; returns true when an opener was started. */
export function openInBrowser(abs) {
  if (process.env.QA_COACH_NO_OPEN) return false;
  try {
    const [cmd, args] = process.platform === "win32" ? ["explorer.exe", [abs]] : process.platform === "darwin" ? ["open", [abs]] : ["xdg-open", [abs]];
    const child = spawn(cmd, args, { detached: true, stdio: "ignore" });
    child.on("error", () => {});
    child.unref();
    return true;
  } catch {
    return false;
  }
}
