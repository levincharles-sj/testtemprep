#!/usr/bin/env node
// QA AI Coach: token usage of PROGRAMME work (sessions in the coach folder only).
// The Stop/SessionEnd hook (save-conversation.mjs) calls recordUsage() to write
// <workspace>/usage/<India date>/<sessionId>.json: token counts per model and an estimate at API list price.
// Only numbers are stored, never conversation content.
//
// CLI:  node usage.mjs today            -> one line: today and this week
//       node usage.mjs week [--week W2] -> this programme week (or the one named), with a line per day
// Prints USAGE_ERROR <reason> and exits 1 if it can't run (the coach then skips the line silently).
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, indiaDate, todayFor, previewDateOf, priceFor, USAGE_LABEL, readMe, startDateOf, weekOf, weekStart } from "./lib.mjs";

const TYPES = ["input", "output", "cacheWrite", "cacheRead"];
const zero = () => ({ input: 0, output: 0, cacheWrite: 0, cacheRead: 0 });
const n = (v) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : 0);
const round4 = (x) => Math.round(x * 10000) / 10000;

/** The session transcript plus any subagent transcripts (<session>/subagents/*.jsonl). */
export function transcriptFiles(transcriptPath) {
  const files = [transcriptPath];
  const sub = path.join(transcriptPath.replace(/\.jsonl$/i, ""), "subagents");
  try {
    if (fs.existsSync(sub))
      for (const f of fs.readdirSync(sub).sort()) if (f.toLowerCase().endsWith(".jsonl")) files.push(path.join(sub, f));
  } catch {
    /* unreadable subagent folder: count the main transcript only */
  }
  return files;
}

/**
 * Sum `message.usage` over assistant messages in one or more transcript JSONL texts.
 * One API response can be written as several lines with the same message id, and earlier lines
 * carry partial output counts, so the LAST line for each id wins. Missing fields count as 0.
 * Returns { first, models: {model: {input, output, cacheWrite, cacheRead}}, totals, estUsd, approximate, messages }.
 */
export function sumUsage(texts) {
  const byId = new Map();
  let first = null;
  let anon = 0;
  texts.forEach((text, fileNo) => {
    for (const line of String(text ?? "").split(/\r?\n/)) {
      if (!line.trim()) continue;
      let o;
      try {
        o = JSON.parse(line);
      } catch {
        continue;
      }
      if (fileNo === 0 && o && o.timestamp && !first) first = o.timestamp;
      if (!o || o.type !== "assistant" || !o.message || typeof o.message.usage !== "object" || !o.message.usage) continue;
      const id = o.message.id || o.requestId || o.uuid || `anon-${anon++}`;
      byId.delete(id); // re-insert so the last line wins
      byId.set(id, o.message);
    }
  });
  const models = {};
  const totals = zero();
  let cost = 0;
  let approximate = false;
  let messages = 0;
  for (const msg of byId.values()) {
    const u = msg.usage;
    const cc = u.cache_creation && typeof u.cache_creation === "object" ? u.cache_creation : null;
    let cw5 = 0, cw1h = 0;
    if (cc && (cc.ephemeral_5m_input_tokens != null || cc.ephemeral_1h_input_tokens != null)) {
      cw5 = n(cc.ephemeral_5m_input_tokens);
      cw1h = n(cc.ephemeral_1h_input_tokens);
    } else cw1h = n(u.cache_creation_input_tokens); // no split recorded: Claude Code's main thread uses the 1-hour cache
    const t = { input: n(u.input_tokens), output: n(u.output_tokens), cacheWrite: cw5 + cw1h, cacheRead: n(u.cache_read_input_tokens) };
    if (!TYPES.some((k) => t[k])) continue; // synthetic or empty messages
    messages++;
    const model = String(msg.model || "unknown");
    const m = (models[model] ||= zero());
    for (const k of TYPES) {
      m[k] += t[k];
      totals[k] += t[k];
    }
    const p = priceFor(model);
    if (!p.known) approximate = true;
    cost += (t.input * p.input + t.output * p.output + cw5 * p.cacheWrite5m + cw1h * p.cacheWrite1h + t.cacheRead * p.cacheRead) / 1e6;
  }
  totals.tokens = TYPES.reduce((a, k) => a + totals[k], 0);
  return { first, models, totals, estUsd: round4(cost), approximate, messages };
}

function safeId(s) {
  return String(s || "").replace(/[^A-Za-z0-9_-]/g, "");
}

/**
 * Write (or overwrite) <ws>/usage/<India date>/<sessionId>.json for one session. Idempotent.
 * The date is the India date (Asia/Kolkata) of the session's first transcript line.
 * Returns the file written, or null when the session has no usage yet.
 */
export function recordUsage(ws, transcriptPath, sessionId) {
  if (!ws || !transcriptPath || !fs.existsSync(transcriptPath)) return null;
  const texts = transcriptFiles(transcriptPath).map((f) => {
    try {
      return fs.readFileSync(f, "utf8");
    } catch {
      return "";
    }
  });
  const s = sumUsage(texts);
  if (!s.messages) return null;
  const sid = safeId(sessionId) || safeId(path.basename(transcriptPath, ".jsonl")) || "session";
  // In the programme manager's preview workspace, usage is filed under the preview date, which "usage.mjs today" reads.
  const date = previewDateOf(readMe(ws)) || indiaDate(s.first ? new Date(s.first) : new Date()) || indiaDate(new Date());
  const rec = {
    date,
    sessionId: sid,
    models: s.models,
    totals: s.totals,
    estUsd: s.estUsd,
    approximate: s.approximate,
    basis: USAGE_LABEL,
    updatedAt: new Date().toISOString(),
  };
  const dir = path.join(ws, "usage", date);
  fs.mkdirSync(dir, { recursive: true });
  // A session is filed under the date it started; drop a copy left under another date by an older run.
  try {
    for (const d of fs.readdirSync(path.join(ws, "usage"))) {
      const old = path.join(ws, "usage", d, `${sid}.json`);
      if (d !== date && fs.existsSync(old)) fs.rmSync(old);
    }
  } catch {
    /* ignore */
  }
  const file = path.join(dir, `${sid}.json`);
  fs.writeFileSync(file, JSON.stringify(rec, null, 2) + "\n", "utf8");
  return file;
}

/** All usage records for the given India dates. Unreadable files are skipped. */
export function readUsage(ws, days) {
  const out = [];
  for (const day of days) {
    const dir = path.join(ws, "usage", day);
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).sort()) {
      if (!f.endsWith(".json")) continue;
      try {
        const r = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8").replace(/^﻿/, ""));
        if (r && typeof r === "object") out.push({ ...r, date: r.date || day });
      } catch {
        /* skip */
      }
    }
  }
  return out;
}

/** Totals over records: { sessions, tokens: {input, output, cacheWrite, cacheRead, total}, estUsd, approximate }. */
export function aggregate(records) {
  const tokens = zero();
  let est = 0, approximate = false;
  for (const r of records) {
    const t = r.totals || {};
    for (const k of TYPES) tokens[k] += n(t[k]);
    est += n(r.estUsd);
    if (r.approximate) approximate = true;
  }
  tokens.total = TYPES.reduce((a, k) => a + tokens[k], 0);
  return { sessions: records.length, tokens, estUsd: round4(est), approximate };
}

function addDays(ymd, k) {
  const d = new Date(ymd + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + k);
  return d.toISOString().slice(0, 10);
}

/** Programme week id ("W1".."W6") holding an India date for a start date, or null (outside the programme, or no start date). */
export function programmeWeek(ymd, startDate) {
  if (!startDate) return null;
  const n = weekOf(startDate, ymd);
  return n ? `W${n}` : null;
}

/**
 * The seven India dates (Mon–Sun) of a programme week for a start date, or of the calendar week holding `ymd`
 * when no week is given.
 */
export function weekDays(week, ymd, startDate) {
  let start;
  if (week) {
    const m = String(week).toUpperCase().match(/^W([1-6])$/);
    if (!m) throw new Error(`Unknown week "${week}". Use W1 to W6.`);
    if (!startDate) throw new Error("No start date in me.json, so the programme weeks are not known.");
    start = weekStart(startDate, Number(m[1]));
  } else {
    const dow = new Date(ymd + "T12:00:00Z").getUTCDay();
    start = addDays(ymd, -((dow + 6) % 7));
  }
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

/** 640000 -> "640k", 1600000 -> "1.6M". */
export function fmtTokens(x) {
  x = n(x);
  if (x >= 1e6) return `${(x / 1e6).toFixed(x >= 1e7 ? 0 : 1)}M`;
  if (x >= 1e3) return `${Math.round(x / 1e3)}k`;
  return String(x);
}

export function fmtUsd(x) {
  return `$${n(x).toFixed(2)}`;
}

function part(a) {
  if (!a.sessions) return "none recorded yet";
  return `${a.sessions} session${a.sessions === 1 ? "" : "s"} · ${fmtTokens(a.tokens.total)} tokens · about ${fmtUsd(a.estUsd)}${a.approximate ? " (approximate)" : ""}`;
}

const DOW = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
/** "2026-10-26" -> "Mon 26 Oct". */
const fmtDay = (ymd) => {
  const d = new Date(ymd + "T12:00:00Z");
  return `${DOW[d.getUTCDay()]} ${d.getUTCDate()} ${MON[d.getUTCMonth()]}`;
};

/** The text `node usage.mjs today|week` prints. */
export function summary(ws, mode = "today", { now = new Date(), week = null } = {}) {
  const me = readMe(ws);
  const today = todayFor(me, now); // the preview date in preview mode
  const startDate = startDateOf(me);
  const label = `${USAGE_LABEL[0].toUpperCase()}${USAGE_LABEL.slice(1)}.`;
  if (mode === "today") {
    const w = programmeWeek(today, startDate);
    const t = aggregate(readUsage(ws, [today]));
    const wk = aggregate(readUsage(ws, weekDays(w, today, startDate)));
    return `Your Claude use today: ${part(t)}. This week${w ? ` (${w})` : ""}: ${part(wk)}. A record for the programme manager; it costs you nothing.`;
  }
  if (mode === "week") {
    const w = week ? String(week).toUpperCase() : programmeWeek(today, startDate);
    const days = weekDays(w, today, startDate);
    const recs = readUsage(ws, days);
    const lines = [`Programme usage ${w || "this week"} (${fmtDay(days[0])} – ${fmtDay(days[6])}): ${part(aggregate(recs))}.`];
    for (const d of days) {
      const a = aggregate(recs.filter((r) => r.date === d));
      if (a.sessions) lines.push(`  ${fmtDay(d)}: ${part(a)}`);
    }
    lines.push(label);
    return lines.join("\n");
  }
  throw new Error(`Unknown option "${mode}". Use: today, or week [--week W<n>]`);
}

/** Claude Code's folder for a working directory's transcripts (~/.claude/projects/<cwd with non-alphanumerics as ->). */
export function projectDir(cwd) {
  const base = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), ".claude");
  return path.join(base, "projects", path.resolve(cwd).replace(/[^A-Za-z0-9]/g, "-"));
}

/**
 * Best effort: bring today's records up to date before printing, so the session that is running
 * /coach done is counted too (its hook has not run yet). Only transcripts of sessions started in
 * this coach folder, changed in the last 12 hours. Never throws.
 */
export function refreshRecent(ws, cwd = process.cwd(), { maxAgeMs = 12 * 3600e3 } = {}) {
  try {
    if (findWorkspace(cwd) !== ws) return 0;
    const dir = projectDir(cwd);
    if (!fs.existsSync(dir)) return 0;
    let count = 0;
    for (const f of fs.readdirSync(dir)) {
      if (!f.endsWith(".jsonl")) continue;
      const full = path.join(dir, f);
      if (Date.now() - fs.statSync(full).mtimeMs > maxAgeMs) continue;
      if (recordUsage(ws, full, path.basename(f, ".jsonl"))) count++;
    }
    return count;
  } catch {
    return 0;
  }
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const args = process.argv.slice(2);
    const mode = (args.find((a) => !a.startsWith("--") && !/^W\d$/i.test(a)) || "today").toLowerCase();
    const wi = args.indexOf("--week");
    const week = wi >= 0 ? args[wi + 1] : null;
    const ws = findWorkspace(process.cwd());
    if (!ws) throw new Error("No me.json found. Start Claude Code in your coach folder.");
    refreshRecent(ws);
    console.log(summary(ws, mode, { week }));
  } catch (err) {
    console.log(`USAGE_ERROR ${err && err.message ? err.message : err}`);
    process.exit(1);
  }
}
