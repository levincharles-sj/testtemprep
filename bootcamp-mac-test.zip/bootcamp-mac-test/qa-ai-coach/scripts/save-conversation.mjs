#!/usr/bin/env node
// QA AI Coach: saves the current Claude Code conversation as readable Markdown
// in <workspace>/conversations/<YYYY-MM-DD>/<session_id>.md, and its token counts (numbers only, never
// content) in <workspace>/usage/<India date>/<session_id>.json (see usage.mjs).
// Runs as a Stop / SessionEnd hook. Does nothing outside a coach workspace (a folder with me.json).
// Never blocks Claude Code: always exits 0.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, readMe, indiaDate, previewDateOf, redact } from "./lib.mjs";
import { recordUsage } from "./usage.mjs";

const MAX_TEXT = 6000; // per message, to keep files readable

function clip(s, n = MAX_TEXT) {
  s = String(s ?? "");
  return s.length > n ? s.slice(0, n) + `\n… [${s.length - n} more characters not shown]` : s;
}

function stripNoise(s) {
  return String(s ?? "")
    .replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, "")
    .replace(/<local-command-stdout>[\s\S]*?<\/local-command-stdout>/g, "")
    .trim();
}

/** Turn a slash-command user message into "/name args". */
function commandText(s) {
  const name = /<command-name>([\s\S]*?)<\/command-name>/.exec(s);
  if (!name) return null;
  const args = /<command-args>([\s\S]*?)<\/command-args>/.exec(s);
  return `${name[1].trim()}${args && args[1].trim() ? " " + args[1].trim() : ""}`;
}

// The Parcelly practice assistant's files (skills/parcelly) never appear in a saved conversation by name.
export const PARCELLY_KB_RE = /skills[\\/]+parcelly/i;
export const PARCELLY_KB_LABEL = "(Parcelly knowledge base)";

function toolSummary(block) {
  const i = block.input || {};
  const hint =
    i.file_path || i.path || i.pattern || i.url || i.command || i.description || i.query || "";
  let h = String(hint).replace(/\s+/g, " ").slice(0, 100);
  let all = "";
  try {
    all = JSON.stringify(i);
  } catch {
    all = "";
  }
  if (PARCELLY_KB_RE.test(String(hint)) || PARCELLY_KB_RE.test(all)) h = PARCELLY_KB_LABEL;
  return `_Tool: ${block.name}${h ? " · " + h : ""}_`;
}

function hhmm(ts) {
  const d = new Date(ts);
  if (isNaN(d)) return "";
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

/** Parse transcript JSONL text into a list of {role, time, text}. Exported for tests. */
export function parseTranscript(jsonl) {
  const entries = [];
  let first = null;
  let last = null;
  // The work helper's answers (weeks 1–2: the tester's own `run:` prompts) are evidence of the tester's AI use,
  // so they are kept. All other tool output is skipped.
  const helperCalls = new Set();
  for (const line of String(jsonl).split(/\r?\n/)) {
    if (!line.trim()) continue;
    let o;
    try {
      o = JSON.parse(line);
    } catch {
      continue;
    }
    if (o.type !== "user" && o.type !== "assistant") continue;
    if (o.isSidechain || o.isMeta) continue;
    const ts = o.timestamp;
    if (ts) {
      if (!first) first = ts;
      last = ts;
    }
    const c = o.message && o.message.content;
    if (o.type === "user") {
      if (typeof c === "string") {
        const cmd = commandText(c);
        const t = cmd || stripNoise(c);
        if (t) entries.push({ role: "Tester", time: ts, text: t });
      } else if (Array.isArray(c)) {
        const texts = c.filter((b) => b.type === "text").map((b) => stripNoise(b.text)).filter(Boolean);
        if (texts.length) entries.push({ role: "Tester", time: ts, text: texts.join("\n\n") });
        // tool_result blocks are skipped (tool output, not the tester's words), except the work helper's answers.
        for (const b of c) {
          if (b.type !== "tool_result" || !helperCalls.has(b.tool_use_id)) continue;
          const out = typeof b.content === "string" ? b.content : Array.isArray(b.content) ? b.content.filter((x) => x.type === "text").map((x) => x.text).join("\n\n") : "";
          if (out.trim()) entries.push({ role: "Claude (work helper)", time: ts, text: out.trim() });
        }
      }
    } else {
      if (!Array.isArray(c)) continue;
      for (const b of c) {
        if (b.type === "text" && b.text && b.text.trim()) entries.push({ role: "Claude", time: ts, text: b.text.trim() });
        else if (b.type === "tool_use") {
          entries.push({ role: "Claude", time: ts, text: toolSummary(b), tool: true });
          const kind = b.input && (b.input.subagent_type || b.input.agent_type);
          if ((b.name === "Agent" || b.name === "Task") && /(^|:)work$/.test(String(kind || ""))) helperCalls.add(b.id);
        }
      }
    }
  }
  return { entries, first, last };
}

/** Render parsed entries to Markdown. Exported for tests. */
export function renderMarkdown({ entries, first, last }, meta) {
  const me = meta.me || {};
  const out = [];
  out.push(`# Conversation ${meta.sessionId}`);
  out.push("");
  if (first) out.push(`- Started: ${new Date(first).toLocaleString("en-GB")}`);
  if (last) out.push(`- Last activity: ${new Date(last).toLocaleString("en-GB")}`);
  out.push(`- Messages: ${entries.filter((e) => !e.tool).length}`);
  out.push(`- Saved automatically by QA AI Coach. Your name, emails and keys are replaced with [TESTER], [EMAIL] and [removed].`);
  out.push("");
  for (const e of entries) {
    if (e.tool) {
      out.push(redact(e.text, me));
      out.push("");
      continue;
    }
    out.push(`### ${e.role}${e.time ? " · " + hhmm(e.time) : ""}`);
    out.push("");
    out.push(redact(clip(e.text), me));
    out.push("");
  }
  return out.join("\n");
}

function readStdin() {
  try {
    return fs.readFileSync(0, "utf8");
  } catch {
    return "";
  }
}

/** Main logic, separated so tests can call it with a fake input object. */
export function capture(input) {
  const ws = findWorkspace(input.cwd || process.cwd());
  if (!ws) return { skipped: "not a coach workspace" };
  const tp = input.transcript_path;
  if (!tp || !fs.existsSync(tp)) return { skipped: "no transcript" };
  const sessionId = String(input.session_id || path.basename(tp, ".jsonl")).replace(/[^A-Za-z0-9_-]/g, "");
  // Usage first, in its own guard: a problem here must never stop the conversation being saved.
  let usageFile = null;
  try {
    usageFile = recordUsage(ws, tp, sessionId);
  } catch (err) {
    logError(ws, err);
  }
  const parsed = parseTranscript(fs.readFileSync(tp, "utf8"));
  if (!parsed.entries.length) return { skipped: "empty", usageFile };
  const me = readMe(ws);
  // India date, like usage/. In a preview workspace (the programme manager's rehearsal), the preview day, so the
  // coach finds "today's" conversations where it looks.
  const day = previewDateOf(me) || indiaDate(parsed.first ? new Date(parsed.first) : new Date());
  const dir = path.join(ws, "conversations", day);
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${sessionId}.md`);
  fs.writeFileSync(file, renderMarkdown(parsed, { sessionId, me }), "utf8");
  return { file, usageFile };
}

function logError(ws, err) {
  try {
    const dir = path.join(ws, "conversations");
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, ".capture-errors.log"), `${new Date().toISOString()} ${err && err.stack ? err.stack : err}\n`);
  } catch {
    /* never block */
  }
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  let input = {};
  try {
    const raw = readStdin();
    input = raw ? JSON.parse(raw) : {};
    capture(input);
  } catch (err) {
    try {
      const ws = findWorkspace(input.cwd || process.cwd());
      if (ws) logError(ws, err);
    } catch {
      /* never block */
    }
  }
  process.exit(0);
}
