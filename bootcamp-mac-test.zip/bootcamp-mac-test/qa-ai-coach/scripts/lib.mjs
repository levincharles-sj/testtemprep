// Shared helpers for the QA AI Coach scripts. No dependencies; Windows and macOS.
import fs from "node:fs";
import crypto from "node:crypto";
import path from "node:path";

/** Walk up from `start` (max 6 levels) to find the coach workspace: the folder holding me.json. */
export function findWorkspace(start) {
  let dir = path.resolve(start || process.cwd());
  for (let i = 0; i < 7; i++) {
    if (fs.existsSync(path.join(dir, "me.json"))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

export function readMe(workspace) {
  try {
    // Windows editors and PowerShell 5.1 often save UTF-8 with a byte-order mark; JSON.parse rejects it.
    return JSON.parse(fs.readFileSync(path.join(workspace, "me.json"), "utf8").replace(/^﻿/, ""));
  } catch {
    return {};
  }
}

/** Local calendar date YYYY-MM-DD for a Date. */
export function localDate(d) {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

const REDACTIONS = [
  [/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, "[EMAIL]"],
  [/\bsk-[A-Za-z0-9_-]{16,}/g, "[key removed]"],
  [/\bgh[pousr]_[A-Za-z0-9]{20,}/g, "[key removed]"],
  [/\bAKIA[0-9A-Z]{16}\b/g, "[key removed]"],
  [/\bxox[abpr]-[A-Za-z0-9-]{10,}/g, "[key removed]"],
  [/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, "[token removed]"],
  [/((?:api[_-]?key|access[_-]?token|secret|password|passwd|pwd|bearer)\s*[:=]\s*)["']?[^\s"',;]{4,}/gi, "$1[removed]"],
  [/(Authorization:\s*Bearer\s+)\S+/gi, "$1[removed]"],
];

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Remove secrets, all emails ([EMAIL]) and the tester's own name ([TESTER]).
 * `me` is the parsed me.json ({name, email}); the full name is replaced in any case; each name part of 3+ letters is replaced when capitalised.
 */
export function redact(text, me = {}) {
  let out = String(text ?? "");
  if (me.email) out = out.replace(new RegExp(escapeRe(String(me.email).trim()), "gi"), "[EMAIL]");
  for (const [re, rep] of REDACTIONS) out = out.replace(re, rep);
  const name = String(me.name || "").trim();
  if (name) {
    out = out.replace(new RegExp(escapeRe(name), "gi"), "[TESTER]");
    // Name parts: only when capitalised ("Grace", "GRACE"), so common words such as "grace" or "will" survive.
    for (const part of name.split(/\s+/).filter((p) => p.length >= 3)) {
      const cap = part[0].toUpperCase() + part.slice(1).toLowerCase();
      for (const form of new Set([cap, part.toUpperCase()])) {
        out = out.replace(new RegExp(`(?<![\\p{L}\\p{N}])${escapeRe(form)}(?![\\p{L}\\p{N}])`, "gu"), "[TESTER]");
      }
    }
  }
  return out;
}

/** Safe file-name part from an email's local part: "Jane.Doe+qa@x.com" → "jane.doe-qa". */
export function emailSlug(email) {
  const local = String(email || "").split("@")[0].toLowerCase();
  const slug = local.replace(/[^a-z0-9._-]+/g, "-").replace(/^[-.]+|[-.]+$/g, "");
  return slug || "unknown";
}

// ---------------------------------------------------------------------------------------------
// Programme calendar (docs/uplift/groups-design.md). Each tester's dates come from their start date
// (me.json "startDate", always a Monday, India date). Week n, day d = start + 7(n-1) + (d-1).
// Week n runs Monday to Sunday. C<n> belongs to W<n> and is due Friday of W<n>. The programme ends
// Friday of week 6 (start + 39). A missed mission can be done at any time later; it is saved as Done late.
// ---------------------------------------------------------------------------------------------

/** Shown whenever a script needs the start date and me.json has none (or an invalid one). */
export const START_DATE_HELP =
  "Your start date isn't set yet. Find it in the portal (Start here → Your programme), then type /coach start followed by the date, for example: /coach start YYYY-MM-DD (the date from the portal)";

/** A date + k days, as YYYY-MM-DD (calendar arithmetic, no time zone involved). */
export function addDays(ymd, k) {
  const d = new Date(`${ymd}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + k);
  return d.toISOString().slice(0, 10);
}

/** Whole days from ymd a to ymd b (b - a). */
export function daysBetween(a, b) {
  return Math.round((Date.parse(`${b}T12:00:00Z`) - Date.parse(`${a}T12:00:00Z`)) / 864e5);
}

/** A real calendar date "YYYY-MM-DD", or null. */
export function validYmd(s) {
  const m = String(s ?? "").trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const ymd = m[0];
  return new Date(`${ymd}T12:00:00Z`).toISOString().slice(0, 10) === ymd ? ymd : null;
}

export const isMonday = (ymd) => new Date(`${ymd}T12:00:00Z`).getUTCDay() === 1;

/**
 * Check a start date typed by a tester. Returns {ok:true, start} or {ok:false, reason} with a plain sentence.
 * Rules: YYYY-MM-DD, a real date, a Monday, between 2026 and 2035.
 */
export function checkStartDate(s) {
  const ymd = validYmd(s);
  if (!ymd) return { ok: false, reason: `"${String(s ?? "").trim()}" is not a date in the form YYYY-MM-DD (year-month-day). Copy the date from the portal.` };
  const y = Number(ymd.slice(0, 4));
  if (y < 2026 || y > 2035) return { ok: false, reason: `${ymd} is outside the years the programme runs. Check the date in the portal.` };
  if (!isMonday(ymd)) return { ok: false, reason: `${ymd} is a ${DAY_NAMES[new Date(`${ymd}T12:00:00Z`).getUTCDay()]}. A start date is always a Monday. Check the date in the portal.` };
  return { ok: true, start: ymd };
}

/** The tester's start date from me.json, or null when missing or invalid. */
export function startDateOf(me) {
  const r = checkStartDate(me && me.startDate);
  return r.ok ? r.start : null;
}

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const DOW_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MON_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
/** "2026-11-03" -> "Tue 3 Nov". */
export function fmtDay(ymd) {
  const d = new Date(`${ymd}T12:00:00Z`);
  return `${DOW_SHORT[d.getUTCDay()]} ${d.getUTCDate()} ${MON_SHORT[d.getUTCMonth()]}`;
}

/** Parse "W2D3" -> {w:2, d:3, id:"W2D3"}; null if not W1–W6 D1–D5. */
export function parseMissionId(id) {
  const m = String(id || "").trim().toUpperCase().match(/^W([1-6])D([1-5])$/);
  return m ? { w: Number(m[1]), d: Number(m[2]), id: `W${m[1]}D${m[2]}` } : null;
}

/** Monday of week n (1–6) for a start date. */
export const weekStart = (start, n) => addDays(start, 7 * (n - 1));
/** Sunday of week n: the end of that week (the programme manager's on-time cut-off for its lessons). */
export const weekEnd = (start, n) => addDays(start, 7 * (n - 1) + 6);
/** Date of a mission ("W2D3") for a start date. */
export function missionDate(start, id) {
  const p = parseMissionId(id);
  if (!p) throw new Error(`"${id}" is not a mission id. Use one like W1D1.`);
  return addDays(start, 7 * (p.w - 1) + (p.d - 1));
}
/** Friday of week 6: the last day of the programme. */
export const programmeEnd = (start) => addDays(start, 39);
/** Friday of the challenge's week: C<n> belongs to W<n>. */
export function challengeDue(start, challenge) {
  const m = String(challenge || "").trim().match(/^c?([1-5])$/i);
  if (!m) throw new Error(`"${challenge}" is not a challenge. Use C1 to C5.`);
  return addDays(start, 7 * (Number(m[1]) - 1) + 4);
}
/** Due date of a weekly hand-in file: C1–C5 on Friday of their week; W6 (the week 6 file) on Thursday of week 6. */
export function handInDue(start, id) {
  if (/^w6$/i.test(String(id || "").trim())) return addDays(start, 38);
  return challengeDue(start, id);
}
/** Week number (1–6) holding an India date (Monday–Sunday), or null outside the programme. */
export function weekOf(start, ymd) {
  const diff = daysBetween(start, ymd);
  if (diff < 0 || diff > 41) return null;
  return Math.floor(diff / 7) + 1;
}
/** Mission id for an India date (a programme weekday), or null (weekend, before or after). */
export function missionOn(start, ymd) {
  const diff = daysBetween(start, ymd);
  if (diff < 0 || diff > 39) return null;
  const d = (diff % 7) + 1;
  return d <= 5 ? `W${Math.floor(diff / 7) + 1}D${d}` : null;
}
const PREVIEW_HASH = "70077dbc7aadd227f4058e393ebdbc46a049890e940aaaa52d12ea12df76f8d0";
/** True only for the programme manager's own workspace. */
export function isPreview(me) {
  if (!me || me.preview !== true || typeof me.previewKey !== "string") return false;
  return crypto.createHash("sha256").update(me.previewKey).digest("hex") === PREVIEW_HASH;
}
/** A date treated as today in that workspace, or null. */
export function previewDateOf(me) {
  return isPreview(me) ? validYmd(me.previewDate) : null;
}

/** "Today" as an India date for this workspace. */
export function todayFor(me, now = new Date()) {
  return previewDateOf(me) || indiaDate(now);
}

/** All 30 mission ids in order. */
/** Lessons with a completion code, kept by proof-code.mjs in proofs/.done.json (not part of the weekly bundle).
 *  A lesson counts as finished once its code is made, even if the proof file is missing or misnamed. */
export const DONE_FILE = path.join("proofs", ".done.json");

export function readDone(ws) {
  try {
    const list = JSON.parse(fs.readFileSync(path.join(ws, DONE_FILE), "utf8").replace(/^﻿/, ""));
    return Array.isArray(list) ? list.filter((r) => r && /^W[1-6]D[1-5]$/.test(r.id)) : [];
  } catch {
    return [];
  }
}

export function recordDone(ws, id, verdict, at = new Date()) {
  const list = readDone(ws).filter((r) => r.id !== id);
  list.push({ id, verdict, at: at.toISOString() });
  fs.mkdirSync(path.join(ws, "proofs"), { recursive: true });
  fs.writeFileSync(path.join(ws, DONE_FILE), JSON.stringify(list, null, 2) + "\n");
}

export const ALL_MISSIONS = Array.from({ length: 30 }, (_, i) => `W${Math.floor(i / 5) + 1}D${(i % 5) + 1}`);

/** Calendar date YYYY-MM-DD in India time (Asia/Kolkata), whatever the laptop's time zone. */
export function indiaDate(d = new Date()) {
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt)) return null;
  // en-CA formats as YYYY-MM-DD
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(dt);
}

/**
 * API list prices, US$ per million tokens, for the usage ESTIMATE only. One place; keep in step with
 * config/pricing.json in the programme repo. Source: https://platform.claude.com/docs/en/about-claude/pricing
 * (checked 20 Oct 2026; see docs/uplift/ops/usage-measurement.md, fact F17).
 * Cache writes cost 1.25x input (5-minute cache) or 2x input (1-hour cache). Cache reads cost
 * `cacheReadX` x input: 0.05x on Opus 5.5 and Sonnet 5.5, 0.1x on Haiku 5.5 (prompts up to 100k tokens).
 */
export const CACHE_WRITE_X = { "5m": 1.25, "1h": 2 };
export const PRICES = {
  "claude-opus-5-5": { input: 4, output: 20, cacheReadX: 0.05 },
  "claude-sonnet-5-5": { input: 2, output: 10, cacheReadX: 0.05 },
  "claude-haiku-5-5": { input: 0.1, output: 0.5, cacheReadX: 0.1 },
};
/** Unknown models are priced as Opus 5.5 (the dearest) and the estimate is marked approximate. */
export const FALLBACK_MODEL = "claude-opus-5-5";
export const USAGE_LABEL = "estimate at API list price; testers' seats are not charged per token";

/** Price row for a model id ("claude-sonnet-5-5", "claude-sonnet-5-5-20261001", …). */
export function priceFor(model) {
  const m = String(model || "").toLowerCase();
  const key = Object.keys(PRICES).find((k) => m === k || m.startsWith(k + "-") || m.startsWith(k + "["));
  const p = PRICES[key || FALLBACK_MODEL];
  return {
    known: !!key,
    input: p.input,
    output: p.output,
    cacheWrite5m: p.input * CACHE_WRITE_X["5m"],
    cacheWrite1h: p.input * CACHE_WRITE_X["1h"],
    cacheRead: p.input * p.cacheReadX,
  };
}
