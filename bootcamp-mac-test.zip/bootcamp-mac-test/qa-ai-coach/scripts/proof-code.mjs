#!/usr/bin/env node
// QA AI Coach: the completion code shown by /coach done.
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, readMe, startDateOf, missionDate, indiaDate, fmtDay, parseMissionId, ALL_MISSIONS, handInDue, isPreview, recordDone } from "./lib.mjs";

export const PORTAL_URL = "https://claude.ai/artifact/1iq8fKEGLY2vdGSGfAzoKe";

/**
 * What the tester must still do after /coach done, as fixed lines the coach shows word for word:
 * NOT_FINISHED, STEP 1–4 (save the code in the portal), ALSO (a file or test due today), NEXT.
 * The code is only on the laptop until the portal shows "Saved: <id>". Exported for tests.
 */
export function afterDoneLines(missionId, code, start) {
  const p = parseMissionId(missionId);
  if (!p) return [];
  const on = (ymd) => (ymd ? fmtDay(ymd) : "see the portal");
  const lines = [
    "NOT_FINISHED You are not finished yet. Your code is only on your laptop until you save it in the portal.",
    `STEP 1. Copy your completion code: ${code}`,
    `STEP 2. Open the portal: ${PORTAL_URL} . Go to Today.`,
    p.w === 6
      ? `STEP 3. Paste the code. Paste your work from today's file into "Paste your work (required this week)". In the small box, write one thing Claude got wrong today, or one thing you will do differently.`
      : `STEP 3. Paste the code. In the box below it, write one thing Claude got wrong today, or one thing you will do differently.`,
    `STEP 4. Press Save code. You should see "Saved: ${p.id}. Well done." Do this by the end of today.`,
  ];
  const also = [];
  if ((p.w === 1 && p.d === 2) || (p.w >= 2 && p.d === 1))
    also.push(`ALSO Today also has a test, on the portal. Did you do it before the lesson? Good, nothing more to do. If not, do it now: open the portal (${PORTAL_URL}), go to Today → ① Test, press Start, then Submit answers.`);
  if (p.d === 5 && p.w <= 5)
    also.push(`ALSO Your week ${p.w} project P${p.w} is due today (${on(start && handInDue(start, `C${p.w}`))}). In your COACH window type /coach submit P${p.w}, then upload the file on the portal's Project tab.`);
  if (p.id === "W6D4")
    also.push(`ALSO Your week 6 project P6 is due today (${on(start && handInDue(start, "W6"))}). In your COACH window type /coach submit P6, then upload the file on the portal's Project tab.`);
  lines.push(...also);
  const next = ALL_MISSIONS[ALL_MISSIONS.indexOf(p.id) + 1];
  const after = next ? `Your next lesson, ${next}, opens on ${on(start && missionDate(start, next))}.` : "That was the last lesson of the programme.";
  lines.push(
    also.length
      ? `NEXT Save the code in the portal (steps above), then do the other ${also.length > 1 ? "things" : "thing"} due today (the ${also.length > 1 ? "lines" : "line"} above about ${also.length > 1 ? "them" : "it"}). When the portal shows ${also.length > 1 ? "them" : "it"} as handed in, you are done for today. ${after}`
      : `NEXT Save the code in the portal (steps above). When the portal shows "Saved: ${p.id}", you are done for today. ${after}`
  );
  return lines;
}

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const MISSION_RE = /^W[1-6]D[1-5]$/;

function base32(buf) {
  let bits = 0;
  let value = 0;
  let out = "";
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

/** The code's check characters: email, lesson and verdict, so no part of the code can be changed by hand. */
export function checkChars(email, missionId, verdict = "PASS") {
  const digest = crypto.createHash("sha256").update(`${String(email).trim().toLowerCase()}|${missionId}|${verdict}`).digest();
  return base32(digest).slice(0, 4);
}

export function proofCode(missionId, verdict, email) {
  if (!MISSION_RE.test(missionId)) throw new Error(`Bad mission id "${missionId}" (expected like W1D2)`);
  if (verdict !== "PASS" && verdict !== "PARTIAL") throw new Error(`Verdict must be PASS or PARTIAL`);
  if (!isEmail(email)) throw new Error("No valid email in me.json. Delete me.json and run /coach again.");
  return `${missionId}-${verdict}-${checkChars(email, missionId, verdict)}`;
}

export function verifyCode(code, email) {
  const m = /^(W[1-6]D[1-5])-(PASS|PARTIAL)-([A-Z2-7]{4})$/.exec(String(code).trim().toUpperCase());
  if (!m) return { valid: false, reason: "format" };
  const ok = checkChars(email, m[1], m[2]) === m[3];
  return { valid: ok, missionId: m[1], verdict: m[2], reason: ok ? "ok" : "checksum does not match this email" };
}

export function isEmail(s) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(s || "").trim());
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const a = process.argv.slice(2);
  try {
    if (a[0] === "--verify") {
      const r = verifyCode(a[1], a[2]);
      console.log(r.valid ? `VALID ${r.missionId} ${r.verdict}` : `INVALID (${r.reason})`);
      process.exit(r.valid ? 0 : 2);
    }
    const ws = findWorkspace(process.cwd());
    if (!ws) throw new Error("No me.json found. Start Claude Code in your qa-ai-coach folder and run /coach first.");
    const me = readMe(ws);
    if (a[0] === "--record") {
      // The tester says a lesson is finished and saved in the portal, so /coach moves on. The portal holds the real
      // record (the saved code), so no code is needed here: testers don't keep their codes (programme manager,
      // 2 Nov 2026). A code is still accepted if they have one.
      const word = String(a[1] || "").trim().toUpperCase();
      const id = /^W[1-6]D[1-5]$/.test(word) ? word : null;
      const r = id ? { valid: true, missionId: id, verdict: "SAID" } : verifyCode(word, me.email);
      if (!r.valid) {
        console.log(`RECORD_INVALID Type the lesson name, for example W1D1.`);
        process.exit(2);
      }
      const start = startDateOf(me);
      if (start && missionDate(start, r.missionId) > indiaDate()) {
        console.log(`RECORD_INVALID ${r.missionId} opens on ${fmtDay(missionDate(start, r.missionId))}.`);
        process.exit(2);
      }
      recordDone(ws, r.missionId, r.verdict);
      console.log(`RECORDED ${r.missionId} ${r.verdict}`);
      process.exit(0);
    }
    if (isPreview(me)) {
      const pid = String(a[0] || "").toUpperCase();
      console.log(`PROOF_CODE ${pid}-PREVIEW-0000`);
      console.log("PREVIEW_ONLY This is a preview code. It does not count and the portal will not accept it.");
      for (const line of afterDoneLines(pid, `${pid}-PREVIEW-0000`, startDateOf(me))) console.log(line);
      process.exit(0);
    }
    const id = String(a[0] || "").toUpperCase();
    const start = startDateOf(me);
    // The portal refuses a code for a mission whose date has not come; say so here instead of making one.
    if (start && MISSION_RE.test(id) && missionDate(start, id) > indiaDate()) {
      throw new Error(`${id} opens on ${fmtDay(missionDate(start, id))}. Its completion code can be made from that day.`);
    }
    const code = proofCode(id, String(a[1] || "").toUpperCase(), me.email);
    recordDone(ws, id, String(a[1]).toUpperCase());
    console.log(`PROOF_CODE ${code}`);
    for (const line of afterDoneLines(id, code, start)) console.log(line);
  } catch (err) {
    console.log(`PROOF_ERROR ${err.message}`);
    process.exit(1);
  }
}
