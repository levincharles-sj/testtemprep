#!/usr/bin/env node
// QA AI Coach: bundle a Weekly Challenge submission as ONE Markdown file.
// Usage: node bundle.mjs C1 [--workspace <path>]
// Creates <workspace>/submissions/<P#|C#|W6>-handin.md (no name or email in the file name) with front-matter (name, email,
// challenge, version (from work/C<n>/VARIANT.txt, if any), startDate (me.json), created, file list with sha256, the week's programme usage totals), then the week's work files
// inlined in fenced blocks, the week's proofs and the week's conversations. Usage is token counts only
// (from usage/<date>/*.json, written by the hook); the raw usage files are never inlined. The programme portal accepts .md
// uploads (not zip). Prints the path of the file to upload.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { findWorkspace, readMe, USAGE_LABEL, startDateOf, weekStart, addDays, START_DATE_HELP, handInDue, fmtDay, todayFor, isPreview, previewDateOf, weekOf } from "./lib.mjs";
import { aggregate, readUsage, weekDays, fmtTokens, fmtUsd, refreshRecent } from "./usage.mjs";
import { isEmail } from "./proof-code.mjs";

const SKIP_DIRS = new Set(["node_modules", ".git", ".cache", "submissions", "playwright-report", "test-results", "blob-report", "last-run", "__pycache__"]);
// Size policy: a hand-in is NEVER refused for size. The bundle is fitted to TARGET_BYTES by trimming the
// largest conversations first, then oversized work files (head and tail kept, with a clear note).
// Proofs are never trimmed. MAX_BYTES is the hard ceiling the portal plans its storage around
// (about 20 testers x 5 challenges x 5 MB stays well inside the portal's 1 GB).
export const TARGET_BYTES = 4 * 1024 * 1024;
export const MAX_BYTES = 5 * 1024 * 1024;
const READ_LIMIT = 50 * 1024 * 1024; // files bigger than this are listed, never read
const CAPS = [
  { conversations: 300 * 1024, work: 400 * 1024 },
  { conversations: 120 * 1024, work: 200 * 1024 },
  { conversations: 40 * 1024, work: 80 * 1024 },
  { conversations: 12 * 1024, work: 30 * 1024 },
  { conversations: 0, work: 10 * 1024 },
];
const BINARY_EXT = new Set([
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".svgz", ".pdf", ".zip", ".gz", ".7z", ".rar",
  ".mp4", ".mov", ".webm", ".avi", ".mp3", ".wav", ".woff", ".woff2", ".ttf", ".otf", ".exe", ".dll",
  ".docx", ".xlsx", ".pptx", ".doc", ".xls", ".ppt", ".jar", ".class", ".bin", ".db", ".sqlite",
  // HAR network recordings (week 2) are text but large and hold cookies: listed with their hash, never inlined.
  ".har",
]);
const LANG = {
  ".ts": "ts", ".tsx": "tsx", ".js": "js", ".mjs": "js", ".cjs": "js", ".json": "json", ".md": "markdown",
  ".yml": "yaml", ".yaml": "yaml", ".py": "python", ".html": "html", ".css": "css", ".csv": "csv",
  ".txt": "text", ".xml": "xml", ".sh": "bash", ".ps1": "powershell", ".feature": "gherkin", ".sql": "sql",
};

function walk(dir, base, out) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    // .claude holds skills; .github holds the CI workflow (week 4). Other dot folders (.git and the like) are skipped.
    if (e.name.startsWith(".") && e.name !== ".claude" && e.name !== ".github") continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name)) continue;
      walk(full, base, out);
    } else if (e.isFile()) {
      // Today's guide (made by start.mjs from the mission) is reading material, not the tester's work.
      if (/-guide\.html$/i.test(e.name)) continue;
      out.push({ full, rel: path.relative(base, full).split(path.sep).join("/") });
    }
  }
  return out;
}

/**
 * Dates covered by a challenge, for a tester's start date: Monday of its week to the following Tuesday
 * (resubmissions), as India dates (the same dates the conversation folders use).
 */
export function challengeWindow(challenge, startDate) {
  // v10: the weekly project P1–P5 uses its week's hand-in slot (C1–C5 in the portal); P6 uses the week 6 slot (W6).
  let word = String(challenge || "").trim().toUpperCase();
  const project = /^P([1-6])$/.exec(word);
  if (project) word = project[1] === "6" ? "W6" : `C${project[1]}`;
  const m = /^C([1-5])$/i.exec(word);
  const w6 = /^W6$/i.test(word);
  if (!m && !w6) throw new Error(`Unknown hand-in "${challenge}". Use your week's project, for example: /coach submit P1`);
  if (!startDate) throw new Error(START_DATE_HELP);
  const n = w6 ? 6 : Number(m[1]);
  const first = weekStart(startDate, n);
  // C<n>: Monday of its week to the following Tuesday (resubmissions). W6: Monday to Sunday of week 6.
  const days = Array.from({ length: w6 ? 7 : 9 }, (_, i) => addDays(first, i));
  const start = new Date(`${days[0]}T00:00:00`);
  const end = new Date(`${days[days.length - 1]}T00:00:00`);
  return { id: w6 ? "W6" : `C${n}`, project: project ? `P${project[1]}` : null, week: `W${n}`, days, start, end, due: handInDue(startDate, w6 ? "W6" : `C${n}`) };
}

/** Pick the files that belong in this challenge's bundle. Exported for tests. */
export function selectFiles(ws, challenge) {
  const win = challengeWindow(challenge, startDateOf(readMe(ws)));
  const files = [];
  const add = (list) => list.forEach((f) => files.push(f));

  // 1. work: work/W<n>/**, work/C<n>/** and the Playwright practice project's tests/w<n>/ and tests/c<n>/;
  //    if all are empty, work files changed during the window
  const pw = path.join(ws, "work", "playwright-practice", "tests");
  // W6: the week folder and the hand-in folder are the same, so each folder is walked once.
  const folders = [...new Set([path.join(ws, "work", win.week), path.join(ws, "work", win.id), path.join(pw, win.week.toLowerCase()), path.join(pw, win.id.toLowerCase())])];
  // v10 projects: the project folder in the portfolio, plus the house rules and skills the project builds.
  if (win.project) {
    const pf = path.join(ws, "portfolio");
    folders.push(path.join(pf, win.project), path.join(pf, ".claude", "skills"));
  }
  // A project's materials/ folder holds the course's own files, not the tester's work: leave it out.
  // So do P4's practice app and practice faults (the course's code) and the agent files Playwright makes on Thursday,
  // and P5's assistant (code, help documents, teaching run, README) with the duplicate replies JSON.
  // P6 leaves out both versions of the assistant, the recorded teaching runs, the v1 baseline and the release note.
  // The tester's golden.csv, geval-criteria.txt, safety-prompts.csv, gate.json, workflow and results\*.csv stay in.
  const COURSE_FILES = /^portfolio\/(P[1-6]\/materials|P4\/app|P4\/faults|P4\/\.claude\/agents|P5\/kb|P5\/teaching|P6\/versions|P6\/teaching|P6\/baseline)\/|^portfolio\/P5\/([^/]+\.py|requirements\.txt|rules-v1\.txt|README\.md|golden-example\.csv|results\/replies\.json)$|^portfolio\/P6\/([^/]+\.py|requirements\.txt|README\.md|release-note-v2\.md)$/;
  const weekWork = folders.flatMap((dir) => walk(dir, ws, [])).filter((f) => !COURSE_FILES.test(f.rel));
  if (win.project && fs.existsSync(path.join(ws, "portfolio", "CLAUDE.md"))) weekWork.push({ full: path.join(ws, "portfolio", "CLAUDE.md"), rel: "portfolio/CLAUDE.md" });
  if (weekWork.length) add(weekWork);
  else
    add(
      walk(path.join(ws, "work"), ws, []).filter((f) => {
        const t = fs.statSync(f.full).mtime;
        return t >= win.start && t <= new Date(win.end.getTime() + 864e5);
      })
    );

  // 2. proofs for that week: proofs/W<n>D*.md
  add(walk(path.join(ws, "proofs"), ws, []).filter((f) => path.basename(f.rel).startsWith(win.week + "D")));

  // 3. conversations from the window's dates
  for (const day of win.days) add(walk(path.join(ws, "conversations", day), ws, []));

  return { win, files };
}

/** True when the bytes look like text we can inline (no NUL bytes, valid UTF-8, not a known binary type). */
export function isTextFile(rel, data) {
  if (BINARY_EXT.has(path.extname(rel).toLowerCase())) return false;
  if (data.includes(0)) return false;
  try {
    new TextDecoder("utf-8", { fatal: true }).decode(data);
    return true;
  } catch {
    return false;
  }
}

/** Keep the head and tail of a long text within `cap` bytes, with a plain note in the middle. */
export function trimText(text, cap) {
  const total = Buffer.byteLength(text, "utf8");
  const head = Math.floor(cap * 0.7), tail = Math.floor(cap * 0.25);
  // Cutting bytes can split a multi-byte character; drop the replacement characters that leaves.
  const cut = (s, n, fromEnd) => { const b = Buffer.from(s, "utf8"); const part = fromEnd ? b.subarray(Math.max(0, b.length - n)) : b.subarray(0, n); return part.toString("utf8").replace(/�/g, ""); };
  const left = Math.round((total - head - tail) / 1024);
  const note = `[... ${left} KB trimmed by the coach to keep the hand-in small. The full file is on the tester's laptop; its sha256 is listed above. ...]`;
  return `${cut(text, head, false)}\n\n${note}\n\n${cut(text, tail, true)}`;
}

/** A backtick fence longer than any run of backticks inside the content. */
function fenceFor(text) {
  let longest = 0;
  for (const m of text.matchAll(/`+/g)) longest = Math.max(longest, m[0].length);
  return "`".repeat(Math.max(3, longest + 1));
}

/** YAML-safe double-quoted scalar. */
function q(s) {
  return JSON.stringify(String(s ?? ""));
}

function section(rel) {
  if (rel.startsWith("work/")) return "work";
  if (rel.startsWith("proofs/")) return "proofs";
  if (rel.startsWith("conversations/")) return "conversations";
  return "work";
}

/** Programme usage for a challenge's week: Mon–Sun of W<n> in India time, so no day counts in two weeks. */
export function weekUsage(ws, week, startDate) {
  const days = weekDays(week, null, startDate);
  return { week, from: days[0], to: days[6], ...aggregate(readUsage(ws, days)) };
}

function usageFrontMatter(u) {
  const t = u.tokens;
  return `usage: { week: ${q(u.week)}, from: ${q(u.from)}, to: ${q(u.to)}, sessions: ${u.sessions}, tokens: { input: ${t.input}, output: ${t.output}, cacheWrite: ${t.cacheWrite}, cacheRead: ${t.cacheRead}, total: ${t.total} }, estUsd: ${u.estUsd}, approximate: ${!!u.approximate} }`;
}

function usageSection(u) {
  const t = u.tokens;
  const body = u.sessions
    ? [
        `${u.sessions} session${u.sessions === 1 ? "" : "s"} in the coach folder from ${u.from} to ${u.to} (India time) · ${fmtTokens(t.total)} tokens · about ${fmtUsd(u.estUsd)}${u.approximate ? " (approximate)" : ""}.`,
        "",
        `Tokens by type: input ${fmtTokens(t.input)} · output ${fmtTokens(t.output)} · cache write ${fmtTokens(t.cacheWrite)} · cache read ${fmtTokens(t.cacheRead)}.`,
      ]
    : [`No usage recorded in the coach folder from ${u.from} to ${u.to} (India time).`];
  const note = `Programme work only, counted by the coach from token numbers (never conversation content). The cost is an ${USAGE_LABEL}.`;
  return ["## Programme usage this week", "", ...body, "", note, ""].join("\n");
}

/** Build the Markdown bundle text. Exported for tests. */
/** The challenge version from work/C<n>/VARIANT.txt (written by challenge.mjs), e.g. "v2"; null if none. */
export function readVariant(ws, challengeId) {
  try {
    const m = /^\s*(v\d+)\s*$/i.exec(fs.readFileSync(path.join(ws, "work", challengeId, "VARIANT.txt"), "utf8"));
    return m ? m[1].toLowerCase() : null;
  } catch {
    return null;
  }
}

export function renderBundle(me, win, items, createdAt, usage = null, variant = null) {
  const counts = { work: 0, proofs: 0, conversations: 0 };
  for (const it of items) if (it.included) counts[section(it.rel)]++;
  const skipped = items.filter((it) => !it.included);

  const fm = [
    "---",
    `name: ${q(me.name || "")}`,
    `email: ${q(String(me.email).trim().toLowerCase())}`,
    `challenge: ${q(win.id)}`,
    ...(win.project ? [`project: ${q(win.project)}`] : []),
    `week: ${q(win.week)}`,
    ...(startDateOf(me) ? [`startDate: ${q(startDateOf(me))}`] : []),
    ...(variant ? [`variant: ${q(variant)}`] : []),
    `created: ${q(createdAt)}`,
    `counts: { work: ${counts.work}, proofs: ${counts.proofs}, conversations: ${counts.conversations}, skipped: ${skipped.length} }`,
    ...(usage ? [usageFrontMatter(usage)] : []),
    "files:",
    ...items.map(
      (it) =>
        `  - { path: ${q(it.rel)}, size: ${it.size}, sha256: ${q(it.sha256)}, included: ${it.included}${it.included ? "" : `, reason: ${q(it.reason)}`} }`
    ),
    "---",
    "",
    win.project ? `# Week ${win.project.slice(1)} project ${win.project}: hand-in` : `# ${win.id} submission`,
    "",
    `${win.project ? `Project ${win.project}` : win.id === "W6" ? "Week 6 file" : `Challenge ${win.id}`} (${win.week}) · ${counts.work} work file(s) · ${counts.proofs} daily record(s) · ${counts.conversations} conversation(s).`,
    "",
  ];

  const parts = [fm.join("\n")];
  if (usage) parts.push(usageSection(usage));
  const titles = { work: "Work files", proofs: "Proofs", conversations: "Conversations" };
  for (const key of ["work", "proofs", "conversations"]) {
    const group = items.filter((it) => it.included && section(it.rel) === key);
    parts.push(`## ${titles[key]}\n`);
    if (!group.length) {
      parts.push("_None._\n");
      continue;
    }
    for (const it of group) {
      const lang = LANG[path.extname(it.rel).toLowerCase()] || "";
      const fence = fenceFor(it.text);
      const body = it.text.endsWith("\n") ? it.text : it.text + "\n";
      parts.push(`### ${it.rel}\n\nsha256 \`${it.sha256}\`\n\n${fence}${lang}\n${body}${fence}\n`);
    }
  }
  if (skipped.length) {
    parts.push("## Skipped files\n");
    parts.push(skipped.map((it) => `- \`${it.rel}\`: ${it.reason}`).join("\n") + "\n");
  }
  return parts.join("\n");
}

/**
 * The files a project hand-in should hold, read from the project page's "What you hand in" list
 * (skills/coach/challenges/C<n>/brief.md). Each item: { path, day } with path relative to the workspace,
 * for example { path: "portfolio/P1/behaviour-log.md", day: "Monday" }. A "`name` skill" means
 * portfolio/.claude/skills/<name>/SKILL.md. Empty when there is no page or no list. Exported for tests.
 */
export function expectedFiles(win, briefDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "skills", "coach", "challenges")) {
  if (!win.project) return [];
  const brief = path.join(briefDir, win.id, "brief.md");
  if (!fs.existsSync(brief)) return [];
  const m = /## What you hand in\s*\n([\s\S]*?)(\n## |$)/.exec(fs.readFileSync(brief, "utf8").replace(/\r\n/g, "\n"));
  if (!m) return [];
  const out = [];
  for (const line of m[1].split("\n")) {
    if (!/^\s*- \[[ x]\]/.test(line)) continue;
    const day = (/\((Monday|Tuesday|Wednesday|Thursday|Friday)\)\s*$/.exec(line) || [])[1] || "";
    for (const t of line.matchAll(/`([^`]+)`(\s+skill)?/g)) {
      const name = t[1].trim().replace(/\\/g, "/");
      if (t[2]) out.push({ path: `portfolio/.claude/skills/${name}/SKILL.md`, day });
      else if (/\.[a-z]+$/i.test(name)) out.push({ path: `portfolio/${name}`, day });
    }
  }
  return out;
}

export function makeBundle(ws, challenge, { now = new Date() } = {}) {
  const me = readMe(ws);
  if (!isEmail(me.email)) throw new Error("No valid email in me.json. Delete me.json and run /coach again to set your name and email.");
  const { win, files } = selectFiles(ws, challenge);
  const variant = readVariant(ws, win.id); // work/C<n>/VARIANT.txt is also inlined as a work file
  let usage = null;
  try {
    usage = weekUsage(ws, win.week, startDateOf(me));
  } catch {
    usage = null; // never let usage stop a hand-in
  }
  const items = [];
  for (const f of files) {
    const st = fs.statSync(f.full);
    if (st.size > READ_LIMIT) {
      items.push({ rel: f.rel, size: st.size, sha256: "", included: false, reason: "over 50 MB, listed only" });
      continue;
    }
    const data = fs.readFileSync(f.full);
    const sha256 = crypto.createHash("sha256").update(data).digest("hex");
    if (!isTextFile(f.rel, data)) {
      const reason = /\.har$/i.test(f.rel)
        ? "network recording (may hold cookies), not inlined"
        : "binary file (not a text file), not inlined";
      items.push({ rel: f.rel, size: st.size, sha256, included: false, reason });
      continue;
    }
    items.push({ rel: f.rel, size: st.size, sha256, included: true, full: data.toString("utf8") });
  }
  const createdAt = now.toISOString();
  let md = "", bytes = 0, trimmed = 0;
  for (let pass = -1; pass < CAPS.length; pass++) {
    trimmed = 0;
    for (const it of items) {
      if (!it.included && !it.full) continue;
      const kind = section(it.rel);
      const cap = pass < 0 || kind === "proofs" ? Infinity : CAPS[pass][kind];
      it.included = true;
      it.text = it.full;
      it.trimmedNote = null;
      if (cap === 0) { it.included = false; it.reason = "conversation left out to keep the hand-in small (full copy on the tester's laptop)"; trimmed++; continue; }
      if (Buffer.byteLength(it.full, "utf8") > cap) { it.text = trimText(it.full, cap); it.trimmedNote = true; trimmed++; }
    }
    md = renderBundle(me, win, items, createdAt, usage, variant);
    bytes = Buffer.byteLength(md, "utf8");
    if (bytes <= TARGET_BYTES) break;
  }
  if (bytes > MAX_BYTES) {
    // Last resort (thousands of files): keep proofs and the file list, drop other bodies.
    for (const it of items) if (it.included && section(it.rel) !== "proofs") { it.included = false; it.reason = "left out to keep the hand-in under 5 MB (full copy on the tester's laptop)"; trimmed++; }
    md = renderBundle(me, win, items, createdAt, usage, variant);
    bytes = Buffer.byteLength(md, "utf8");
  }
  const outDir = path.join(ws, "submissions");
  fs.mkdirSync(outDir, { recursive: true });
  // Named after what the tester typed: P1-… for a project (its portal slot is still C1), C1-… or W6-… otherwise.
  const outFile = path.join(outDir, `${win.project || win.id}-handin.md`);
  fs.writeFileSync(outFile, md, "utf8");
  const counts = { work: 0, proofs: 0, conversations: 0 };
  for (const it of items) if (it.included) counts[section(it.rel)]++;
  return {
    outFile,
    size: bytes,
    manifest: {
      trimmed,
      challenge: win.id,
      project: win.project,
      week: win.week,
      due: win.due,
      variant,
      counts,
      usage,
      skipped: items.filter((it) => !it.included).map((it) => `${it.rel} (${it.reason})`),
      missing: expectedFiles(win).filter((e) => !fs.existsSync(path.join(ws, ...e.path.split("/")))),
      files: items.map(({ rel, size, sha256, included }) => ({ path: rel, size, sha256, included })),
    },
  };
}

export const PORTAL_URL = "https://claude.ai/artifact/1iq8fKEGLY2vdGSGfAzoKe";

/**
 * The numbered upload steps the coach shows after a bundle is made (one STEP line each). They match
 * the portal: Project tab → the hand-in card → "Your file" → Upload → "Handed in <day>. Waiting for review."
 * Exported for tests.
 */
export function uploadSteps({ outFile, id, due, project }) {
  const card = project ? `the Week ${project.slice(1)} project card` : id === "W6" ? "the Week 6 project card" : `the Week ${id.slice(1)} project card`;
  const dir = path.dirname(outFile), name = path.basename(outFile);
  return [
    `STEP 1. Your file is ready: ${outFile}`,
    `STEP 2. Open the portal: ${PORTAL_URL} . Go to the Project tab. Find ${card}.`,
    `STEP 3. Under "Your file", press the button to choose a file (Choose File or Browse). In the window, open the folder ${dir} and pick ${name}. Then press Upload.`,
    `STEP 4. You should see "Handed in" with today's date and "Waiting for review" on the card. That means it worked.`,
    // Week 6 has no fix slot (the last week): a Not yet is fixed by the end of Friday.
    due ? `STEP 5. Due: ${fmtDay(due)}, by the end of the day. Late work is still reviewed and marked Late. If it comes back to you as Not yet, fix it by ${id === "W6" ? "the end of Friday" : "the next Tuesday"}: it still counts as on time.` : `STEP 5. Due: see the date on the card in the portal.`,
    `STEP 6. No upload button, or the upload fails? Tell the programme manager. Do not email the file anywhere else. If you hand in again, the new file replaces the old one.`,
  ];
}

/** A project whose week has not started has nothing to hand in yet (launch check, 22 Oct 2026: /coach submit P2 in
 *  week 1 made a near-empty file). Throws with a plain sentence; preview workspaces are not checked. Exported for tests. */
export function notBeforeItsWeek(ws, challenge, now = new Date()) {
  const me = readMe(ws), start = startDateOf(me);
  if (!start || (isPreview(me) && !previewDateOf(me))) return; // a preview with a date acts as on that date
  const win = challengeWindow(challenge, start), today = todayFor(me, now);
  if (today >= win.days[0]) return;
  const pid = win.project || win.id, cur = weekOf(start, today);
  throw new Error(`${pid} is your week ${win.week.slice(1)} project. That week starts on ${fmtDay(win.days[0])}, so there is nothing to hand in yet.` +
    (cur ? ` This week's project is P${cur}: type /coach submit P${cur} on its Friday.` : ` Your programme starts on ${fmtDay(start)}.`));
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const wsFlag = args.indexOf("--workspace");
  const ws = findWorkspace(wsFlag >= 0 ? args[wsFlag + 1] : process.cwd());
  const challenge = args.find((a, i) => !a.startsWith("--") && (wsFlag < 0 || i !== wsFlag + 1));
  try {
    if (!ws) throw new Error("No me.json found. Start Claude Code in your qa-ai-coach folder and run /coach first.");
    notBeforeItsWeek(ws, challenge);
    refreshRecent(ws); // count the running session too (its hook hasn't run yet); never throws
    const { outFile, size, manifest } = makeBundle(ws, challenge);
    const c = manifest.counts;
    console.log(`BUNDLE_OK ${outFile}`);
    console.log(`Size: ${(size / 1024).toFixed(0)} KB · work files: ${c.work} · daily records: ${c.proofs} · conversations: ${c.conversations}`);
    const u = manifest.usage;
    if (u) console.log(`Programme usage ${manifest.week}: ${u.sessions} session(s) · ${fmtTokens(u.tokens.total)} tokens · about ${fmtUsd(u.estUsd)} (${USAGE_LABEL})`);
    if (c.work === 0) console.log(manifest.project ? `WARNING: no project files found. Your project files are in portfolio/${manifest.project}/.` : "WARNING: no work files found for this challenge. Save your challenge files in work/" + manifest.week + "/ or work/" + manifest.challenge + "/.");
    for (const m of manifest.missing) console.log(`WARNING: Missing project file: ${m.path}${m.day ? ` (made in the ${m.day} lesson)` : ""}`);
    if (manifest.skipped.length) console.log("Skipped (listed in the bundle, not inlined): " + manifest.skipped.join(", "));
    if (manifest.trimmed) console.log(`NOTE: ${manifest.trimmed} long file(s) or conversation(s) were shortened to keep the hand-in small. That's fine: upload it as it is.`);
    console.log("NOT_FINISHED You are not finished yet. The file is only on your laptop.");
    for (const line of uploadSteps({ outFile, id: manifest.challenge, due: manifest.due, project: manifest.project })) console.log(line);
    console.log(`NEXT Upload the file now (steps above). You are finished only when the portal shows "Handed in" on the card.`);
  } catch (err) {
    console.log(`BUNDLE_ERROR ${err.message}`);
    process.exit(1);
  }
}
