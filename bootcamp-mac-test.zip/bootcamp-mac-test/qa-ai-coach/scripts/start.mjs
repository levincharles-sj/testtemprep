#!/usr/bin/env node
// QA AI Coach: get the workspace ready for a mission.
// Usage: node start.mjs W<n>D<d> [--workspace <path>]
// 1. Makes work/, proofs/ and submissions/ if missing.
// 2. Adds the coach's allow rules and quiet display settings to <workspace>/.claude/settings.json (merged, never
//    removes or overrides the tester's own rules and choices),
//    so saving inside work/, proofs/ and submissions/ doesn't ask "Allow?" in later turns.
// 3. Copies the mission's practice files (missions/W<n>/D<d>-materials/) into work/W<n>/. Never overwrites a
//    tester's changed file: the fresh copy goes alongside as "<name>.new".
// 4. Date gate (docs/uplift/groups-design.md): a mission opens on its own date, worked out from me.json startDate.
//    A mission whose date has not come is refused (START_NOT_YET).
//    An earlier mission still runs; a NOTE line says it is saved as Done late.
// 5. Writes today's guide, work/W<n>/D<d>-guide.html (the tester sections only, see guide.mjs), as an offline copy.
//    It no longer opens by itself: the same lesson brief is on the portal's Today tab (22 Oct 2026).
// 6. Week 2 lessons: makes sure the practice site (Shady Meadows B&B, http://127.0.0.1:3080) runs on this laptop
//    (site.mjs ensureSite: starts it detached if it does not answer; never opens a browser).
// Output lines: START_OK, PREVIEW, SETTINGS <added|ok|new-restart>, MATERIAL, NEWCOPY, KEPT, NOTE, PROJECT P<n> <folder>, GUIDE <path> <opened|ready>,
// SITE ready <url> | SITE failed <reason> (week 2 only);
// or START_NEED_START_DATE, START_NOT_YET, START_ERROR.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, readMe, startDateOf, missionDate, todayFor, fmtDay, START_DATE_HELP, isPreview, previewDateOf } from "./lib.mjs";
import { catchUpNote } from "./plan.mjs";
import { writeGuide, splitSections } from "./guide.mjs";
import { ensureSettings } from "./settings.mjs";
import { ensureSite } from "./site.mjs";

/** Lessons that use the local practice site. */
export const SITE_WEEKS = new Set(["W2"]);

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const MISSIONS = path.join(HERE, "..", "skills", "coach", "missions");
const BLOCKED = /(^|[\\/])(private|keys?|mutants?)([\\/]|$)|marking|answer[-_ ]?key|solution/i;
// Offline packs (recorded evidence for when a practice website is down) are never copied up front:
// testers must collect their own evidence. The coach hands a pack over only when the site really fails.
export const OFFLINE = /(^|[\\/_-])offline/i;

export { ALLOW_RULES, DISPLAY_SETTINGS, ENV_SETTINGS, ensureSettings } from "./settings.mjs";

export function parseMission(word) {
  const m = String(word || "").trim().toUpperCase().match(/^W([1-6])D([1-5])$/);
  return m ? { id: `W${m[1]}D${m[2]}`, week: `W${m[1]}`, day: `D${m[2]}` } : null;
}

function listFiles(dir, base = dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    const rel = path.relative(base, full);
    if (BLOCKED.test(rel) || OFFLINE.test(rel)) continue;
    if (entry.isDirectory()) out.push(...listFiles(full, base));
    else if (entry.isFile()) out.push(rel);
  }
  return out.sort();
}

/** The project (P1–P6) a v10 lesson belongs to, from its front matter; null for older missions. */
export function projectOf(mission, source = MISSIONS) {
  const file = path.join(source, mission.week, `${mission.day}.md`);
  if (!fs.existsSync(file)) return null;
  const m = String(splitSections(fs.readFileSync(file, "utf8")).front.project || "").trim().toUpperCase().match(/^P[1-6]$/);
  return m ? m[0] : null;
}

/**
 * Copy the mission's materials; returns {copied, kept, newCopies} as workspace-relative paths.
 * v10 lessons (front matter `project: P<n>`) copy to portfolio/P<n>/materials/, the folder the WORK window works in;
 * older missions copy to work/W<n>/.
 */
export function copyMaterials(mission, workspace, source = MISSIONS) {
  const src = path.join(source, mission.week, `${mission.day}-materials`);
  const lists = { copied: [], kept: [], newCopies: [] };
  if (!fs.existsSync(src)) return lists;
  const project = projectOf(mission, source);
  const dest = project ? path.join(workspace, "portfolio", project, "materials") : path.join(workspace, "work", mission.week);
  for (const rel of listFiles(src)) {
    // Python's cache folders are never course material (a local run of the week 5 starter leaves them behind).
    if (rel.split(/[\\/]/).includes("__pycache__")) continue;
    const content = fs.readFileSync(path.join(src, rel));
    // A project lesson's "project/" folder is a starter project (for example package.json and playwright.config.ts):
    // it goes into the project folder itself, portfolio/P<n>/, not into materials/.
    const parts = rel.split(/[\\/]/);
    const to = project && parts[0] === "project" && parts.length > 1 ? path.join(path.dirname(dest), ...parts.slice(1)) : path.join(dest, rel);
    const show = path.relative(workspace, to).split(path.sep).join("/");
    fs.mkdirSync(path.dirname(to), { recursive: true });
    if (!fs.existsSync(to)) {
      fs.writeFileSync(to, content);
      lists.copied.push(show);
    } else if (Buffer.compare(fs.readFileSync(to), content) === 0) {
      lists.kept.push(show);
    } else {
      let alt = `${to}.new`;
      for (let i = 2; fs.existsSync(alt); i++) alt = `${to}.new-${i}`;
      fs.writeFileSync(alt, content);
      lists.newCopies.push(path.relative(workspace, alt).split(path.sep).join("/"));
    }
  }
  return lists;
}

/** Raised when a mission can't start yet; `code` is the output keyword. */
export class GateError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

/**
 * The date gate. Returns the NOTE sentence for a catch-up ("" when none).
 * Throws GateError START_NEED_START_DATE or START_NOT_YET.
 */
export function checkDate(mission, me, now = new Date()) {
  const startDate = startDateOf(me);
  const today = todayFor(me, now);
  if (isPreview(me)) {
    return startDate && missionDate(startDate, mission.id) <= today ? catchUpNote(startDate, mission.id, today) : "";
  }
  if (!startDate) throw new GateError("START_NEED_START_DATE", START_DATE_HELP);
  const date = missionDate(startDate, mission.id);
  if (date > today) throw new GateError("START_NOT_YET", `${mission.id} opens on ${fmtDay(date)}.`);
  return catchUpNote(startDate, mission.id, today);
}

export function start(word, workspaceArg, source = MISSIONS, { now = new Date(), open = false } = {}) {
  const mission = parseMission(word);
  if (!mission) throw new Error(`"${word}" is not a lesson id. Use one like W1D1.`);
  const workspace = workspaceArg || findWorkspace(process.cwd());
  if (!workspace) throw new Error("No me.json found. Type /coach with your name, work email and start date first.");
  const me = readMe(workspace);
  const note = checkDate(mission, me, now);
  const preview = isPreview(me) ? previewDateOf(me) || "on" : "";
  for (const d of ["work", "proofs", "submissions", "portfolio"]) fs.mkdirSync(path.join(workspace, d), { recursive: true });
  const settings = ensureSettings(workspace);
  const lists = copyMaterials(mission, workspace, source);
  const startDate = startDateOf(me);
  const guide = writeGuide(mission, workspace, source, { date: startDate ? fmtDay(missionDate(startDate, mission.id)) : "" });
  // The page opens in the browser only the first time a lesson starts: never again for that lesson (not even when
  // a coach update changes the page), and never when me.json says "noOpen": true.
  // The lesson brief now lives on the portal's Today tab (programme manager, 22 Oct 2026): one place for testers.
  // The page is still written as an offline copy, but it no longer opens by itself.
  if (guide) guide.opened = false;
  return { mission, settings, note, preview, guide, project: projectOf(mission, source), ...lists };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const wsIdx = args.indexOf("--workspace");
  const ws = wsIdx >= 0 ? path.resolve(args[wsIdx + 1]) : null;
  try {
    const r = start(args[0], ws, MISSIONS, { open: !args.includes("--no-open") });
    console.log(`START_OK ${r.mission.id}`);
    if (r.preview) console.log(r.preview === "on" ? "PREVIEW on" : `PREVIEW ${r.preview} ${fmtDay(r.preview)}`);
    console.log(`SETTINGS ${r.settings}`);
    for (const f of r.copied) console.log(`MATERIAL ${f}`);
    for (const f of r.kept) console.log(`KEPT ${f}`);
    for (const f of r.newCopies) console.log(`NEWCOPY ${f}`);
    if (r.project) console.log(`PROJECT ${r.project} portfolio/${r.project}`);
    if (r.guide) console.log(`GUIDE ${r.guide.rel} ${r.guide.opened ? "opened" : "ready"}`);
    if (r.note) console.log(`NOTE ${r.note}`);
    if (SITE_WEEKS.has(r.mission.week) && r.settings !== "new-restart") console.log((await ensureSite()).line);
  } catch (e) {
    console.log(`${e instanceof GateError ? e.code : "START_ERROR"} ${e.message}`);
    process.exitCode = 1;
  }
}
