#!/usr/bin/env node
// QA AI Coach: hand over an offline pack when a practice website is down.
// Usage: node offline.mjs <W<n>D<d> | C<n>> [reason words…] [--workspace <path>]
// Copies the mission's or challenge's offline pack (any file or folder with "offline" in its path) into
// work/W<n>/offline/ or work/C<n>/offline/, and writes USED-OFFLINE.md with the India date and the reason,
// so marking knows the evidence came from the pack. Copies binary files (screenshots) as they are.
// Week 2 (the local practice site): first runs the site check (site.mjs). If the site was not running and this check
// started it, no pack is handed over: it prints SITE ready and OFFLINE_RETRY, and the tester tries the page again.
// If the site was already running, or cannot start, the pack is handed over as usual (SITE line first).
// Output lines: SITE, OFFLINE_RETRY, OFFLINE_OK, COPIED, KEPT; or OFFLINE_ERROR.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, indiaDate } from "./lib.mjs";
import { ensureSite } from "./site.mjs";

export const SITE_WEEKS = new Set(["W2"]);

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILL = path.join(HERE, "..", "skills", "coach");
const IS_OFFLINE = /(^|[\\/_-])offline/i;
const BLOCKED = /(^|[\\/])(private|keys?|mutants?)([\\/]|$)|marking|answer[-_ ]?key|solution/i;

function walk(dir, base = dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    const rel = path.relative(base, full);
    if (BLOCKED.test(rel)) continue;
    if (e.isDirectory()) walk(full, base, out);
    else if (e.isFile()) out.push(rel);
  }
  return out;
}

/** Offline files for a mission or challenge id: [{from, rel}] where rel is the path inside the pack. */
export function packFor(id, skillDir = SKILL) {
  const m = String(id || "").toUpperCase().match(/^(?:(W[1-6])(D[1-5])|(C[1-6]))$/);
  if (!m) throw new Error(`"${id}" is not a mission (like W1D5) or a challenge (like C2).`);
  const files = [];
  if (m[3]) {
    const dir = path.join(skillDir, "challenges", m[3]);
    for (const rel of walk(dir)) if (IS_OFFLINE.test(rel)) files.push({ from: path.join(dir, rel), rel });
    return { kind: "challenge", folder: m[3], files };
  }
  const [week, day] = [m[1], m[2]];
  const mat = path.join(skillDir, "missions", week, `${day}-materials`);
  for (const rel of walk(mat)) if (IS_OFFLINE.test(rel)) files.push({ from: path.join(mat, rel), rel });
  const shared = path.join(skillDir, "missions", week, "offline");
  for (const rel of walk(shared)) if (path.basename(rel).toUpperCase().startsWith(`${day}-`)) files.push({ from: path.join(shared, rel), rel });
  return { kind: "mission", folder: week, files };
}

export function handOver(id, reason, workspace, skillDir = SKILL) {
  const pack = packFor(id, skillDir);
  if (!pack.files.length) throw new Error(`${String(id).toUpperCase()} has no offline pack. Ask the programme manager.`);
  const dest = path.join(workspace, "work", pack.folder, "offline");
  const copied = [], kept = [];
  for (const f of pack.files) {
    const to = path.join(dest, f.rel.replace(/^offline[\\/]/i, ""));
    const show = path.relative(workspace, to).split(path.sep).join("/");
    fs.mkdirSync(path.dirname(to), { recursive: true });
    if (fs.existsSync(to)) kept.push(show);
    else {
      fs.copyFileSync(f.from, to);
      copied.push(show);
    }
  }
  const note = path.join(dest, "USED-OFFLINE.md");
  const line = `- ${indiaDate()} · ${String(id).toUpperCase()} · ${String(reason || "site did not load").trim()}\n`;
  if (!fs.existsSync(note)) fs.writeFileSync(note, "# Offline pack used\n\nThe practice website was not available, so recorded material was used.\n\n");
  fs.appendFileSync(note, line);
  return { dest: path.relative(workspace, dest).split(path.sep).join("/"), copied, kept };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const wsIdx = args.indexOf("--workspace");
  const ws = wsIdx >= 0 ? path.resolve(args[wsIdx + 1]) : findWorkspace(process.cwd());
  const rest = wsIdx >= 0 ? args.filter((_, i) => i !== wsIdx && i !== wsIdx + 1) : args;
  try {
    if (!ws) throw new Error("No me.json found. Start Claude Code in your coach folder.");
    const week = String(rest[0] || "").toUpperCase().match(/^(W[1-6])D[1-5]$/);
    if (week && SITE_WEEKS.has(week[1])) {
      const site = await ensureSite();
      console.log(site.line);
      if (site.status === "started") {
        console.log(`OFFLINE_RETRY The practice site was not running. It runs again now: ${site.url}. Load the page again (F5).`);
        process.exit(0);
      }
    }
    const r = handOver(rest[0], rest.slice(1).join(" "), ws);
    console.log(`OFFLINE_OK ${r.dest}`);
    for (const f of r.copied) console.log(`COPIED ${f}`);
    for (const f of r.kept) console.log(`KEPT ${f}`);
  } catch (e) {
    console.log(`OFFLINE_ERROR ${e.message}`);
    process.exitCode = 1;
  }
}
