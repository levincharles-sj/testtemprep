#!/usr/bin/env node
// QA AI bootcamps, week 3: start or stop the Parcelly support chat page on this laptop (detached, no window).
// Run from the bootcamp workspace.
//   node chat-page.mjs start | stop | status
// Output: CHAT ready <url> · CHAT stopped · CHAT failed <reason>. QA_BOOTCAMP_CHAT_PORT changes the port (tests).
import http from "node:http";
import net from "node:net";
import path from "node:path";
import fs from "node:fs";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker } from "./lib.mjs";
import { nodeOk } from "./practice-app.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SERVER = path.join(HERE, "..", "..", "apps", "chat", "server.mjs");
export const CHAT_PORT = Number(process.env.QA_BOOTCAMP_CHAT_PORT) || 4370;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function probe(port = CHAT_PORT, timeout = 1500) {
  return new Promise((resolve) => {
    const req = http.get({ host: "127.0.0.1", port, path: "/api/health", timeout }, (res) => {
      res.resume();
      res.on("end", () => resolve({ ours: res.statusCode === 200 && res.headers["x-practice-app"] === "qa-ai-bootcamp-chat" }));
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => resolve({ ours: false }));
  });
}

function portInUse(port) {
  return new Promise((resolve) => {
    const s = net.connect({ host: "127.0.0.1", port });
    s.setTimeout(1000);
    s.once("connect", () => { s.destroy(); resolve(true); });
    s.once("timeout", () => { s.destroy(); resolve(false); });
    s.once("error", () => resolve(false));
  });
}

export async function stopChat({ port = CHAT_PORT } = {}) {
  if (!(await probe(port)).ours) return { status: "stopped", line: "CHAT stopped" };
  await new Promise((resolve) => {
    const req = http.request({ host: "127.0.0.1", port, path: "/__coach/stop", method: "POST", timeout: 1500, headers: { "X-Coach-Stop": "1" } }, (res) => { res.resume(); res.on("end", resolve); });
    req.on("error", () => resolve()); req.on("timeout", () => req.destroy()); req.end();
  });
  const until = Date.now() + 4000;
  while (Date.now() < until && (await portInUse(port))) await sleep(150);
  return { status: "stopped", line: "CHAT stopped" };
}

export async function startChat({ workspace = findMarker(process.cwd()) || process.cwd(), port = CHAT_PORT, waitMs = 8000 } = {}) {
  const url = `http://127.0.0.1:${port}`;
  if (!nodeOk()) return { status: "failed", line: `CHAT failed Node 22.13 or later is needed; this laptop has Node ${process.versions.node}` };
  if ((await probe(port)).ours) await stopChat({ port }); // always restart, so it serves this workspace
  if (await portInUse(port)) return { status: "failed", line: `CHAT failed port ${port} is used by another program` };
  if (!fs.existsSync(SERVER)) return { status: "failed", line: "CHAT failed the chat page is missing from the coach; update the coach" };
  const child = spawn(process.execPath, ["--no-warnings", SERVER], { detached: true, stdio: "ignore", windowsHide: true,
    env: { ...process.env, PORT: String(port), CHAT_WS: workspace } });
  child.on("error", () => {});
  child.unref();
  const until = Date.now() + waitMs;
  while (Date.now() < until) {
    await sleep(150);
    if ((await probe(port, 800)).ours) return { status: "started", line: `CHAT ready ${url}` };
    if (child.exitCode !== null) break;
  }
  return { status: "failed", line: `CHAT failed the chat page did not start${child.exitCode !== null ? ` (exit code ${child.exitCode})` : ""}` };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const cmd = process.argv[2] || "status";
  let r;
  if (cmd === "start") r = await startChat();
  else if (cmd === "stop") r = await stopChat();
  else if (cmd === "status") r = (await probe()).ours ? { status: "running", line: `CHAT ready http://127.0.0.1:${CHAT_PORT}` } : { status: "stopped", line: "CHAT stopped" };
  else r = { status: "failed", line: `CHAT failed unknown command "${cmd}" (use start, stop or status)` };
  console.log(r.line);
  if (r.status === "failed") process.exitCode = 1;
}
