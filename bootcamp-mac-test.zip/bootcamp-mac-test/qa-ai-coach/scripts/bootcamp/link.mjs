#!/usr/bin/env node
// QA AI bootcamps: add a folder to the bootcamp (/bootcamp link <folder>), for example the smoke tests inside a project
// repository. After this, the guards, the WORK-window rules and conversation saving also work there.
// Run from the bootcamp workspace: node link.mjs "<folder>"
// Output: LINKED <folder> · or LINK_ERROR <plain reason>
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findMarker, addLink } from "./lib.mjs";

export function link(ws, target) {
  if (!target) return "LINK_ERROR give the folder, for example: /bootcamp link C:\\projects\\orion\\smoke-tests";
  const folder = path.resolve(ws, target.replace(/^~(?=$|[\\/])/, os.homedir()));
  if (!fs.existsSync(folder) || !fs.statSync(folder).isDirectory()) return `LINK_ERROR the folder ${folder} does not exist`;
  const root = path.parse(folder).root;
  const home = path.resolve(os.homedir());
  if (folder === root || folder.toLowerCase() === home.toLowerCase()) return "LINK_ERROR that folder is too big: link the smoke test folder itself, not a whole drive or your home folder";
  if (/^[a-z]:\\(windows|program files)/i.test(folder) || /^\/(system|library|usr|bin|etc)\b/i.test(folder)) return "LINK_ERROR that is a system folder";
  if (path.resolve(folder).toLowerCase() === path.resolve(ws).toLowerCase()) return "LINK_ERROR that is the bootcamp folder itself: it is already part of the bootcamp";
  // Only a test folder: one with its own package.json (the starter's, or the project's test framework), or an empty
  // one. A broad folder such as C:\work would put every other project's sessions under the bootcamp.
  const entries = fs.readdirSync(folder);
  if (entries.length && !entries.includes("package.json")) return "LINK_ERROR link the test folder itself (the one with package.json), not a folder above it";
  // A repository root (.git) is the whole client project, not a test folder. The starter makes smoke-tests/ inside it.
  if (entries.includes(".git")) return "LINK_ERROR that is the root of a project repository. Link only the smoke-tests folder inside it (/bootcamp starter makes it, after your DM agrees)";
  addLink(folder, ws);
  return `LINKED ${folder}`;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  console.log(ws ? link(ws, process.argv[2]) : "LINK_ERROR not a bootcamp folder (no bootcamp.json here or above)");
}
