#!/usr/bin/env node
// QA AI bootcamps: checks a week report before Saturday (/bootcamp report). Run from the bootcamp workspace:
//   node report.mjs [week-1]
// Checks <week>/report.html: the 8 sections are there; section 6 has at least 2 examples; the pass and fail counts in
// section 2 match the smoke folder's last-run/results.json (the login set-up step and the seed test left out); no
// password, token or key (values from .env and known patterns); no email address or phone number; no address with a
// token, key or password in it; no FILL comment left from the template.
// Output: REPORT_ISSUE <plain line> (one per problem) or REPORT_OK, then REPORT <n> issues. Never prints a value.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findMarker, foldersOf, secretValues, findSecret } from "./lib.mjs";

export const SECTIONS = [
  "What I set out to do", "What I achieved", "How I achieved it", "My thought process",
  "How I made the AI deliver", "What the AI got wrong", "Decisions and blockers", "Decision and next steps",
];
// Week 2: the go-live sign-off report (starter evals/templates/signoff-report.html).
export const SECTIONS_W2 = [
  "What I set out to do", "What I found", "tools and plugins", "My thought process",
  "How I made the AI deliver", "What the AI got wrong", "Decisions and blockers", "Decision, conditions and next steps",
];

// Week 3: the security report (starter redteam/templates/security-report.html).
export const SECTIONS_W3 = [
  "What I set out to do", "What I achieved", "How I achieved it", "My thought process",
  "Findings", "What the AI got wrong", "Decisions and blockers", "Decision and next steps",
];

/** Week 3: findings rows (table rows in the Findings section) and how many name a severity. */
export function findingsOf(html) {
  const body = (String(html).match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i) || [])[1] || "";
  const rows = (body.match(/<tr\b[\s\S]*?<\/tr>/gi) || []);
  const withSeverity = rows.filter((r) => /\b(critical|high|medium|low)\b/i.test(r.replace(/<[^>]+>/g, " "))).length;
  return { rows: rows.length, withSeverity };
}

/** Week 2: saved scores the numbers can be traced to (practice: evals/results/scores-*.csv; AI project: its summary). */
export function savedScores(ws) {
  const out = [];
  for (const dir of [path.join(ws, "evals", "results"), path.join(ws, "evals", "ai-project", "results")]) {
    let names = [];
    try { names = fs.readdirSync(dir); } catch { continue; }
    for (const n of names) if (/^scores-.*\.csv$|^ai-project-summary\.md$/.test(n)) out.push(path.join(dir, n));
  }
  return out;
}

const strip = (html) => String(html)
  .replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<script[\s\S]*?<\/script>/gi, " ")
  .replace(/<!--[\s\S]*?-->/g, " ").replace(/<[^>]+>/g, " ")
  .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
  .replace(/\s+/g, " ").trim();

/** Split the report into sections by its h2 headings: [{ title, html }]. */
export function sections(html) {
  const out = [];
  const re = /<h2[^>]*>([\s\S]*?)<\/h2>/gi;
  const marks = [...String(html).matchAll(re)];
  marks.forEach((m, i) => {
    const end = i + 1 < marks.length ? marks[i + 1].index : String(html).length;
    out.push({ title: strip(m[1]), html: String(html).slice(m.index + m[0].length, end) });
  });
  return out;
}

/** Smoke test counts from a Playwright JSON report, without the login set-up step and the seed test. */
/**
 * Phone numbers in visible text: +91 numbers, Indian mobiles (10 digits starting 6-9, spaces allowed after 5) and
 * landlines with an STD code (0 + 2-4 digits, a dash or space, 6-8 digits). Digit runs inside file names, paths, ids
 * and timestamps (scores-v2-20261126-225410.csv, 2026-11-26T22:54:10) are words, not phone numbers.
 */
export function findPhones(text) {
  const words = String(text).split(/\s+/);
  const cleaned = words.filter((w) => !/[\\/._]|[A-Za-z]-\d|\d-[A-Za-z]|\d{4}-\d{2}-\d{2}|\d:\d/.test(w.replace(/[.,;:!?)]+$/, ""))).join(" ");
  const re = /(?<![\w-])(?:\+91[\s-]?[6-9]\d{4}\s?\d{5}|0?[6-9]\d{4}\s?\d{5}|0\d{2,4}[\s-]\d{6,8})(?![\w-])/g;
  return cleaned.match(re) || [];
}

export function countRun(results) {
  // Each smoke test counts once per project, even after repeat runs (--repeat-each lists it several times):
  // failed if any repeat failed, flaky if any was flaky, skipped if all were skipped, else passed.
  const tests = new Map();
  const walk = (suite, titles) => {
    for (const spec of suite.specs || []) {
      const file = String(spec.file || suite.file || "");
      if (/auth\.setup\.ts$|(^|[\\/])seed(\.role2)?\.spec\.ts$/.test(file)) continue;
      for (const t of spec.tests || []) {
        if (/setup/i.test(String(t.projectName || ""))) continue;
        const key = [file, ...titles, spec.title, spec.line ?? "", t.projectName || ""].join("|");
        const list = tests.get(key) || [];
        list.push(t.status);
        tests.set(key, list);
      }
    }
    for (const s of suite.suites || []) walk({ ...s, file: s.file || suite.file }, [...titles, s.title || ""]);
  };
  for (const s of (results && results.suites) || []) walk(s, [s.title || ""]);
  let passed = 0, failed = 0, flaky = 0, skipped = 0;
  for (const st of tests.values()) {
    if (st.includes("unexpected")) failed++;
    else if (st.includes("flaky")) flaky++;
    else if (st.every((x) => x === "skipped")) skipped++;
    else passed++;
  }
  return { passed, failed, flaky, skipped };
}

function findResults(ws) {
  const candidates = [path.join(ws, "smoke-tests"), ...foldersOf(ws).slice(1)];
  for (const f of candidates) {
    const file = path.join(f, "last-run", "results.json");
    if (fs.existsSync(file)) return file;
  }
  return null;
}

/** All issues with the report, as plain lines (no values). */
export function check(ws, week = "week-1") {
  const file = path.join(ws, week, "report.html");
  if (!fs.existsSync(file)) return { error: `${week}/report.html is not there yet` };
  const html = fs.readFileSync(file, "utf8");
  const issues = [];
  const secs = sections(html);
  const find = (name) => secs.find((s) => s.title.toLowerCase().includes(name.toLowerCase()));
  const wanted = week === "week-2" ? SECTIONS_W2 : week === "week-3" ? SECTIONS_W3 : SECTIONS;
  for (const name of wanted) if (!find(name)) issues.push(`section "${name}" is missing`);

  const s6 = find("What the AI got wrong");
  if (s6) {
    const before = (s6.html.match(/>\s*Before\b/gi) || []).length;
    const items = (s6.html.match(/<li\b/gi) || []).length;
    const examples = Math.max(before, items);
    if (examples < 2) issues.push(`section 6 (what the AI got wrong) has ${examples} example${examples === 1 ? "" : "s"}; it needs at least 2 real ones`);
  }

  if (week === "week-2") {
    if (!savedScores(ws).length) issues.push("no saved scores found (evals/results/scores-*.csv, or ai-project/results/ai-project-summary.md), so the numbers in section 2 cannot be traced: run run_metrics.py first");
    const s8 = find("Decision, conditions");
    if (s8 && !/\b(go with conditions|no[\s‑-]go|go)\b/i.test(strip(s8.html))) issues.push("section 8 does not say the decision: go, go with conditions, or no-go");
  }
  if (week === "week-3") {
    const s5 = find("Findings");
    if (s5) {
      const fnd = findingsOf(s5.html);
      if (fnd.rows < 2) issues.push(`section 5 (findings) has ${fnd.rows} finding${fnd.rows === 1 ? "" : "s"}; it needs at least 2 with evidence (a clean result is fine, but then say so in section 2 and keep 2 attempts as evidence)`);
      if (fnd.withSeverity < fnd.rows) issues.push(`${fnd.rows - fnd.withSeverity} finding${fnd.rows - fnd.withSeverity === 1 ? " has" : "s have"} no severity (critical, high, medium or low)`);
    }
    const s8 = find("Decision and next steps");
    if (s8 && !/\b(go with conditions|no[\s‑-]go|go)\b/i.test(strip(s8.html))) issues.push("section 8 does not say the decision: go, go with conditions, or no-go");
  }
  const s2 = week === "week-1" ? find("What I achieved") : null;
  if (s2) {
    const text = strip(s2.html);
    const resultsFile = findResults(ws);
    if (!resultsFile) issues.push("no test run found (last-run/results.json in the smoke folder), so the numbers in section 2 cannot be checked: run the tests once");
    else {
      let run = null;
      try { run = countRun(JSON.parse(fs.readFileSync(resultsFile, "utf8"))); } catch { issues.push("the last test run (last-run/results.json) cannot be read: run the tests once more"); }
      if (run) {
        const said = (word) => {
          const m = text.match(new RegExp(`(\\d+)\\s+(?:smoke\\s+)?(?:tests?\\s+)?${word}`, "i"));
          return m ? Number(m[1]) : null;
        };
        const p = said("passing|passed|pass\\b"), f = said("failing|failed|fail\\b");
        if (p === null) issues.push("section 2 does not say how many smoke tests pass (for example \"7 smoke tests passing\")");
        else if (p !== run.passed) issues.push(`section 2 says ${p} smoke tests pass, but the last run shows ${run.passed} (login set-up and seed left out): run the tests again or correct the number`);
        if (f !== null && f !== run.failed) issues.push(`section 2 says ${f} fail, but the last run shows ${run.failed}`);
        if (f === null && run.failed > 0) issues.push(`the last run has ${run.failed} failing test${run.failed === 1 ? "" : "s"}, and section 2 does not say so`);
      }
    }
  }

  const visible = strip(html);
  const secret = findSecret(html, secretValues(ws));
  if (secret) issues.push(`the report holds ${secret.kind}: remove it (show names such as TEST_PASSWORD, never values)`);
  if (/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/.test(visible)) issues.push("the report shows an email address: remove it or write the role instead (for example \"the test account\")");
  if (findPhones(visible).length) issues.push("the report shows what looks like a phone number: remove it");
  if (/[?&](token|access_token|key|api_key|apikey|password|pwd|secret|sig|signature)=/i.test(html)) issues.push("the report has an address with a token, key or password in it: remove that address");
  if (/<!--\s*FILL/i.test(html)) issues.push("the report still has parts from the template to fill (FILL comments): fill or delete them");
  return { issues };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  if (!ws) console.log("REPORT_ERROR not a bootcamp folder (no bootcamp.json here or above)");
  else {
    const week = /^week-[1-3]$/.test(process.argv[2] || "") ? process.argv[2] : "week-1";
    const r = check(ws, week);
    if (r.error) console.log(`REPORT_ERROR ${r.error}`);
    else {
      for (const i of r.issues) console.log(`REPORT_ISSUE ${i}`);
      if (!r.issues.length) console.log("REPORT_OK");
      console.log(`REPORT ${r.issues.length} issues`);
    }
  }
}
