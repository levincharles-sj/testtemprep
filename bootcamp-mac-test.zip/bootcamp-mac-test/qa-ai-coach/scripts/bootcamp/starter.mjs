#!/usr/bin/env node
// QA AI bootcamps: put the week 1 smoke test starter in place. The coach runs it from the bootcamp workspace:
//   node starter.mjs                 → <workspace>/smoke-tests (tests stay on the laptop)
//   node starter.mjs <folder>        → that folder, for example a smoke-tests folder in the project repository
// Never overwrites a file the tester changed: the fresh copy goes beside it as <name>.new.
// A folder outside the workspace is linked (registered), so the guards and conversation saving work there too.
// Never runs npm: the tester runs `npm run setup` in the TESTS terminal.
// Output: STARTER_OK <folder>, COPIED <rel>, KEPT <rel>, LINKED <folder>, NEXT <line> · or STARTER_ERROR <reason>
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findBootcamp, addLink } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const TEMPLATE = path.join(HERE, "..", "..", "skills", "bootcamp", "starter", "smoke-tests");

function listFiles(dir, base = dir) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...listFiles(full, base));
    else if (e.isFile()) out.push(path.relative(base, full));
  }
  return out.sort();
}

const norm = (p) => path.resolve(p).replace(/[\\/]+$/, "").toLowerCase();
const PROD_SEGMENT = /^(prod|production|live|release|deploy(ment)?s?|infra(structure)?|secrets?)$/i;

/** Why a target folder may not be used, or null. */
export function refuseReason(target, workspace) {
  const t = norm(target);
  if (t === norm(workspace)) return "the bootcamp folder itself cannot hold the smoke tests; use a folder inside it, for example smoke-tests";
  if (path.parse(path.resolve(target)).root === path.resolve(target)) return "a drive's top folder cannot hold the smoke tests";
  if (t === norm(os.homedir())) return "your home folder cannot hold the smoke tests; use a folder inside a project or the bootcamp folder";
  const system = process.platform === "win32"
    ? [process.env.SystemRoot || "C:\\Windows", process.env.ProgramFiles || "C:\\Program Files", process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)", process.env.ProgramData || "C:\\ProgramData"]
    : ["/System", "/Library", "/Applications", "/usr", "/bin", "/sbin", "/etc", "/opt"];
  if (system.some((s) => t === norm(s) || t.startsWith(norm(s) + path.sep))) return "a system folder cannot hold the smoke tests";
  // A folder that already holds a project (its own package.json or .git) is never used: the starter's own
  // "setup" script and .gitignore would mix with the project's. The tests go in a new folder inside it.
  const abs = path.resolve(target);
  const ours = fs.existsSync(path.join(abs, "scripts", "check-secrets.mjs"));
  if (!ours && (fs.existsSync(path.join(abs, "package.json")) || fs.existsSync(path.join(abs, ".git")))) {
    return `this folder already holds a project (it has its own package.json or .git); use a new folder inside it, for example ${path.join(abs, "smoke-tests")}`;
  }
  const segs = abs.split(/[\\/]+/).slice(-2);
  const bad = segs.find((s) => PROD_SEGMENT.test(s));
  if (bad) return `the folder name "${bad}" looks like production or deployment configuration; put the smoke tests in their own folder, agreed with your dev lead`;
  return null;
}

export function placeStarter({ cwd = process.cwd(), target, template = TEMPLATE } = {}) {
  const lines = [];
  const found = findBootcamp(cwd);
  if (!found) return { ok: false, lines: ["STARTER_ERROR this is not your bootcamp folder. Start Claude in your bootcamp folder and try again."] };
  const ws = found.workspace;
  const dest = path.resolve(ws, target || "smoke-tests");
  const reason = refuseReason(dest, ws);
  if (reason) return { ok: false, lines: [`STARTER_ERROR ${reason}.`] };
  if (fs.existsSync(dest) && !fs.statSync(dest).isDirectory()) return { ok: false, lines: [`STARTER_ERROR ${dest} is a file, not a folder.`] };
  if (!fs.existsSync(template)) return { ok: false, lines: ["STARTER_ERROR the starter is missing from the coach; update the coach."] };
  fs.mkdirSync(dest, { recursive: true });
  for (const rel of listFiles(template)) {
    const src = path.join(template, rel);
    const out = path.join(dest, rel);
    const relShown = rel.split(path.sep).join("/");
    if (fs.existsSync(out)) {
      if (fs.readFileSync(out).equals(fs.readFileSync(src))) continue;
      fs.copyFileSync(src, `${out}.new`);
      lines.push(`KEPT ${relShown} (fresh copy as ${relShown}.new)`);
      continue;
    }
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.copyFileSync(src, out);
    lines.push(`COPIED ${relShown}`);
  }
  const inside = norm(dest).startsWith(norm(ws) + path.sep);
  if (!inside) {
    addLink(dest, ws, "smoke");
    lines.push(`LINKED ${dest}`);
  }
  lines.unshift(`STARTER_OK ${dest}`);
  lines.push(`NEXT In the TESTS terminal: cd "${dest}" then npm run setup`);
  return { ok: true, lines, folder: dest, linked: !inside };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const r = placeStarter({ target: process.argv[2] });
    console.log(r.lines.join("\n"));
    if (!r.ok) process.exitCode = 1;
  } catch (e) {
    console.log(`STARTER_ERROR ${e.message}`);
    process.exitCode = 1;
  }
}
