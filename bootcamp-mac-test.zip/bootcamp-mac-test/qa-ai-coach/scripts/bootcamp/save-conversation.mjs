#!/usr/bin/env node
// QA AI bootcamps: saves the current Claude Code conversation as readable Markdown in
// <bootcamp>/.bootcamp/conversations/<India date>/<session_id>.md. Runs as a Stop / SessionEnd hook.
// Works in the bootcamp workspace and in linked folders (a smoke test folder in a project repository): the file always
// goes to the bootcamp workspace, never into the project repository.
// Removes: values from the tester's .env files, known key and token patterns, all email addresses, and the tester's
// first name. The coach reads these files for the journal ("prompts that worked", "what Claude got wrong").
// Does nothing outside a bootcamp. Never blocks: always exits 0.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseTranscript, renderMarkdown } from "../save-conversation.mjs";
import { findBootcamp, readBootcamp, secretValues, scrub, todayFor, STATE_DIR } from "./lib.mjs";

export function capture(input, now = new Date()) {
  const found = findBootcamp(input.cwd || process.cwd());
  if (!found) return { skipped: "not a bootcamp folder" };
  const ws = found.workspace;
  const tp = input.transcript_path;
  if (!tp || !fs.existsSync(tp)) return { skipped: "no transcript" };
  const sessionId = String(input.session_id || path.basename(tp, ".jsonl")).replace(/[^A-Za-z0-9_-]/g, "");
  const parsed = parseTranscript(fs.readFileSync(tp, "utf8"));
  if (!parsed.entries.length) return { skipped: "empty" };
  const bc = readBootcamp(ws);
  const values = secretValues(ws);
  for (const e of parsed.entries) e.text = scrub(e.text, values);
  // The day of the LAST message: a WORK window left open overnight is saved under the day it is still used.
  const day = todayFor(bc, parsed.last ? new Date(parsed.last) : now);
  const root = path.join(ws, STATE_DIR, "conversations");
  const dir = path.join(root, day);
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${sessionId}.md`);
  // One file per conversation: an earlier copy under another day is removed (this file holds the whole conversation).
  try {
    for (const d of fs.readdirSync(root)) {
      const old = path.join(root, d, `${sessionId}.md`);
      if (d !== day && fs.existsSync(old)) fs.rmSync(old);
    }
  } catch { /* keep going */ }
  const where = found.linked ? `\n- Folder: linked folder ${path.basename(found.linked)}` : "";
  // renderMarkdown also removes emails and the name in `me` (first name only in the bootcamp).
  const md = renderMarkdown(parsed, { sessionId, me: { name: bc.firstName || "" } }).replace(/\n- Messages:/, `${where}\n- Messages:`);
  fs.writeFileSync(file, scrub(md, values), "utf8");
  return { file };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const raw = fs.readFileSync(0, "utf8");
    capture(raw ? JSON.parse(raw) : {});
  } catch {
    /* never block */
  }
  process.exit(0);
}
