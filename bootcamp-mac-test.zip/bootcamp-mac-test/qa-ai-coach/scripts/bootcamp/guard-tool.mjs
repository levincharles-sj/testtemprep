#!/usr/bin/env node
// QA AI bootcamps: PreToolUse hook. Acts only in a bootcamp workspace (bootcamp.json) or a folder linked to one;
// everywhere else it prints nothing (so it never changes the programme manager's or anyone else's sessions).
// It denies, with a plain reason:
// 1. Jetrix write tools, always; Jetrix read tools while Jetrix is off for this tester.
// 2. Reading, searching, writing or naming a .env file (not .env.example) in any tool, command or browser step.
// 3. Any tool call that contains a secret value from the tester's .env files (a command, a file Claude writes,
//    text typed into the browser).
// 4. In WORK windows: reading or searching the QA AI Coach plugin's own folder (the coach's files and practice apps).
// On any internal problem it prints nothing and exits 0 (the starter's deny rules still apply).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findBootcamp, secretValues, findSecret, readBootcamp } from "./lib.mjs";
import { isCoachSession } from "./guard-prompt.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const PLUGIN_ROOT = path.resolve(HERE, "..", "..");

export const JETRIX_RE = /mission_control_/i;
export const JETRIX_WRITE_RE = /mission_control_(create|update|delete|complete|bulk_update|upsert|assess_intent)/i;
// ".env" or ".env.local" as a file name, but not .env.example / .env.sample / .env.template, and not ".environment".
export const ENV_FILE_RE = /(^|[\s"'`/\\=<>|;&(,:*])\.env(?:\.(?!example\b|sample\b|template\b)[\w-]+)?(?![\w.-]*(?:example|sample|template))(?=$|[\s"'`/\\<>|;&),:*])/i;
const INSTALLED_PLUGIN_RE = /[\\/]\.claude[\\/]plugins[\\/][^"'\s]*qa-ai-coach/i;

const deny = (reason) => ({ deny: true, reason });

function inputText(input) {
  try { return JSON.stringify(input || {}); } catch { return ""; }
}
/** The parts of a tool call that can name a file or folder. */
function pathParts(input) {
  const i = input || {};
  return [i.file_path, i.path, i.notebook_path, i.pattern, i.glob, i.command, i.url, i.filename].filter((x) => typeof x === "string");
}

export function decide({ cwd, toolName, toolInput, sessionId, pluginRoot = PLUGIN_ROOT }) {
  const found = findBootcamp(cwd);
  if (!found) return {};
  const ws = found.workspace;
  const name = String(toolName || "");

  if (JETRIX_RE.test(name)) {
    if (JETRIX_WRITE_RE.test(name)) return deny("Jetrix is read-only in the bootcamp. Claude may never create, change or delete anything in Jetrix.");
    const bc = readBootcamp(ws);
    if (!bc.jetrix || bc.jetrix.mode !== "read") return deny("Jetrix is off. In the COACH window, type /bootcamp jetrix on followed by your project's name, if you want the coach to read it.");
  }

  const parts = pathParts(toolInput);
  if (parts.some((p) => ENV_FILE_RE.test(p) || /(^|[\\/])\.env$/i.test(p))) {
    return deny("Claude may not read, search, change or name .env files: they hold your passwords and keys. Code reads them with process.env.NAME. You edit .env yourself in VS Code.");
  }
  const coach = isCoachSession(ws, sessionId);
  // The COACH session runs only the coach's own scripts in a shell; it reads and changes its files with Read, Write
  // and Edit (live runs showed `cat`, `sed` and `node -e` on state.json, which make testers answer "Allow?").
  if (coach && /^(Bash|PowerShell)$/.test(name)) {
    const norm = (x) => String(x).replace(/\\/g, "/").replace(/\/+/g, "/").toLowerCase();
    let cmd = norm((toolInput || {}).command || "").trim();
    const wsN = norm(path.resolve(ws));
    // A leading "cd <the workspace>" (&& or ;) is harmless.
    cmd = cmd.replace(/^(cd|set-location|sl)\s+("([^"]*)"|'([^']*)'|(\S+))\s*(&&|;)\s*/, (m, _c, _q, a, b, c) => (norm(a || b || c).replace(/\/$/, "") === wsN ? "" : m));
    const root = norm(path.resolve(pluginRoot));
    const ownScript = new RegExp(`^(&\\s*)?node(\\.exe)?\\s+["']?${root.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}/scripts/bootcamp/[\\w.-]+\\.mjs["']?(\\s|$)`);
    if (!ownScript.test(cmd) || /(&&|\|\||;|\||`|\$\()/.test(cmd.replace(ownScript, ""))) {
      return deny("In the COACH window, run only the coach's own scripts (node \".../scripts/bootcamp/<script>.mjs\"). Read files with Read, Glob or Grep, and change them with Write or Edit.");
    }
  }
  // The coach may check that the saved login exists (Glob lists names only); nobody may open it.
  if (!(coach && name === "Glob") && parts.some((p) => /(^|[\\/])playwright[\\/]\.auth([\\/]|$)/i.test(p) || /(^|[\s"'\\/])\.auth[\\/]/i.test(p))) {
    return deny("The saved login (playwright/.auth) holds a live session. Claude may not open or print it. Tests use it through the Playwright config.");
  }
  // The WORK window works on the tests, not on the coach's own files in the bootcamp folder.
  if (!coach) {
    // Only at the top of the bootcamp folder: smoke-tests/tests/api/requests/ or a journal.md in a test project are the tester's own.
    const COACH_FILES = /^(conduit-practice-note\.txt|intake\.json|bootcamp\.json|decisions\.md|journal\.md|my-bootcamp-plan\.html|\.bootcamp|requests)([\\/]|$)/i;
    const inWs = (p) => {
      const abs = path.resolve(cwd, String(p).replace(/^["']|["']$/g, ""));
      const rel = path.relative(ws, abs);
      return rel && !rel.startsWith("..") && !path.isAbsolute(rel) ? rel : null;
    };
    let hit = parts.some((p) => {
      const rel = inWs(p);
      return (rel && COACH_FILES.test(rel)) || /conduit-practice-note\.txt|[\\/]\.bootcamp[\\/]|intake\.json/i.test(p);
    });
    // Commands: look at every word, resolved from the folder the command is in (and from any folder it cd's into).
    const command = typeof (toolInput || {}).command === "string" ? toolInput.command : "";
    if (!hit && command) {
      const words = command.match(/"[^"]*"|'[^']*'|[^\s;&|<>()]+/g) || [];
      const clean = (w) => w.replace(/^["']|["']$/g, "");
      const bases = [cwd];
      for (let i = 0; i < words.length - 1; i++) {
        if (/^(cd|pushd|Set-Location|sl)$/i.test(words[i])) bases.push(path.resolve(cwd, clean(words[i + 1])));
      }
      const wsLow = path.resolve(ws).toLowerCase();
      // A cd into the bootcamp folder itself is allowed (the tester's own week-N/ files live there), but a wildcard
      // there (cat *, type *.md) would read the coach's files too.
      const intoWs = bases.slice(1).some((b) => path.resolve(b).toLowerCase() === wsLow) || path.resolve(cwd).toLowerCase() === wsLow;
      if (intoWs && words.some((w) => /[*?]/.test(w) && !/[\\/]/.test(clean(w)))) hit = true;
      for (const w of words.map(clean)) {
        if (hit) break;
        for (const b of bases) {
          const rel = path.relative(ws, path.resolve(b, w));
          if (rel && !rel.startsWith("..") && !path.isAbsolute(rel) && COACH_FILES.test(rel)) { hit = true; break; }
        }
      }
    }
    if (hit) return deny("That is one of the coach's own files in your bootcamp folder. The WORK window works on your tests. Ask the coach in the COACH window instead.");
  }
  const secret = findSecret(inputText(toolInput), secretValues(ws));
  if (secret && /value from your \.env/.test(secret.kind)) {
    return deny("This step would put a secret value from your .env file into a command, a file or the browser. Use the name (process.env.NAME) instead. If the browser needs a password, the tester logs in by hand.");
  }

  if (!coach) {
    const norm = (x) => String(x).replace(/\\/g, "/").toLowerCase();
    const root = norm(path.resolve(pluginRoot));
    const hit = parts.some((p) => norm(p).includes(root) || INSTALLED_PLUGIN_RE.test(p));
    if (hit) return deny("The QA AI Coach's own files are out of scope in the WORK window. Test the app the way a user or client would: through its pages, its API and its docs.");
  }
  return {};
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const input = JSON.parse(fs.readFileSync(0, "utf8") || "{}");
    const r = decide({ cwd: input.cwd || process.cwd(), toolName: input.tool_name, toolInput: input.tool_input, sessionId: input.session_id });
    if (r.deny) {
      process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: r.reason } }));
    }
  } catch {
    // never fail a tool call because of the guard itself
  }
  process.exit(0);
}
