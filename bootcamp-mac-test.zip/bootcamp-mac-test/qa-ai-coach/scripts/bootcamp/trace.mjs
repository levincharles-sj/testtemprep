#!/usr/bin/env node
// QA AI bootcamps, week 2: turn an agent run into a readable trace (Markdown), for the tester.
//   node trace.mjs <runId|latest>
// Writes <workspace>/week-2/traces/<runId>.md and prints TRACE <path>. A conversation of several turns
// (--continue) is shown from its first turn. Never shows the system prompt or the build variant.
// Output: TRACE <path> · or TRACE_ERROR <reason>
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findMarker } from "./lib.mjs";
import { runsDir } from "./agent.mjs";

const plain = (v) => {
  if (v === null || v === undefined) return "-";
  if (typeof v !== "object") return String(v);
  return Object.entries(v).map(([k, x]) => `${k}: ${typeof x === "object" ? JSON.stringify(x) : x}`).join(" · ");
};

function readRun(ws, id) {
  try { return JSON.parse(fs.readFileSync(path.join(runsDir(ws), id, "run.json"), "utf8")); } catch { return null; }
}
function readTools(ws, id) {
  try {
    return fs.readFileSync(path.join(runsDir(ws), id, "tools.jsonl"), "utf8").split(/\r?\n/).filter(Boolean).map((l) => JSON.parse(l));
  } catch { return []; }
}

export function latestRun(ws) {
  let dirs = [];
  try { dirs = fs.readdirSync(runsDir(ws)).filter((d) => fs.existsSync(path.join(runsDir(ws), d, "run.json"))); } catch { return null; }
  return dirs.sort().pop() || null;
}

/** The chain of turns, first to last. */
export function chain(ws, id) {
  const out = [];
  for (let cur = id, guard = 0; cur && guard < 50; guard++) {
    const r = readRun(ws, cur);
    if (!r) break;
    out.unshift(r);
    cur = r.parent;
  }
  return out;
}

export function render(ws, id) {
  const turns = chain(ws, id);
  if (!turns.length) return null;
  const first = turns[0];
  const md = [`# Trace ${id}`, "", `- Agent version: ${first.version} · customer: ${first.customer} · started: ${first.started}`,
    `- Turns: ${turns.length} · total time: ${(turns.reduce((s, t) => s + (t.durationMs || 0), 0) / 1000).toFixed(1)} s`, ""];
  turns.forEach((t, i) => {
    md.push(`## Turn ${i + 1}`, "", "**Customer:**", "", `> ${String(t.message).replace(/\n/g, "\n> ")}`, "");
    if (t.status === "environment-error") { md.push("**The agent's tools did not start. This turn is not an answer of the agent.**", ""); return; }
    md.push(`**Intent label:** ${t.intent || "(none given)"}`, "");
    const calls = readTools(ws, t.runId);
    if (!calls.length) md.push("**Tool calls:** none", "");
    else {
      md.push("**Tool calls, in order:**", "");
      calls.forEach((c, k) => {
        md.push(`${k + 1}. \`${c.tool}\` (${c.ms} ms)`, `   - Asked with: ${plain(c.args)}`, `   - Got back: ${plain(c.result)}`);
      });
      md.push("");
    }
    md.push("**Reply:**", "", `> ${String(t.reply || "").replace(/\n/g, "\n> ")}`, "");
    const u = t.usage || {};
    md.push(`*Time: ${((t.durationMs || 0) / 1000).toFixed(1)} s · steps: ${t.turns ?? "-"} · tokens: ${u.input ?? 0} in, ${u.output ?? 0} out, ${(u.cacheWrite ?? 0) + (u.cacheRead ?? 0)} cached*`, "");
  });
  return md.join("\n");
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  const want = process.argv[2] || "latest";
  if (!ws) console.log("TRACE_ERROR not a bootcamp folder");
  else {
    const id = want === "latest" ? latestRun(ws) : want;
    const md = id && render(ws, id);
    if (!md) console.log(`TRACE_ERROR no run ${want}`);
    else {
      const out = path.join(ws, "week-2", "traces", `${id}.md`);
      fs.mkdirSync(path.dirname(out), { recursive: true });
      fs.writeFileSync(out, md, "utf8");
      console.log(`TRACE ${out}`);
    }
  }
}
