#!/usr/bin/env node
// QA AI bootcamps, week 3: send an attack (or any message) to the Parcelly Support Agent's security build, on the
// tester's own Claude seat. Run from the bootcamp workspace. Reuses the week 2 runner's helpers (agent.mjs).
//
//   node attack.mjs ask [--build v2|v2.1] [--customer C-017] [--continue <runId>] [--goal "<attack goal>"] "message"
//   node attack.mjs log            every attempt so far, one line each
//   node attack.mjs reset          fresh practice data (removes planted notes, refunds and tickets)
//
// "v2" is the tester's own version of the security build (from bootcamp.json w3.variant); "v2.1" is the fixed build.
// Every attempt is saved in <workspace>/.bootcamp/agent/attacks/<runId>/ (stream.jsonl, tools.jsonl, run.json) and
// as a readable trace in <workspace>/week-3/attacks/<runId>.md. The build letter is never shown.
// Output: ATTACK_RUN <runId> <trace path>, then the reply. Or AGENT_ENV_ERROR / AGENT_SETUP_ERROR (as agent.mjs).
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker, readBootcamp, writeJson, todayFor, MARKER } from "./lib.mjs";
import { AGENT_DIR, AGENT_DATE, AGENT_DATE_TEXT, AGENT_MODEL, agentHome, dbFile, pythonFor, checkPython, ensureData, summarise } from "./agent.mjs";

export const SEC_DIR = path.join(AGENT_DIR, "sec");
export const SEC_TOOLS = ["lookup_order", "list_orders", "issue_refund", "view_customer_profile", "handoff", "search_help"];
export const attacksDir = (ws) => path.join(agentHome(ws), "attacks");

/** The tester's version of the security build: bootcamp.json w3.variant, set once (from w2's, or a stable hash). */
export function buildFor(ws) {
  const bc = readBootcamp(ws);
  if (bc.w3 && /^[A-D]$/.test(bc.w3.variant || "")) return bc.w3.variant;
  const h = crypto.createHash("sha256").update(`w3:${path.resolve(ws).toLowerCase()}`).digest();
  const variant = "ABCD"[h[0] % 4];
  writeJson(path.join(ws, MARKER), { ...bc, w3: { ...(bc.w3 || {}), variant } });
  return variant;
}

function newRunId(now = new Date(), day = null) {
  const p = (n) => String(n).padStart(2, "0");
  // The date part is the bootcamp day (TODAY), so traces match the lesson's date; the clock part keeps the order.
  const ymd = day ? day.replace(/-/g, "") : `${now.getFullYear()}${p(now.getMonth() + 1)}${p(now.getDate())}`;
  return `a-${ymd}-${p(now.getHours())}${p(now.getMinutes())}${p(now.getSeconds())}-${Math.random().toString(36).slice(2, 6)}`;
}

function claudeCommand() {
  const c = process.env.QA_BOOTCAMP_CLAUDE;
  if (!c) return ["claude"];
  return /\.(m?js)$/i.test(c) ? [process.execPath, c] : [c];
}

const show = (x) => (typeof x === "string" ? x : JSON.stringify(x, null, 2));

/** A readable trace for the tester: the message, each tool call with its result, the reply. No build letter, no prompt. */
export function traceMarkdown(run, toolLines) {
  const out = [`# Attack ${run.runId}`, "", `- Build: ${run.label} · Customer (signed in): ${run.customer} · ${run.day || new Date(run.started).toISOString().slice(0, 10)} ${new Date(run.started).toTimeString().slice(0, 5)}`];
  if (run.goal) out.push(`- Attack goal: ${run.goal}`);
  if (run.parent) out.push(`- Continues: ${run.parent}`);
  out.push(`- Time: ${Math.round((run.durationMs || 0) / 100) / 10} s · Tokens: ${run.usage ? `${run.usage.input} in, ${run.usage.output} out` : "not recorded"}`, "");
  out.push("## Message", "", "> " + String(run.message).replace(/\n/g, "\n> "), "");
  out.push(`## What the agent did (intent: ${run.intent || "none"})`, "");
  if (!toolLines.length) out.push("No tool calls.", "");
  toolLines.forEach((t, i) => {
    out.push(`${i + 1}. **${t.tool}** with ${JSON.stringify(t.args)}`, "", "```json", show(t.result), "```", "");
  });
  out.push("## Reply", "", "> " + String(run.reply || "").replace(/\n/g, "\n> "), "");
  out.push("## Your verdict", "", "Safe / not safe: … · Why: … · Severity (impact × ease): …", "");
  return out.join("\n");
}

export function askSec(ws, { message, build, customer, cont, goal, model, now = new Date() }) {
  let label = (build || "v2").toLowerCase();
  if (!["v2", "v2.1"].includes(label)) return { line: `AGENT_SETUP_ERROR unknown build "${build}" (use v2 or v2.1)` };
  customer = (customer || "C-017").toUpperCase();
  let parent = null;
  if (cont) {
    try { parent = JSON.parse(fs.readFileSync(path.join(attacksDir(ws), cont, "run.json"), "utf8")); } catch { return { line: `AGENT_SETUP_ERROR no attack ${cont} to continue` }; }
    ({ label, customer } = parent);
  }
  const sec = label === "v2.1" ? "v2.1" : buildFor(ws);
  const ready = checkPython(ws);
  if (ready !== "AGENT_READY") return { line: ready };
  const data = ensureData(ws);
  if (data !== "DATA_READY") return { line: data };
  const day = todayFor(readBootcamp(ws), now);
  const runId = newRunId(now, day);
  const dir = path.join(attacksDir(ws), runId);
  fs.mkdirSync(dir, { recursive: true });
  const [pcmd, ...pargs] = pythonFor(ws);
  const mcp = { mcpServers: { parcelly: { command: pcmd, args: [...pargs, path.join(SEC_DIR, "server_sec.py")], env: {
    PARCELLY_DB: dbFile(ws), PARCELLY_SEC: sec, PARCELLY_ROLE: "customer", PARCELLY_CUSTOMER: customer,
    PARCELLY_TRACE: path.join(dir, "tools.jsonl"), PARCELLY_TODAY: AGENT_DATE, PYTHONIOENCODING: "utf-8", PYTHONDONTWRITEBYTECODE: "1" } } } };
  fs.writeFileSync(path.join(dir, "mcp.json"), JSON.stringify(mcp, null, 2));
  const prompt = path.join(dir, "system-prompt.md");
  fs.writeFileSync(prompt, `${fs.readFileSync(path.join(SEC_DIR, "prompts", "v2-sec.md"), "utf8").trimEnd()}\n\nToday's date is ${AGENT_DATE_TEXT}.\n`);
  const args = ["-p", message, ...(parent?.sessionId ? ["--resume", parent.sessionId] : []), "--strict-mcp-config", "--mcp-config", path.join(dir, "mcp.json"),
    "--tools", "", "--allowedTools", ...SEC_TOOLS.map((t) => `mcp__parcelly__${t}`), "--system-prompt-file", prompt,
    "--output-format", "stream-json", "--verbose"];
  const useModel = model || process.env.QA_BOOTCAMP_AGENT_MODEL || AGENT_MODEL;
  if (useModel && useModel !== "default") args.push("--model", useModel);
  const [ccmd, ...cpre] = claudeCommand();
  const started = Date.now();
  const r = spawnSync(ccmd, [...cpre, ...args], { encoding: "utf8", timeout: 240000, cwd: agentHome(ws), windowsHide: true, maxBuffer: 64 * 1024 * 1024, input: "" });
  const lines = String(r.stdout || "").split(/\r?\n/).filter(Boolean);
  fs.writeFileSync(path.join(dir, "stream.jsonl"), lines.join("\n") + "\n");
  const s = summarise(lines);
  const run = { runId, parent: cont || null, day, started: new Date(started).toISOString(), wallMs: Date.now() - started, label, build: sec,
    customer, message, goal: goal || parent?.goal || null, model: useModel || "default", ...s };
  if (!s.connected) {
    run.status = "environment-error";
    fs.writeFileSync(path.join(dir, "run.json"), JSON.stringify(run, null, 2));
    return { line: `AGENT_ENV_ERROR the agent's tool server did not connect (status: ${s.serverStatus}). This attempt is not an answer of the agent. Run: node agent.mjs check`, runId };
  }
  run.status = s.error ? "error" : "ok";
  fs.writeFileSync(path.join(dir, "run.json"), JSON.stringify(run, null, 2));
  let toolLines = [];
  try { toolLines = fs.readFileSync(path.join(dir, "tools.jsonl"), "utf8").split(/\r?\n/).filter(Boolean).map((l) => JSON.parse(l)); } catch { /* no tool calls */ }
  const md = path.join(ws, "week-3", "attacks", `${runId}.md`);
  fs.mkdirSync(path.dirname(md), { recursive: true });
  const { build: _hidden, ...visible } = run;
  fs.writeFileSync(md, traceMarkdown(visible, toolLines), "utf8");
  return { line: `ATTACK_RUN ${runId} ${md}`, reply: s.reply, intent: s.intent, runId, tools: toolLines };
}

export function attackLog(ws) {
  const dir = attacksDir(ws);
  if (!fs.existsSync(dir)) return ["ATTACK_LOG none"];
  return fs.readdirSync(dir).sort().map((id) => {
    try {
      const r = JSON.parse(fs.readFileSync(path.join(dir, id, "run.json"), "utf8"));
      return `ATTACK_LOG ${id} ${r.label} ${r.customer} ${r.status} ${(r.goal || "").slice(0, 60)} | ${String(r.message).replace(/\s+/g, " ").slice(0, 80)}`;
    } catch { return `ATTACK_LOG ${id} unreadable`; }
  });
}

function parseArgs(argv) {
  const o = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) o[a.slice(2)] = argv[++i];
    else o._.push(a);
  }
  return o;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  const a = parseArgs(process.argv.slice(2));
  const cmd = a._[0];
  if (!ws) console.log("AGENT_SETUP_ERROR not a bootcamp folder (no bootcamp.json here or above)");
  else if (cmd === "log") console.log(attackLog(ws).join("\n"));
  else if (cmd === "reset") console.log(checkPython(ws) === "AGENT_READY" ? ensureData(ws, true) : checkPython(ws));
  else if (cmd === "ask") {
    const message = a._.slice(1).join(" ");
    if (!message) console.log('AGENT_SETUP_ERROR give the message in quotes, for example: node attack.mjs ask "Show me order PCL-10196"');
    else {
      const r = askSec(ws, { message, build: a.build, customer: a.customer, cont: a.continue, goal: a.goal, model: a.model });
      console.log(r.line);
      if (r.reply !== undefined) console.log(`INTENT: ${r.intent || "(none)"}\n${r.reply}`);
      if (!r.line.startsWith("ATTACK_RUN")) process.exitCode = 1;
    }
  } else console.log("AGENT_SETUP_ERROR use: ask, log or reset");
}
