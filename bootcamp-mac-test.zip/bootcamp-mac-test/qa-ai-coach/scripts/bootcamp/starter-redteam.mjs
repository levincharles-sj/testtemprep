#!/usr/bin/env node
// QA AI bootcamps, week 3: put the red-team project in place. The coach runs it from the bootcamp workspace:
//   node starter-redteam.mjs          → <workspace>/redteam
// Never overwrites a file the tester changed: the fresh copy goes beside it as <name>.new.
// Writes redteam/coach.json (where the coach's attack runner is), so target.py can find it on Windows and Mac.
// Never installs anything: the tester makes the Python environment in the TESTS terminal (the NEXT lines say how).
// Output: STARTER_OK <folder>, COPIED <rel>, KEPT <rel>, NEXT <line> · or STARTER_ERROR <reason>
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findBootcamp, readBootcamp } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const PLUGIN_ROOT = path.resolve(HERE, "..", "..");
export const TEMPLATE = path.join(PLUGIN_ROOT, "skills", "bootcamp", "starter", "redteam");
const SKIP = /(^|[\\/])(__pycache__|\.venv|\.deepeval|\.pytest_cache|results)([\\/]|$)|\.pyc$/;

function listFiles(dir, base = dir) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    const rel = path.relative(base, full);
    if (SKIP.test(rel)) continue;
    if (e.isDirectory()) out.push(...listFiles(full, base));
    else if (e.isFile()) out.push(rel);
  }
  return out.sort();
}

export function nextLines(os, dest) {
  return os === "mac"
    ? [`cd "${dest}"`, "python3.12 -m venv .venv", ".venv/bin/python -m pip install -r requirements.txt", ".venv/bin/python -m pytest tests/test_offline.py -q"]
    : [`cd "${dest}"`, "py -3.12 -m venv .venv", ".\\.venv\\Scripts\\python.exe -m pip install -r requirements.txt", ".\\.venv\\Scripts\\python.exe -m pytest tests/test_offline.py -q"];
}

export function placeRedteam({ cwd = process.cwd(), template = TEMPLATE, pluginRoot = PLUGIN_ROOT } = {}) {
  const found = findBootcamp(cwd);
  if (!found) return { ok: false, lines: ["STARTER_ERROR this is not your bootcamp folder. Start Claude in your bootcamp folder and try again."] };
  const ws = found.workspace;
  if (!fs.existsSync(template)) return { ok: false, lines: ["STARTER_ERROR the red-team starter is missing from the coach; update the coach."] };
  const dest = path.join(ws, "redteam");
  if (fs.existsSync(dest) && !fs.statSync(dest).isDirectory()) return { ok: false, lines: [`STARTER_ERROR ${dest} is a file, not a folder.`] };
  fs.mkdirSync(path.join(dest, "results"), { recursive: true });
  const lines = [`STARTER_OK ${dest}`];
  for (const rel of listFiles(template)) {
    const src = path.join(template, rel);
    const out = path.join(dest, rel);
    const shown = rel.split(path.sep).join("/");
    if (fs.existsSync(out)) {
      if (fs.readFileSync(out).equals(fs.readFileSync(src))) continue;
      fs.copyFileSync(src, `${out}.new`);
      lines.push(`KEPT ${shown} (fresh copy as ${shown}.new)`);
      continue;
    }
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.copyFileSync(src, out);
    lines.push(`COPIED ${shown}`);
  }
  fs.writeFileSync(path.join(dest, "coach.json"), JSON.stringify({ plugin: pluginRoot, workspace: ws }, null, 2) + "\n");
  for (const l of nextLines(readBootcamp(ws).os, dest)) lines.push(`NEXT ${l}`);
  return { ok: true, lines, folder: dest };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const r = placeRedteam();
    console.log(r.lines.join("\n"));
    if (!r.ok) process.exitCode = 1;
  } catch (e) {
    console.log(`STARTER_ERROR ${e.message}`);
    process.exitCode = 1;
  }
}
