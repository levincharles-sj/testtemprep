#!/usr/bin/env node
// QA AI bootcamps: PostToolUse hook. Acts only in a bootcamp workspace (bootcamp.json) or a folder linked to one.
// If a tool's output holds a secret value from the tester's .env files or a known key pattern (for example a search
// across files that hit .env, or a script that printed process.env), it replaces the output Claude sees with the same
// output where each secret is "[removed]". The output keeps the tool's own shape (Claude Code ignores a replacement
// with a different shape). The tool has already run; only what Claude sees changes.
// On any internal problem it prints nothing and exits 0.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findBootcamp, secretValues, scrub } from "./lib.mjs";

/** Scrub every string inside a value, keeping its shape. Returns { value, changed }. */
export function scrubDeep(value, values) {
  let changed = false;
  const walk = (v) => {
    if (typeof v === "string") {
      const s = scrub(v, values, { heuristics: false });
      if (s !== v) changed = true;
      return s;
    }
    if (Array.isArray(v)) return v.map(walk);
    if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, walk(x)]));
    return v;
  };
  return { value: walk(value), changed };
}

export function decide({ cwd, toolResponse }) {
  const found = findBootcamp(cwd);
  if (!found || toolResponse === undefined) return {};
  const { value, changed } = scrubDeep(toolResponse, secretValues(found.workspace));
  return changed ? { updated: value } : {};
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const input = JSON.parse(fs.readFileSync(0, "utf8") || "{}");
    const r = decide({ cwd: input.cwd || process.cwd(), toolResponse: input.tool_response });
    if (r.updated !== undefined) {
      process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: "PostToolUse", updatedToolOutput: r.updated,
        additionalContext: "A secret value in this tool's output was replaced with [removed]. Never try to print or read secret values; use their names." } }));
    }
  } catch {
    // never fail a tool call because of the guard itself
  }
  process.exit(0);
}
