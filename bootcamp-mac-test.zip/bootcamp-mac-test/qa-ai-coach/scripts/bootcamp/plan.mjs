#!/usr/bin/env node
// QA AI bootcamps: what to do now. Run from the bootcamp workspace.
//   node plan.mjs --init                 first run: bootcamp.json, folders, settings (prints INIT_OK, SETTINGS ...)
//   node plan.mjs                        today's day and the state around it
//   node plan.mjs --done <day> <met|not-met>   record a finished day (after /bootcamp done)
// Output lines (in this order, each optional):
//   TODAY <date> <day> · PREVIEW <date> · SETTINGS <added|ok|new-restart> · INTAKE needed · MESSAGE <sentence> · RUN <day> <date> | RUN none
//   DAY <id> <date> <done|open|future> · SATURDAY <date> <n> · OPEN <week> <id> <state> <item> · LINK <folder>
//   ENV ok | ENV down <reason> | ENV unknown | ENV practice-app-down · SILENT <n> days
//   PLAN_ERROR <reason>
import fs from "node:fs";
import path from "node:path";
import http from "node:http";
import crypto from "node:crypto";
import https from "node:https";
import { fileURLToPath } from "node:url";
import {
  MARKER, STATE_DIR, DAYS, WEEKS, ALL_DAYS, weekOn, weekOfDay, parseDay, findMarker, readBootcamp, readIntake, readJson, writeJson,
  todayFor, previewOn, ensureSettings, foldersOf, parseEnv, envFilesIn, fmtDay, addDays,
} from "./lib.mjs";
import { findWorkspace } from "../lib.mjs";

const DONE_FILE = path.join(STATE_DIR, "days.json");
export const readDays = (ws) => readJson(path.join(ws, DONE_FILE), {});

const DECISIONS_HEAD = `# My decisions and blockers

The coach adds an entry for each blocker and each decision. Check each one, and change it into your own words.
Format: what was blocked · who I asked, and when · the answer and the date they gave · my decision and why · what it changes.
`;
const JOURNAL_HEAD = `# My bootcamp journal

One entry per day, written at /bootcamp done: my decisions, the tools I used, the prompts that worked, what Claude got wrong and how I caught it. My Saturday report is built from it.
`;
const CONTEXT_README = `# Project context (stays on this laptop)

Put your project's material here: requirement or feature documents, existing test cases, a ticket export (CSV), API docs (Swagger, OpenAPI or Postman).

Rules:
- This folder never goes into git and is never shared.
- Remove customer names, emails and phone numbers from any export first.
- No passwords, tokens or keys.
- Use it only if the client allows AI tools on your project.
`;

export function init(ws, now = new Date()) {
  const out = [];
  if (fs.existsSync(path.join(ws, MARKER))) out.push("INIT_OK existing");
  else {
    const os = process.platform === "darwin" ? "mac" : process.platform === "win32" ? "windows" : "mac";
    writeJson(path.join(ws, MARKER), { version: 1, firstName: "", os, createdAt: now.toISOString(), jetrix: { mode: "off" } });
    out.push("INIT_OK new");
  }
  for (const d of ["week-1", "week-2", "week-3", "project-context", "requests", STATE_DIR]) fs.mkdirSync(path.join(ws, d), { recursive: true });
  const put = (rel, text) => { const f = path.join(ws, rel); if (!fs.existsSync(f)) fs.writeFileSync(f, text, "utf8"); };
  put("decisions.md", DECISIONS_HEAD);
  put("journal.md", JOURNAL_HEAD);
  put(path.join("project-context", "README.md"), CONTEXT_README);
  out.push(`SETTINGS ${ensureSettings(ws)}`);
  return out;
}

export function recordDone(ws, day, verdict, now = new Date()) {
  const id = parseDay(day);
  if (!id) return `PLAN_ERROR "${day}" is not a bootcamp day (W1D1 to W3D5)`;
  const days = readDays(ws);
  days[id] = { at: now.toISOString(), on: todayFor(readBootcamp(ws), now), mustHave: verdict === "met" ? "met" : "not-met" };
  writeJson(path.join(ws, DONE_FILE), days);
  return `DONE_RECORDED ${id} ${days[id].mustHave}`;
}

/** Working days (Mon-Fri bootcamp days) strictly between two dates. */
function workingDaysBetween(a, b) {
  return ALL_DAYS.filter((d) => DAYS[d] > a && DAYS[d] < b).length;
}

function baseUrl(ws) {
  for (const folder of foldersOf(ws)) {
    for (const f of envFilesIn(folder)) {
      if (!/[\\/]\.env$/.test(f)) continue;
      let text = "";
      try { text = fs.readFileSync(f, "utf8"); } catch { continue; }
      const hit = parseEnv(text).find((e) => e.name === "BASE_URL" && /^https?:\/\//i.test(e.value));
      if (hit) return hit.value;
    }
  }
  return null;
}

// The Conduit practice app on this laptop (practice-app.mjs). When it does not answer, the coach starts it.
export const PRACTICE_APP_RE = /^https?:\/\/(?:127\.0\.0\.1|localhost):4310(?:[/?#]|$)/i;
const PROXY_VARS = ["HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy", "ALL_PROXY", "all_proxy"];

/**
 * Any HTTP answer counts as up (a login page or a 401 is fine). A refused or unknown address is down. Not sure is
 * "unknown", never "down": no answer in time (a slow VPN), or a network error behind a company proxy (Node does not
 * use the proxy, so the error says nothing about the environment). The practice app not answering is
 * "practice-app-down".
 */
export function envCheck(url, timeout = 5000, env = process.env) {
  return new Promise((resolve) => {
    if (!url) return resolve("ENV unknown");
    let u;
    try { u = new URL(url); } catch { return resolve("ENV unknown"); }
    const practice = PRACTICE_APP_RE.test(url);
    const proxied = !practice && PROXY_VARS.some((k) => env[k]);
    let settled = false;
    const done = (line) => { if (!settled) { settled = true; resolve(line); } };
    const lib = u.protocol === "https:" ? https : http;
    const req = lib.request(u, { method: "GET", timeout }, (res) => { res.resume(); done("ENV ok"); });
    req.on("timeout", () => { done(practice ? "ENV practice-app-down" : "ENV unknown"); req.destroy(); });
    req.on("error", (e) => {
      // A certificate error means the server answered (a company network that inspects traffic): it is up.
      if (/CERT|SELF_SIGNED|UNABLE_TO_VERIFY|TLS|SSL/i.test(String(e.code || e.message))) return done("ENV ok");
      if (practice) return done("ENV practice-app-down");
      if (proxied) return done("ENV unknown");
      done(`ENV down ${e.code === "ENOTFOUND" ? "the address was not found (VPN off?)" : e.code === "ECONNREFUSED" ? "nothing answers at that address" : e.message}`);
    });
    req.end();
  });
}

/**
 * Week 2 and 3: each tester gets one of four builds (A-D) of the practice agent, with different planted faults.
 * Chosen once from a stable hash of the bootcamp folder's path, saved in bootcamp.json w2.variant, never printed.
 * The programme manager may change it in bootcamp.json (for example so buddies get different builds).
 */
export function variantFor(ws) {
  const h = crypto.createHash("sha256").update(path.resolve(ws).toLowerCase()).digest();
  return "ABCD"[h[0] % 4];
}
export function assignVariant(ws) {
  const bc = readBootcamp(ws);
  if (bc.w2 && /^[A-D]$/.test(bc.w2.variant || "")) return bc.w2.variant;
  const variant = variantFor(ws);
  writeJson(path.join(ws, MARKER), { ...bc, w2: { ...(bc.w2 || {}), variant } });
  return variant;
}

export async function plan(ws, now = new Date(), { checkEnv = true } = {}) {
  const out = [];
  try { assignVariant(ws); } catch { /* bootcamp.json missing or read-only: the agent runner falls back to its default */ }
  const bc = readBootcamp(ws);
  const today = todayFor(bc, now);
  out.push(`TODAY ${today} ${fmtDay(today)}`);
  if (previewOn(bc)) out.push(`PREVIEW ${today}`);
  out.push(`SETTINGS ${ensureSettings(ws)}`);
  const intake = readIntake(ws);
  if (!intake || intake.status !== "done") out.push("INTAKE needed");
  const days = readDays(ws);
  const week = weekOn(today);
  let run = null, message = null;
  if (today < DAYS.W1D1) message = `Week 1 starts on ${fmtDay(DAYS.W1D1)}.`;
  else if (today > WEEKS.W3.saturday) message = "The bootcamps are finished. Well done.";
  else if (!week) {
    const next = Object.entries(WEEKS).find(([, w]) => w.start > today);
    message = next ? `Week ${next[0].slice(1)} starts on ${fmtDay(next[1].start)}.` : null;
  } else if (today === WEEKS[week].saturday) message = "Today is presentation day. Open your report.html. Good luck.";
  else {
    const open = ALL_DAYS.filter((d) => weekOfDay(d) === week && DAYS[d] <= today && !days[d]);
    run = open[0] || null;
    if (run && DAYS[run] < today) message = `You still have ${run} (${fmtDay(DAYS[run])}) to finish. Let's do that first.`;
    if (!run) message = "Today's work is done. See you tomorrow.";
  }
  if (message) out.push(`MESSAGE ${message}`);
  out.push(run ? `RUN ${run} ${DAYS[run]}` : "RUN none");
  for (const d of ALL_DAYS) out.push(`DAY ${d} ${DAYS[d]} ${days[d] ? "done" : DAYS[d] <= today ? "open" : "future"}`);
  const sat = Object.values(WEEKS).map((w) => w.saturday).find((s) => s >= today);
  if (sat) out.push(`SATURDAY ${sat} ${Math.round((Date.parse(sat) - Date.parse(today)) / 86400000)}`);
  if (intake && Array.isArray(intake.readiness)) {
    const showNext = week && today >= addDays(WEEKS[week].start, 2);
    for (const r of intake.readiness) {
      if (!r || ["ready", "not-needed"].includes(r.state)) continue;
      const w = r.week || "W1";
      if (w === week || (!week && w === "W1") || (showNext && w === `W${Number(week.slice(1)) + 1}`)) out.push(`OPEN ${w} ${r.id} ${r.state} ${r.item || ""}`.trim());
    }
  }
  for (const f of foldersOf(ws).slice(1)) out.push(`LINK ${f}`);
  if (checkEnv) out.push(await envCheck(baseUrl(ws)));
  if (week && today >= WEEKS[week].start) {
    const doneDates = Object.values(days).map((v) => v.on || String(v.at).slice(0, 10)).sort();
    const last = doneDates[doneDates.length - 1] || addDays(WEEKS.W1.start, -1);
    const gap = workingDaysBetween(last, today);
    if (gap >= 2) out.push(`SILENT ${gap} days`);
  }
  return out;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  try {
    if (args[0] === "--init") {
      const here = process.cwd();
      const ws = findMarker(here) || here;
      if (!findMarker(here) && !/qa-ai-bootcamp/i.test(path.basename(here))) console.log("PLAN_ERROR this folder is not called qa-ai-bootcamp");
      else if (!findMarker(here) && findWorkspace(here)) console.log("PLAN_ERROR this folder is inside your QA AI Programme coach folder; make the bootcamp folder outside it (C:\\qa-ai-bootcamp or ~/qa-ai-bootcamp)");
      else console.log(init(ws).join("\n"));
    } else {
      const ws = findMarker(process.cwd());
      if (!ws) console.log("PLAN_ERROR not a bootcamp folder (no bootcamp.json here or above)");
      else if (args[0] === "--done") console.log(recordDone(ws, args[1], args[2]));
      else console.log((await plan(ws)).join("\n"));
    }
  } catch (e) {
    console.log(`PLAN_ERROR ${e.message}`);
  }
}
