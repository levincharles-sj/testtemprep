// Shared helpers for the QA AI bootcamps (the /bootcamp skill and its hooks). No dependencies; Windows and macOS.
//
// The bootcamp workspace is the folder holding bootcamp.json (C:\qa-ai-bootcamp or ~/qa-ai-bootcamp). It never holds
// me.json, so the programme's /coach scripts and hooks never act there.
// Linked folders (a smoke test folder inside a project repository, for example) are registered in a small file in
// the tester's home folder, so the hooks know which bootcamp they belong to wherever Claude Code starts.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { indiaDate, isPreview, validYmd, addDays, fmtDay } from "../lib.mjs";

export { indiaDate, fmtDay, addDays, validYmd };

export const MARKER = "bootcamp.json";
export const STATE_DIR = ".bootcamp";

// ---------- calendar (fixed dates, India time) ----------
export const WEEKS = {
  W1: { start: "2026-11-30", saturday: "2026-12-05", theme: "AI-driven test automation" },
  W2: { start: "2026-12-07", saturday: "2026-12-12", theme: "Evals for AI agents: the go-live sign-off" },
  W3: { start: "2026-12-14", saturday: "2026-12-19", theme: "Responsible AI and security testing" },
};
export const DAYS = Object.fromEntries(
  Object.entries(WEEKS).flatMap(([w, { start }]) => [1, 2, 3, 4, 5].map((d) => [`${w}D${d}`, addDays(start, d - 1)])),
);
export const ALL_DAYS = Object.keys(DAYS);

export function parseDay(word) {
  const m = String(word || "").trim().toUpperCase().match(/^W([1-3])D([1-5])$/);
  return m ? `W${m[1]}D${m[2]}` : null;
}
export const weekOfDay = (id) => id.slice(0, 2);
/** The bootcamp week (W1-W3) a date falls in, Monday to Saturday; null outside. */
export function weekOn(ymd) {
  for (const [w, { start, saturday }] of Object.entries(WEEKS)) if (ymd >= start && ymd <= saturday) return w;
  return null;
}

// ---------- the tester's home registry of linked folders ----------
export function homeDir() {
  return process.env.QA_BOOTCAMP_HOME || path.join(os.homedir(), ".qa-ai-bootcamp");
}
const sameOrInside = (child, parent) => {
  const c = path.resolve(child).toLowerCase(), p = path.resolve(parent).toLowerCase();
  return c === p || c.startsWith(p.endsWith(path.sep) ? p : p + path.sep);
};
export function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
  } catch {
    return fallback;
  }
}
export function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + "\n");
}
export function readLinks() {
  const list = readJson(path.join(homeDir(), "links.json"), []);
  return Array.isArray(list) ? list.filter((l) => l && l.folder && l.workspace) : [];
}
/** Register `folder` as part of the bootcamp in `workspace`. Returns the updated list. */
export function addLink(folder, workspace, purpose = "smoke") {
  const list = readLinks().filter((l) => path.resolve(l.folder).toLowerCase() !== path.resolve(folder).toLowerCase());
  list.push({ folder: path.resolve(folder), workspace: path.resolve(workspace), purpose, linkedAt: new Date().toISOString() });
  writeJson(path.join(homeDir(), "links.json"), list);
  addWorkspaceDirectory(workspace, folder);
  return list;
}
/**
 * Let the COACH window (opened on the workspace) read and edit a linked folder without "Allow?": add it to the
 * workspace's .claude/settings.json permissions.additionalDirectories, keeping everything already there.
 */
export function addWorkspaceDirectory(workspace, folder) {
  const file = path.join(workspace, ".claude", "settings.json");
  const s = fs.existsSync(file) ? readJson(file, null) : {};
  if (!s || typeof s !== "object") return false; // not valid JSON: leave the tester's file alone
  s.permissions = s.permissions && typeof s.permissions === "object" ? s.permissions : {};
  const dirs = Array.isArray(s.permissions.additionalDirectories) ? s.permissions.additionalDirectories : [];
  const abs = path.resolve(folder);
  if (dirs.some((d) => path.resolve(String(d)).toLowerCase() === abs.toLowerCase())) return false;
  s.permissions.additionalDirectories = [...dirs, abs];
  writeJson(file, s);
  return true;
}

/** Walk up from `start` (max 8 levels) for bootcamp.json. */
export function findMarker(start) {
  let dir = path.resolve(start || process.cwd());
  for (let i = 0; i < 9; i++) {
    if (fs.existsSync(path.join(dir, MARKER))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

/**
 * The bootcamp that `start` belongs to: { workspace, linked } or null.
 * `linked` is the linked folder when `start` is inside one (else null).
 */
export function findBootcamp(start) {
  const ws = findMarker(start);
  if (ws) return { workspace: ws, linked: null };
  const here = path.resolve(start || process.cwd());
  const hit = readLinks()
    .filter((l) => sameOrInside(here, l.folder) && fs.existsSync(path.join(l.workspace, MARKER)))
    .sort((a, b) => b.folder.length - a.folder.length)[0];
  return hit ? { workspace: path.resolve(hit.workspace), linked: path.resolve(hit.folder) } : null;
}

export const readBootcamp = (ws) => readJson(path.join(ws, MARKER), {});
export const readState = (ws) => readJson(path.join(ws, STATE_DIR, "state.json"), {});
export const writeState = (ws, s) => writeJson(path.join(ws, STATE_DIR, "state.json"), s);
export const readIntake = (ws) => readJson(path.join(ws, "intake.json"), null);

/** Today's India date, or the preview date in a preview workspace (programme manager's key only). */
export function todayFor(bc, now = new Date()) {
  if (process.env.QA_BOOTCAMP_TODAY && validYmd(process.env.QA_BOOTCAMP_TODAY)) return process.env.QA_BOOTCAMP_TODAY;
  return (isPreview(bc) && validYmd(bc.previewDate)) || indiaDate(now);
}
export const previewOn = (bc) => isPreview(bc);

/** Every folder that belongs to this bootcamp: the workspace and its linked folders. */
export function foldersOf(ws) {
  const out = [path.resolve(ws)];
  for (const l of readLinks()) if (path.resolve(l.workspace).toLowerCase() === path.resolve(ws).toLowerCase()) out.push(path.resolve(l.folder));
  return [...new Set(out)];
}

// ---------- secrets from .env files ----------
// Which .env values count as secrets: a value of 8 characters or more whose name says it is secret, or any value of
// 16 characters or more that looks random. Addresses, user names and switches (BASE_URL, TEST_USER, AUTH=manual)
// are not secrets, so a tester can still talk about them.
export const SECRET_NAME = /(PASS|PWD|SECRET|TOKEN|API_?KEY|ACCESS_?KEY|PRIVATE|CREDENTIAL|TOTP|OTP|CLIENT_?SECRET|AUTH_?CODE|SESSION|COOKIE|SIGNING|WEBHOOK|CAPTCHA|_KEY\b)/i;
// A value whose name says it is secret counts from 6 characters (short test passwords exist); other values only when
// they look random (16 or more characters).
export const MIN_SECRET = 6;

export function parseEnv(text) {
  const out = [];
  for (const raw of String(text || "").replace(/^\uFEFF/, "").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const m = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2].trim();
    const q = v.match(/^(["'])(.*?)\1(?:\s+#.*)?$/);
    if (q) v = q[2];
    else v = v.replace(/#.*$/, "").trim(); // as Node's own loader does: an unquoted # starts a comment
    out.push({ name: m[1], value: v });
  }
  return out;
}
export function looksRandom(v) {
  // Tokens and keys mix letters and digits; addresses, emails and file paths are not secrets.
  if (v.length < 16 || /\s|@/.test(v) || /^[a-z][a-z0-9+.-]*:\/\//i.test(v) || /[\\/]/.test(v)) return false;
  if (!/[0-9]/.test(v) || !/[A-Za-z]/.test(v)) return false;
  // qa_automation_user01, test.env.orion-01: made of words, so a name, not a key.
  if (/[._-]/.test(v) && /(?:^|[._-])[a-z]{4,}(?=[._-]|\d|$)/i.test(v)) return false;
  return new Set(v).size / v.length > 0.35;
}
export function isSecretEntry({ name, value }) {
  if (!value || value.length < MIN_SECRET) return false;
  if (/^(true|false|yes|no|on|off|manual|auto|none|null|test|staging|local)$/i.test(value)) return false;
  return SECRET_NAME.test(name) || looksRandom(value);
}

const ENV_NAMES = /^\.env(\.(?!example$|sample$|template$)[\w.-]+)?$/i;
/** The .env files of one folder and its usual sub-folders (not node_modules or .git). */
export function envFilesIn(folder, depth = 2) {
  const out = [];
  const walk = (dir, d) => {
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (e.isFile() && ENV_NAMES.test(e.name)) out.push(path.join(dir, e.name));
      else if (e.isDirectory() && d > 0 && !/^(node_modules|\.git|\.venv|venv|playwright-report|test-results|conversations)$/i.test(e.name)) walk(path.join(dir, e.name), d - 1);
    }
  };
  walk(folder, depth);
  return out;
}
/** Secret values from every .env of this bootcamp (workspace and linked folders), longest first. */
export function secretValues(ws) {
  const values = new Set();
  for (const folder of foldersOf(ws)) {
    for (const f of envFilesIn(folder)) {
      let text = "";
      try { text = fs.readFileSync(f, "utf8"); } catch { continue; }
      for (const e of parseEnv(text)) if (isSecretEntry(e)) values.add(e.value);
    }
  }
  return [...values].sort((a, b) => b.length - a.length);
}

// ---------- known secret patterns (no .env needed) ----------
// Entries: [kind, regex, check?, "heuristic"?, context?]. A context regex must also match somewhere in the text.
// A message about logging in: only then is a lone password-like word ("Tester@123") taken as a password.
export const LOGIN_CONTEXT = /\b(?:log\s?in|logon|sign\s?in|signin|password|passwd|pwd|pass|creds?|credentials?|user(?:name)?|account|auth\w*)\b/i;
export const SECRET_PATTERNS = [
  ["a private key", /-----BEGIN [A-Z ]*PRIVATE KEY-----/],
  ["an API key", /\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{16,}/],
  ["a GitHub token", /\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})/],
  ["a cloud key", /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b|\bAIza[0-9A-Za-z_-]{30,}/],
  ["a Slack token", /\bxox[abprs]-[A-Za-z0-9-]{10,}/],
  ["a login token (JWT)", /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/],
  ["a bearer token", /\bBearer\s+[A-Za-z0-9._~+/-]{20,}=*/i],
  ["a connection string with a password", /\b[a-z][a-z0-9+.-]*:\/\/[^\s:/@]+:[^\s@/]{4,}@/i],
  ["a login (basic auth)", /\bAuthorization:\s*Basic\s+[A-Za-z0-9+/]{8,}={0,2}/i],
  ["a session cookie", /\b(?:session(?:id)?|cookie|sid|jsessionid|connect\.sid)\s*[=:]\s*["']?([A-Za-z0-9+/_%.-]{24,})/i],
  // "password is Practice123" is stopped; "check that the password is required" is not: the value must look like a
  // password (a digit or a symbol, or a capital letter after the first letter). The keyword must stand alone:
  // "DEBUG=pw:browser*" is not a password.
  ["a password", /(?<![=:/\w-])(?:password|passwd|pwd|passcode|pass|pw)(?:\s*(?:is|=|:)\s*|\s+-\s+)["'`]?([^\s"'`]{6,})/i, (v) => valueLike(v), "heuristic"],
  // A user name and a password together: "qa.user@client.com / Welcome_123", "creds: admin / Adm1n_2026",
  // "username qauser password Qwerty12".
  ["a user name and password", /(?:[\w.+-]+@[\w-]+\.[\w.]+|\b(?:creds?|credentials|login|user(?:name)?)\s*[:=]?\s*\S+)\s+\/\s+["'`]?([^\s"'`]{6,})/i, (v) => valueLike(v), "heuristic"],
  ["a user name and password", /\buser(?:name)?\s+\S+\s+(?:and\s+)?(?:password|pwd|pass|pw)\s+["'`]?([^\s"'`]{6,})/i, (v) => valueLike(v), "heuristic"],
  // An authenticator (TOTP) secret: base32 text after the word, for example "TOTP secret JBSWY3DPEHPK3PXP".
  ["an authenticator secret", /\b(?:totp|otp|2fa|mfa|authenticator)\b[^\n]{0,40}?\b([A-Z2-7]{16,}=*)(?![A-Za-z0-9])/i, (v) => /[A-Z]/.test(v) && /[2-7]/.test(v), "heuristic"],
  // A whole word (between spaces) that looks like a password: capitals, small letters, a digit and a symbol, and no
  // address characters (/ ? & = . -), only in a message about logging in ("login with Tester@123"). "Chrome@131",
  // "iPhone15+", "/search?Category=Shoes2&sort=asc" and "v1.2.3-RC1+build" are not stopped.
  ["a word that looks like a password", /(?<!\S)(?<!\b(?:task|uses)\s*:\s*)([A-Za-z0-9!@#$%^*+~]{8,64})(?=[.,;:!?)]?(?:\s|$))/, (v) => /[A-Z]/.test(v) && /[a-z]/.test(v) && /\d/.test(v) && /[!@#$%^*+~]/.test(v.replace(/!$/, "")), "heuristic", LOGIN_CONTEXT],
  ["a secret or key", /\b(?:api[_-]?key|secret|access[_-]?token|client[_-]?secret|totp[_-]?secret)\s*(?:is|=|:)\s*["']?([A-Za-z0-9._~+/-]{8,})/i, (v) => valueLike(v), "heuristic"],
];
// A name that points to a secret is not a secret: process.env.TEST_PASSWORD, ${{ secrets.X }}, $X, %X%, env.X.
export function isReference(v) {
  const w = String(v || "");
  return /^(?:process\.env\.|import\.meta\.env\.|env\.|os\.environ|\$\{\{|\$\{?[A-Z_]|%[A-Z_]+%|secrets\.)/i.test(w) || /^[A-Z][A-Z0-9_]{2,}$/.test(w);
}
function valueLike(v) {
  const raw = String(v || "");
  if (/^[([{<]/.test(raw)) return false; // "Password: (Required)", "password: [hidden]"
  const w = raw.replace(/[`'"\])}>]+$/, "").replace(/[.,;:!?]+$/, "");
  if (isReference(w)) return false;
  if (/^[a-z]+$/i.test(w) && !/[A-Z]/.test(w.slice(1))) return false; // one plain word: "required", "Required"
  if (/^[a-z0-9]+(?:[-_][a-z0-9]+)+$/.test(w)) return false; // a lower-case name: "login-page-01", "smoke_suite"
  return w.length >= 6 && (/[0-9]/.test(w) || /[^A-Za-z]/.test(w) || /[A-Z]/.test(w.slice(1)));
}

/** What secret the text holds: { kind } or null. Checks .env values first (exact match), then the patterns. */
export function findSecret(text, values = []) {
  const s = String(text || "");
  for (const v of values) if (v && v.length >= MIN_SECRET && s.includes(v)) return { kind: "a value from your .env file" };
  for (const [kind, re, check, , context] of SECRET_PATTERNS) {
    if (context && !context.test(s)) continue;
    const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
    for (const m of s.matchAll(g)) if (!check || check(m[1])) return { kind };
  }
  return null;
}

/**
 * Replace .env values and known secret patterns with [removed].
 * heuristics=false keeps only exact .env values and the sure key formats (private keys, API keys, tokens): used on
 * tool output, where guessing "password-like" words would change file contents Claude needs to edit.
 */
export function scrub(text, values = [], { heuristics = true } = {}) {
  let out = String(text ?? "");
  for (const v of values) if (v && v.length >= MIN_SECRET) out = out.split(v).join("[removed]");
  for (const [, re, check, kind, context] of SECRET_PATTERNS) {
    if (!heuristics && kind === "heuristic") continue;
    if (context && !context.test(out)) continue;
    const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
    const hasGroup = new RegExp(`${re.source}|`).exec("").length > 1;
    out = out.replace(g, (whole, ...args) => {
      const value = hasGroup ? args[0] : undefined;
      if (check && !check(value)) return whole;
      return value ? whole.replace(value, "[removed]") : "[removed]";
    });
  }
  return out;
}

// ---------- workspace settings ----------
// Allow rules so the coach can save its files without "Allow?" each time; deny rules so Claude never reads .env.
export const ALLOW_RULES = ["Edit(./.bootcamp/**)", "Edit(./week-1/**)", "Edit(./week-2/**)", "Edit(./week-3/**)", "Edit(./decisions.md)",
  "Edit(./journal.md)", "Edit(./intake.json)", "Edit(./my-bootcamp-plan.html)", "Edit(./requests/**)", "Edit(./smoke-tests/prompts/**)"];
export const DENY_RULES = ["Read(./.env)", "Read(./.env.*)", "Read(**/.env)", "Read(**/.env.*)"];
export const DISPLAY_SETTINGS = {
  spinnerVerbs: { mode: "replace", verbs: ["Coach is working"] },
  spinnerTipsEnabled: false,
  showThinkingSummaries: false,
  showTurnDuration: false,
  awaySummaryEnabled: false,
  promptSuggestionEnabled: false,
};
/** Merge the bootcamp rules into <folder>/.claude/settings.json; returns "added", "ok" or "new-restart". */
export function ensureSettings(folder, { allow = ALLOW_RULES, deny = DENY_RULES, display = DISPLAY_SETTINGS, extra = {} } = {}) {
  const dir = path.join(folder, ".claude");
  const file = path.join(dir, "settings.json");
  const folderIsNew = !fs.existsSync(dir);
  let s = {};
  if (fs.existsSync(file)) {
    s = readJson(file, null);
    if (!s) throw new Error(".claude/settings.json is not valid JSON. Fix or delete it, then try again.");
  }
  s.permissions = s.permissions || {};
  const a = Array.isArray(s.permissions.allow) ? s.permissions.allow : [];
  const d = Array.isArray(s.permissions.deny) ? s.permissions.deny : [];
  const addA = allow.filter((r) => !a.includes(r)), addD = deny.filter((r) => !d.includes(r));
  const addDisp = Object.keys(display).filter((k) => !(k in s));
  const addExtra = Object.keys(extra).filter((k) => JSON.stringify(s[k]) !== JSON.stringify(extra[k]));
  if (!addA.length && !addD.length && !addDisp.length && !addExtra.length) return "ok";
  s.permissions.allow = [...a, ...addA];
  s.permissions.deny = [...d, ...addD];
  for (const k of addDisp) s[k] = display[k];
  for (const k of addExtra) s[k] = extra[k];
  writeJson(file, s);
  return folderIsNew ? "new-restart" : "added";
}
