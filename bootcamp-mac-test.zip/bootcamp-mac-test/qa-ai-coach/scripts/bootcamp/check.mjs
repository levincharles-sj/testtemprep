#!/usr/bin/env node
// QA AI bootcamps: the set-up and safety check (/bootcamp check). Run from the bootcamp workspace.
// Prints one line per check:  OK <what>  ·  FAIL <what> | FIX <plain fix>  ·  LATER <what> | FIX <fix> (needed in a later week)
// and IT <what> for problems only IT can fix (admin rights, proxy, certificates). Last line: CHECK <ok> of <total>.
// Never prints a value from a .env file: names only.
import fs from "node:fs";
import path from "node:path";
import https from "node:https";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker, readBootcamp, foldersOf, parseEnv, readJson, DENY_RULES, todayFor, WEEKS } from "./lib.mjs";

const WIN = process.platform === "win32";
const run = (cmd, args, opts = {}) => {
  const r = spawnSync(cmd, args, { encoding: "utf8", timeout: opts.timeout || 20000, shell: WIN, cwd: opts.cwd, windowsHide: true });
  return { ok: r.status === 0, out: `${r.stdout || ""}${r.stderr || ""}`.trim(), status: r.status };
};
const vparts = (v) => String(v).replace(/^v/, "").split(".").map(Number);
const atLeast = (v, min) => { const a = vparts(v), b = vparts(min); for (let i = 0; i < 3; i++) { if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) > (b[i] || 0); } return true; };

function ping(url, timeout = 6000) {
  return new Promise((resolve) => {
    const req = https.get(url, { timeout }, (res) => { res.resume(); resolve({ ok: true }); });
    req.on("timeout", () => req.destroy(Object.assign(new Error("timeout"), { code: "TIMEOUT" })));
    req.on("error", (e) => resolve({ ok: false, code: e.code || e.message }));
  });
}

/** "Python 3.12.4" or later: true. */
export function pythonOk(out) {
  const m = String(out || "").match(/Python\s+(\d+)\.(\d+)/i);
  return !!m && Number(m[1]) === 3 && Number(m[2]) >= 12;
}

export async function checks(ws, { network = true, tools = true } = {}) {
  const out = [];
  const ok = (t) => out.push(`OK ${t}`);
  const fail = (t, fix) => out.push(`FAIL ${t} | FIX ${fix}`);
  const later = (t, fix) => out.push(`LATER ${t} | FIX ${fix}`);
  const it = (t) => out.push(`IT ${t}`);
  const bc = readBootcamp(ws);
  const mac = bc.os === "mac";

  ok(`Laptop: ${mac ? "Mac" : "Windows"} (${process.platform} ${process.arch})`);
  if (atLeast(process.versions.node, "22.13.0")) ok(`Node.js ${process.versions.node}`);
  else fail(`Node.js ${process.versions.node} is too old (22.13 or later is needed)`, `install Node.js 22 LTS from https://nodejs.org (the "LTS" button)${mac ? "" : ", then close and open the terminal"}`);

  if (tools) {
    if (WIN) {
      // A fresh Windows blocks npm.ps1 and npx.ps1 in PowerShell ("running scripts is disabled on this system").
      const pol = spawnSync("powershell.exe", ["-NoProfile", "-Command", "Get-ExecutionPolicy"], { encoding: "utf8", timeout: 15000, windowsHide: true });
      const p = String(pol.stdout || "").trim();
      if (/^(Restricted|AllSigned)$/i.test(p)) fail(`PowerShell blocks npm and npx (execution policy: ${p})`, "in PowerShell, type: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned   then answer Y (no admin needed). If your company blocks this too, ask IT, and meanwhile type npm.cmd and npx.cmd instead of npm and npx");
      else if (p) ok(`PowerShell allows npm and npx (execution policy: ${p})`);
    }
    const git = run("git", ["--version"]);
    git.ok ? ok(git.out.split("\n")[0]) : fail("git is not installed", `install git from https://git-scm.com${mac ? " (or type: xcode-select --install)" : ""}`);
    const cc = run("claude", ["--version"]);
    const ccv = cc.ok ? cc.out.split(" ")[0] : "";
    if (!cc.ok) fail("Claude Code did not answer", "update it: type claude update in a terminal");
    else if (!atLeast(ccv, "2.1.332")) fail(`Claude Code ${ccv} is older than the coach needs (2.1.332)`, "type claude update in a terminal, then start claude again");
    else ok(`Claude Code ${ccv}`);
    // Python 3.12 or later. Windows: the py launcher picks the newest (py -3), else python; Mac: python3.
    const pyTries = mac ? [["python3", ["--version"]]] : [["py", ["-3", "--version"]], ["python", ["--version"]]];
    const py = pyTries.map(([c, a]) => run(c, a)).find((r) => r.ok && pythonOk(r.out));
    py ? ok(`${py.out} (for week 2)`) : later("Python 3.12 or later (needed from Monday 7 December)", mac ? "install Python 3.12 or later from https://www.python.org/downloads/" : "install Python 3.12 or later from https://www.python.org/downloads/ (tick \"Add python.exe to PATH\")");
  }

  try {
    const st = fs.statfsSync(ws);
    const gb = (st.bavail * st.bsize) / 1e9;
    gb >= 3 ? ok(`Free disk space: ${gb.toFixed(1)} GB`) : fail(`Free disk space is low: ${gb.toFixed(1)} GB (3 GB or more is needed)`, "delete large files you do not need, or empty the recycle bin");
  } catch { /* statfs not available: skip */ }
  // Windows: week 2's Python packages have deep file paths; past 260 characters pip leaves them half installed.
  if (WIN && ws.length > 60) {
    const what = `The bootcamp folder's path is long (${ws.length} characters): week 2's Python packages may not install ("Windows Long Path support")`;
    const fix = "use a short folder such as C:\\qa-ai-bootcamp, or ask IT to switch on long paths in Windows";
    todayFor(bc) >= WEEKS.W2.start ? fail(what, fix) : later(what, fix);
  }
  if (/onedrive|icloud|dropbox|google drive/i.test(ws)) fail("The bootcamp folder is inside a synced folder (OneDrive, iCloud or Dropbox)", mac ? "use ~/qa-ai-bootcamp in your home folder" : "use C:\\qa-ai-bootcamp");

  if (network) {
    const npm = await ping("https://registry.npmjs.org/-/ping");
    if (npm.ok) ok("Internet: npm can download packages");
    else if (/CERT|SELF_SIGNED|UNABLE_TO_VERIFY/i.test(String(npm.code))) it(`The company network changes secure connections (${npm.code}). Ask IT for the company root certificate and set NODE_EXTRA_CA_CERTS (see the IT request)`);
    else if (process.env.HTTPS_PROXY || process.env.https_proxy) it(`npm cannot reach the internet through the proxy (${npm.code}). Ask IT for the proxy settings for npm and Playwright`);
    else fail(`npm cannot reach the internet (${npm.code})`, "check the Wi-Fi or VPN, then try again; if it still fails, type /bootcamp stuck");
  }

  const smoke = [path.join(ws, "smoke-tests"), ...foldersOf(ws).slice(1)].filter((f) => fs.existsSync(path.join(f, "package.json")));
  if (!smoke.length) out.push("INFO No smoke test folder yet: it is made in today's lesson");
  for (const f of smoke) {
    const label = f === path.join(ws, "smoke-tests") ? "smoke-tests" : path.basename(f);
    const pkg = readJson(path.join(f, "package.json"), {});
    const pw = (pkg.devDependencies || {})["@playwright/test"] || (pkg.dependencies || {})["@playwright/test"];
    if (!pw) { fail(`${label}: Playwright is not in package.json`, "ask Claude in the WORK window to add @playwright/test 1.64.1"); continue; }
    fs.existsSync(path.join(f, "node_modules", "@playwright", "test")) ? ok(`${label}: packages installed (Playwright ${pw})`) : fail(`${label}: packages are not installed`, "in the TESTS terminal, in that folder, type: npm run setup");
    if (tools && fs.existsSync(path.join(f, "node_modules", "@playwright", "test"))) {
      const dry = run("npx", ["playwright", "install", "--dry-run", "chromium"], { cwd: f, timeout: 30000 });
      const loc = (dry.out.match(/Install location:\s*(.+)/) || [])[1];
      loc && fs.existsSync(loc.trim()) ? ok(`${label}: the Chromium browser for this Playwright is installed`) : fail(`${label}: the browser for this Playwright version is missing`, "in the TESTS terminal, in that folder, type: npx playwright install chromium");
    }
    const envFile = path.join(f, ".env");
    if (!fs.existsSync(envFile)) fail(`${label}: no .env file`, "in the TESTS terminal, in that folder, type: npm run setup (it makes .env from .env.example); then type your values in VS Code");
    else {
      const envText = fs.readFileSync(envFile, "utf8");
      const names = new Map(parseEnv(envText).map((e) => [e.name, e.value]));
      const hashLines = envText.split(/\r?\n/).map((l) => l.trim()).filter((l) => /^[A-Za-z_][\w.-]*\s*=\s*[^"'#\s][^#]*#/.test(l)).map((l) => l.split("=")[0].trim());
      if (hashLines.length) fail(`${label}: .env has a value with # and no quotes (${hashLines.join(", ")}): everything from # is cut off`, "open .env in VS Code and put that value in double quotes, for example NAME=\"...\"");
      const manual = String(names.get("AUTH") || "").toLowerCase() === "manual";
      const need = ["BASE_URL", ...(manual ? [] : ["TEST_USER", "TEST_PASSWORD"])];
      const missing = need.filter((n) => !names.get(n));
      missing.length ? fail(`${label}: .env has no value for ${missing.join(", ")}`, "open .env in VS Code and type the values yourself (never in the chat)") : ok(`${label}: .env has ${need.join(", ")} (values not shown)`);
      const base = String(names.get("BASE_URL") || "");
      // Many real test environments have plain names: ask, never fail.
      if (base && !/test|qa|stag|uat|dev|sandbox|localhost|127\.0\.0\.1/i.test(base)) out.push(`INFO ${label}: BASE_URL has no test, qa, staging, uat, dev or sandbox in it. Please confirm to the coach that it is a test environment (yes or no, never the address)`);
    }
    if (fs.existsSync(path.join(f, ".git")) || run("git", ["rev-parse", "--is-inside-work-tree"], { cwd: f }).ok) {
      const ig = run("git", ["check-ignore", "-q", ".env"], { cwd: f });
      ig.ok ? ok(`${label}: .env is ignored by git`) : fail(`${label}: .env is NOT ignored by git`, "ask Claude in the WORK window to add .env to .gitignore, then run npm run check-secrets");
    }
    fs.existsSync(path.join(f, "scripts", "check-secrets.mjs")) ? ok(`${label}: check-secrets is there`) : fail(`${label}: check-secrets is missing`, "type /bootcamp in the COACH window: the starter step adds it");
    const mcp = readJson(path.join(f, ".mcp.json"), null);
    const server = mcp && mcp.mcpServers && mcp.mcpServers["playwright-test"];
    if (!server) fail(`${label}: the browser for Claude (.mcp.json) is not set up`, "in the TESTS terminal, in that folder, type: npm run setup");
    else ok(`${label}: Claude's browser is set up${(server.args || []).includes("--headless") ? " (hidden)" : " (visible)"}`);
    const agents = ["planner", "generator", "healer"].filter((a) => fs.existsSync(path.join(f, ".claude", "agents", `playwright-test-${a}.md`)));
    agents.length === 3 ? ok(`${label}: the planner, generator and healer are there`) : fail(`${label}: Playwright's test agents are missing (${3 - agents.length})`, "in the TESTS terminal, in that folder, type: npm run setup");
    const s = readJson(path.join(f, ".claude", "settings.json"), {});
    const deny = (s.permissions && s.permissions.deny) || [];
    DENY_RULES.slice(0, 2).every((r) => deny.includes(r)) ? ok(`${label}: Claude may not read .env (deny rules)`) : fail(`${label}: the rules that stop Claude reading .env are missing`, "in the TESTS terminal, in that folder, type: npm run setup");
  }
  const total = out.filter((l) => /^(OK|FAIL|IT)\b/.test(l)).length;
  out.push(`CHECK ${out.filter((l) => l.startsWith("OK")).length} of ${total}`);
  return out;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  if (!ws) console.log("CHECK_ERROR not a bootcamp folder (no bootcamp.json here or above)");
  else console.log((await checks(ws, { network: !process.argv.includes("--offline") })).join("\n"));
}
