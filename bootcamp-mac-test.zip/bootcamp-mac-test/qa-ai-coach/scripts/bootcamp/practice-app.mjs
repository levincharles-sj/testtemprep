#!/usr/bin/env node
// QA AI bootcamps: start, stop or reset the Conduit practice app (the week 1 fallback app) on this laptop.
// Run from the tester's bootcamp folder. The data lives in .bootcamp/practice-app/ there, so it survives coach updates.
//
//   node practice-app.mjs start [mfa] [captcha]   make sure it runs with exactly these switches (others off); keeps the data
//   node practice-app.mjs reset [mfa] [captcha]   stop it, delete its data, start it fresh
//   node practice-app.mjs stop
//   node practice-app.mjs status
//
// Output (one line): APP ready <url> mfa=<off|totp> captcha=<off|on> [data=kept|fresh]
//                    APP stopped · APP failed <reason>
// Detached: it keeps running after Claude Code closes; no window, no output. Never opens a browser.
// QA_BOOTCAMP_APP_PORT changes the port (tests only).
import http from "node:http";
import net from "node:net";
import path from "node:path";
import fs from "node:fs";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SERVER = path.join(HERE, "..", "..", "apps", "conduit", "server.mjs");
export const APP_PORT = Number(process.env.QA_BOOTCAMP_APP_PORT) || 4310;
const MIN_NODE = [22, 13];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function nodeOk(version = process.versions.node) {
  const [a, b] = version.split(".").map(Number);
  return a > MIN_NODE[0] || (a === MIN_NODE[0] && b >= MIN_NODE[1]);
}

/** GET /api/environment; resolves {ours, root, options} and never throws. */
export function probe(port = APP_PORT, timeout = 1500) {
  return new Promise((resolve) => {
    const req = http.get({ host: "127.0.0.1", port, path: "/api/environment", timeout, headers: { Accept: "application/json" } }, (res) => {
      res.resume();
      res.on("end", () => {
        const ours = res.statusCode === 200 && res.headers["x-practice-app"] === "qa-ai-bootcamp-conduit";
        let root = null;
        try { root = decodeURIComponent(res.headers["x-practice-app-root"] || ""); } catch { /* ignore */ }
        resolve({ ours, root, options: String(res.headers["x-practice-app-options"] || "") });
      });
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => resolve({ ours: false, root: null, options: "" }));
  });
}

function portInUse(port) {
  return new Promise((resolve) => {
    const s = net.connect({ host: "127.0.0.1", port });
    s.setTimeout(1000);
    s.once("connect", () => { s.destroy(); resolve(true); });
    s.once("timeout", () => { s.destroy(); resolve(false); });
    s.once("error", () => resolve(false));
  });
}

function askStop(port) {
  return new Promise((resolve) => {
    const req = http.request({ host: "127.0.0.1", port, path: "/__coach/stop", method: "POST", timeout: 1500, headers: { "X-Coach-Stop": "1" } }, (res) => { res.resume(); res.on("end", resolve); });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => resolve());
    req.end();
  });
}

// The "dev team's note" for the practice app: written to a file the tester opens in VS Code, so the coach never has
// to show a password in the chat. Practice values for a laptop app, never real secrets.
export const NOTE_FILE = "conduit-practice-note.txt";
export const NOTE = `Conduit practice app: note from the "dev team"
==============================================

Test environment: http://127.0.0.1:4310   (API docs: http://127.0.0.1:4310/openapi.yaml)

Test accounts for automation (type these into .env yourself, never into a chat):
  TEST_USER=smoke-member@conduit.test        (a member: your main test account)
  TEST_PASSWORD=Smoke-Pass-2026

A second role in your tests (the moderator), if your smoke picks need one:
  TEST_USER_2=smoke-moderator@conduit.test
  TEST_PASSWORD_2=Smoke-Pass-2026

If the coach switches on two-step sign-in (MFA), the authenticator secret goes in .env:
  TEST_TOTP_SECRET=ONWW623FFVWWK3LCMVZC25DPORYC22ZR      (the member)
  TEST_TOTP_SECRET_2=ONWW623FFVWW6ZDFOJQXI33SFV2G65DQ    (the moderator, only if you use the second role)

If the coach switches on the captcha, the test key goes in .env:
  CAPTCHA_TEST_KEY=conduit-captcha-test-key-2026

These are practice values for an app on your own laptop. Treat them like real secrets anyway:
they go in .env only, and never into a chat, a test file or a commit.
`;
export function writeNote(workspace) {
  try {
    const f = path.join(workspace, NOTE_FILE);
    if (!fs.existsSync(f)) fs.writeFileSync(f, NOTE, "utf8");
  } catch { /* the note is a help, never a reason to fail */ }
}

const optionsText =({ mfa, captcha }) => `mfa=${mfa ? "totp" : "off"};captcha=${captcha ? "on" : "off"}`;
const readable = (o) => o.replace(";", " ");

export async function stopApp({ port = APP_PORT } = {}) {
  const p = await probe(port);
  if (!p.ours) return { status: "stopped", line: "APP stopped" };
  await askStop(port);
  const until = Date.now() + 4000;
  while (Date.now() < until && (await portInUse(port))) await sleep(150);
  return (await portInUse(port)) ? { status: "failed", line: "APP failed the practice app did not stop" } : { status: "stopped", line: "APP stopped" };
}

/**
 * Make sure the app runs with exactly these switches. fresh=true deletes the data first.
 * Returns {status: "running"|"started"|"failed", line}.
 */
export async function startApp({ workspace = findMarker(process.cwd()) || process.cwd(), port = APP_PORT, mfa = false, captcha = false, fresh = false,
  server = SERVER, waitMs = 8000 } = {}) {
  const url = `http://127.0.0.1:${port}`;
  const want = optionsText({ mfa, captcha });
  const failed = (reason) => ({ status: "failed", line: `APP failed ${reason}` });
  if (!nodeOk()) return failed(`Node 22.13 or later is needed; this laptop has Node ${process.versions.node}`);
  if (!fs.existsSync(server)) return failed("the practice app is missing from the coach; update the coach");
  const dataDir = path.join(workspace, ".bootcamp", "practice-app");
  const dbFile = path.join(dataDir, "conduit.db");
  const first = await probe(port);
  const sameCopy = first.ours && first.root && path.resolve(first.root).toLowerCase() === path.dirname(server).toLowerCase();
  if (sameCopy && first.options === want && !fresh) writeNote(workspace);
  if (sameCopy && first.options === want && !fresh) return { status: "running", line: `APP ready ${url} ${readable(want)} data=kept` };
  if (first.ours) {
    const s = await stopApp({ port });
    if (s.status === "failed") return failed("the old copy of the practice app did not stop; restart the laptop and try again");
  }
  if (await portInUse(port)) return failed(`port ${port} is used by another program, so the practice app cannot start`);
  fs.mkdirSync(dataDir, { recursive: true });
  if (fresh) {
    for (const f of [dbFile, `${dbFile}-wal`, `${dbFile}-shm`]) fs.rmSync(f, { force: true });
  }
  const keep = fs.existsSync(dbFile);
  let child;
  try {
    child = spawn(process.execPath, ["--no-warnings", server], {
      detached: true,
      stdio: "ignore",
      windowsHide: true,
      env: {
        ...process.env, PORT: String(port), CONDUIT_DB: dbFile, KEEP_DATA: keep ? "1" : "",
        CONDUIT_MFA: mfa ? "totp" : "", CONDUIT_CAPTCHA: captcha ? "on" : "",
      },
    });
    child.on("error", () => {});
    child.unref();
  } catch (e) {
    return failed(`the practice app could not start (${e.message})`);
  }
  const until = Date.now() + waitMs;
  while (Date.now() < until) {
    await sleep(150);
    const p = await probe(port, 800);
    if (p.ours && p.options === want) {
      writeNote(workspace);
      return { status: "started", line: `APP ready ${url} ${readable(want)} data=${keep ? "kept" : "fresh"}` };
    }
    if (child.exitCode !== null) break;
  }
  if (child.exitCode !== null) return failed(`the practice app stopped at once (exit code ${child.exitCode})`);
  return failed(`the practice app did not answer within ${Math.round(waitMs / 1000)} seconds`);
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const [cmd = "status", ...rest] = process.argv.slice(2);
  const words = rest.map((w) => w.toLowerCase());
  const switches = { mfa: words.includes("mfa"), captcha: words.includes("captcha") };
  let r;
  if (cmd === "start") r = await startApp(switches);
  else if (cmd === "reset") r = await startApp({ ...switches, fresh: true });
  else if (cmd === "stop") r = await stopApp();
  else if (cmd === "status") {
    const p = await probe();
    r = p.ours ? { status: "running", line: `APP ready http://127.0.0.1:${APP_PORT} ${readable(p.options)}` } : { status: "stopped", line: "APP stopped" };
  } else r = { status: "failed", line: `APP failed unknown command "${cmd}" (use start, reset, stop or status)` };
  console.log(r.line);
  if (r.status === "failed") process.exitCode = 1;
}
