#!/usr/bin/env node
// QA AI bootcamps, week 2: read-only look at the practice data and the documents the agent uses, so the tester can
// check the expected answers of their golden set. Never shows how the agent's tools work.
//   node lookup.mjs order PCL-10011 | customer C-017 | orders C-017 | find delivered prepaid over 2000 | ticket H-1001 | lockers Pune | policy | help <words>
// Output: the data in plain text, or LOOKUP_ERROR <reason>.
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker } from "./lib.mjs";
import { AGENT_DIR, pythonFor, dbFile, checkPython, ensureData } from "./agent.mjs";

export const WHAT = ["order", "customer", "orders", "find", "ticket", "lockers", "policy", "help"];

export function lookup(ws, what, rest) {
  if (!WHAT.includes(what)) return `LOOKUP_ERROR use one of: ${WHAT.join(", ")}`;
  const ready = checkPython(ws);
  if (ready !== "AGENT_READY") return ready.replace("AGENT_SETUP_ERROR", "LOOKUP_ERROR");
  const data = ensureData(ws);
  if (data !== "DATA_READY") return data.replace("AGENT_SETUP_ERROR", "LOOKUP_ERROR");
  const [cmd, ...pre] = pythonFor(ws);
  const r = spawnSync(cmd, [...pre, "data.py", "--db", dbFile(ws), "lookup", what, ...rest], { encoding: "utf8", cwd: AGENT_DIR,
    windowsHide: true, env: { ...process.env, PYTHONIOENCODING: "utf-8", PYTHONDONTWRITEBYTECODE: "1" } });
  return r.status === 0 ? r.stdout.trimEnd() : `LOOKUP_ERROR ${(r.stderr || "").trim().split("\n").pop()}`;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  const [what, ...rest] = process.argv.slice(2);
  console.log(ws ? lookup(ws, what, rest) : "LOOKUP_ERROR not a bootcamp folder");
}
