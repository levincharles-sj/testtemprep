#!/usr/bin/env node
// QA AI bootcamps, week 2: run the Parcelly Support Agent on the tester's own Claude seat (no API key).
// Run from the bootcamp workspace (or a folder inside it).
//
//   node agent.mjs ask [--version v1|v2] [--variant A|B|C|D] [--customer C-017] [--continue <runId>] [--model <m>] "message"
//   node agent.mjs reset            fresh practice data (the tester's own copy)
//   node agent.mjs check            is Python with the MCP SDK ready?
//
// Each run is saved in <workspace>/.bootcamp/agent/runs/<runId>/: stream.jsonl (Claude's raw events), tools.jsonl
// (every tool call with inputs, result and time) and run.json (reply, intent label, tools, turns, time, tokens).
// Output: AGENT_RUN <runId>, then the reply. Or AGENT_ENV_ERROR <reason> (the tool server did not connect: the run is
// not an answer of the agent), or AGENT_SETUP_ERROR <reason> with the fix.
// The variant comes from bootcamp.json w2.variant when not given. QA_BOOTCAMP_CLAUDE replaces the claude command (tests).
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker, readBootcamp, todayFor, STATE_DIR } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const AGENT_DIR = path.resolve(HERE, "..", "..", "agents-practice", "parcelly-support");
export const TOOLS = {
  v1: ["lookup_order", "list_orders", "change_address", "issue_refund", "handoff", "search_help"],
  v2: ["lookup_order", "list_orders", "change_address", "issue_refund", "handoff", "search_help", "find_lockers"],
};
const WIN = process.platform === "win32";
export const INSTALL_LINE = WIN
  ? 'py -3.12 -m pip install "mcp==2.3.0"'
  : 'python3 -m pip install "mcp==2.3.0"';

export const AGENT_DATE = "2026-12-08";
export const AGENT_DATE_TEXT = "Tuesday 8 December 2026";
export const agentHome = (ws) => path.join(ws, STATE_DIR, "agent");
export const dbFile = (ws) => path.join(agentHome(ws), "parcelly.db");
export const runsDir = (ws) => path.join(agentHome(ws), "runs");

/** The Python to use: the week 2 venv if there is one, else the system Python 3.12. Returns [command, ...args]. */
export function pythonFor(ws) {
  const venv = path.join(ws, "evals", ".venv", WIN ? "Scripts" : "bin", WIN ? "python.exe" : "python");
  if (fs.existsSync(venv)) return [venv];
  if (process.env.QA_BOOTCAMP_PYTHON) return [process.env.QA_BOOTCAMP_PYTHON];
  return WIN ? ["py", "-3.12"] : ["python3"];
}

function py(ws, args, opts = {}) {
  const [cmd, ...pre] = pythonFor(ws);
  return spawnSync(cmd, [...pre, ...args], { encoding: "utf8", timeout: opts.timeout || 60000, cwd: AGENT_DIR, windowsHide: true,
    env: { ...process.env, PYTHONIOENCODING: "utf-8", PYTHONDONTWRITEBYTECODE: "1" } });
}

export function checkPython(ws, agentDir = AGENT_DIR) {
  // The week 1 release (R0) ships without the practice agent: it arrives with the week 2 coach update.
  if (!fs.existsSync(path.join(agentDir, "server.py"))) return "AGENT_SETUP_ERROR the practice support agent starts in week 2. It arrives with the coach update on Sunday 6 December.";
  const r = py(ws, ["-c", "import mcp.server.mcpserver, sqlite3; print('ok')"]);
  if (r.error) return `AGENT_SETUP_ERROR Python 3.12 was not found. Install it from https://www.python.org/downloads/, then: ${INSTALL_LINE}`;
  if (r.status !== 0) return `AGENT_SETUP_ERROR the MCP Python SDK 2.x is not installed. Type: ${INSTALL_LINE}`;
  return "AGENT_READY";
}

export function ensureData(ws, reset = false) {
  fs.mkdirSync(agentHome(ws), { recursive: true });
  const r = py(ws, ["data.py", "--db", dbFile(ws), reset ? "--reset" : "--ensure"]);
  return r.status === 0 ? `DATA_READY` : `AGENT_SETUP_ERROR the practice data could not be made: ${(r.stderr || "").trim().split("\n").pop()}`;
}

function newRunId(now = new Date(), day = null) {
  const p = (n) => String(n).padStart(2, "0");
  // The date part is the bootcamp day (TODAY), so traces match the lesson's date; the clock part keeps the order.
  const ymd = day ? day.replace(/-/g, "") : `${now.getFullYear()}${p(now.getMonth() + 1)}${p(now.getDate())}`;
  return `r-${ymd}-${p(now.getHours())}${p(now.getMinutes())}${p(now.getSeconds())}-${Math.random().toString(36).slice(2, 6)}`;
}

function claudeCommand() {
  const c = process.env.QA_BOOTCAMP_CLAUDE;
  if (!c) return ["claude"];
  return /\.(m?js)$/i.test(c) ? [process.execPath, c] : [c];
}

/** Read Claude's stream-JSON events into a summary. */
export function summarise(lines) {
  const ev = [];
  for (const l of lines) { try { ev.push(JSON.parse(l)); } catch { /* not JSON */ } }
  const init = ev.find((e) => e.type === "system" && e.subtype === "init") || {};
  const server = (init.mcp_servers || []).find((s) => s.name === "parcelly");
  const calls = [];
  let reply = "";
  for (const e of ev) {
    if (e.type === "assistant") for (const b of e.message?.content || []) {
      if (b.type === "tool_use") calls.push({ id: b.id, name: String(b.name).replace(/^mcp__parcelly__/, ""), input: b.input });
      if (b.type === "text") reply += (reply ? "\n" : "") + b.text;
    }
    if (e.type === "user") for (const b of e.message?.content || []) {
      if (b.type === "tool_result") {
        const c = calls.find((x) => x.id === b.tool_use_id);
        if (c) c.result = Array.isArray(b.content) ? b.content.map((x) => x.text || "").join("") : b.content;
      }
    }
  }
  const result = ev.find((e) => e.type === "result") || {};
  const intent = (reply.match(/^\s*INTENT:\s*([^\n]+)/i) || [])[1]?.trim() || null;
  return {
    connected: server ? server.status === "connected" : false,
    serverStatus: server ? server.status : "missing",
    sessionId: result.session_id || init.session_id || null,
    // The agent may write its INTENT line more than once (before a tool call and again in the final reply).
    reply: reply.replace(/^[ \t]*INTENT:[^\n]*\n?/gim, "").trim(),
    intent, tools: calls.map(({ name, input, result: r }) => ({ name, input, result: r })),
    turns: result.num_turns ?? null, durationMs: result.duration_ms ?? null,
    usage: result.usage ? { input: result.usage.input_tokens, output: result.usage.output_tokens,
      cacheWrite: result.usage.cache_creation_input_tokens, cacheRead: result.usage.cache_read_input_tokens } : null,
    error: result.is_error ? (result.result || "error") : null,
  };
}

// The model for the practice agent (CLAUDE.md rule 7: the cheapest model that works). See the reference-set evidence
// in the build notes kept with the programme. QA_BOOTCAMP_AGENT_MODEL or --model overrides it.
export const AGENT_MODEL = "haiku";

export function ask(ws, { message, version, variant, customer, cont, model, now = new Date() }) {
  const bc = readBootcamp(ws);
  version = (version || "v2").toLowerCase();
  if (!TOOLS[version]) return { line: `AGENT_SETUP_ERROR unknown version "${version}" (use v1 or v2)` };
  variant = (variant || bc.w2?.variant || "clean").toUpperCase();
  customer = (customer || "C-017").toUpperCase();
  let parent = null;
  if (cont) {
    try { parent = JSON.parse(fs.readFileSync(path.join(runsDir(ws), cont, "run.json"), "utf8")); } catch { return { line: `AGENT_SETUP_ERROR no run ${cont} to continue` }; }
    ({ version, customer } = parent);
    variant = parent.variant;
  }
  const ready = checkPython(ws);
  if (ready !== "AGENT_READY") return { line: ready };
  const data = ensureData(ws);
  if (data !== "DATA_READY") return { line: data };
  const runId = newRunId(now, todayFor(readBootcamp(ws), now));
  const dir = path.join(runsDir(ws), runId);
  fs.mkdirSync(dir, { recursive: true });
  const [pcmd, ...pargs] = pythonFor(ws);
  const mcpConfig = { mcpServers: { parcelly: { command: pcmd, args: [...pargs, path.join(AGENT_DIR, "server.py")], env: {
    PARCELLY_DB: dbFile(ws), PARCELLY_VERSION: version, PARCELLY_VARIANT: variant, PARCELLY_CUSTOMER: customer,
    PARCELLY_TRACE: path.join(dir, "tools.jsonl"), PARCELLY_TODAY: AGENT_DATE, PYTHONIOENCODING: "utf-8", PYTHONDONTWRITEBYTECODE: "1" } } } };
  fs.writeFileSync(path.join(dir, "mcp.json"), JSON.stringify(mcpConfig, null, 2));
  const base = path.join(AGENT_DIR, "prompts", version === "v2" && variant === "C" ? "v2-c.md" : `${version}.md`);
  // The agent works on a fixed date (the practice data is built around it), so it never reads the laptop's clock.
  const prompt = path.join(dir, "system-prompt.md");
  fs.writeFileSync(prompt, `${fs.readFileSync(base, "utf8").trimEnd()}

Today's date is ${AGENT_DATE_TEXT}.
`);
  const args = ["-p", message, ...(parent?.sessionId ? ["--resume", parent.sessionId] : []), "--strict-mcp-config", "--mcp-config", path.join(dir, "mcp.json"),
    "--tools", "", "--allowedTools", ...TOOLS[version].map((t) => `mcp__parcelly__${t}`), "--system-prompt-file", prompt,
    "--output-format", "stream-json", "--verbose"];
  const useModel = model || process.env.QA_BOOTCAMP_AGENT_MODEL || AGENT_MODEL;
  if (useModel && useModel !== "default") args.push("--model", useModel);
  const [ccmd, ...cpre] = claudeCommand();
  const started = Date.now();
  const r = spawnSync(ccmd, [...cpre, ...args], { encoding: "utf8", timeout: 240000, cwd: agentHome(ws), windowsHide: true, maxBuffer: 64 * 1024 * 1024, input: "" });
  const lines = String(r.stdout || "").split(/\r?\n/).filter(Boolean);
  fs.writeFileSync(path.join(dir, "stream.jsonl"), lines.join("\n") + "\n");
  const s = summarise(lines);
  const run = { runId, parent: cont || null, started: new Date(started).toISOString(), wallMs: Date.now() - started, version, variant, customer, message, model: useModel || "default", ...s };
  if (!s.connected) {
    run.status = "environment-error";
    fs.writeFileSync(path.join(dir, "run.json"), JSON.stringify(run, null, 2));
    return { line: `AGENT_ENV_ERROR the agent's tool server did not connect (status: ${s.serverStatus}). This run is not an answer of the agent. Run: node agent.mjs check`, runId };
  }
  run.status = s.error ? "error" : "ok";
  fs.writeFileSync(path.join(dir, "run.json"), JSON.stringify(run, null, 2));
  return { line: `AGENT_RUN ${runId}`, reply: s.reply, intent: s.intent, runId };
}

function parseArgs(argv) {
  const o = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) o[a.slice(2)] = argv[++i];
    else o._.push(a);
  }
  return o;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  const a = parseArgs(process.argv.slice(2));
  const cmd = a._[0];
  if (!ws) console.log("AGENT_SETUP_ERROR not a bootcamp folder (no bootcamp.json here or above)");
  else if (cmd === "check") console.log(checkPython(ws));
  else if (cmd === "reset") console.log(checkPython(ws) === "AGENT_READY" ? ensureData(ws, true) : checkPython(ws));
  else if (cmd === "ask") {
    const message = a._.slice(1).join(" ");
    if (!message) console.log('AGENT_SETUP_ERROR give the customer\'s message in quotes, for example: node agent.mjs ask "Where is my order PCL-10011?"');
    else {
      const r = ask(ws, { message, version: a.version, variant: a.variant, customer: a.customer, cont: a.continue, model: a.model });
      console.log(r.line);
      if (r.reply !== undefined) console.log(`INTENT: ${r.intent || "(none)"}\n${r.reply}`);
      if (!r.line.startsWith("AGENT_RUN")) process.exitCode = 1;
    }
  } else console.log("AGENT_SETUP_ERROR use: ask, reset or check");
}
