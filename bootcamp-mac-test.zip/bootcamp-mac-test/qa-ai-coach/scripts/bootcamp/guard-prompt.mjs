#!/usr/bin/env node
// QA AI bootcamps: UserPromptSubmit hook. Acts only in a bootcamp workspace (bootcamp.json) or a folder linked to one;
// everywhere else it prints nothing.
// 1. Secret guard: a message that holds a value from the tester's .env files (secret values of 8+ characters) or
//    looks like a password, token or key is stopped before it reaches Claude. The tester sees why and what to do.
// 2. Customer-data hint: a message with many email addresses or phone numbers reaches Claude with a note to check
//    it is test data.
// 3. COACH sessions: a session where the tester typed /bootcamp is remembered (.bootcamp/coach-sessions.json).
// 4. WORK window: other prompts get the bootcamp's work rules and today's "Work window rules (for Claude only)".
// On any internal problem it prints nothing and exits 0 (the starter's deny rules and check-secrets still apply).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findBootcamp, findMarker, secretValues, findSecret, readJson, writeJson, readState, readBootcamp, todayFor, fmtDay, DAYS, STATE_DIR } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const MISSIONS = path.join(HERE, "..", "..", "skills", "bootcamp", "missions");
export const BOOTCAMP_RE = /^\s*\/(?:qa-ai-coach:)?bootcamp(?:\s|$)/i;

export const COACH_WINDOW_ONLY = "Please use your COACH window (the bootcamp folder) for /bootcamp. This window is for your tests.";

export function blockReason(kind) {
  if (kind === "a word that looks like a password") {
    return [
      "Stopped: this message has a word that looks like a password (capitals, small letters, a digit and a symbol). It was not sent to Claude.",
      "If it is a real password, never send it: put it in your .env file yourself, and use its name (for example TEST_PASSWORD). If it was real, change it today: it is still in this laptop's message history.",
      "If it is only an example or test data, write it another way, for example \"8 characters with a capital, a digit and a symbol\", and send the message again.",
    ].join("\n");
  }
  return [
    `Stopped: this message holds ${kind}. It was not sent to Claude.`,
    "Claude never needs a password, token or key. Put the value in your .env file yourself, and use its name in your message (for example TEST_PASSWORD).",
    "If this was a real password or key, change it today: it is still in this laptop's message history.",
  ].join("\n");
}

export function markCoachSession(ws, sessionId) {
  if (!sessionId) return;
  const file = path.join(ws, STATE_DIR, "coach-sessions.json");
  const list = readJson(file, []);
  if (!list.includes(sessionId)) writeJson(file, [...list, sessionId].slice(-200));
}
export const isCoachSession = (ws, sessionId) => !!sessionId && readJson(path.join(ws, STATE_DIR, "coach-sessions.json"), []).includes(sessionId);

/** Many distinct emails (5+) or phone numbers (5+) in one message. */
export function looksLikeCustomerData(text) {
  const emails = new Set(String(text).match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g) || []);
  const phones = new Set(String(text).match(/(?:\+?\d[\d\s-]{8,}\d)/g) || []);
  return emails.size >= 5 || phones.size >= 5;
}

export function workRulesOf(md) {
  const text = String(md || "").replace(/\r\n/g, "\n");
  const m = text.match(/\n## Work window rules \(for Claude only\)\n([\s\S]*?)(?=\n## |\s*$)/);
  return m ? m[1].trim() : "";
}

export const GENERAL_RULES = [
  "[QA AI bootcamp: rules for this WORK window. The tester is in the Techjays QA AI bootcamp. Claude writes all the code; the tester decides and checks.]",
  "- Write, run and fix the code the tester asks for. Explain in plain, simple English (the tester reads English as a second language): short sentences, no idioms.",
  "- The tester owns the decisions: which tests to keep, expected results, verdicts, severities, go or no-go. When asked to decide, give the facts, then hand the decision back in one line with one question.",
  "- Never print the value of an environment variable (console.log(process.env...), echo $X, Get-ChildItem Env:). Never open playwright/.auth. Never read, search, print or write any .env file, and never type a password, token or key anywhere (code, commands, the browser). Code reads values with process.env.NAME. When the browser reaches a login page that the saved session does not cover, stop and ask the tester to log in by hand.",
  "- Smoke tests only read by default: they must not create, change, delete, send or pay. A test that writes needs the tester to confirm it is on their write list. Before running tests, list what they will create, change, send or pay for (or say: nothing).",
  "- Test only the test environment the tester named. If an address looks like production, stop and ask.",
  "- The healer (or any fix for a failing test) may change locators and waits only. Never change an expected value to make a test pass: report the difference as a possible bug, with what the page shows. When the broken part is text the user reads (a button or link name used as a locator), say so and let the tester decide against the page or the requirement.",
  "- Never commit, push, or change an existing CI pipeline unless the tester asks for it in this message. Never change project files outside the smoke test folder.",
  "- Do not read, search or open the QA AI Coach plugin's own files.",
  "- Do not review or grade your own tests, and do not list their weaknesses, risks or 'things to look at': finding those is the tester's job. Hand back only the files, the run result, and one line per test on what it checks. This also applies to the planner, generator and healer: put this line in their prompts.",
].join("\n");

export function workContext({ ws, now = new Date(), missions = MISSIONS }) {
  const bc = readBootcamp(ws);
  const state = readState(ws);
  const today = todayFor(bc, now);
  const day = /^W[1-3]D[1-5]$/.test(state.day || "") ? state.day : Object.keys(DAYS).find((d) => DAYS[d] === today);
  let rules = "";
  if (day) {
    try {
      rules = workRulesOf(fs.readFileSync(path.join(missions, day.slice(0, 2), `${day.slice(2)}.md`), "utf8"));
    } catch { /* no mission file yet */ }
  }
  const step = typeof state.step === "string" && state.day === day ? state.step.slice(0, 60) : "not known";
  // The bootcamp date, so files Claude writes (reports, plans) carry it, never the laptop clock.
  const dateLine = `Today (the bootcamp date): ${fmtDay(today)} (${today}). Use this date in anything you write; never the computer's date.`;
  return [GENERAL_RULES, dateLine, day ? `Today: ${day}, current step: ${step}.` : "", rules].filter(Boolean).join("\n\n");
}

/** Decide what to do with a prompt. Returns { block?, reason?, context? } (all empty = do nothing). */
export function decide({ cwd, prompt, sessionId, now = new Date(), missions = MISSIONS }) {
  const found = findBootcamp(cwd);
  if (!found) return {};
  const ws = found.workspace;
  const p = String(prompt || "");
  const secret = findSecret(p, secretValues(ws));
  if (secret) return { block: true, reason: blockReason(secret.kind) };
  if (BOOTCAMP_RE.test(p)) {
    // Only a window opened on the bootcamp folder itself is a COACH window. /bootcamp typed in smoke-tests/ or a linked
    // folder (a WORK window) would otherwise unlock the coach's files for that session.
    const here = path.resolve(cwd || process.cwd());
    const marker = findMarker(here);
    if (!marker || path.resolve(marker).toLowerCase() !== here.toLowerCase()) {
      return { block: true, reason: COACH_WINDOW_ONLY };
    }
    markCoachSession(ws, sessionId);
    return {};
  }
  const notes = [];
  if (looksLikeCustomerData(p)) notes.push("This message holds many email addresses or phone numbers. Before you use them, ask the tester in one line to confirm they are test data, never real customer data.");
  if (/^\s*\//.test(p) || isCoachSession(ws, sessionId)) return notes.length ? { context: notes.join("\n") } : {};
  return { context: [workContext({ ws, now, missions }), ...notes].join("\n\n") };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const input = JSON.parse(fs.readFileSync(0, "utf8") || "{}");
    const r = decide({ cwd: input.cwd || process.cwd(), prompt: input.prompt, sessionId: input.session_id });
    if (r.block) {
      process.stdout.write(JSON.stringify({ decision: "block", reason: r.reason, hookSpecificOutput: { hookEventName: "UserPromptSubmit", suppressOriginalPrompt: true } }));
    } else if (r.context) {
      process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: "UserPromptSubmit", additionalContext: r.context } }));
    }
  } catch {
    // never fail a prompt because of the guard itself
  }
  process.exit(0);
}
