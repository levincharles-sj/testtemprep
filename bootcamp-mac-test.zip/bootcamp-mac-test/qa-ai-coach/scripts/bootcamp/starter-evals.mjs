#!/usr/bin/env node
// QA AI bootcamps, week 2: put the eval project in place. The coach runs it from the bootcamp workspace:
//   node starter-evals.mjs          → <workspace>/evals
// Never overwrites a file the tester changed: the fresh copy goes beside it as <name>.new.
// Writes evals/coach.json (where the coach's agent runner is), so ask_golden.py can find it on Windows and Mac.
// Never installs anything: the tester makes the Python environment in the TESTS terminal (the NEXT lines say how).
// Output: STARTER_OK <folder>, COPIED <rel>, KEPT <rel>, NEXT <line> (one per command) · or STARTER_ERROR <reason>
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findBootcamp, readBootcamp, DAYS } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const PLUGIN_ROOT = path.resolve(HERE, "..", "..");
export const TEMPLATE = path.join(PLUGIN_ROOT, "skills", "bootcamp", "starter", "evals");
// --ai-project: the offline tools for a tester's own project AI go to <workspace>/evals/ai-project/ (run there with python -m ai_project).
export const AI_TEMPLATE = path.join(PLUGIN_ROOT, "skills", "bootcamp", "starter", "ai-project");
// The release note of v2 is tester-visible by design (what changed): copied to evals/docs/release-note-v2.md.
export const RELEASE_NOTE = path.join(PLUGIN_ROOT, "agents-practice", "parcelly-support", "release-note-v2.md");
const SKIP = /(^|[\\/])(__pycache__|\.venv|\.deepeval|\.pytest_cache|results)([\\/]|$)|\.pyc$/;

function listFiles(dir, base = dir) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    const rel = path.relative(base, full);
    if (SKIP.test(rel)) continue;
    if (e.isDirectory()) out.push(...listFiles(full, base));
    else if (e.isFile()) out.push(rel);
  }
  return out.sort();
}

// The tests do not import deepeval, so a half-installed environment (Windows long paths) would pass them: this line
// imports what the week needs and prints "ready".
export const IMPORT_CHECK = (py) => `${py} -c "import deepeval.utils, mcp, sklearn; print('ready')"`;

export function nextLines(os, dest) {
  return os === "mac"
    ? [`cd "${dest}"`, "python3.12 -m venv .venv", ".venv/bin/python -m pip install -r requirements.txt", IMPORT_CHECK(".venv/bin/python"), ".venv/bin/python -m pytest tests -q"]
    : [`cd "${dest}"`, "py -3.12 -m venv .venv", ".\\.venv\\Scripts\\python.exe -m pip install -r requirements.txt", IMPORT_CHECK(".\\.venv\\Scripts\\python.exe"), ".\\.venv\\Scripts\\python.exe -m pytest tests -q"];
}

/** Copy every file of `template` into `dest`; never overwrite a changed file (fresh copy as .new). Returns output lines. */
function copyTree(template, dest, prefix = "") {
  const lines = [];
  for (const rel of listFiles(template)) {
    const src = path.join(template, rel);
    const out = path.join(dest, rel);
    const shown = prefix + rel.split(path.sep).join("/");
    if (fs.existsSync(out)) {
      if (fs.readFileSync(out).equals(fs.readFileSync(src))) continue;
      fs.copyFileSync(src, `${out}.new`);
      lines.push(`KEPT ${shown} (fresh copy as ${shown}.new)`);
      continue;
    }
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.copyFileSync(src, out);
    lines.push(`COPIED ${shown}`);
  }
  return lines;
}

export function placeEvals({ cwd = process.cwd(), template = TEMPLATE, pluginRoot = PLUGIN_ROOT, aiProject = false, aiTemplate = AI_TEMPLATE } = {}) {
  const found = findBootcamp(cwd);
  if (!found) return { ok: false, lines: ["STARTER_ERROR this is not your bootcamp folder. Start Claude in your bootcamp folder and try again."] };
  const ws = found.workspace;
  if (!fs.existsSync(template)) return { ok: false, lines: ["STARTER_ERROR the eval starter is missing from the coach; update the coach."] };
  const dest = path.join(ws, "evals");
  if (fs.existsSync(dest) && !fs.statSync(dest).isDirectory()) return { ok: false, lines: [`STARTER_ERROR ${dest} is a file, not a folder.`] };
  fs.mkdirSync(path.join(dest, "results"), { recursive: true });
  const lines = [`STARTER_OK ${dest}`];
  lines.push(...copyTree(template, dest));
  if (aiProject) {
    if (!fs.existsSync(aiTemplate)) return { ok: false, lines: ["STARTER_ERROR the AI-project tools are missing from the coach; update the coach."] };
    lines.push(...copyTree(aiTemplate, path.join(dest, "ai-project"), "ai-project/"));
    lines.push(`AI_PROJECT ${path.join(dest, "ai-project")}`);
  }
  if (fs.existsSync(RELEASE_NOTE)) {
    const note = path.join(dest, "docs", "release-note-v2.md");
    if (!fs.existsSync(note)) {
      fs.mkdirSync(path.dirname(note), { recursive: true });
      fs.copyFileSync(RELEASE_NOTE, note);
      lines.push("COPIED docs/release-note-v2.md");
    }
  }
  // The bootcamp calendar: files are dated with the bootcamp day, never the laptop clock.
  fs.writeFileSync(path.join(dest, "coach.json"), JSON.stringify({ plugin: pluginRoot, workspace: ws, days: DAYS,
    today: "the WORK window gets today's bootcamp date with every message; scripts use plan.mjs (its TODAY line)" }, null, 2) + "\n");
  for (const l of nextLines(readBootcamp(ws).os, dest)) lines.push(`NEXT ${l}`);
  return { ok: true, lines, folder: dest };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const r = placeEvals({ aiProject: process.argv.includes("--ai-project") });
    console.log(r.lines.join("\n"));
    if (!r.ok) process.exitCode = 1;
  } catch (e) {
    console.log(`STARTER_ERROR ${e.message}`);
    process.exitCode = 1;
  }
}
