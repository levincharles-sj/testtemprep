#!/usr/bin/env node
// QA AI bootcamps: writes my-bootcamp-plan.html in the bootcamp workspace from intake.json, the finished days and the
// decision log. Stays on the laptop. Run from the workspace: node plan-page.mjs [--open]
// Output: PLAN_PAGE <path> <opened|ready> · or PLAN_PAGE_ERROR <reason>
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { findMarker, readBootcamp, readIntake, WEEKS, DAYS, ALL_DAYS, weekOfDay, todayFor, fmtDay, addDays } from "./lib.mjs";
import { readDays } from "./plan.mjs";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const TRACK = {
  real: ["Your project's app", "real"], "conduit-for-now": ["Conduit for now, your app when access arrives", "pending"], conduit: ["Conduit practice app", "practice"],
  "ai-project": ["Your project's AI", "real"], practice: ["Practice support agent", "practice"],
};
const STATE = { ready: ["Ready", "ok"], asked: ["Asked", "wait"], open: ["Not asked yet", "todo"], blocked: ["Blocked", "bad"], "not-needed": ["Not needed", "muted"] };
const THEMES = { W1: "AI-driven test automation on your app", W2: "Evals for AI agents: the go-live sign-off", W3: "Responsible AI and security testing" };
const DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri"];

export function decisionPoints() {
  return [
    [DAYS.W1D1, "End of Monday: environment, account, project context and AI-tools permission. Any missing: Conduit now."],
    [DAYS.W1D2, "End of Tuesday: anything still blocking moves to Conduit. No new waiting after this."],
    [DAYS.W1D4, "Thursday: CI answers from DevOps, for Friday's CI step."],
    [DAYS.W2D1, "End of Monday 7 Dec: AI project data and the TL's agreement, or the practice agent."],
    [DAYS.W3D1, "Monday 14 Dec: the TL's written agreement for attacks on your AI, or the practice agent."],
  ];
}

export function validate(intake) {
  if (!intake) return "intake.json is missing";
  if (!intake.project || typeof intake.project !== "object") return "intake.json has no project section";
  if (!intake.tracks || !intake.tracks.W1) return "intake.json has no tracks.W1";
  for (const w of ["W1", "W2", "W3"]) if (intake.tracks[w] && !TRACK[intake.tracks[w].track]) return `tracks.${w}.track "${intake.tracks[w].track}" is not a known track`;
  if (intake.readiness && !Array.isArray(intake.readiness)) return "readiness must be a list";
  return null;
}

export function render({ bc, intake, days, today, decisionsCount = 0, journalCount = 0 }) {
  const p = intake.project || {};
  const weeks = Object.entries(WEEKS).map(([w, info]) => {
    const t = intake.tracks?.[w] || { track: w === "W1" ? "conduit" : "practice", reason: "" };
    const [label, cls] = TRACK[t.track] || ["Not decided", "pending"];
    const dots = ALL_DAYS.filter((d) => weekOfDay(d) === w).map((d, i) => {
      const s = days[d] ? (days[d].mustHave === "met" ? "done" : "part") : DAYS[d] <= today ? "open" : "future";
      return `<li class="dot ${s}" title="${d} ${esc(fmtDay(DAYS[d]))}: ${s}"><span>${DAY_NAMES[i]}</span></li>`;
    }).join("");
    const satDays = Math.round((Date.parse(info.saturday) - Date.parse(today)) / 86400000);
    return `<article class="week ${today >= info.start && today <= info.saturday ? "now" : ""}">
      <p class="wk">WEEK ${w.slice(1)} · ${esc(fmtDay(info.start))}</p><h3>${esc(THEMES[w])}</h3>
      <p class="track ${cls}">${esc(label)}</p><p class="why">${esc(t.reason || "")}</p>
      <ul class="dots">${dots}<li class="dot sat"><span>Sat</span></li></ul>
      <p class="sat">Present on <b>${esc(fmtDay(info.saturday))}</b>${satDays >= 0 && satDays <= 6 ? ` · ${satDays === 0 ? "today" : `in ${satDays} day${satDays === 1 ? "" : "s"}`}` : ""}</p></article>`;
  }).join("");
  const req = new Map((intake.requests || []).map((r) => [r.n, r]));
  const rows = (intake.readiness || []).slice().sort((a, b) => String(a.week).localeCompare(String(b.week)) || String(a.neededBy).localeCompare(String(b.neededBy)))
    .map((r) => {
      const [st, cls] = STATE[r.state] || [r.state, "todo"];
      const asked = r.request && req.get(r.request)?.sentOn ? fmtDay(req.get(r.request).sentOn.slice(0, 10)) : "";
      const late = r.neededBy && r.neededBy < today && !["ready", "not-needed"].includes(r.state);
      return `<tr class="${late ? "late" : ""}"><td>${esc(r.week || "W1")}</td><td>${esc(r.item || r.id)}</td><td>${esc(r.owner || "")}</td><td>${esc(asked)}</td><td>${esc(r.neededBy ? fmtDay(r.neededBy) : "")}</td><td><span class="badge ${cls}">${esc(st)}</span></td></tr>`;
    }).join("");
  const counts = (intake.readiness || []).reduce((a, r) => ((a[r.state] = (a[r.state] || 0) + 1), a), {});
  const total = (intake.readiness || []).length || 1;
  const bar = ["ready", "asked", "open", "blocked"].map((s) => `<span class="seg ${STATE[s][1]}" style="width:${((counts[s] || 0) / total) * 100}%"></span>`).join("");
  const points = decisionPoints().map(([d, t]) => `<li class="${d < today ? "past" : d === today ? "today" : ""}"><b>${esc(fmtDay(d))}</b> ${esc(t)}</li>`).join("");
  const data = ["W1", "W2", "W3"].map((w) => `<li><b>Week ${w.slice(1)}:</b> ${esc(intake.testData?.[w] || "To decide with the coach")}</li>`).join("");
  const sent = (intake.requests || []).filter((r) => r.sentOn).length;
  const first = [
    ["Set-up check", null], ["Intake and this plan", intake.status === "done"], [`Requests sent (${sent} of ${(intake.requests || []).length})`, (intake.requests || []).length > 0 && sent === (intake.requests || []).length],
    ["Project summary and app profile", null], ["First test running", null],
  ].map(([t, ok]) => `<li class="${ok ? "ok" : ""}">${esc(t)}</li>`).join("");
  return `<!doctype html>
<html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>My bootcamp plan</title>
<style>
:root{--bg:#F6F7FB;--card:#FFFFFF;--ink:#141414;--muted:#5B6372;--line:#E4E6EE;--brand:#6870F8;--ok:#1FA98A;--wait:#E3A03C;--bad:#D64545;--todo:#8A90A2}
@media (prefers-color-scheme:dark){:root{--bg:#0E1124;--card:#171B33;--ink:#EEF0FA;--muted:#A9AEC6;--line:#2A2F4D}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.45 system-ui,"Segoe UI",sans-serif}
main{max-width:1040px;margin:auto;padding:24px 16px 48px}h1{font-size:28px;margin:0}h2{font-size:19px;margin:28px 0 10px}
.top{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;flex-wrap:wrap}.sub{color:var(--muted);margin:4px 0 0}
.weeks{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}
.week{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;border-top:4px solid var(--brand)}.week.now{box-shadow:0 0 0 2px var(--brand)}
.wk{font-size:12px;letter-spacing:1.5px;color:var(--muted);margin:0}.week h3{margin:6px 0 10px;font-size:18px}
.track{display:inline-block;font-weight:600;font-size:14px;padding:3px 10px;border-radius:999px;margin:0}.track.real{background:rgba(31,169,138,.15);color:var(--ok)}
.track.pending{background:rgba(227,160,60,.18);color:var(--wait)}.track.practice{background:rgba(104,112,248,.15);color:var(--brand)}
.why{color:var(--muted);font-size:14px;min-height:20px;margin:8px 0}.dots{list-style:none;display:flex;gap:6px;padding:0;margin:8px 0}
.dot{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;border:2px solid var(--line);color:var(--muted)}
.dot.done{background:var(--ok);border-color:var(--ok);color:#fff}.dot.part{background:var(--wait);border-color:var(--wait);color:#fff}.dot.open{border-color:var(--brand);color:var(--brand)}.dot.sat{border-style:dashed}
.sat{margin:6px 0 0;font-size:14px}.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 16px}
.bar{display:flex;height:12px;border-radius:6px;overflow:hidden;background:var(--line);margin:4px 0 10px}.seg.ok{background:var(--ok)}.seg.wait{background:var(--wait)}.seg.todo{background:var(--todo)}.seg.bad{background:var(--bad)}
.table{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:8px;border-bottom:1px solid var(--line);vertical-align:top}th{color:var(--muted);font-weight:600}
tr.late td{background:rgba(214,69,69,.08)}.badge{font-size:12px;font-weight:600;padding:2px 8px;border-radius:999px;white-space:nowrap}.badge.ok{background:rgba(31,169,138,.15);color:var(--ok)}
.badge.wait{background:rgba(227,160,60,.18);color:var(--wait)}.badge.todo{background:rgba(138,144,162,.18);color:var(--todo)}.badge.bad{background:rgba(214,69,69,.15);color:var(--bad)}.badge.muted{color:var(--muted)}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}ul.plain{margin:0;padding-left:18px}ul.plain li{margin:6px 0}
ol.points{margin:0;padding-left:18px}ol.points li{margin:6px 0}ol.points li.past{color:var(--muted)}ol.points li.today{font-weight:600}
ul.check{list-style:none;padding:0;margin:0}ul.check li{padding:6px 0 6px 28px;position:relative}ul.check li::before{content:"";position:absolute;left:0;top:8px;width:16px;height:16px;border-radius:4px;border:2px solid var(--line)}
ul.check li.ok::before{background:var(--ok);border-color:var(--ok)}.legend{color:var(--muted);font-size:13px}
</style></head><body><main>
<div class="top"><div><h1>My bootcamp plan${bc.firstName ? `, ${esc(bc.firstName)}` : ""}</h1>
<p class="sub">${esc(p.codeName ? `Project ${p.codeName}` : "")}${p.about ? ` · ${esc(p.about)}` : ""}</p></div>
<p class="sub">Updated ${esc(fmtDay(today))} · ${decisionsCount} decisions · ${journalCount} journal entries</p></div>
<h2>Three weeks</h2><section class="weeks">${weeks}</section>
<p class="legend">Green: done, must-have met · amber: done, must-have not met · blue ring: open · grey: later.</p>
<h2>What I need, week by week</h2><div class="card"><div class="bar">${bar}</div><div class="table"><table>
<thead><tr><th>Week</th><th>What</th><th>From</th><th>Asked</th><th>Needed by</th><th>State</th></tr></thead><tbody>${rows || '<tr><td colspan="6">Nothing yet. The coach adds items in the intake.</td></tr>'}</tbody></table></div></div>
<div class="two"><section><h2>Decision points</h2><div class="card"><ol class="points">${points}</ol></div></section>
<section><h2>Monday, first day</h2><div class="card"><ul class="check">${first}</ul></div></section></div>
<h2>Test data plan</h2><div class="card"><ul class="plain">${data}</ul></div>
</main></body></html>
`;
}

function openInBrowser(file) {
  if (process.env.QA_COACH_NO_OPEN) return false;
  try {
    const [cmd, args] = process.platform === "win32" ? ["explorer.exe", [file]] : process.platform === "darwin" ? ["open", [file]] : ["xdg-open", [file]];
    const child = spawn(cmd, args, { detached: true, stdio: "ignore" });
    child.on("error", () => {});
    child.unref();
    return true;
  } catch {
    return false;
  }
}

const countMatches = (file, re) => { try { return (fs.readFileSync(file, "utf8").match(re) || []).length; } catch { return 0; } };

export function writePage(ws, { open = false, now = new Date() } = {}) {
  const intake = readIntake(ws);
  const problem = validate(intake);
  if (problem) return `PLAN_PAGE_ERROR ${problem}`;
  const bc = readBootcamp(ws);
  const html = render({
    bc, intake, days: readDays(ws), today: todayFor(bc, now),
    decisionsCount: countMatches(path.join(ws, "decisions.md"), /^## /gm), journalCount: countMatches(path.join(ws, "journal.md"), /^## W\dD\d/gm),
  });
  const file = path.join(ws, "my-bootcamp-plan.html");
  fs.writeFileSync(file, html, "utf8");
  const opened = open && !bc.noOpen && openInBrowser(file);
  return `PLAN_PAGE ${file} ${opened ? "opened" : "ready"}`;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  try {
    console.log(ws ? writePage(ws, { open: process.argv.includes("--open") }) : "PLAN_PAGE_ERROR not a bootcamp folder");
  } catch (e) {
    console.log(`PLAN_PAGE_ERROR ${e.message}`);
  }
}
