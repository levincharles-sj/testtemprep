#!/usr/bin/env node
// QA AI bootcamps, week 2: the reference set's recorded runs (13 fixed conversations, each run 5 times on v1 and on
// the tester's own v2 build). Run from the bootcamp workspace.
//
//   node reference.mjs list                                  the cases, and how many runs passed per version
//   node reference.mjs show <case> [--build v1|v2] [--run n]  copy the readable traces into week-2/reference/
//
// The tester's v2 build comes from bootcamp.json w2.variant. Only v1 and that build are ever shown, and always as
// "v1" and "v2": the variant is never named. Output lines:
//   REF_CASE <id> <intent> <first message>
//   REF_RUN <id> <v1|v2> run<n> <one-line summary> <path of the trace copied into week-2/reference/>
//   REF_ERROR <plain reason>
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findMarker, readBootcamp } from "./lib.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const AGENT_DIR = path.resolve(HERE, "..", "..", "agents-practice", "parcelly-support");
export const CASES = path.join(AGENT_DIR, "reference", "reference-cases.csv");
export const RECORDED = path.join(AGENT_DIR, "recorded");

export function parseCsv(text) {
  const rows = []; let row = [], f = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { f += '"'; i++; } else if (c === '"') q = false; else f += c; }
    else if (c === '"') q = true; else if (c === ",") { row.push(f); f = ""; } else if (c === "\n") { row.push(f); rows.push(row); row = []; f = ""; } else if (c !== "\r") f += c;
  }
  if (f || row.length) { row.push(f); rows.push(row); }
  const [h, ...rest] = rows;
  return rest.filter((r) => r.length > 1).map((r) => Object.fromEntries(h.map((k, i) => [k, r[i]])));
}

export const readCases = (file = CASES) => parseCsv(fs.readFileSync(file, "utf8"));

/** The recorded build folder for "v1" or "v2" (the tester's variant). */
export function buildFor(which, variant) {
  if (which === "v1") return "v1";
  if (!/^[A-D]$/.test(String(variant || ""))) return null;
  return `v2-${variant}`;
}

function runsOf(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => /^run\d+\.json$/.test(f)).sort((a, b) => parseInt(a.slice(3)) - parseInt(b.slice(3)));
}

export function list(ws, { recorded = RECORDED, cases = CASES } = {}) {
  const variant = (readBootcamp(ws).w2 || {}).variant;
  const out = [];
  for (const c of readCases(cases)) {
    const first = (JSON.parse(c.turns)[0] || "").replace(/\s+/g, " ");
    const counts = ["v1", "v2"].map((w) => {
      const b = buildFor(w, variant);
      if (!b) return `${w}: (not set)`;
      const runs = runsOf(path.join(recorded, b, c.id)).map((f) => JSON.parse(fs.readFileSync(path.join(recorded, b, c.id, f), "utf8")));
      return `${w}: ${runs.length} runs`;
    });
    out.push(`REF_CASE ${c.id} ${c.expected_intent} ${first.length > 90 ? first.slice(0, 87) + "..." : first} (${counts.join(", ")})`);
  }
  if (!variant) out.push("REF_ERROR your week 2 build is not set yet: the coach sets it on Monday 7 December. Until then only v1 is shown.");
  return out;
}

export function show(ws, caseId, { build, run, recorded = RECORDED, cases = CASES } = {}) {
  const id = String(caseId || "").toUpperCase();
  const c = readCases(cases).find((x) => x.id === id);
  if (!c) return [`REF_ERROR there is no reference case "${caseId}": type node reference.mjs list`];
  const variant = (readBootcamp(ws).w2 || {}).variant;
  const which = build ? [String(build).toLowerCase()] : ["v1", "v2"];
  if (which.some((w) => !["v1", "v2"].includes(w))) return ["REF_ERROR use --build v1 or --build v2 (v2 is your own release candidate)"];
  const target = path.join(ws, "week-2", "reference");
  fs.mkdirSync(target, { recursive: true });
  const out = [];
  for (const w of which) {
    const b = buildFor(w, variant);
    if (!b) { out.push("REF_ERROR your week 2 build is not set yet: the coach sets it on Monday 7 December."); continue; }
    const dir = path.join(recorded, b, id);
    const files = runsOf(dir).filter((f) => !run || f === `run${Number(run)}.json`);
    if (!files.length) { out.push(`REF_ERROR no recorded run ${run ? run + " " : ""}for ${id} on ${w}`); continue; }
    for (const f of files) {
      const r = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"));
      const md = f.replace(/\.json$/, ".md");
      const dest = path.join(target, `${id}-${w}-${md}`);
      fs.writeFileSync(dest, fs.readFileSync(path.join(dir, md), "utf8"));
      out.push(`REF_RUN ${id} ${w} ${md.replace(/\.md$/, "")} ${r.summary || ""} ${dest}`.replace(/\s+/g, " ").trim());
    }
  }
  return out;
}

function parseArgs(argv) {
  const o = { _: [] };
  for (let i = 0; i < argv.length; i++) argv[i].startsWith("--") ? (o[argv[i].slice(2)] = argv[++i]) : o._.push(argv[i]);
  return o;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const ws = findMarker(process.cwd());
  const a = parseArgs(process.argv.slice(2));
  let lines;
  if (!ws) lines = ["REF_ERROR not a bootcamp folder (no bootcamp.json here or above)"];
  else if (a._[0] === "list") lines = list(ws);
  else if (a._[0] === "show") lines = show(ws, a._[1], { build: a.build, run: a.run });
  else lines = ["REF_ERROR use: list, or show <case> [--build v1|v2] [--run n]"];
  console.log(lines.join("\n"));
  if (lines.some((l) => l.startsWith("REF_ERROR"))) process.exitCode = 1;
}
