#!/usr/bin/env node
// QA AI Coach: work out the tester's programme calendar and which mission to run (docs/uplift/groups-design.md).
// Usage:
//   node plan.mjs [--workspace <path>]                   today's plan from me.json startDate + proofs/
//   node plan.mjs --set-start YYYY-MM-DD [--workspace]   check the date (a Monday) and save it in me.json
// Plan output (one item per line):
//   PLAN_OK
//   TODAY <ymd> <Day D Mon>
//   START <ymd> <Day D Mon>
//   PHASE before|running|ended
//   WEEK W<n> <Mon ymd> <Sun ymd> | WEEK none
//   WEEKEND yes|no
//   RUN <id> <Day D Mon> | RUN none
//   MESSAGE <one sentence to show the tester, word for word>
//   MISSION <id> <ymd> <Day D Mon> <state>[ <Sunday ymd>]   states: done | open | missed | future
//   EARLIER <ids…>   the other unfinished missions up to today, oldest first (after RUN)
//   PREVIEW on | PREVIEW <ymd> <Day D Mon>   rehearsal workspace only.
// Or: PLAN_NEED_START_DATE <help>, PLAN_ERROR <message>.
// --set-start prints START_SET <ymd> <Day D Mon> and SETTINGS <added|ok|new-restart> (the coach's allow rules,
// as start.mjs writes them), or START_INVALID <reason>.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { verifyCode } from "./proof-code.mjs";
import {
  findWorkspace, readMe, todayFor, previewDateOf, isPreview, startDateOf, checkStartDate, START_DATE_HELP, fmtDay, missionDate,
  weekOf, weekStart, weekEnd, programmeEnd, ALL_MISSIONS, parseMissionId, handInDue, readDone,
} from "./lib.mjs";

/** "2026-11-08" -> "Sunday 8 Nov" (used where the design spells the day out). */
export function sundayLabel(ymd) {
  return `Sunday ${fmtDay(ymd).slice(4)}`;
}

/** State of one mission for a tester on an India date. */
export function missionState(start, id, today, done) {
  if (done) return { state: "done" };
  const date = missionDate(start, id);
  if (date > today) return { state: "future" };
  if (date === today) return { state: "open" };
  return { state: "missed", until: weekEnd(start, parseMissionId(id).w) };
}

/** Sentence for a catch-up of an earlier mission (start.mjs NOTE line); "" when nothing needs saying. */
export function catchUpNote(start, id, today) {
  // A lesson always counts once it is done (programme manager, 30 Oct 2026): late work is saved as Done late.
  const p = parseMissionId(id);
  const date = missionDate(start, id);
  if (date >= today) return "";
  return `${p.id} was due on ${fmtDay(date)}. Your code is saved as Done late, and the lesson still adds to your project. Well done for catching up.`;
}

/** The full plan as an object. `doneIds` is a Set of finished mission ids. */
export function makePlan({ start, today, doneIds = new Set() }) {
  const end = programmeEnd(start);
  const lastSunday = weekEnd(start, 6);
  const missions = ALL_MISSIONS.map((id) => ({ id, date: missionDate(start, id), ...missionState(start, id, today, doneIds.has(id)) }));
  const phase = today < start ? "before" : today > lastSunday ? "ended" : "running";
  const week = phase === "running" ? weekOf(start, today) : null;
  const dow = new Date(`${today}T12:00:00Z`).getUTCDay();
  const weekend = dow === 0 || dow === 6;
  const unfinished = (m) => m.state !== "done" && m.state !== "future";
  // Carry on where the tester left off: the oldest unfinished lesson up to today, in any week, because each lesson
  // builds on the ones before (programme manager, 30 Oct 2026). EARLIER lists the others, oldest first.
  const behind = week ? missions.filter(unfinished) : [];
  const run = behind[0] || null;
  const nextFuture = missions.find((m) => m.state === "future");
  const earlier = behind.slice(1).map((m) => m.id);
  // A tester still on an earlier week's lesson is told when this week's project is due.
  const due = week && run && parseMissionId(run.id).w < week && week <= 6 ? handInDue(start, week === 6 ? "W6" : `C${week}`) : null;
  const projectLine = due && due >= today
    ? ` Your week ${week} ${week === 6 ? "file" : "project"} is due on ${fmtDay(due)}. If you can't catch up by then, tell the programme manager.`
    : "";

  let message;
  if (phase === "before") {
    message = `Your programme starts on ${fmtDay(start)}. W1D1 opens that day.`;
  } else if (phase === "ended") {
    message = `Your programme ended on ${fmtDay(end)}. You can repeat any lesson for practice, for example /coach W1D1.`;
  } else if (run && parseMissionId(run.id).w < week) {
    message = `Welcome back. You stopped at ${run.id} (${fmtDay(run.date)}), so we carry on from there: each lesson builds on the one before.${projectLine}`;
  } else if (run && weekend) {
    message = `It's the weekend. ${run.id} (${fmtDay(run.date)}) is still open: a good time to catch up.`;
  } else if (run && run.date < today) {
    message = `You still have ${run.id} (${fmtDay(run.date)}) to finish. Let's do that first.`;
  } else if (run) {
    message = `Today's lesson is ${run.id} (${fmtDay(run.date)}).`;
  } else if (nextFuture) {
    message = weekend
      ? `It's the weekend and this week's lessons are finished. Check that each code shows Saved in the portal. Next: ${nextFuture.id} opens on ${fmtDay(nextFuture.date)}.`
      : `Every lesson up to today is finished. Check that each code shows Saved in the portal. Next: ${nextFuture.id} opens on ${fmtDay(nextFuture.date)}.`;
  } else {
    message = `Every lesson up to today is finished. Check that each code shows Saved in the portal. Your programme ends on ${fmtDay(end)}.`;
  }
  return { start, today, phase, week, weekend, run, message, missions, earlier, end };
}

/** The lines the CLI prints for a plan. */
export function planLines(p) {
  const lines = ["PLAN_OK", `TODAY ${p.today} ${fmtDay(p.today)}`, `START ${p.start} ${fmtDay(p.start)}`, `PHASE ${p.phase}`];
  if (p.preview) lines.splice(1, 0, p.preview === true ? "PREVIEW on" : `PREVIEW ${p.preview} ${fmtDay(p.preview)}`);
  lines.push(p.week ? `WEEK W${p.week} ${weekStart(p.start, p.week)} ${weekEnd(p.start, p.week)}` : "WEEK none");
  lines.push(`WEEKEND ${p.weekend ? "yes" : "no"}`);
  lines.push(p.run ? `RUN ${p.run.id} ${fmtDay(p.run.date)}` : "RUN none");
  lines.push(`MESSAGE ${p.message}`);
  for (const m of p.missions) lines.push(`MISSION ${m.id} ${m.date} ${fmtDay(m.date)} ${m.state}${m.until ? ` ${m.until}` : ""}`);
  if (p.earlier.length) lines.push(`EARLIER ${p.earlier.join(" ")}`);
  return lines;
}

/** Finished missions: a proof file that names the lesson (proofs/W1D1.md, W1D1-proof.md, proof-w1d1.md …), or a
 *  completion code recorded in proofs/.done.json. A tester who has a code is never sent back to that lesson
 *  (tester report, 2 Nov 2026: the proof file was missing, so /coach kept returning to W1D1). */
export function doneIdsIn(ws, email) {
  const dir = path.join(ws, "proofs");
  const ids = new Set([...readDone(ws).map((r) => r.id), ...codesInConversations(ws, email)]);
  if (!fs.existsSync(dir)) return ids;
  for (const f of fs.readdirSync(dir)) {
    const m = f.match(/(?:^|[^A-Z0-9])(W[1-6]D[1-5])(?![0-9]).*\.md$/i);
    if (m) ids.add(m[1].toUpperCase());
  }
  return ids;
}

/** Lessons whose completion code appears in the saved conversations (conversations/<date>/*.md) and matches
 *  this tester's email: codes made before proofs/.done.json existed (coach 0.24.2). */
export function codesInConversations(ws, email) {
  const ids = new Set();
  if (!email) return ids;
  const root = path.join(ws, "conversations");
  if (!fs.existsSync(root)) return ids;
  for (const day of fs.readdirSync(root, { withFileTypes: true })) {
    if (!day.isDirectory()) continue;
    for (const f of fs.readdirSync(path.join(root, day.name))) {
      if (!f.endsWith(".md")) continue;
      let text;
      try { text = fs.readFileSync(path.join(root, day.name, f), "utf8"); } catch { continue; }
      for (const m of text.matchAll(/\b(W[1-6]D[1-5]-(?:PASS|PARTIAL)-[A-Z2-7]{4})\b/g)) {
        const r = verifyCode(m[1], email);
        if (r.valid) ids.add(r.missionId);
      }
    }
  }
  return ids;
}

/** Plan for a workspace; returns {needStart:true} when me.json has no valid start date. */
export function planFor(ws, now = new Date()) {
  const me = readMe(ws);
  const start = startDateOf(me);
  if (!start) return { needStart: true };
  const plan = makePlan({ start, today: todayFor(me, now), doneIds: doneIdsIn(ws, me.email) });
  if (isPreview(me)) plan.preview = previewDateOf(me) || true;
  return plan;
}

/** Save a start date in me.json (keeps every other field). Returns {ok, start} or {ok:false, reason}. */
export function setStart(ws, value) {
  const r = checkStartDate(value);
  if (!r.ok) return r;
  const file = path.join(ws, "me.json");
  const me = readMe(ws);
  me.startDate = r.start;
  fs.writeFileSync(file, JSON.stringify(me, null, 2) + "\n");
  return r;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const wsIdx = args.indexOf("--workspace");
  const ws = wsIdx >= 0 ? path.resolve(args[wsIdx + 1]) : findWorkspace(process.cwd());
  try {
    if (!ws) throw new Error("No me.json found. Start Claude Code in your coach folder (C:\\qa-ai-coach) and type /coach with your name, work email and start date.");
    const setIdx = args.indexOf("--set-start");
    if (setIdx >= 0) {
      const r = setStart(ws, args[setIdx + 1]);
      console.log(r.ok ? `START_SET ${r.start} ${fmtDay(r.start)}` : `START_INVALID ${r.reason}`);
      if (!r.ok) process.exitCode = 1;
      else {
        // The coach's allow rules go in now, at the first run (usually before the start date), so the one-time
        // restart happens during set-up and not at the start of the first lesson (launch check, 22 Oct 2026).
        const { ensureSettings } = await import("./settings.mjs");
        console.log(`SETTINGS ${ensureSettings(ws)}`);
      }
    } else {
      const p = planFor(ws);
      if (p.needStart) console.log(`PLAN_NEED_START_DATE ${START_DATE_HELP}`);
      else console.log(planLines(p).join("\n"));
    }
  } catch (e) {
    console.log(`PLAN_ERROR ${e.message}`);
    process.exitCode = 1;
  }
}

