#!/usr/bin/env node
// QA AI Coach: copy a Weekly Challenge's tester files into the workspace.
// Usage: node challenge.mjs C<n> [--workspace <path>]
// Copies skills/coach/challenges/C<n>/ (brief, submission template, any starter pack)
// into <workspace>/work/C<n>/. Never overwrites a tester's file: if one exists, the
// fresh copy is written alongside it as "<name>.new" (or ".new-2", ".new-3"…).
// A challenge with a league/ folder (C4 in v8) gets a pack personalised from me.json's email (rates.mjs, rules, starter).
// A challenge with a variants/ folder (v1/, v2/, …) gets ONE version, chosen from me.json's email
// (variantFor, same rule as scripts/eval/common.py variant_for): the common files plus that version's
// files, copied flat into work/C<n>/, and work/C<n>/VARIANT.txt. Other versions are never copied.
// The due date is Friday of the challenge's week, from me.json startDate (docs/uplift/groups-design.md).
// Output lines: CHALLENGE_OK, COPIED, NEWCOPY, KEPT, PERSONAL, VARIANT, BRIEF, DUE (or DUE_UNKNOWN when no start date); or CHALLENGE_ERROR.
import fs from "node:fs";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { findWorkspace, readMe, startDateOf, challengeDue, fmtDay, START_DATE_HELP } from "./lib.mjs";
import { paramsFor, ratesModule, renderTemplate } from "./rates.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_SOURCE = path.join(HERE, "..", "skills", "coach", "challenges");

// Defence in depth: never copy anything that looks like private or marking material.
const BLOCKED = /(^|[\\/])(private|keys?|mutants?)([\\/]|$)|marking|answer[-_ ]?key|solution/i;

/** Normalise "c1", "C1", "1" to "C1"; null if not C1–C5. */
export function normaliseChallenge(word) {
  const m = String(word || "").trim().match(/^c?([1-5])$/i);
  return m ? `C${m[1]}` : null;
}

/** Friday of the challenge's week (YYYY-MM-DD) for a start date. C<n> belongs to W<n>. */
export function dueDate(id, start) {
  return challengeDue(start, id);
}

/**
 * Version for a tester: (first byte of sha256(lowercase email + "|C<n>")) mod count + 1.
 * Must match scripts/eval/common.py variant_for (the manager scripts use it to pick the marking key).
 */
export function variantFor(email, challenge, count) {
  const key = String(email || "").trim().toLowerCase();
  if (!key) throw new Error("A work email is needed to choose your challenge version.");
  const id = normaliseChallenge(challenge) || String(challenge).trim().toUpperCase();
  if (!(count >= 1)) throw new Error("No challenge versions found.");
  const h = crypto.createHash("sha256").update(`${key}|${id}`, "utf8").digest();
  return (h[0] % count) + 1;
}

/** The version folders under <challenge>/variants/ (v1, v2, …), in number order; [] if none. */
export function listVariants(src) {
  const dir = path.join(src, "variants");
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isDirectory() && /^v\d+$/i.test(e.name))
    .map((e) => e.name)
    .sort((a, b) => Number(a.slice(1)) - Number(b.slice(1)));
}

function listFiles(dir, base = dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    const rel = path.relative(base, full);
    if (dir === base && entry.isDirectory() && entry.name === "variants") continue; // handled per tester
    if (BLOCKED.test(rel)) continue;
    if (/(^|[\\/_-])offline/i.test(rel)) continue; // offline packs only when a site is down (coach copies them)
    if (/\.template\./.test(entry.name)) continue; // rendered per tester, never copied raw
    if (entry.isDirectory()) out.push(...listFiles(full, base));
    else if (entry.isFile()) out.push(rel);
  }
  return out.sort();
}

function freeName(target) {
  let candidate = `${target}.new`;
  for (let i = 2; fs.existsSync(candidate); i++) candidate = `${target}.new-${i}`;
  return candidate;
}

/** Write `content` to `to` without ever overwriting a different tester file. */
function writeOrNew(to, content, dest, lists) {
  const rel = path.relative(dest, to);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  if (!fs.existsSync(to)) {
    fs.writeFileSync(to, content);
    lists.copied.push(rel);
  } else if (fs.readFileSync(to, "utf8") === content) {
    lists.kept.push(rel);
  } else {
    const alt = freeName(to);
    fs.writeFileSync(alt, content);
    lists.newCopies.push(path.relative(dest, alt));
  }
}

/**
 * A league pack is personal: build rates.mjs, pricing-rules.md and the starter test from the
 * tester's work email (me.json), so copied tests fail on someone else's engine.
 */
function personaliseLeague(id, src, dest, workspace, lists) {
  const tplDir = path.join(src, "league");
  if (!fs.existsSync(path.join(tplDir, "pricing-rules.template.md"))) return null;
  const me = readMe(workspace);
  if (!me.email) throw new Error(`Your work email isn't set up yet. Type /coach first, give your work email, then run /coach challenge ${id} again.`);
  const params = paramsFor(me.email);
  const out = path.join(dest, "league");
  writeOrNew(path.join(out, "rates.mjs"), ratesModule(params), dest, lists);
  writeOrNew(path.join(out, "pricing-rules.md"), renderTemplate(fs.readFileSync(path.join(tplDir, "pricing-rules.template.md"), "utf8"), params), dest, lists);
  writeOrNew(path.join(out, "league.test.mjs"), renderTemplate(fs.readFileSync(path.join(tplDir, "league.test.template.mjs"), "utf8"), params), dest, lists);
  return params;
}

/** Copy challenge files; returns {id, dest, copied, newCopies, kept, brief, due, personal}. */
export function copyChallenge({ workspace, word, source = DEFAULT_SOURCE }) {
  const id = normaliseChallenge(word);
  if (!id) throw new Error(`"${word ?? ""}" is not a challenge. Use C1 to C5, for example /coach challenge C1.`);
  const src = path.join(source, id);
  if (!fs.existsSync(src)) {
    throw new Error(`${id} isn't published yet. Type /exit. In PowerShell, type this line and press Enter:\n  claude plugin marketplace update techjays-qa-ai-coach; claude plugin update qa-ai-coach@techjays-qa-ai-coach\nThen type claude and try again.`);
  }
  const dest = path.join(workspace, "work", id);
  fs.mkdirSync(dest, { recursive: true });
  const copied = [], newCopies = [], kept = [];
  // Common files, then the tester's own version flat on top (same names: the version's file wins).
  const plan = new Map(listFiles(src).map((rel) => [rel, path.join(src, rel)]));
  const versions = listVariants(src);
  let variant = null;
  if (versions.length) {
    const me = readMe(workspace);
    if (!me.email) throw new Error(`Your work email isn't set up yet. Type /coach first, give your work email, then run /coach challenge ${id} again.`);
    const chosen = versions[variantFor(me.email, id, versions.length) - 1];
    variant = chosen.toLowerCase();
    const vdir = path.join(src, "variants", chosen);
    for (const rel of listFiles(vdir)) plan.set(rel, path.join(vdir, rel));
  }
  for (const [rel, from] of [...plan.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) {
    const to = path.join(dest, rel);
    fs.mkdirSync(path.dirname(to), { recursive: true });
    if (!fs.existsSync(to)) {
      fs.copyFileSync(from, to);
      copied.push(rel);
    } else if (fs.readFileSync(to).equals(fs.readFileSync(from))) {
      kept.push(rel); // identical: nothing to do
    } else {
      const alt = freeName(to);
      fs.copyFileSync(from, alt);
      newCopies.push(path.relative(dest, alt));
    }
  }
  if (variant) writeOrNew(path.join(dest, "VARIANT.txt"), `${variant}\n`, dest, { copied, newCopies, kept });
  const personal = personaliseLeague(id, src, dest, workspace, { copied, newCopies, kept });
  const brief = path.join(dest, "brief.md");
  const start = startDateOf(readMe(workspace));
  const due = start ? dueDate(id, start) : null;
  return { id, dest, copied, newCopies, kept, brief: fs.existsSync(brief) ? brief : null, due, personal: !!personal, variant };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const wsFlag = args.indexOf("--workspace");
  const word = args.find((a, i) => !a.startsWith("--") && (wsFlag < 0 || i !== wsFlag + 1));
  try {
    const workspace = findWorkspace(wsFlag >= 0 ? args[wsFlag + 1] : process.cwd());
    if (!workspace) throw new Error("No me.json found. Start Claude Code in your qa-ai-coach folder and type /coach first.");
    const r = copyChallenge({ workspace, word });
    const show = (p) => path.join("work", r.id, p).split(path.sep).join("/");
    console.log(`CHALLENGE_OK ${r.id} ${path.join("work", r.id).split(path.sep).join("/")}`);
    for (const f of r.copied) console.log(`COPIED ${show(f)}`);
    for (const f of r.newCopies) console.log(`NEWCOPY ${show(f)} (your existing file was kept; this is the fresh copy)`);
    for (const f of r.kept) console.log(`KEPT ${show(f)} (already there, unchanged)`);
    if (r.variant) console.log(`VARIANT ${r.variant}`);
    if (r.personal) console.log(`PERSONAL ${show("league/pricing-rules.md")} (your own rate card: tests copied from others won't pass)`);
    if (r.brief) console.log(`BRIEF ${show("brief.md")}`);
    console.log(r.due ? `DUE ${r.due} ${fmtDay(r.due)} end of day` : `DUE_UNKNOWN ${START_DATE_HELP}`);
  } catch (err) {
    console.log(`CHALLENGE_ERROR ${err.message}`);
    process.exit(1);
  }
}
