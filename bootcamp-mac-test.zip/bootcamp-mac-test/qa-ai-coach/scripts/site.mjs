#!/usr/bin/env node
// QA AI Coach: make sure the week 2 practice site (Shady Meadows B&B, ../site/server.mjs) runs on this laptop.
// Usage: node site.mjs
// - If http://127.0.0.1:3080/api/room answers with the practice site's rooms, it does nothing.
// - Otherwise it starts `node <plugin>/site/server.mjs` detached (it keeps running after Claude Code closes; no window,
//   no output), waits until it answers (at most about 5 seconds) and prints the result.
// - Never opens a browser.
// Output: SITE ready http://127.0.0.1:3080 · or SITE failed <reason>
// QA_COACH_SITE_PORT changes the port (tests only).
import http from "node:http";
import net from "node:net";
import path from "node:path";
import fs from "node:fs";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SERVER = path.join(HERE, "..", "site", "server.mjs");
export const SITE_PORT = Number(process.env.QA_COACH_SITE_PORT) || 3080;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** GET /api/room; resolves {ok, status, ours} and never throws. */
export function probe(port = SITE_PORT, timeout = 1500) {
  return new Promise((resolve) => {
    const req = http.get({ host: "127.0.0.1", port, path: "/api/room", timeout, headers: { Accept: "application/json" } }, (res) => {
      let body = "";
      res.setEncoding("utf8");
      res.on("data", (c) => { if (body.length < 100000) body += c; });
      res.on("end", () => {
        let rooms = null;
        try { rooms = JSON.parse(body).rooms; } catch { /* not ours */ }
        const ours = res.statusCode === 200 && Array.isArray(rooms) && res.headers["x-practice-site"] === "qa-ai-coach-shady-meadows";
        let root = null;
        try { root = res.headers["x-practice-site-root"] ? decodeURIComponent(res.headers["x-practice-site-root"]) : null; } catch { /* old copy */ }
        resolve({ ok: ours, status: res.statusCode, ours, root });
      });
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => resolve({ ok: false, status: 0, ours: false }));
  });
}

/** Ask a running copy of the practice site to stop. Never throws. */
function stopOld(port) {
  return new Promise((resolve) => {
    const req = http.request({ host: "127.0.0.1", port, path: "/__coach/stop", method: "POST", timeout: 1500 }, (res) => { res.resume(); res.on("end", resolve); });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => resolve());
    req.end();
  });
}

/** Is anything listening on the port? */
function portInUse(port) {
  return new Promise((resolve) => {
    const s = net.connect({ host: "127.0.0.1", port });
    s.setTimeout(1000);
    s.once("connect", () => { s.destroy(); resolve(true); });
    s.once("timeout", () => { s.destroy(); resolve(false); });
    s.once("error", () => resolve(false));
  });
}

/**
 * Make sure the practice site answers. Returns {status: "running"|"started"|"failed", url, line, pid?, reason?}.
 * "running": it already answered; "started": this call started it.
 */
export async function ensureSite({ port = SITE_PORT, server = SERVER, waitMs = 5000 } = {}) {
  const url = `http://127.0.0.1:${port}`;
  const ready = (status, pid) => ({ status, url, pid, line: `SITE ready ${url}` });
  const failed = (reason) => ({ status: "failed", url, reason, line: `SITE failed ${reason}` });
  const first = await probe(port);
  const same = (a, b) => !!a && path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();
  if (first.ok && same(first.root, path.dirname(server))) return ready("running");
  if (first.ok) {
    // An older copy (another coach version's folder) is running: stop it, then start this one.
    await stopOld(port);
    const until = Date.now() + 3000;
    while (Date.now() < until && (await portInUse(port))) await sleep(150);
  }
  if (await portInUse(port)) return failed(`port ${port} is used by another program, so the practice site cannot start`);
  if (!fs.existsSync(server)) return failed("the practice site is missing from the coach; update the coach");
  let child;
  try {
    child = spawn(process.execPath, [server], {
      detached: true,
      stdio: "ignore",
      windowsHide: true,
      env: { ...process.env, PORT: String(port) },
    });
    child.on("error", () => {});
    child.unref();
  } catch (e) {
    return failed(`the practice site could not start (${e.message})`);
  }
  const until = Date.now() + waitMs;
  while (Date.now() < until) {
    await sleep(150);
    if ((await probe(port, 800)).ok) return ready("started", child.pid);
    if (child.exitCode !== null) break;
  }
  if (child.exitCode !== null) return failed(`the practice site stopped at once (exit code ${child.exitCode})`);
  return failed(`the practice site did not answer within ${Math.round(waitMs / 1000)} seconds`);
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const r = await ensureSite();
  console.log(r.line);
  if (r.status === "failed") process.exitCode = 1;
}
