// QA AI Coach: the workspace's .claude/settings.json (allow rules and quiet display settings).
// Used by start.mjs (each lesson start) and plan.mjs --set-start (the first run), so the one-time restart
// happens during set-up. Kept in its own module: start.mjs imports plan.mjs, so plan.mjs cannot import start.mjs.
import fs from "node:fs";
import path from "node:path";

// Claude Code applies Edit(path) rules to every file-writing tool (a Write(path) rule is ignored with a warning).
// Agent(qa-ai-coach:work): the clean work helper that runs the tester's `run:` prompts. A skill's allowed-tools
// only last for the turn /coach was typed, so without this rule every later `run:` would ask "Allow?".
export const ALLOW_RULES = ["Edit(./work/**)", "Edit(./proofs/**)", "Edit(./submissions/**)", "Edit(./portfolio/**)", "Agent(qa-ai-coach:work)"];

// A quiet terminal for testers (programme manager, 21 Oct): the spinner says "Coach is working", no tips, no
// thinking summaries, tool calls collapsed to one-line summaries, no "Cooked for" line. Keys from the settings
// reference (code.claude.com/docs/en/settings-reference). Set only when absent: a tester's own choice is kept.
export const DISPLAY_SETTINGS = {
  spinnerVerbs: { mode: "replace", verbs: ["Coach is working"] },
  spinnerTipsEnabled: false,
  showThinkingSummaries: false,
  verbose: false,
  showTurnDuration: false,
  // No "※ recap" lines between lesson steps (programme manager, 23 Oct).
  awaySummaryEnabled: false,
  // No grey suggested next message in the input box: it would type the lesson's answers for the tester (23 Oct).
  promptSuggestionEnabled: false,
};

// The coach waits for the work helper in the same turn instead of backgrounding it (programme manager, 23 Oct):
// with fork mode on, Claude cannot wait for a subagent in an interactive terminal (code.claude.com/docs/en/env-vars).
// Read at session start, so they apply from the next `claude`. Set only when absent.
export const ENV_SETTINGS = {
  CLAUDE_CODE_FORK_SUBAGENT: "0",
  CLAUDE_CODE_DISABLE_BACKGROUND_TASKS: "1",
  // Takes precedence over promptSuggestionEnabled and the /config toggle.
  CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION: "false",
};

/** Merge ALLOW_RULES and the missing DISPLAY_SETTINGS and ENV_SETTINGS into settings.json; returns "added", "ok" or "new-restart". */
export function ensureSettings(workspace) {
  const dir = path.join(workspace, ".claude");
  const file = path.join(dir, "settings.json");
  const folderIsNew = !fs.existsSync(dir);
  let settings = {};
  if (fs.existsSync(file)) {
    try {
      settings = JSON.parse(fs.readFileSync(file, "utf8").replace(/^﻿/, "")) || {};
    } catch {
      throw new Error(`.claude/settings.json is not valid JSON. Fix or delete it, then type /coach again.`);
    }
  }
  settings.permissions = settings.permissions || {};
  const allow = Array.isArray(settings.permissions.allow) ? settings.permissions.allow : [];
  const missing = ALLOW_RULES.filter((r) => !allow.includes(r));
  const display = Object.keys(DISPLAY_SETTINGS).filter((k) => !(k in settings));
  const env = settings.env && typeof settings.env === "object" ? settings.env : {};
  const envMissing = Object.keys(ENV_SETTINGS).filter((k) => !(k in env));
  if (!missing.length && !display.length && !envMissing.length) return "ok";
  settings.permissions.allow = [...allow, ...missing];
  for (const k of display) settings[k] = DISPLAY_SETTINGS[k];
  if (envMissing.length) settings.env = { ...env, ...Object.fromEntries(envMissing.map((k) => [k, ENV_SETTINGS[k]])) };
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(settings, null, 2) + "\n");
  // Claude Code reloads settings live, but only for a .claude folder that existed when the session started.
  return folderIsNew ? "new-restart" : "added";
}
