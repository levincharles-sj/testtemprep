# QA AI Coach

The coach for the Techjays QA AI Programme. It runs in Claude Code on your laptop.

**Everything you need is in the QA AI Training Portal:** https://claude.ai/artifact/1iq8fKEGLY2vdGSGfAzoKe
Start with its **Start here** page: it installs this coach step by step.

## How you use it
- **Weeks 1–2: one window, the COACH window** (Claude Code in `C:\qa-ai-coach`). Type `/coach`. The coach teaches today's method, checks your thinking and gives hints, never answers. To use Claude for the task, type `run:` and your own prompt; the coach shows Claude's full answer.
- **From week 3: a WORK window too.** VS Code opens `C:\qa-ai-coach\portfolio`, and Claude runs in its terminal. You set it up in the first lesson of week 3. The decisions stay yours.

| Type (in the COACH window) | What happens |
|---|---|
| `/coach Your Name, your.name@techjays.com, YYYY-MM-DD` | First time only: saves your name, work email and start date on your laptop. Use the start date shown in the portal (Start here → Your programme). |
| `/coach` | Today's lesson, one small part at a time |
| `/coach W3D3` | Catch up a missed day (once its date has come) |
| `/coach start YYYY-MM-DD` | Saves or changes your start date |
| `/coach done` | Checks your work and gives your completion code for the portal |
| `/coach project P1` | Shows this week's project and which of its files you already have |
| `/coach submit P1` | Packs your week's project into one file for the portal, then shows how to upload it |
| `/coach submit W6` | Thursday of week 6: packs your week 6 work into one file for the portal |
| `/coach help` | Shows this list |

## You are not finished until the portal shows it
- **Every day:** `/coach done` gives a code. It is only on your laptop. Open the portal → **Today** → paste the code → write one line → press **Save code**. You should see "Saved: W2D3. Well done."
- **Friday of weeks 1–5, and Thursday of week 6:** `/coach submit P1` (P2 … P6) makes one file and shows its full path, for example `C:\qa-ai-coach\submissions\P1-handin.md`. Open the portal → **Project** → the hand-in card → **Your file** → pick the file from `C:\qa-ai-coach\submissions` → **Upload**. You should see "Handed in" and "Waiting for review".
- **Upload fails, or no upload button?** Tell the programme manager. Do not email the file anywhere else. Handing in again replaces the earlier file.

In week 5, `/parcelly` (in the WORK window) starts the Parcelly assistant you test.

**Every day, before you type `claude`:** `claude plugin marketplace update techjays-qa-ai-coach; claude plugin update qa-ai-coach@techjays-qa-ai-coach` (in PowerShell). Refreshing the marketplace alone does not update the coach.

## Your data
- Your name, work email and start date stay only in `me.json` on your laptop.
- Conversations in your coach folder are saved to `conversations/` and go into your weekly hand-in. Never paste passwords or client data.
- Please don't open the coach's own files (lessons, notes): it spoils the practice.
