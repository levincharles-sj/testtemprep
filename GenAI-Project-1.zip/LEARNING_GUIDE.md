# Complete Learning Guide: Teaching an LLM to Reason with GRPO

## Table of Contents
1. [What Are We Actually Doing?](#1-what-are-we-actually-doing)
2. [The Core Problem: LLMs Can't Count](#2-the-core-problem-llms-cant-count)
3. [The Solution Stack](#3-the-solution-stack)
4. [LoRA: Training Without Breaking the Bank](#4-lora-training-without-breaking-the-bank)
5. [GRPO: The Reinforcement Learning Method](#5-grpo-the-reinforcement-learning-method)
6. [Reward Functions: Teaching What "Good" Means](#6-reward-functions-teaching-what-good-means)
7. [Hyperparameters Explained](#7-hyperparameters-explained)
8. [The Complete Training Flow](#8-the-complete-training-flow)
9. [Common Pitfalls and How to Avoid Them](#9-common-pitfalls-and-how-to-avoid-them)

---

## 1. What Are We Actually Doing?

**The Goal**: Teach a 3-billion parameter language model (Qwen 2.5-3B-Instruct) to count letters in words using step-by-step reasoning.

**Why This Matters**: This is a microcosm of a bigger challenge in AI. LLMs are great at pattern matching and generating fluent text, but they struggle with tasks requiring precise, sequential reasoning. If we can teach them to break down problems into steps, we unlock more reliable AI systems.

**What You'll Build**: A LoRA adapter (a small file ~50-100MB) that plugs into the base model and gives it a new skill: systematic letter counting.

---

## 2. The Core Problem: LLMs Can't Count

### Why LLMs Fail at Counting

LLMs don't "see" words the way humans do. They process text as tokens (word pieces), not individual letters. When you ask:

> "How many e's are in 'effectiveness'?"

The model might tokenize "effectiveness" as ["effect", "iveness"] and has no direct access to the letter-level structure.

### The Solution: Chain-of-Thought (CoT)

We force the model to:
1. Spell out the word letter by letter
2. Check each letter against the target
3. Keep a running count
4. State the final answer

This is like asking a human to count by pointing at each letter instead of guessing.

---

## 3. The Solution Stack

Here's what each component does:

```
┌─────────────────────────────────────────────────────────────┐
│                    YOUR TRAINING SETUP                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   Unsloth   │───▶│    LoRA     │───▶│    GRPO     │     │
│  │ (Speed Up)  │    │ (Efficient) │    │ (Learning)  │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                  │                  │             │
│         ▼                  ▼                  ▼             │
│  Makes training      Only trains         Uses rewards      │
│  2x faster with      ~0.1% of            to guide          │
│  60% less memory     parameters          learning          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Component Breakdown:

| Component | What It Does | Why We Need It |
|-----------|--------------|----------------|
| **Qwen 2.5-3B-Instruct** | Base language model | Starting point - already knows language |
| **LoRA** | Parameter-efficient fine-tuning | Can't afford to train all 3B parameters |
| **Unsloth** | Memory optimization | Makes it possible on a single T4 GPU |
| **vLLM** | Fast inference engine | GRPO needs thousands of generations |
| **GRPO** | Reinforcement learning algorithm | Teaches model through trial and error |

---

## 4. LoRA: Training Without Breaking the Bank

### The Problem with Full Fine-Tuning

- Qwen 2.5-3B has **3 billion parameters**
- Training all of them needs **~24GB+ VRAM**
- Takes **days** even on good hardware
- Creates a **full copy** of the model (~6GB file)

### How LoRA Works

LoRA (Low-Rank Adaptation) is like adding a small "patch" to the model instead of rewriting it.

```
Traditional Fine-Tuning:
┌──────────────────────────────────────┐
│  Original Weights (3B parameters)    │  ← Train ALL of these
│  W = [████████████████████████████]  │
└──────────────────────────────────────┘

LoRA Fine-Tuning:
┌──────────────────────────────────────┐
│  Original Weights (FROZEN)           │
│  W = [████████████████████████████]  │
│       +                              │
│  LoRA Adapter (64 rank = tiny!)      │
│  ΔW = A × B (30-100M parameters)     │
└──────────────────────────────────────┘
```

### Key Parameters Explained

#### `lora_rank = 64`

**What it is**: The "width" of the adapter matrices.

**Analogy**: Think of it like resolution. Higher rank = more detail, but more parameters.

| Rank | Parameters | Use Case |
|------|-----------|----------|
| 8 | ~2M | Very simple tasks |
| 32 | ~15M | Moderate complexity |
| **64** | **~30M** | **Good balance (our choice)** |
| 128 | ~60M | Complex tasks |
| 256 | ~120M | Near full fine-tuning capacity |

**Why 64?**: The task (letter counting) requires learning a structured reasoning pattern. 64 gives enough capacity without being wasteful.

#### `target_modules`

**What they are**: Which parts of the transformer to adapt.

```python
target_modules=[
    "q_proj",    # Query projection - "what am I looking for?"
    "k_proj",    # Key projection - "what information is available?"
    "v_proj",    # Value projection - "what's the actual content?"
    "o_proj",    # Output projection - combines attention results
    "gate_proj", # MLP gating - controls information flow
    "up_proj",   # MLP expansion - processes information
    "down_proj", # MLP compression - refines output
]
```

**Why all of them?**: For reasoning tasks, we need the model to change how it:
1. **Attends** to information (q, k, v, o projections)
2. **Processes** information (gate, up, down projections)

Targeting only attention would limit the model's ability to learn the new reasoning pattern.

---

## 5. GRPO: The Reinforcement Learning Method

### What is GRPO?

GRPO = **Group Relative Policy Optimization**

It's the algorithm that made DeepSeek's reasoning models possible. Instead of needing a separate "critic" model to evaluate responses, GRPO compares responses within a batch.

### How It Works (Simplified)

```
Step 1: Generate Multiple Responses
┌─────────────────────────────────────────────────────────────┐
│ Prompt: "How many e's in 'tree'?"                           │
│                                                              │
│ Generation 1: "1. t-0, 2. r-0, 3. e-1, 4. e-2 → Answer: 2" │ ✓ Good!
│ Generation 2: "The word tree has 2 e's"                     │ ✗ No reasoning
│ Generation 3: "1. t-0, 2. r-0, 3. e-1, 4. e-1 → Answer: 1" │ ✗ Wrong count
│ Generation 4: "1. t-0, 2. e-1, 3. e-2, 4. r-2 → Answer: 2" │ ✗ Wrong spelling
└─────────────────────────────────────────────────────────────┘

Step 2: Score Each Response
┌─────────────────────────────────────────────────────────────┐
│ Response 1: +0.5 (numbering) +2.0 (spelling) +1.0 (count)  │
│             +1.0 (format) +2.0 (correct) = 6.5              │
│ Response 2: 0 + 0 + 0 + 0 - 1.0 = -1.0                      │
│ Response 3: +0.5 + 2.0 - 0.5 + 1.0 - 1.0 = 2.0              │
│ Response 4: +0.5 - 1.0 + 0.5 + 1.0 + 2.0 = 3.0              │
└─────────────────────────────────────────────────────────────┘

Step 3: Learn from Comparison
┌─────────────────────────────────────────────────────────────┐
│ "Response 1 scored highest → make model more likely to     │
│  generate similar responses"                                │
│                                                              │
│ "Response 2 scored lowest → make model less likely to      │
│  generate similar responses"                                │
└─────────────────────────────────────────────────────────────┘
```

### Why GRPO Over Other Methods?

| Method | Needs Reward Model? | Complexity | Memory |
|--------|---------------------|------------|--------|
| PPO | Yes (separate model) | High | High |
| DPO | No | Medium | Medium |
| **GRPO** | **No** | **Medium** | **Low** |

GRPO is practical because it doesn't need a second large model for evaluation.

---

## 6. Reward Functions: Teaching What "Good" Means

Reward functions are **the most important part** of this project. They define what behaviors we want.

### The 5 Reward Functions

#### 1. `numbering_reward_func` - Sequential Structure

**Purpose**: Ensure the model numbers its steps correctly (1, 2, 3...)

```python
# Good: 1. t, 2. r, 3. e, 4. e  → Gets rewards
# Bad:  1. t, 2. r, 3. e, 3. e  → Gets penalties (3 repeated)
```

**Rewards**:
- `+0.5` per correctly numbered line
- `-0.5` per incorrectly numbered line
- `-1.0` per line beyond word length

**Why?**: Sequential numbering helps the model track where it is in the word.

#### 2. `spelling_reward_func` - Accurate Spelling

**Purpose**: Ensure the model spells the word correctly

```python
# Word: "goal"
# Good: g-o-a-l     → +2.0 (exact match)
# Bad:  g-o-a-l-l   → -0.5 (extra letter) -1.0 (wrong letter)
```

**Rewards**:
- `+2.0` for exact spelling match
- `-0.5` per letter of length difference
- `-1.0` per extra letter not in word
- `-0.5` per missing letter

**Why?**: If the model misspells the word, the count will be wrong.

#### 3. `counting_reward_func` - Running Total Accuracy

**Purpose**: Ensure the running count at each step is correct

```python
# Counting 'e' in 'tree'
# Good: 1. t - 0 so far ✓
#       2. r - 0 so far ✓
#       3. e - 1 so far ✓
#       4. e - 2 so far ✓

# Bad:  1. t - 0 so far ✓
#       2. r - 0 so far ✓
#       3. e - 1 so far ✓
#       4. e - 1 so far ✗ (should be 2!)
```

**Rewards**:
- `+1.0` per accurate count
- `-1.0` per inaccurate count

**Why?**: This is the core skill - tracking the count as you go.

#### 4. `format_reward_func` - Output Structure

**Purpose**: Ensure the model uses the expected XML format

```python
# Good:
# <reasoning>...step by step...</reasoning>
# <answer>2</answer>

# Bad:
# "The answer is 2"  (no tags)
```

**Rewards**:
- `+0.5` for using `<reasoning>` and `<answer>` tags
- `+0.5` for having a numeric answer

**Why?**: Structured output is easier to parse and verify.

#### 5. `correct_answer_reward_func` - Final Result

**Purpose**: Reward getting the right final answer

**Rewards**:
- `+2.0` for correct answer
- `-1.0` for incorrect answer

**Why?**: Ultimately, we want the right answer!

### Reward Shaping Philosophy

Notice how rewards are distributed:

```
Total possible reward breakdown:
├── Process rewards (how you got there)
│   ├── numbering:  ~0.5 per letter (variable)
│   ├── spelling:   up to +2.0
│   ├── counting:   ~1.0 per letter (variable)
│   └── format:     up to +1.0
│
└── Outcome reward (what you got)
    └── correct:    +2.0 or -1.0
```

This balance is intentional:
- **Heavy process rewards**: Guide the model to use the right method
- **Outcome reward**: Ensure we still optimize for the final answer

---

## 7. Hyperparameters Explained

### Training Hyperparameters

```python
COMMON_GRPO_TRAINING_PARAMS = dict(
    learning_rate=10e-6,              # How big each learning step is
    beta=0.0001,                       # KL penalty coefficient
    per_device_train_batch_size=16,    # Prompts per GPU per step
    num_generations=4,                 # Completions per prompt
    gradient_accumulation_steps=1,     # Batches before update
    ...
)
```

#### `learning_rate = 10e-6` (0.00001)

**What it does**: Controls how much the model changes each step.

```
Too High (1e-3):
┌──────────────────────────────────────┐
│ Step 1: Model learns letter counting │
│ Step 2: Model forgets how to speak! │ ← Catastrophic!
└──────────────────────────────────────┘

Just Right (1e-5):
┌──────────────────────────────────────┐
│ Step 1: Tiny improvement            │
│ Step 100: Good improvement          │
│ Step 500: Great at counting         │
│ Still speaks normally!              │ ← What we want
└──────────────────────────────────────┘
```

#### `beta = 0.0001` (KL Divergence Coefficient)

**What it does**: Prevents the model from changing too much from its original behavior.

```
High beta (0.1):
"Stay very close to original" → Learns slowly, very stable

Low beta (0.0001):
"You can change more freely" → Learns faster, slight instability risk
```

**Our choice**: Low beta because we want the model to learn a new behavior (step-by-step reasoning) that's different from its default.

#### `per_device_train_batch_size = 16` & `num_generations = 4`

These work together:
- 16 total samples per step
- 4 generations per prompt
- = 16/4 = **4 unique prompts** per training step

**Why 4 generations?**: GRPO needs multiple responses to compare. 4 is a good balance between:
- Enough variety to learn from comparisons
- Not so many that training is slow

#### `gradient_accumulation_steps = 1`

**What it does**: How many mini-batches to accumulate before updating weights.

```
gradient_accumulation_steps = 1:
Batch 1 → Update weights
Batch 2 → Update weights
Batch 3 → Update weights

gradient_accumulation_steps = 4:
Batch 1 → Accumulate
Batch 2 → Accumulate
Batch 3 → Accumulate
Batch 4 → Update weights (using all 4)
```

**Our choice**: 1 (simplest case, no accumulation needed with our batch size).

#### `max_steps = 100`

**What it does**: Total training iterations.

**Estimation**:
- 5 steps takes ~3-5 minutes
- 100 steps takes ~60-100 minutes
- After 100 steps, you should see meaningful improvement

---

## 8. The Complete Training Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    TRAINING PIPELINE                         │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ 1. LOAD MODEL                                                │
│    • Download Qwen 2.5-3B-Instruct                          │
│    • Apply 4-bit quantization (saves memory)                │
│    • Initialize vLLM for fast generation                    │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. ADD LoRA ADAPTERS                                         │
│    • Create small trainable matrices                        │
│    • Attach to: q_proj, k_proj, v_proj, o_proj,            │
│                 gate_proj, up_proj, down_proj               │
│    • Freeze all original weights                            │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. PREPARE DATASET                                           │
│    • 62 words × ~5 letter combinations each                 │
│    • Format: {"prompt": [...], "counts": N, ...}            │
│    • Each sample is a letter-counting question              │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. TRAINING LOOP (repeat for max_steps)                      │
│                                                              │
│    For each step:                                            │
│    a) Sample 4 prompts from dataset                         │
│    b) Generate 4 completions per prompt (16 total)          │
│    c) Score all 16 with reward functions                    │
│    d) Compute GRPO loss (reward high, penalize low)         │
│    e) Backpropagate through LoRA parameters only            │
│    f) Update LoRA weights                                    │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. SAVE & EVALUATE                                           │
│    • Save LoRA adapter (~50-100MB file)                     │
│    • Compare OLD (base) vs NEW (base + LoRA)                │
│    • Check for catastrophic forgetting                      │
└─────────────────────────────────────────────────────────────┘
```

---

## 9. Common Pitfalls and How to Avoid Them

### 1. Out of Memory (OOM) Errors

**Symptom**: CUDA out of memory error

**Solutions**:
```python
# Reduce batch size
per_device_train_batch_size=8  # Instead of 16

# Reduce GPU memory utilization
gpu_memory_utilization=0.4  # Instead of 0.5

# Reduce LoRA rank
lora_rank = 32  # Instead of 64
```

### 2. Rewards Not Increasing

**Symptom**: Reward stays flat or decreases

**Possible causes**:
- Learning rate too low → Try `1e-5` instead of `1e-6`
- Beta too high → Try `0.00001`
- Reward functions have bugs → Test them individually first

### 3. Model Outputs Gibberish

**Symptom**: Fine-tuned model produces nonsense

**Cause**: Learning rate too high, model "forgot" language

**Solution**: Restart with lower learning rate (`1e-6`)

### 4. Catastrophic Forgetting

**Symptom**: Model can't answer general questions anymore

**Cause**: Too much training, too high learning rate

**Solutions**:
- Use lower learning rate
- Use fewer training steps
- Increase beta (KL penalty)

### 5. Assertion Errors in Reward Functions

**Symptom**: `assert res[1] > res[0]` fails

**Cause**: Reward logic is incorrect

**Debug**: Print intermediate values:
```python
print(f"Response 1: {responses[0]}")
print(f"Response 2: {responses[1]}")
print(f"Rewards: {res}")
```

---

## Quick Reference Card

### Key Values to Remember

| Parameter | Value | Why |
|-----------|-------|-----|
| `lora_rank` | 64 | Balanced capacity for reasoning |
| `learning_rate` | 1e-5 | Small steps, stable learning |
| `beta` | 0.0001 | Allow new behavior |
| `per_device_train_batch_size` | 16 | T4 GPU friendly |
| `num_generations` | 4 | Good comparison signal |
| `max_steps` | 100 | ~1 hour training |

### Reward Values Summary

| Function | Good Behavior | Reward | Bad Behavior | Penalty |
|----------|---------------|--------|--------------|---------|
| Numbering | Correct sequence | +0.5 | Wrong number | -0.5 |
| Spelling | Exact match | +2.0 | Extra letter | -1.0 |
| Counting | Accurate total | +1.0 | Wrong count | -1.0 |
| Format | Has tags + digit | +1.0 | Missing | 0 |
| Correct | Right answer | +2.0 | Wrong | -1.0 |

---

## Final Thoughts

This project teaches you the fundamentals of:

1. **Parameter-efficient fine-tuning** with LoRA
2. **Reinforcement learning from human feedback** concepts (reward shaping)
3. **Modern training infrastructure** (Unsloth, vLLM)
4. **Reasoning capabilities** in LLMs

The same techniques scale to much harder problems: math reasoning, code generation, multi-step planning. Master these basics, and you have a foundation for advanced LLM development.

Good luck with your project! 🚀
