# UDA-Hub System Design

## Overview

UDA-Hub (Universal Decision Agent Hub) is a multi-agent customer support system built with LangGraph. It handles support tickets for CultPass, a cultural experiences subscription service.

## Architecture Pattern: HIERARCHICAL (Supervisor)

This system uses a **Hierarchical/Supervisor architecture pattern** where:
- The **Classifier Agent** acts as the supervisor, analyzing incoming requests and routing to specialized agents
- Specialized agents (Account Lookup, Resolver, Escalation) handle specific tasks
- The **Orchestrator** manages state flow and agent coordination
- Routing decisions are made at defined checkpoints based on classification and confidence scores

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         HIERARCHICAL ARCHITECTURE                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│                           ┌──────────────────┐                          │
│                           │  User Message    │                          │
│                           └────────┬─────────┘                          │
│                                    │                                     │
│                                    ▼                                     │
│    ┌───────────────────────────────────────────────────────────────┐    │
│    │                    CLASSIFIER AGENT (Supervisor)               │    │
│    │    • Analyzes message content                                  │    │
│    │    • Determines issue category                                 │    │
│    │    • Decides if immediate escalation needed                    │    │
│    └───────────────────────────────────────────────────────────────┘    │
│                                    │                                     │
│                    ┌───────────────┴───────────────┐                    │
│                    │ ROUTER                        │                    │
│                    ▼                               ▼                    │
│    ┌─────────────────────────┐     ┌─────────────────────────────┐     │
│    │  ACCOUNT LOOKUP AGENT   │     │     ESCALATION AGENT        │     │
│    │  • Fetch user context   │     │  • Blocked accounts         │     │
│    │  • Subscription status  │     │  • Human requests           │     │
│    │  • Past interactions    │     │  • Complex issues           │     │
│    └───────────┬─────────────┘     │  • Low confidence KB match  │     │
│                │                    └─────────────────────────────┘     │
│                ▼                                   │                    │
│    ┌─────────────────────────┐                     │                    │
│    │   RAG RETRIEVAL         │                     │                    │
│    │  (Knowledge Base)       │                     │                    │
│    │  • Semantic search      │                     │                    │
│    │  • Confidence scoring   │                     │                    │
│    └───────────┬─────────────┘                     │                    │
│                │                                    │                    │
│                │ ROUTER (Confidence Check)          │                    │
│                ▼                                    │                    │
│    ┌─────────────────────────┐                     │                    │
│    │    RESOLVER AGENT       │                     │                    │
│    │  • Generate response    │                     │                    │
│    │    from KB articles     │                     │                    │
│    │  • Personalize with     │                     │                    │
│    │    user context         │                     │                    │
│    └───────────┬─────────────┘                     │                    │
│                │                                    │                    │
│                └───────────────┬────────────────────┘                   │
│                                ▼                                         │
│                    ┌──────────────────┐                                 │
│                    │  Response/Handoff │                                 │
│                    └──────────────────┘                                 │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

## Agent Roles and Responsibilities

### 1. Classifier Agent (`agentic/agents/classifier.py`)
**Role**: Supervisor / Router

**Responsibilities**:
- Analyze incoming support ticket message
- Classify into predefined categories
- Determine if immediate human escalation is required
- Route to appropriate downstream agents

**Categories Handled**:
| Category | Description | Escalation |
|----------|-------------|------------|
| login_access | Password, login issues | No |
| subscription | Plan questions, benefits | No |
| billing | Payments, refunds | No |
| reservation | Bookings, cancellations | No |
| technical | App issues, bugs | No |
| account_blocked | Suspended accounts | Yes (auto) |
| general_inquiry | Other questions | No |
| escalation | User requests human | Yes (auto) |

### 2. Account Lookup Agent (`agentic/agents/account_lookup.py`)
**Role**: Context Provider

**Responsibilities**:
- Extract user identifiers (email) from messages
- Query CultPass database for user information
- Retrieve subscription status and history
- Fetch past conversation history for personalization
- Provide user context to downstream agents

**Functions**:
- `get_user_by_email()` - Lookup user record
- `get_user_subscription()` - Get subscription details
- `get_user_reservations()` - Get booking history
- `lookup_user_context()` - Build complete context string

### 3. Resolver Agent (`agentic/agents/resolver.py`)
**Role**: Solution Provider

**Responsibilities**:
- Generate helpful responses using KB articles
- Personalize responses with user context
- Follow tone guidelines from knowledge base
- Store interaction to memory for future reference

**Inputs**:
- User message
- Ticket category
- Knowledge base articles (from RAG)
- User context (from Account Lookup)

### 4. Escalation Agent (`agentic/agents/escalation.py`)
**Role**: Human Handoff

**Responsibilities**:
- Generate appropriate handoff messages
- Explain to user that human support is coming
- Provide context summary for human agents
- Store interaction to memory

**Triggers**:
- Account blocked/suspended
- User explicitly requests human
- Low confidence KB match (< 70%)
- Complex issues beyond KB scope

## Tools

### RAG Tools (`agentic/tools/rag_tools.py`)
**Purpose**: Semantic search over knowledge base

**Components**:
- `OpenAIEmbeddings` - Text to vector (text-embedding-ada-002)
- `Chroma` - Vector storage and retrieval
- `search_knowledge_base` - Main search tool with confidence scoring
- `search_knowledge_by_category` - Category-optimized search

**Confidence Scoring** (Real Chroma Similarity):
- Uses actual cosine distance from Chroma vector search
- Converted to similarity: `1.0 - (distance / 2.0)`
- Range: 0.0 (no match) to 1.0 (perfect match)
- Threshold: 0.65 (below this triggers escalation)

| Confidence | Meaning | Action |
|------------|---------|--------|
| > 0.80 | Strong KB match | Resolve |
| 0.65 - 0.80 | Acceptable match | Resolve |
| < 0.65 | Weak/no match | Escalate |

### Memory Tools (`agentic/tools/memory.py`)
**Purpose**: Long-term conversation persistence

**Functions**:
- `store_interaction()` - Save message to TicketMessage table
- `get_history()` - Retrieve conversation history for ticket
- `get_user_history()` - Get all history for a user (cross-session)
- `format_history_for_context()` - Format for LLM prompt

## Memory Architecture

### Short-term Memory (Session)
- Uses `thread_id` via LangGraph's MemorySaver
- Maintains conversation context within a session
- Resets between different tickets/sessions

### Long-term Memory (Persistent)
- Stored in `TicketMessage` table in udahub.db
- Persists across sessions and restarts
- Enables cross-session personalization
- Retrieved by Account Lookup agent

## Logging

Structured JSON logging is configured throughout the workflow for machine-parsable output:

```json
{"node": "CLASSIFIER", "event": "classification_complete", "input": "I can't log in", "category": "login_access", "needs_escalation": false}
{"node": "ROUTER", "event": "routing", "decision": "account_lookup"}
{"node": "ACCOUNT_LOOKUP", "event": "tool_invoked", "tool": "get_user_info", "input": "alice@example.com"}
{"node": "ACCOUNT_LOOKUP", "event": "tool_result", "tool": "get_user_info", "success": true, "result_length": 245}
{"node": "RAG", "event": "search_complete", "confidence": 0.85, "threshold": 0.65, "articles_found": true}
{"node": "ROUTER", "event": "routing", "decision": "resolve"}
{"node": "RESOLVER", "event": "response_generated", "response_length": 312, "tools_used": ["get_user_info", "search_knowledge_base"]}
```

**Log Fields:**
- `node`: Agent/component (CLASSIFIER, ACCOUNT_LOOKUP, RAG, ROUTER, RESOLVER, ESCALATION)
- `event`: Action type (tool_invoked, tool_result, search_complete, routing, etc.)
- Additional context-specific fields (confidence, tools_used, etc.)

## Data Flow

1. **Input**: User message arrives
2. **Classification**: Classifier determines category and escalation need
3. **Routing**: Based on classification, route to account_lookup or escalate
4. **Context Building**: Account Lookup fetches user info and history
5. **Knowledge Retrieval**: RAG searches for relevant KB articles
6. **Confidence Check**: If confidence < threshold, escalate
7. **Resolution/Escalation**: Generate appropriate response
8. **Memory Storage**: Persist interaction for future reference
9. **Output**: Response to user

## Database Schema

### CultPass DB (External)
- Users, Subscriptions, Experiences, Reservations

### UDA-Hub DB (Core)
- Accounts, Users (mapped), Tickets, TicketMessages, Knowledge

### Chroma Vector DB
- Knowledge article embeddings
- Persisted to `data/core/chroma_db/`

## Key Design Decisions

1. **Hierarchical Pattern**: Classifier as supervisor for clear routing logic
2. **4 Specialized Agents**: Each with single responsibility
3. **Confidence-based Escalation**: RAG score determines human handoff
4. **Long-term Memory**: Persist to DB for cross-session context
5. **Structured Logging**: Full visibility into agent decisions
6. **RAG with Chroma**: Semantic search for better KB matching
7. **Fail-safe Escalation**: When in doubt, escalate to human
