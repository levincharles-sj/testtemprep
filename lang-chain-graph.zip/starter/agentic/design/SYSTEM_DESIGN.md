# UDA-Hub System Design

## Overview

UDA-Hub (Universal Decision Agent Hub) is a multi-agent customer support system built with LangGraph. It handles support tickets for CultPass, a cultural experiences subscription service.

## Architecture Pattern: HIERARCHICAL (Supervisor)

This system uses a **Hierarchical/Supervisor architecture pattern** where:
- The **Classifier Agent** acts as the supervisor, analyzing incoming requests and routing to specialized agents
- Specialized agents (Account Lookup, Resolver, Escalation) handle specific tasks
- The **Orchestrator** manages state flow and agent coordination
- Routing decisions are made at defined checkpoints based on classification and confidence scores

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         HIERARCHICAL ARCHITECTURE                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│                           ┌──────────────────┐                          │
│                           │  User Message    │                          │
│                           └────────┬─────────┘                          │
│                                    │                                     │
│                                    ▼                                     │
│    ┌───────────────────────────────────────────────────────────────┐    │
│    │                    CLASSIFIER AGENT (Supervisor)               │    │
│    │    • Analyzes message content                                  │    │
│    │    • Determines issue category                                 │    │
│    │    • Decides if immediate escalation needed                    │    │
│    └───────────────────────────────────────────────────────────────┘    │
│                                    │                                     │
│                    ┌───────────────┴───────────────┐                    │
│                    │ ROUTER                        │                    │
│                    ▼                               ▼                    │
│    ┌─────────────────────────┐     ┌─────────────────────────────┐     │
│    │  ACCOUNT LOOKUP AGENT   │     │     ESCALATION AGENT        │     │
│    │  • Fetch user context   │     │  • Blocked accounts         │     │
│    │  • Subscription status  │     │  • Human requests           │     │
│    │  • Past interactions    │     │  • Complex issues           │     │
│    └───────────┬─────────────┘     │  • Low confidence KB match  │     │
│                │                    └─────────────────────────────┘     │
│                ▼                                   │                    │
│    ┌─────────────────────────┐                     │                    │
│    │   RAG RETRIEVAL         │                     │                    │
│    │  (Knowledge Base)       │                     │                    │
│    │  • Semantic search      │                     │                    │
│    │  • Confidence scoring   │                     │                    │
│    └───────────┬─────────────┘                     │                    │
│                │                                    │                    │
│                │ ROUTER (Confidence Check)          │                    │
│                ▼                                    │                    │
│    ┌─────────────────────────┐                     │                    │
│    │    RESOLVER AGENT       │                     │                    │
│    │  • Generate response    │                     │                    │
│    │    from KB articles     │                     │                    │
│    │  • Personalize with     │                     │                    │
│    │    user context         │                     │                    │
│    └───────────┬─────────────┘                     │                    │
│                │                                    │                    │
│                └───────────────┬────────────────────┘                   │
│                                ▼                                         │
│                    ┌──────────────────┐                                 │
│                    │  Response/Handoff │                                 │
│                    └──────────────────┘                                 │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

## Agent Roles and Responsibilities

### 1. Classifier Agent (`agentic/agents/classifier.py`)
**Role**: Supervisor / Router

**Responsibilities**:
- Analyze incoming support ticket message
- Classify into predefined categories
- Determine if immediate human escalation is required
- Route to appropriate downstream agents

**Categories Handled**:
| Category | Description | Escalation |
|----------|-------------|------------|
| login_access | Password, login issues | No |
| subscription | Plan questions, benefits | No |
| billing | Payments, refunds | No |
| reservation | Bookings, cancellations | No |
| technical | App issues, bugs | No |
| account_blocked | Suspended accounts | Yes (auto) |
| general_inquiry | Other questions | No |
| escalation | User requests human | Yes (auto) |

### 2. Account Lookup Agent (`agentic/agents/account_lookup.py`)
**Role**: Context Provider

**Responsibilities**:
- Extract user identifiers (email) from messages
- Query CultPass database for user information
- Retrieve subscription status and history
- Fetch past conversation history for personalization
- Provide user context to downstream agents

**Functions**:
- `get_user_by_email()` - Lookup user record
- `get_user_subscription()` - Get subscription details
- `get_user_reservations()` - Get booking history
- `lookup_user_context()` - Build complete context string

### 3. Resolver Agent (`agentic/agents/resolver.py`)
**Role**: Solution Provider

**Responsibilities**:
- Generate helpful responses using KB articles
- Personalize responses with user context
- Follow tone guidelines from knowledge base
- Store interaction to memory for future reference

**Inputs**:
- User message
- Ticket category
- Knowledge base articles (from RAG)
- User context (from Account Lookup)

### 4. Escalation Agent (`agentic/agents/escalation.py`)
**Role**: Human Handoff

**Responsibilities**:
- Generate appropriate handoff messages
- Explain to user that human support is coming
- Provide context summary for human agents
- Store interaction to memory

**Triggers**:
- Account blocked/suspended
- User explicitly requests human
- Low confidence KB match (< 70%)
- Complex issues beyond KB scope

## Tools

### RAG Tools (`agentic/tools/rag_tools.py`)
**Purpose**: Semantic search over knowledge base

**Components**:
- `OpenAIEmbeddings` - Text to vector (text-embedding-ada-002)
- `Chroma` - Vector storage and retrieval
- `search_knowledge_base` - Main search tool with confidence scoring
- `search_knowledge_by_category` - Category-optimized search

**Confidence Scoring**:
| Score | Condition | Action |
|-------|-----------|--------|
| 0.9 | 1+ High relevance match | Resolve |
| 0.75 | 2+ Medium matches | Resolve |
| 0.6 | 1 Medium match | Resolve |
| 0.4 | Only Low matches | Escalate |
| 0.0 | No matches / Error | Escalate |

### Memory Tools (`agentic/tools/memory.py`)
**Purpose**: Long-term conversation persistence

**Functions**:
- `store_interaction()` - Save message to TicketMessage table
- `get_history()` - Retrieve conversation history for ticket
- `get_user_history()` - Get all history for a user (cross-session)
- `format_history_for_context()` - Format for LLM prompt

## Memory Architecture

### Short-term Memory (Session)
- Uses `thread_id` via LangGraph's MemorySaver
- Maintains conversation context within a session
- Resets between different tickets/sessions

### Long-term Memory (Persistent)
- Stored in `TicketMessage` table in udahub.db
- Persists across sessions and restarts
- Enables cross-session personalization
- Retrieved by Account Lookup agent

## Logging

Structured logging is configured throughout the workflow:

```
14:32:01 | INFO | [CLASSIFIER] Processing: I can't log into my account...
14:32:02 | INFO | [CLASSIFIER] Category: login_access, Escalate: False
14:32:02 | INFO | [ROUTER] Proceeding to account lookup
14:32:02 | INFO | [ACCOUNT_LOOKUP] Checking for user context...
14:32:03 | INFO | [RAG] Searching KB for category: login_access
14:32:03 | INFO | [RAG] Confidence score: 0.90
14:32:03 | INFO | [ROUTER] Proceeding to resolution
14:32:04 | INFO | [RESOLVER] Generating response...
14:32:05 | INFO | [RESOLVER] Response generated (245 chars)
14:32:05 | INFO | [RESOLVER] Interaction stored to memory
```

## Data Flow

1. **Input**: User message arrives
2. **Classification**: Classifier determines category and escalation need
3. **Routing**: Based on classification, route to account_lookup or escalate
4. **Context Building**: Account Lookup fetches user info and history
5. **Knowledge Retrieval**: RAG searches for relevant KB articles
6. **Confidence Check**: If confidence < threshold, escalate
7. **Resolution/Escalation**: Generate appropriate response
8. **Memory Storage**: Persist interaction for future reference
9. **Output**: Response to user

## Database Schema

### CultPass DB (External)
- Users, Subscriptions, Experiences, Reservations

### UDA-Hub DB (Core)
- Accounts, Users (mapped), Tickets, TicketMessages, Knowledge

### Chroma Vector DB
- Knowledge article embeddings
- Persisted to `data/core/chroma_db/`

## Key Design Decisions

1. **Hierarchical Pattern**: Classifier as supervisor for clear routing logic
2. **4 Specialized Agents**: Each with single responsibility
3. **Confidence-based Escalation**: RAG score determines human handoff
4. **Long-term Memory**: Persist to DB for cross-session context
5. **Structured Logging**: Full visibility into agent decisions
6. **RAG with Chroma**: Semantic search for better KB matching
7. **Fail-safe Escalation**: When in doubt, escalate to human
