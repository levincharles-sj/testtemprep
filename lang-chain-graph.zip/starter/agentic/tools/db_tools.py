"""
Tools for interacting with CultPass and UDA-Hub databases.
These tools allow agents to retrieve user info, subscriptions, and knowledge articles.

Knowledge Base Search uses RAG (Retrieval Augmented Generation):
- OpenAI embeddings for semantic understanding
- Chroma vector store for similarity search
- See rag_tools.py for implementation details
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from langchain_core.tools import tool

# Import RAG-based search (uses Chroma + OpenAI embeddings)
from agentic.tools.rag_tools import search_knowledge_base, search_knowledge_by_category

# Get the directory where this file is located
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Database paths - using relative paths from project root
CULTPASS_DB = os.path.join(BASE_DIR, "data", "external", "cultpass.db")
UDAHUB_DB = os.path.join(BASE_DIR, "data", "core", "udahub.db")


def get_cultpass_engine():
    """Create engine for CultPass database."""
    return create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)


def get_udahub_engine():
    """Create engine for UDA-Hub database."""
    return create_engine(f"sqlite:///{UDAHUB_DB}", echo=False)


@tool
def get_user_info(user_email: str) -> str:
    """
    Look up a CultPass user by their email address.
    Use this to get user account status and subscription info.
    
    Args:
        user_email: The user's email address
    
    Returns:
        User information including name, account status, and subscription details.
    """
    from data.models import cultpass
    
    engine = get_cultpass_engine()
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        user = session.query(cultpass.User).filter_by(email=user_email).first()
        
        if not user:
            return f"No user found with email: {user_email}"
        
        result = f"User Information:\n"
        result += f"- Name: {user.full_name}\n"
        result += f"- Email: {user.email}\n"
        result += f"- Account Status: {'BLOCKED' if user.is_blocked else 'Active'}\n"
        
        # Get subscription info
        if user.subscription:
            sub = user.subscription
            result += f"\nSubscription:\n"
            result += f"- Tier: {sub.tier}\n"
            result += f"- Status: {sub.status}\n"
            result += f"- Monthly Quota: {sub.monthly_quota} experiences\n"
        else:
            result += "\nNo active subscription found."
        
        return result
    
    finally:
        session.close()


@tool
def get_user_reservations(user_email: str) -> str:
    """
    Get all reservations for a user.
    
    Args:
        user_email: The user's email address
    
    Returns:
        List of user's reservations with status and event details.
    """
    from data.models import cultpass
    
    engine = get_cultpass_engine()
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        user = session.query(cultpass.User).filter_by(email=user_email).first()
        
        if not user:
            return f"No user found with email: {user_email}"
        
        if not user.reservations:
            return f"No reservations found for {user.full_name}"
        
        result = f"Reservations for {user.full_name}:\n\n"
        for res in user.reservations:
            exp = res.experience
            result += f"- {exp.title}\n"
            result += f"  Location: {exp.location}\n"
            result += f"  Status: {res.status}\n"
            result += f"  Date: {exp.when}\n\n"
        
        return result
    
    finally:
        session.close()


@tool
def check_subscription_status(user_email: str) -> str:
    """
    Check if a user's subscription is active and what tier they have.
    
    Args:
        user_email: The user's email address
    
    Returns:
        Subscription status and tier information.
    """
    from data.models import cultpass
    
    engine = get_cultpass_engine()
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        user = session.query(cultpass.User).filter_by(email=user_email).first()
        
        if not user:
            return f"No user found with email: {user_email}"
        
        if not user.subscription:
            return f"No subscription found for {user.full_name}. They may need to sign up."
        
        sub = user.subscription
        result = f"Subscription Status for {user.full_name}:\n"
        result += f"- Status: {sub.status}\n"
        result += f"- Tier: {sub.tier}\n"
        result += f"- Monthly Quota: {sub.monthly_quota} experiences\n"
        result += f"- Started: {sub.started_at}\n"
        
        if sub.ended_at:
            result += f"- Ended: {sub.ended_at}\n"
        
        return result
    
    finally:
        session.close()


# Export all tools
all_tools = [
    search_knowledge_base,      # RAG-based semantic search
    search_knowledge_by_category,  # Category-based RAG search
    get_user_info,
    get_user_reservations,
    check_subscription_status,
]
