"""
RAG Tools - Retrieval Augmented Generation using Chroma and OpenAI embeddings.

This module provides semantic search capabilities for the knowledge base
using vector embeddings instead of simple keyword matching.

How it works:
1. Knowledge articles are embedded using OpenAI's embedding model
2. Embeddings are stored in Chroma vector database
3. User queries are embedded and compared semantically
4. Most similar articles are retrieved for context
"""

# =============================================================================
# SQLite Version Fix for Chroma
# =============================================================================
# Chroma requires SQLite >= 3.35.0, but many systems have older versions.
# This patch swaps the built-in sqlite3 with pysqlite3-binary which bundles
# a newer SQLite version. Must be done BEFORE importing chromadb.
#
# If you don't need this (SQLite >= 3.35.0 already), you can remove this block.
# =============================================================================
__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')
# =============================================================================

# Load environment variables (for OPENAI_API_KEY)
from dotenv import load_dotenv
load_dotenv()

import os
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.tools import tool

# Directory for Chroma persistence
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CHROMA_PERSIST_DIR = os.path.join(BASE_DIR, "data", "core", "chroma_db")

# Initialize embeddings model
# Uses OpenAI's text-embedding-ada-002 by default
embeddings = OpenAIEmbeddings()

# Global variable to hold the vector store (initialized lazily)
_vector_store = None


def get_vector_store() -> Chroma:
    """
    Get or create the Chroma vector store.
    
    Uses lazy initialization - only loads when first accessed.
    Persists to disk so embeddings survive restarts.
    """
    global _vector_store
    
    if _vector_store is None:
        _vector_store = Chroma(
            collection_name="knowledge_base",
            embedding_function=embeddings,
            persist_directory=CHROMA_PERSIST_DIR,
        )
    
    return _vector_store


def initialize_vector_store(articles: list[dict]) -> Chroma:
    """
    Initialize the vector store with knowledge base articles.
    
    This should be called during database setup (02_core_db_setup.py).
    
    Args:
        articles: List of dicts with 'title', 'content', 'tags' keys
    
    Returns:
        The initialized Chroma vector store
    """
    global _vector_store
    
    # Create documents from articles
    documents = []
    for article in articles:
        # Combine title and content for better semantic matching
        page_content = f"Title: {article['title']}\n\n{article['content']}"
        
        # Store metadata for filtering and display
        metadata = {
            "title": article["title"],
            "tags": article.get("tags", ""),
        }
        
        doc = Document(page_content=page_content, metadata=metadata)
        documents.append(doc)
    
    # Ensure parent directory exists
    os.makedirs(os.path.dirname(CHROMA_PERSIST_DIR), exist_ok=True)
    
    # Create fresh vector store (delete existing if any)
    if os.path.exists(CHROMA_PERSIST_DIR):
        import shutil
        shutil.rmtree(CHROMA_PERSIST_DIR)
    
    # Create and populate the vector store
    _vector_store = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        collection_name="knowledge_base",
        persist_directory=CHROMA_PERSIST_DIR,
    )
    
    print(f"✅ Initialized vector store with {len(documents)} articles")
    return _vector_store


@tool
def search_knowledge_base(query: str) -> str:
    """
    Search the knowledge base using semantic similarity.
    
    This tool uses RAG (Retrieval Augmented Generation):
    1. Converts query to vector embedding using OpenAI
    2. Finds most similar articles in Chroma vector store
    3. Returns relevant articles to help answer the question
    
    Args:
        query: Natural language query (e.g., 'how do I reset my password')
    
    Returns:
        Relevant knowledge articles for answering the user's question
    """
    vector_store = get_vector_store()
    
    # Perform similarity search
    # Returns top 3 most relevant documents
    results = vector_store.similarity_search_with_score(query, k=3)
    
    if not results:
        return "No relevant articles found in the knowledge base."
    
    # Format results with relevance scores
    output = "Found the following relevant articles:\n\n"
    
    for i, (doc, score) in enumerate(results, 1):
        title = doc.metadata.get("title", "Untitled")
        tags = doc.metadata.get("tags", "")
        
        # Lower score = more similar in Chroma
        relevance = "High" if score < 0.5 else "Medium" if score < 0.8 else "Low"
        
        output += f"**Article {i}: {title}** (Relevance: {relevance})\n"
        output += f"Tags: {tags}\n"
        output += f"{doc.page_content}\n\n"
        output += "-" * 40 + "\n\n"
    
    return output


@tool
def search_knowledge_by_category(category: str) -> str:
    """
    Search knowledge base by ticket category.
    
    Maps ticket categories to relevant search terms for better retrieval.
    
    Args:
        category: Ticket category (login_access, subscription, billing, etc.)
    
    Returns:
        Articles relevant to the category
    """
    # Map categories to semantic search queries
    category_queries = {
        "login_access": "login password reset account access authentication",
        "subscription": "subscription plan tier benefits included monthly",
        "billing": "payment refund charge billing credit card",
        "reservation": "reservation booking cancel event reserve",
        "technical": "app crash error bug technical issue not working",
        "account_blocked": "account blocked suspended restricted access",
        "general_inquiry": "cultpass service help information",
    }
    
    query = category_queries.get(category, category)
    return search_knowledge_base.invoke(query)


# Export for use in other modules
__all__ = [
    "search_knowledge_base",
    "search_knowledge_by_category", 
    "initialize_vector_store",
    "get_vector_store",
]
