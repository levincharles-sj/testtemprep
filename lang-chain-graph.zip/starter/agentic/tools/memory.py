"""
Memory Tools - Long-term memory persistence for conversations.

This module handles:
1. Storing interactions to TicketMessage table
2. Retrieving conversation history for context
3. Cross-session memory for personalization
"""
import uuid
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from data.models.udahub import TicketMessage, Ticket, User, RoleEnum


# Database path (relative to project root)
UDAHUB_DB = "data/core/udahub.db"


def get_db_session():
    """Create a database session."""
    engine = create_engine(f"sqlite:///{UDAHUB_DB}", echo=False)
    Session = sessionmaker(bind=engine)
    return Session()


def store_interaction(
    ticket_id: str,
    role: str,
    content: str
) -> str | None:
    """
    Store a conversation message to the database.
    
    Args:
        ticket_id: The ticket this message belongs to
        role: 'user', 'ai', 'agent', or 'system'
        content: The message content
    
    Returns:
        message_id if successful, None otherwise
    """
    try:
        session = get_db_session()
        
        # Map role string to enum
        role_map = {
            "user": RoleEnum.user,
            "ai": RoleEnum.ai,
            "agent": RoleEnum.agent,
            "system": RoleEnum.system,
        }
        role_enum = role_map.get(role, RoleEnum.system)
        
        message = TicketMessage(
            message_id=str(uuid.uuid4()),
            ticket_id=ticket_id,
            role=role_enum,
            content=content,
        )
        
        session.add(message)
        session.commit()
        message_id = message.message_id
        session.close()
        
        return message_id
        
    except Exception:
        return None


def get_history(
    ticket_id: str,
    limit: int = 10
) -> list[dict]:
    """
    Retrieve conversation history for a ticket.
    
    Args:
        ticket_id: The ticket to get history for
        limit: Maximum number of messages to retrieve
    
    Returns:
        List of message dicts with role and content
    """
    try:
        session = get_db_session()
        
        messages = (
            session.query(TicketMessage)
            .filter_by(ticket_id=ticket_id)
            .order_by(TicketMessage.created_at.desc())
            .limit(limit)
            .all()
        )
        
        # Reverse to get chronological order
        messages = list(reversed(messages))
        
        result = []
        for msg in messages:
            result.append({
                "role": msg.role.value,
                "content": msg.content,
                "created_at": str(msg.created_at) if msg.created_at else None,
            })
        
        session.close()
        return result
        
    except Exception:
        return []


def get_user_history(
    user_id: str,
    limit: int = 20
) -> list[dict]:
    """
    Retrieve all conversation history for a user across tickets.
    
    Useful for personalization - understanding user's past issues.
    
    Args:
        user_id: The user's ID
        limit: Maximum number of messages to retrieve
    
    Returns:
        List of message dicts with ticket context
    """
    try:
        session = get_db_session()
        
        # Get all tickets for this user
        tickets = session.query(Ticket).filter_by(user_id=user_id).all()
        ticket_ids = [t.ticket_id for t in tickets]
        
        if not ticket_ids:
            session.close()
            return []
        
        # Get messages from all tickets
        messages = (
            session.query(TicketMessage)
            .filter(TicketMessage.ticket_id.in_(ticket_ids))
            .order_by(TicketMessage.created_at.desc())
            .limit(limit)
            .all()
        )
        
        result = []
        for msg in messages:
            result.append({
                "ticket_id": msg.ticket_id,
                "role": msg.role.value,
                "content": msg.content,
                "created_at": str(msg.created_at) if msg.created_at else None,
            })
        
        session.close()
        return result
        
    except Exception:
        return []


def format_history_for_context(history: list[dict]) -> str:
    """
    Format conversation history as context string for the LLM.
    
    Args:
        history: List of message dicts
    
    Returns:
        Formatted string for prompt context
    """
    if not history:
        return "No previous conversation history."
    
    lines = ["Previous conversation:"]
    for msg in history:
        role = msg["role"].upper()
        content = msg["content"]
        lines.append(f"[{role}]: {content}")
    
    return "\n".join(lines)
