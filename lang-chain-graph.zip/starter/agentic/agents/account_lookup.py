"""
Account Lookup Agent - Retrieves user account information from external systems.

This agent:
1. Looks up user details from CultPass database
2. Fetches subscription status, reservation history
3. Provides context for personalized responses
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Get database path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CULTPASS_DB = os.path.join(BASE_DIR, "data", "external", "cultpass.db")


def get_user_by_email(email: str) -> dict | None:
    """
    Look up a CultPass user by email address.
    
    Args:
        email: User's email address
    
    Returns:
        dict with user info or None if not found
    """
    from data.models.cultpass import User
    
    try:
        engine = create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        user = session.query(User).filter_by(email=email).first()
        
        if not user:
            session.close()
            return None
        
        result = {
            "user_id": user.user_id,
            "name": user.full_name,
            "email": user.email,
            "is_blocked": user.is_blocked,
        }
        
        session.close()
        return result
        
    except Exception:
        return None


def get_user_subscription(user_id: str) -> dict | None:
    """
    Get subscription details for a user.
    
    Args:
        user_id: The user's ID
    
    Returns:
        dict with subscription info or None
    """
    from data.models.cultpass import Subscription
    
    try:
        engine = create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        subscription = session.query(Subscription).filter_by(user_id=user_id).first()
        
        if not subscription:
            session.close()
            return None
        
        result = {
            "tier": subscription.tier,
            "status": subscription.status,
            "monthly_quota": subscription.monthly_quota,
            "started_at": str(subscription.started_at) if subscription.started_at else None,
            "ended_at": str(subscription.ended_at) if subscription.ended_at else None,
        }
        
        session.close()
        return result
        
    except Exception:
        return None


def get_user_reservations(user_id: str, limit: int = 5) -> list[dict]:
    """
    Get recent reservations for a user.
    
    Args:
        user_id: The user's ID
        limit: Max number of reservations to return
    
    Returns:
        list of reservation dicts
    """
    from data.models.cultpass import Reservation
    
    try:
        engine = create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        reservations = (
            session.query(Reservation)
            .filter_by(user_id=user_id)
            .order_by(Reservation.created_at.desc())
            .limit(limit)
            .all()
        )
        
        result = []
        for res in reservations:
            result.append({
                "reservation_id": res.reservation_id,
                "experience_id": res.experience_id,
                "status": res.status,
            })
        
        session.close()
        return result
        
    except Exception:
        return []


def lookup_user_context(email: str) -> str:
    """
    Build a complete user context string for the resolver agent.
    
    Args:
        email: User's email address
    
    Returns:
        Formatted string with user context
    """
    user = get_user_by_email(email)
    
    if not user:
        return "User not found in system."
    
    context_parts = [f"Customer: {user['name']} ({user['email']})"]
    
    if user.get('is_blocked'):
        context_parts.append("⚠️ Account Status: BLOCKED")
    
    # Get subscription
    subscription = get_user_subscription(user['user_id'])
    if subscription:
        context_parts.append(
            f"Subscription: {subscription['tier']} ({subscription['status']})"
        )
        context_parts.append(f"Monthly Quota: {subscription['monthly_quota']} experiences")
    
    # Get recent reservations
    reservations = get_user_reservations(user['user_id'], limit=3)
    if reservations:
        context_parts.append(f"Recent reservations: {len(reservations)} found")
    
    return "\n".join(context_parts)
