"""
Account Lookup Agent - Retrieves user account information from external systems.

This agent:
1. Looks up user details from CultPass database
2. Fetches subscription status, reservation history
3. Provides context for personalized responses
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from data.models.cultpass import User, Subscription, Reservation


# Database path (relative to project root)
CULTPASS_DB = "data/external/cultpass.db"


def get_user_by_email(email: str) -> dict | None:
    """
    Look up a CultPass user by email address.
    
    Args:
        email: User's email address
    
    Returns:
        dict with user info or None if not found
    """
    try:
        engine = create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        user = session.query(User).filter_by(email=email).first()
        
        if not user:
            session.close()
            return None
        
        result = {
            "user_id": user.id,
            "name": user.name,
            "email": user.email,
            "created_at": str(user.created_at) if user.created_at else None,
        }
        
        session.close()
        return result
        
    except Exception:
        return None


def get_user_subscription(user_id: str) -> dict | None:
    """
    Get subscription details for a user.
    
    Args:
        user_id: The user's ID
    
    Returns:
        dict with subscription info or None
    """
    try:
        engine = create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        subscription = session.query(Subscription).filter_by(user_id=user_id).first()
        
        if not subscription:
            session.close()
            return None
        
        result = {
            "plan": subscription.plan,
            "status": subscription.status,
            "start_date": str(subscription.start_date) if subscription.start_date else None,
            "end_date": str(subscription.end_date) if subscription.end_date else None,
        }
        
        session.close()
        return result
        
    except Exception:
        return None


def get_user_reservations(user_id: str, limit: int = 5) -> list[dict]:
    """
    Get recent reservations for a user.
    
    Args:
        user_id: The user's ID
        limit: Max number of reservations to return
    
    Returns:
        list of reservation dicts
    """
    try:
        engine = create_engine(f"sqlite:///{CULTPASS_DB}", echo=False)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        reservations = (
            session.query(Reservation)
            .filter_by(user_id=user_id)
            .order_by(Reservation.created_at.desc())
            .limit(limit)
            .all()
        )
        
        result = []
        for res in reservations:
            result.append({
                "reservation_id": res.id,
                "experience_id": res.experience_id,
                "status": res.status,
                "date": str(res.reservation_date) if res.reservation_date else None,
            })
        
        session.close()
        return result
        
    except Exception:
        return []


def lookup_user_context(email: str) -> str:
    """
    Build a complete user context string for the resolver agent.
    
    Args:
        email: User's email address
    
    Returns:
        Formatted string with user context
    """
    user = get_user_by_email(email)
    
    if not user:
        return "User not found in system."
    
    context_parts = [f"Customer: {user['name']} ({user['email']})"]
    
    # Get subscription
    subscription = get_user_subscription(user['user_id'])
    if subscription:
        context_parts.append(
            f"Subscription: {subscription['plan']} ({subscription['status']})"
        )
    
    # Get recent reservations
    reservations = get_user_reservations(user['user_id'], limit=3)
    if reservations:
        context_parts.append(f"Recent reservations: {len(reservations)} found")
    
    return "\n".join(context_parts)
