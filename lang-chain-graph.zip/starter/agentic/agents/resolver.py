"""
Resolver Agent - Attempts to resolve support tickets using the knowledge base.

This agent:
1. Searches the knowledge base for relevant articles
2. Formulates a helpful response based on the articles
3. Can use tools to look up user-specific information
"""
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


RESOLVER_SYSTEM_PROMPT = """You are a helpful customer support agent for CultPass, a cultural experiences subscription service.

Your goal is to help users with their questions using the information provided to you.

GUIDELINES:
1. Be friendly, professional, and concise
2. Use the knowledge base information to provide accurate answers
3. If user information is available, personalize your response
4. If you cannot fully resolve the issue, acknowledge it and suggest next steps
5. Do NOT make up information - only use what's provided
6. Do NOT promise refunds or account changes without proper verification

When you have knowledge base articles, use the "Suggested phrasing" sections as a guide for your tone.

If you need to look up user information, you can ask for their email address."""


def generate_response(
    user_message: str,
    category: str,
    knowledge_context: str,
    user_context: str,
    model: ChatOpenAI
) -> str:
    """
    Generate a response to the user's support request.
    
    Args:
        user_message: The user's original message
        category: The classified category of the ticket
        knowledge_context: Relevant knowledge base articles
        user_context: User-specific information (if available)
        model: The LLM to use for generation
    
    Returns:
        A helpful response string
    """
    context_parts = []
    
    if knowledge_context:
        context_parts.append(f"KNOWLEDGE BASE ARTICLES:\n{knowledge_context}")
    
    if user_context:
        context_parts.append(f"USER INFORMATION:\n{user_context}")
    
    context = "\n\n".join(context_parts) if context_parts else "No additional context available."
    
    messages = [
        SystemMessage(content=RESOLVER_SYSTEM_PROMPT),
        HumanMessage(content=f"""Issue Category: {category}

{context}

USER MESSAGE: {user_message}

Please provide a helpful response to the user.""")
    ]
    
    response = model.invoke(messages)
    return response.content
