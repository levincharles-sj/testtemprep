"""
Escalation Agent - Handles cases that need human support.

This agent:
1. Acknowledges the user's issue
2. Explains that a human agent will help
3. Collects any necessary information before handoff
"""
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


ESCALATION_REASONS = {
    "account_blocked": "Your account appears to be suspended, which requires review by our support team.",
    "escalation": "You've requested to speak with a human agent.",
    "complex_issue": "This issue requires additional review by our support team.",
    "refund_request": "Refund requests need to be processed by our billing team.",
}


ESCALATION_SYSTEM_PROMPT = """You are a customer support agent for CultPass who is transitioning the conversation to a human agent.

Your job is to:
1. Acknowledge the user's concern with empathy
2. Explain that you're connecting them with a human agent
3. Provide realistic expectations about response time
4. Summarize the issue for the human agent (in a note)

Support Hours: Monday-Friday, 9am-6pm
Average Response Time: 2-4 hours during business hours

Be warm and reassuring. The user may be frustrated."""


def generate_escalation_response(
    user_message: str,
    reason: str,
    user_context: str,
    model: ChatOpenAI
) -> str:
    """
    Generate an escalation response that hands off to human support.
    
    Args:
        user_message: The user's original message
        reason: Why escalation is needed (category key)
        user_context: User-specific information (if available)
        model: The LLM to use for generation
    
    Returns:
        A response explaining the escalation
    """
    reason_text = ESCALATION_REASONS.get(reason, ESCALATION_REASONS["complex_issue"])
    
    context = f"USER INFORMATION:\n{user_context}" if user_context else "No user information available."
    
    messages = [
        SystemMessage(content=ESCALATION_SYSTEM_PROMPT),
        HumanMessage(content=f"""Escalation Reason: {reason_text}

{context}

USER MESSAGE: {user_message}

Please generate a response that:
1. Acknowledges their concern
2. Explains you're connecting them to human support
3. Sets expectations about response time""")
    ]
    
    response = model.invoke(messages)
    return response.content
