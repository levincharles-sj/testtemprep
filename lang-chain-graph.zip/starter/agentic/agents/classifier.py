"""
Classifier Agent - Classifies incoming support tickets into categories.

This agent analyzes the user's message and determines:
1. The issue type (login, subscription, reservation, billing, technical, etc.)
2. Whether it can be resolved by AI or needs human escalation
"""
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


# Issue categories that the classifier can identify
ISSUE_CATEGORIES = [
    "login_access",      # Login, password, account access issues
    "subscription",      # Subscription plans, tiers, benefits
    "billing",           # Payments, refunds, charges
    "reservation",       # Booking, cancellation, event access
    "technical",         # App crashes, QR codes, technical bugs
    "account_blocked",   # Blocked/suspended accounts (needs escalation)
    "general_inquiry",   # General questions about the service
    "escalation",        # User explicitly requests human support
]


CLASSIFIER_SYSTEM_PROMPT = """You are a ticket classifier for CultPass, a cultural experiences subscription service.

Your job is to analyze the user's message and classify it into one of these categories:
- login_access: Issues with logging in, passwords, account access
- subscription: Questions about plans, tiers, benefits, what's included
- billing: Payment issues, refunds, charges, updating payment methods
- reservation: Booking events, cancelling reservations, checking status
- technical: App not working, crashes, QR codes not scanning
- account_blocked: User's account is blocked or suspended (ALWAYS needs escalation)
- general_inquiry: General questions about CultPass
- escalation: User explicitly asks to speak to a human

IMPORTANT RULES:
1. If the user mentions their account is blocked/suspended, classify as "account_blocked"
2. If the user explicitly asks for a human, classify as "escalation"
3. Choose the most specific category that fits

Respond with ONLY the category name, nothing else."""


def classify_ticket(message: str, model: ChatOpenAI) -> dict:
    """
    Classify a support ticket message.
    
    Args:
        message: The user's support message
        model: The LLM to use for classification
    
    Returns:
        dict with 'category' and 'needs_escalation' fields
    """
    messages = [
        SystemMessage(content=CLASSIFIER_SYSTEM_PROMPT),
        HumanMessage(content=f"Classify this message: {message}")
    ]
    
    response = model.invoke(messages)
    category = response.content.strip().lower()
    
    # Validate category
    if category not in ISSUE_CATEGORIES:
        category = "general_inquiry"  # Default fallback
    
    # Determine if escalation is needed
    needs_escalation = category in ["account_blocked", "escalation"]
    
    return {
        "category": category,
        "needs_escalation": needs_escalation
    }
