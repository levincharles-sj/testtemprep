"""
UDA-Hub Workflow - LangGraph orchestration for multi-agent support system.

Architecture Pattern: HIERARCHICAL (Supervisor)
- Classifier acts as supervisor, routing to specialized agents
- Each agent has a specific responsibility
- Orchestrator manages flow and state

Agents:
1. Classifier Agent - Determines ticket type (supervisor role)
2. Account Lookup Agent - Retrieves user context
3. Resolver Agent - Attempts to resolve using knowledge base
4. Escalation Agent - Hands off to human support when needed

Built from scratch using LangGraph StateGraph (not using prebuilt agents).
"""
import json
import logging
import re
from typing import TypedDict, Annotated, Literal
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

# Import our agents and tools
from agentic.agents.classifier import classify_ticket
from agentic.agents.resolver import generate_response
from agentic.agents.escalation import generate_escalation_response
from agentic.agents.account_lookup import lookup_user_context
from agentic.tools.rag_tools import search_knowledge_with_scores
from agentic.tools.db_tools import get_user_info, get_user_reservations, check_subscription_status
from agentic.tools.memory import store_interaction, get_history, format_history_for_context


# =============================================================================
# STRUCTURED LOGGING CONFIGURATION
# =============================================================================
class StructuredLogger:
    """JSON-structured logger for machine-parsable logs."""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Only add handler if not already present
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('%(message)s'))
            self.logger.addHandler(handler)
    
    def log(self, node: str, event: str, **data):
        """Log a structured event with JSON data."""
        log_entry = {
            "node": node,
            "event": event,
            **data
        }
        self.logger.info(json.dumps(log_entry))

logger = StructuredLogger("udahub.workflow")


# =============================================================================
# STATE DEFINITION
# =============================================================================
class AgentState(TypedDict):
    """State that persists across the workflow."""
    messages: Annotated[list[BaseMessage], add_messages]
    category: str
    needs_escalation: bool
    knowledge_context: str
    knowledge_confidence: float  # Real similarity score 0.0-1.0
    user_context: str
    ticket_id: str
    tools_invoked: list[str]  # Track which tools were called


# Initialize the LLM
model = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# Confidence threshold for escalation
CONFIDENCE_THRESHOLD = 0.65  # If similarity score is below this, escalate


# =============================================================================
# NODE FUNCTIONS
# =============================================================================

def classify_node(state: AgentState) -> AgentState:
    """Node 1: Classify the incoming ticket."""
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    classification = classify_ticket(user_message, model)
    
    logger.log(
        node="CLASSIFIER",
        event="classification_complete",
        input=user_message[:100],
        category=classification["category"],
        needs_escalation=classification["needs_escalation"]
    )
    
    return {
        **state,
        "category": classification["category"],
        "needs_escalation": classification["needs_escalation"],
        "tools_invoked": state.get("tools_invoked", []),
    }


def account_lookup_node(state: AgentState) -> AgentState:
    """Node 2: Look up user account information using db_tools."""
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    tools_invoked = state.get("tools_invoked", [])
    user_context = ""
    
    # Try to extract email from message
    email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', user_message)
    
    if email_match:
        email = email_match.group()
        
        # Invoke get_user_info tool
        logger.log(
            node="ACCOUNT_LOOKUP",
            event="tool_invoked",
            tool="get_user_info",
            input=email
        )
        
        try:
            user_info = get_user_info.invoke(email)
            tools_invoked.append("get_user_info")
            user_context = user_info
            
            logger.log(
                node="ACCOUNT_LOOKUP",
                event="tool_result",
                tool="get_user_info",
                success=True,
                result_length=len(user_info)
            )
            
            # Also get reservations if user found
            if "No user found" not in user_info:
                logger.log(
                    node="ACCOUNT_LOOKUP",
                    event="tool_invoked",
                    tool="get_user_reservations",
                    input=email
                )
                
                reservations = get_user_reservations.invoke(email)
                tools_invoked.append("get_user_reservations")
                user_context += "\n\n" + reservations
                
                logger.log(
                    node="ACCOUNT_LOOKUP",
                    event="tool_result",
                    tool="get_user_reservations",
                    success=True
                )
                
        except Exception as e:
            logger.log(
                node="ACCOUNT_LOOKUP",
                event="tool_error",
                tool="get_user_info",
                error=str(e)
            )
    else:
        # No email found, use account_lookup agent
        user_context = lookup_user_context("")
        logger.log(
            node="ACCOUNT_LOOKUP",
            event="no_email_found",
            fallback="agent_lookup"
        )
    
    # Add conversation history for context
    ticket_id = state.get("ticket_id", "")
    if ticket_id:
        history = get_history(ticket_id, limit=5)
        if history:
            user_context += "\n\n" + format_history_for_context(history)
            logger.log(
                node="ACCOUNT_LOOKUP",
                event="history_retrieved",
                message_count=len(history)
            )
    
    return {
        **state,
        "user_context": user_context,
        "tools_invoked": tools_invoked,
    }


def retrieve_knowledge_node(state: AgentState) -> AgentState:
    """Node 3: Retrieve relevant knowledge base articles with real confidence scoring."""
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    category = state.get("category", "general_inquiry")
    tools_invoked = state.get("tools_invoked", [])
    
    search_terms = f"{category} {user_message}"
    
    logger.log(
        node="RAG",
        event="search_started",
        query=search_terms[:100],
        category=category
    )
    
    try:
        # Use the new function that returns real similarity scores
        knowledge_context, confidence = search_knowledge_with_scores(search_terms)
        tools_invoked.append("search_knowledge_base")
        
        logger.log(
            node="RAG",
            event="search_complete",
            confidence=round(confidence, 3),
            threshold=CONFIDENCE_THRESHOLD,
            articles_found="No relevant" not in knowledge_context
        )
        
    except Exception as e:
        logger.log(
            node="RAG",
            event="search_error",
            error=str(e)
        )
        knowledge_context = f"Knowledge base search failed: {str(e)}"
        confidence = 0.0
    
    # Check confidence for escalation
    needs_escalation = state.get("needs_escalation", False)
    if confidence < CONFIDENCE_THRESHOLD and not needs_escalation:
        logger.log(
            node="RAG",
            event="low_confidence_escalation",
            confidence=round(confidence, 3),
            threshold=CONFIDENCE_THRESHOLD,
            decision="escalate"
        )
        needs_escalation = True
    
    return {
        **state,
        "knowledge_context": knowledge_context,
        "knowledge_confidence": confidence,
        "needs_escalation": needs_escalation,
        "tools_invoked": tools_invoked,
    }


def resolve_node(state: AgentState) -> AgentState:
    """Node 4: Generate a resolution response."""
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    logger.log(
        node="RESOLVER",
        event="generating_response",
        category=state.get("category"),
        confidence=round(state.get("knowledge_confidence", 0), 3)
    )
    
    response = generate_response(
        user_message=user_message,
        category=state.get("category", "general_inquiry"),
        knowledge_context=state.get("knowledge_context", ""),
        user_context=state.get("user_context", ""),
        model=model
    )
    
    logger.log(
        node="RESOLVER",
        event="response_generated",
        response_length=len(response),
        tools_used=state.get("tools_invoked", [])
    )
    
    # Store interaction to memory
    ticket_id = state.get("ticket_id", "")
    if ticket_id:
        store_interaction(ticket_id, "user", user_message)
        store_interaction(ticket_id, "ai", response)
        logger.log(
            node="RESOLVER",
            event="memory_stored",
            ticket_id=ticket_id
        )
    
    return {
        **state,
        "messages": [AIMessage(content=response)],
    }


def escalate_node(state: AgentState) -> AgentState:
    """Node 5: Handle escalation to human support."""
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    reason = state.get("category", "complex_issue")
    confidence = state.get("knowledge_confidence", 1.0)
    
    if confidence < CONFIDENCE_THRESHOLD:
        reason = f"{reason} (low KB confidence: {confidence:.0%})"
    
    logger.log(
        node="ESCALATION",
        event="escalating",
        reason=reason,
        confidence=round(confidence, 3),
        category=state.get("category")
    )
    
    response = generate_escalation_response(
        user_message=user_message,
        reason=reason,
        user_context=state.get("user_context", ""),
        model=model
    )
    
    logger.log(
        node="ESCALATION",
        event="handoff_complete",
        response_length=len(response),
        tools_used=state.get("tools_invoked", [])
    )
    
    # Store interaction to memory
    ticket_id = state.get("ticket_id", "")
    if ticket_id:
        store_interaction(ticket_id, "user", user_message)
        store_interaction(ticket_id, "ai", response)
    
    return {
        **state,
        "messages": [AIMessage(content=response)],
    }


# =============================================================================
# ROUTING FUNCTIONS
# =============================================================================

def route_after_classification(state: AgentState) -> Literal["account_lookup", "escalate"]:
    """Router: Decide whether to continue processing or escalate immediately."""
    if state.get("needs_escalation", False):
        logger.log(node="ROUTER", event="routing", decision="escalate", reason="immediate_escalation_flag")
        return "escalate"
    logger.log(node="ROUTER", event="routing", decision="account_lookup")
    return "account_lookup"


def route_after_knowledge(state: AgentState) -> Literal["resolve", "escalate"]:
    """Router: After KB retrieval, check confidence and decide path."""
    if state.get("needs_escalation", False):
        logger.log(
            node="ROUTER",
            event="routing",
            decision="escalate",
            reason="low_confidence_or_flag",
            confidence=round(state.get("knowledge_confidence", 0), 3)
        )
        return "escalate"
    logger.log(node="ROUTER", event="routing", decision="resolve")
    return "resolve"


# =============================================================================
# BUILD THE GRAPH
# =============================================================================

def build_workflow() -> StateGraph:
    """Construct the LangGraph workflow."""
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("classify", classify_node)
    workflow.add_node("account_lookup", account_lookup_node)
    workflow.add_node("retrieve_knowledge", retrieve_knowledge_node)
    workflow.add_node("resolve", resolve_node)
    workflow.add_node("escalate", escalate_node)
    
    # Set entry point
    workflow.set_entry_point("classify")
    
    # Routing
    workflow.add_conditional_edges(
        "classify",
        route_after_classification,
        {"account_lookup": "account_lookup", "escalate": "escalate"}
    )
    
    workflow.add_edge("account_lookup", "retrieve_knowledge")
    
    workflow.add_conditional_edges(
        "retrieve_knowledge",
        route_after_knowledge,
        {"resolve": "resolve", "escalate": "escalate"}
    )
    
    workflow.add_edge("resolve", END)
    workflow.add_edge("escalate", END)
    
    return workflow


# =============================================================================
# SESSION MEMORY INSPECTION
# =============================================================================

def get_session_state(thread_id: str) -> dict | None:
    """
    Inspect the stored session state for a given thread_id.
    
    This retrieves the LangGraph checkpoint state for debugging/inspection.
    
    Args:
        thread_id: The thread/session ID
    
    Returns:
        The stored state dict or None
    """
    try:
        config = {"configurable": {"thread_id": thread_id}}
        state = orchestrator.get_state(config)
        if state and state.values:
            return {
                "messages": [
                    {"role": "human" if isinstance(m, HumanMessage) else "ai", "content": m.content}
                    for m in state.values.get("messages", [])
                ],
                "category": state.values.get("category"),
                "needs_escalation": state.values.get("needs_escalation"),
                "knowledge_confidence": state.values.get("knowledge_confidence"),
                "tools_invoked": state.values.get("tools_invoked", []),
            }
    except Exception:
        pass
    return None


# =============================================================================
# COMPILE AND EXPORT
# =============================================================================

workflow = build_workflow()
memory = MemorySaver()
orchestrator = workflow.compile(checkpointer=memory)

logger.log(node="WORKFLOW", event="initialized", status="ready")
