"""
UDA-Hub Workflow - LangGraph orchestration for multi-agent support system.

Architecture Pattern: HIERARCHICAL (Supervisor)
- Classifier acts as supervisor, routing to specialized agents
- Each agent has a specific responsibility
- Orchestrator manages flow and state

Agents:
1. Classifier Agent - Determines ticket type (supervisor role)
2. Account Lookup Agent - Retrieves user context
3. Resolver Agent - Attempts to resolve using knowledge base
4. Escalation Agent - Hands off to human support when needed

Built from scratch using LangGraph StateGraph (not using prebuilt agents).
"""
import logging
from typing import TypedDict, Annotated, Literal
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

# Import our agents and tools
from agentic.agents.classifier import classify_ticket
from agentic.agents.resolver import generate_response
from agentic.agents.escalation import generate_escalation_response
from agentic.agents.account_lookup import lookup_user_context
from agentic.tools.rag_tools import search_knowledge_base
from agentic.tools.memory import store_interaction, get_history, format_history_for_context


# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("udahub.workflow")


# =============================================================================
# STATE DEFINITION
# =============================================================================
class AgentState(TypedDict):
    """State that persists across the workflow."""
    messages: Annotated[list[BaseMessage], add_messages]  # Conversation history
    category: str  # Classified ticket category
    needs_escalation: bool  # Whether to escalate to human
    knowledge_context: str  # Retrieved KB articles
    knowledge_confidence: float  # RAG retrieval confidence score
    user_context: str  # User information (if available)
    ticket_id: str  # For memory persistence


# Initialize the LLM
model = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# Confidence threshold for escalation
CONFIDENCE_THRESHOLD = 0.7  # If RAG score is below this, escalate


# =============================================================================
# NODE FUNCTIONS - Each node performs a specific task in the workflow
# =============================================================================

def classify_node(state: AgentState) -> AgentState:
    """
    Node 1: Classify the incoming ticket.
    
    Takes the user's message and determines:
    - What category it belongs to
    - Whether it needs human escalation
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    logger.info(f"[CLASSIFIER] Processing: {user_message[:50]}...")
    
    # Classify the ticket
    classification = classify_ticket(user_message, model)
    
    logger.info(f"[CLASSIFIER] Category: {classification['category']}, Escalate: {classification['needs_escalation']}")
    
    return {
        **state,
        "category": classification["category"],
        "needs_escalation": classification["needs_escalation"],
    }


def account_lookup_node(state: AgentState) -> AgentState:
    """
    Node 2: Look up user account information.
    
    Searches for user context based on email or user ID.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    logger.info("[ACCOUNT_LOOKUP] Checking for user context...")
    
    # Try to extract email from message (simple pattern)
    import re
    email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', user_message)
    
    user_context = ""
    if email_match:
        email = email_match.group()
        logger.info(f"[ACCOUNT_LOOKUP] Found email: {email}")
        user_context = lookup_user_context(email)
    
    # Also check for previous conversation context
    ticket_id = state.get("ticket_id", "")
    if ticket_id:
        history = get_history(ticket_id, limit=5)
        if history:
            user_context += "\n\n" + format_history_for_context(history)
            logger.info(f"[ACCOUNT_LOOKUP] Added {len(history)} messages from history")
    
    return {
        **state,
        "user_context": user_context,
    }


def retrieve_knowledge_node(state: AgentState) -> AgentState:
    """
    Node 3: Retrieve relevant knowledge base articles.
    
    Searches the KB and calculates confidence score for escalation decision.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    category = state.get("category", "general_inquiry")
    
    logger.info(f"[RAG] Searching KB for category: {category}")
    
    # Build search query from category and message
    search_terms = f"{category} {user_message}"
    
    # Search the knowledge base
    try:
        knowledge_context = search_knowledge_base.invoke(search_terms)
        
        # Calculate confidence based on result content
        confidence = calculate_rag_confidence(knowledge_context)
        logger.info(f"[RAG] Confidence score: {confidence:.2f}")
        
    except Exception as e:
        logger.error(f"[RAG] Search failed: {str(e)}")
        knowledge_context = f"Knowledge base search failed: {str(e)}"
        confidence = 0.0
    
    # Determine if low confidence should trigger escalation
    needs_escalation = state.get("needs_escalation", False)
    if confidence < CONFIDENCE_THRESHOLD and not needs_escalation:
        logger.info(f"[RAG] Low confidence ({confidence:.2f} < {CONFIDENCE_THRESHOLD}), flagging for escalation")
        needs_escalation = True
    
    return {
        **state,
        "knowledge_context": knowledge_context,
        "knowledge_confidence": confidence,
        "needs_escalation": needs_escalation,
    }


def calculate_rag_confidence(knowledge_context: str) -> float:
    """
    Calculate confidence score from RAG results.
    
    Looks for relevance indicators in the returned context.
    """
    if not knowledge_context:
        return 0.0
    
    if "No relevant articles found" in knowledge_context:
        return 0.0
    
    if "search failed" in knowledge_context.lower():
        return 0.0
    
    # Count high/medium/low relevance matches
    high_count = knowledge_context.count("Relevance: High")
    medium_count = knowledge_context.count("Relevance: Medium")
    low_count = knowledge_context.count("Relevance: Low")
    
    # Weighted score
    if high_count >= 1:
        return 0.9
    elif medium_count >= 2:
        return 0.75
    elif medium_count >= 1:
        return 0.6
    elif low_count >= 1:
        return 0.4
    
    # Has some content but no clear relevance markers
    return 0.5


def resolve_node(state: AgentState) -> AgentState:
    """
    Node 4: Generate a resolution response.
    
    Uses the knowledge base and user context to generate a helpful response.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    logger.info("[RESOLVER] Generating response...")
    
    # Generate response using the resolver agent
    response = generate_response(
        user_message=user_message,
        category=state.get("category", "general_inquiry"),
        knowledge_context=state.get("knowledge_context", ""),
        user_context=state.get("user_context", ""),
        model=model
    )
    
    logger.info(f"[RESOLVER] Response generated ({len(response)} chars)")
    
    # Store interaction to memory
    ticket_id = state.get("ticket_id", "")
    if ticket_id:
        store_interaction(ticket_id, "user", user_message)
        store_interaction(ticket_id, "ai", response)
        logger.info("[RESOLVER] Interaction stored to memory")
    
    return {
        **state,
        "messages": [AIMessage(content=response)],
    }


def escalate_node(state: AgentState) -> AgentState:
    """
    Node 5: Handle escalation to human support.
    
    Generates an appropriate handoff message and notes for the human agent.
    """
    last_message = state["messages"][-1]
    user_message = last_message.content if hasattr(last_message, 'content') else str(last_message)
    
    # Build escalation reason
    reason = state.get("category", "complex_issue")
    confidence = state.get("knowledge_confidence", 1.0)
    
    if confidence < CONFIDENCE_THRESHOLD:
        reason = f"{reason} (low KB match confidence: {confidence:.0%})"
    
    logger.info(f"[ESCALATION] Escalating: {reason}")
    
    # Generate escalation response
    response = generate_escalation_response(
        user_message=user_message,
        reason=reason,
        user_context=state.get("user_context", ""),
        model=model
    )
    
    logger.info("[ESCALATION] Handoff message generated")
    
    # Store interaction to memory
    ticket_id = state.get("ticket_id", "")
    if ticket_id:
        store_interaction(ticket_id, "user", user_message)
        store_interaction(ticket_id, "ai", response)
        logger.info("[ESCALATION] Interaction stored to memory")
    
    return {
        **state,
        "messages": [AIMessage(content=response)],
    }


# =============================================================================
# ROUTING FUNCTIONS
# =============================================================================

def route_after_classification(state: AgentState) -> Literal["account_lookup", "escalate"]:
    """
    Router: Decide whether to continue processing or escalate immediately.
    """
    if state.get("needs_escalation", False):
        logger.info("[ROUTER] Immediate escalation required")
        return "escalate"
    logger.info("[ROUTER] Proceeding to account lookup")
    return "account_lookup"


def route_after_knowledge(state: AgentState) -> Literal["resolve", "escalate"]:
    """
    Router: After KB retrieval, check confidence and decide path.
    """
    if state.get("needs_escalation", False):
        logger.info("[ROUTER] Escalating due to low confidence or escalation flag")
        return "escalate"
    logger.info("[ROUTER] Proceeding to resolution")
    return "resolve"


# =============================================================================
# BUILD THE GRAPH
# =============================================================================

def build_workflow() -> StateGraph:
    """
    Construct the LangGraph workflow.
    
    Flow:
    1. classify -> (router) -> either account_lookup or escalate
    2. account_lookup -> retrieve_knowledge -> (router) -> resolve or escalate
    3. resolve -> END
    4. escalate -> END
    """
    # Create the graph with our state schema
    workflow = StateGraph(AgentState)
    
    # Add nodes (4 agents + 1 tool node)
    workflow.add_node("classify", classify_node)
    workflow.add_node("account_lookup", account_lookup_node)
    workflow.add_node("retrieve_knowledge", retrieve_knowledge_node)
    workflow.add_node("resolve", resolve_node)
    workflow.add_node("escalate", escalate_node)
    
    # Set entry point
    workflow.set_entry_point("classify")
    
    # Add conditional routing after classification
    workflow.add_conditional_edges(
        "classify",
        route_after_classification,
        {
            "account_lookup": "account_lookup",
            "escalate": "escalate",
        }
    )
    
    # Account lookup -> knowledge retrieval
    workflow.add_edge("account_lookup", "retrieve_knowledge")
    
    # Conditional routing after knowledge retrieval (confidence check)
    workflow.add_conditional_edges(
        "retrieve_knowledge",
        route_after_knowledge,
        {
            "resolve": "resolve",
            "escalate": "escalate",
        }
    )
    
    # Terminal edges
    workflow.add_edge("resolve", END)
    workflow.add_edge("escalate", END)
    
    logger.info("[WORKFLOW] Graph built successfully")
    return workflow


# =============================================================================
# COMPILE AND EXPORT
# =============================================================================

# Build the workflow
workflow = build_workflow()

# Compile with memory checkpointer for conversation persistence
memory = MemorySaver()
orchestrator = workflow.compile(checkpointer=memory)

logger.info("[WORKFLOW] Orchestrator compiled and ready")
