# 01_external_db_setup.py
# Setup script for CultPass external database
# Run this to populate the CultPass database with test data

from datetime import datetime, timedelta
import json
import uuid
import random
from sqlalchemy import create_engine

from utils import reset_db, get_session, model_to_dict
from data.models import cultpass

# =============================================================================
# Udahub Accounts - CultPass Database
# =============================================================================

print("=" * 60)
print("Setting up CultPass External Database")
print("=" * 60)

# Initialize database
cultpass_db = "data/external/cultpass.db"
reset_db(cultpass_db)

engine = create_engine(f"sqlite:///{cultpass_db}", echo=False)
cultpass.Base.metadata.create_all(engine)

# =============================================================================
# Load Experiences
# =============================================================================
print("\n📍 Loading Experiences...")

experience_data = []
with open('data/external/cultpass_experiences.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        experience_data.append(json.loads(line))

print(f"Loaded {len(experience_data)} experiences")

with get_session(engine) as session:
    experiences = []
    for idx, experience in enumerate(experience_data):
        exp = cultpass.Experience(
            experience_id=str(uuid.uuid4())[:6],
            title=experience["title"],
            description=experience["description"],
            location=experience["location"],
            when=datetime.now() + timedelta(days=idx+1),
            slots_available=random.randint(1, 30),
            is_premium=(idx % 2 == 0)
        )
        experiences.append(exp)
    session.add_all(experiences)

# =============================================================================
# Load Users
# =============================================================================
print("\n👤 Loading Users...")

cultpass_users = []
with open('data/external/cultpass_users.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        cultpass_users.append(json.loads(line))

print(f"Loaded {len(cultpass_users)} users")

with get_session(engine) as session:
    db_users = []
    for user_info in cultpass_users:
        user = cultpass.User(
            user_id=user_info["id"],
            full_name=user_info["name"],
            email=user_info["email"],
            is_blocked=user_info["is_blocked"],
            created_at=datetime.now()
        )
        db_users.append(user)
    session.add_all(db_users)

# =============================================================================
# Create Subscriptions
# =============================================================================
print("\n💳 Creating Subscriptions...")

subscription_tiers = ['basic', 'premium']
subscription_statuses = ['active', 'cancelled']

with get_session(engine) as session:
    subscriptions = []
    for idx, user_info in enumerate(cultpass_users):
        sub = cultpass.Subscription(
            subscription_id=str(uuid.uuid4())[:6],
            user_id=user_info["id"],
            status=random.choice(subscription_statuses),
            tier=random.choice(subscription_tiers),
            monthly_quota=4 if random.random() > 0.5 else 8,
            started_at=datetime.now() - timedelta(days=random.randint(30, 365)),
        )
        subscriptions.append(sub)
    session.add_all(subscriptions)

# =============================================================================
# Create Reservations
# =============================================================================
print("\n📅 Creating Reservations...")

with get_session(engine) as session:
    experience_ids = [
        exp.experience_id
        for exp in session.query(cultpass.Experience).all()
    ]
    
    # Create 2 reservations for the first user
    reservation1 = cultpass.Reservation(
        reservation_id=str(uuid.uuid4())[:6],
        user_id=cultpass_users[0]["id"],
        experience_id=random.choice(experience_ids),
        status="reserved",
    )
    reservation2 = cultpass.Reservation(
        reservation_id=str(uuid.uuid4())[:6],
        user_id=cultpass_users[0]["id"],
        experience_id=random.choice(experience_ids),
        status="reserved",
    )
    session.add_all([reservation1, reservation2])
    
    # Add some reservations for other users too
    for user_info in cultpass_users[1:4]:
        res = cultpass.Reservation(
            reservation_id=str(uuid.uuid4())[:6],
            user_id=user_info["id"],
            experience_id=random.choice(experience_ids),
            status=random.choice(["reserved", "attended", "cancelled"]),
        )
        session.add(res)

# =============================================================================
# Tests - Verify the data
# =============================================================================
print("\n" + "=" * 60)
print("Verification Tests")
print("=" * 60)

print("\n📋 Users:")
with get_session(engine) as session:
    users = session.query(cultpass.User).all()
    for user in users:
        print(user)

print("\n💳 Subscriptions:")
with get_session(engine) as session:
    users = session.query(cultpass.User).all()
    for user in users:
        print(user.subscription)

print("\n📍 Experiences:")
with get_session(engine) as session:
    experiences = session.query(cultpass.Experience).all()
    for experience in experiences:
        print(experience)

print("\n📅 Reservations:")
with get_session(engine) as session:
    reservations = session.query(cultpass.Reservation).all()
    for res in reservations:
        print(res)

print("\n✅ CultPass database setup complete!")
