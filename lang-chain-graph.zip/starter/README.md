# UDA-Hub: Universal Decision Agent for Customer Support

A multi-agent customer support system built with LangGraph for CultPass, a cultural experiences subscription service.

## Project Title

UDA-Hub (Universal Decision Agent Hub) - Intelligent Support Ticket Resolution System

## Project Description

UDA-Hub is a LangGraph-powered multi-agent system that:
- **Understands** customer support tickets through intelligent classification
- **Routes** tickets to the appropriate handling flow
- **Resolves** common issues using RAG (Retrieval Augmented Generation)
- **Escalates** complex issues to human agents when needed
- **Maintains** conversation context through short-term memory

### RAG Implementation

This project uses **semantic search** for knowledge retrieval:

```
User Query → OpenAI Embeddings → Chroma Vector Search → Top 3 Articles → LLM Response
```

**Why RAG?**
- Semantic understanding (not just keyword matching)
- "I can't get in" matches "login issues" even without exact words
- Better accuracy for natural language queries

## Getting Started

### Prerequisites

- Python 3.10+
- OpenAI API key

### Dependencies

```bash
pip install -r requirements.txt
```

Key dependencies:
- `langchain` & `langchain-openai` - LLM framework
- `langchain-chroma` & `chromadb` - Vector store for RAG
- `langgraph` - Multi-agent orchestration
- `sqlalchemy` - Database ORM
- `python-dotenv` - Environment management

### Installation

1. Clone the repository
2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env` and add your OpenAI API key:
   ```bash
   cp .env.example .env
   # Edit .env and add your OPENAI_API_KEY
   ```
5. Initialize the databases:
   ```bash
   python 01_external_db_setup.py
   python 02_core_db_setup.py
   ```
   **Note**: The second script creates the Chroma vector store with embeddings.
   
6. Run the application:
   ```bash
   # Option 1: Python script (command line chat)
   python 03_agentic_app.py
   
   # Option 2: Jupyter notebook (recommended for testing)
   jupyter notebook 03_agentic_app.ipynb
   ```

## Using the Notebook

The `03_agentic_app.ipynb` notebook is the best way to test and understand the system. It includes:

1. **Setup & Imports** - Load environment and orchestrator
2. **Simple Questions** - Test resolver path (login, subscription, reservations)
3. **Escalation Tests** - Test blocked accounts and human requests
4. **RAG Semantic Search** - Test that "I can't get in" finds login articles
5. **Conversation Memory** - Test context retention across messages
6. **Individual Agents** - Test classifier, resolver, escalation separately
7. **Interactive Chat** - Have a live conversation with the agent
8. **Workflow Visualization** - See the LangGraph structure

## Testing

### Running Tests

```bash
python -m pytest tests/ -v
```

Or run directly:
```bash
python tests/test_agents.py
```

### Test Breakdown

- **TestClassifierAgent**: Tests ticket classification accuracy
  - Login issues → `login_access`
  - Blocked accounts → triggers escalation
  - Human requests → triggers escalation
  
- **TestRAGRetrieval**: Tests semantic search with Chroma
  - "I forgot my password" → finds login articles
  - "I want my money back" → finds refund articles
  - Relevance scores included in results
  
- **TestResolverAgent**: Tests response generation
  - With knowledge context
  - Without context (graceful handling)
  
- **TestEscalationAgent**: Tests escalation responses
  - Blocked account handling
  - Explicit human requests
  
- **TestWorkflowIntegration**: End-to-end tests
  - Simple query flow
  - Escalation flow
  - RAG integration in full workflow

## Project Architecture

```
starter/
├── agentic/
│   ├── agents/           # Individual agent implementations
│   │   ├── classifier.py # Ticket classification
│   │   ├── resolver.py   # Knowledge-based resolution
│   │   └── escalation.py # Human handoff
│   ├── design/           # System documentation
│   │   └── SYSTEM_DESIGN.md
│   ├── tools/            # Database and RAG tools
│   │   ├── db_tools.py   # User lookup tools
│   │   └── rag_tools.py  # Chroma + OpenAI RAG
│   └── workflow.py       # LangGraph orchestration
├── data/
│   ├── core/             # UDA-Hub database + Chroma
│   │   └── chroma_db/    # Vector embeddings
│   ├── external/         # CultPass database
│   └── models/           # SQLAlchemy models
├── tests/                # Test suite
├── 01_external_db_setup.py   # Setup CultPass DB
├── 02_core_db_setup.py       # Setup UDA-Hub DB + RAG
├── 03_agentic_app.py         # CLI chat interface
├── 03_agentic_app.ipynb      # Jupyter notebook (recommended)
├── utils.py
├── .env                      # Your API key (create from .env.example)
└── requirements.txt
```

## How It Works

1. **User sends message** → Enters the workflow
2. **Classifier Agent** analyzes and categorizes the ticket
3. **Router** decides: resolve or escalate?
4. **Resolution path**: 
   - Query embedded with OpenAI
   - Chroma finds similar articles
   - Top 3 articles passed to resolver
   - LLM generates response
5. **Escalation path**: Acknowledge → Hand off to human
6. **Response** returned to user

## RAG Details

### Embedding Model
- **Model**: OpenAI `text-embedding-ada-002`
- **Dimensions**: 1536
- **Cost**: ~$0.0001 per 1K tokens

### Vector Store
- **Database**: Chroma
- **Persistence**: `data/core/chroma_db/`
- **Collection**: `knowledge_base`

### Retrieval
- **Method**: Cosine similarity
- **Top-K**: 3 articles
- **Scoring**: High (<0.5), Medium (<0.8), Low (>0.8)

## Built With

- [LangGraph](https://github.com/langchain-ai/langgraph) - Multi-agent orchestration
- [LangChain](https://github.com/langchain-ai/langchain) - LLM application framework
- [Chroma](https://www.trychroma.com/) - Vector database for RAG
- [OpenAI](https://openai.com/) - GPT-4o-mini & Embeddings
- [SQLAlchemy](https://www.sqlalchemy.org/) - Database ORM
- [SQLite](https://www.sqlite.org/) - Relational database

## Key Features

- **No Prebuilt Agents**: Custom StateGraph built from scratch
- **RAG with Chroma**: Semantic search using OpenAI embeddings
- **Automatic Escalation**: Blocked accounts and human requests route to support
- **Session Memory**: Conversation context maintained via thread_id
- **Modular Design**: Easy to add new agents or modify workflow
- **14 Knowledge Articles**: Covers login, billing, reservations, technical issues
