# 02_core_db_setup.py
# Setup script for UDA-Hub core database
# Run this after 01_external_db_setup.py

import json
import uuid
from sqlalchemy import create_engine

from utils import reset_db, get_session, model_to_dict
from data.models import udahub

# =============================================================================
# Udahub Application - Core Database
# =============================================================================

print("=" * 60)
print("Setting up UDA-Hub Core Database")
print("=" * 60)

# Initialize database
udahub_db = "data/core/udahub.db"
reset_db(udahub_db)

engine = create_engine(f"sqlite:///{udahub_db}", echo=False)
udahub.Base.metadata.create_all(engine)

# =============================================================================
# Create Account
# =============================================================================
print("\n🏢 Creating Account...")

account_id = "cultpass"
account_name = "CultPass Card"

with get_session(engine) as session:
    account = udahub.Account(
        account_id=account_id,
        account_name=account_name,
    )
    session.add(account)

# =============================================================================
# Integrations - Knowledge Base
# =============================================================================
print("\n📚 Loading Knowledge Base Articles...")

cultpass_articles = []
with open('data/external/cultpass_articles.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        cultpass_articles.append(json.loads(line))

print(f"Loaded {len(cultpass_articles)} articles")

# Verify we have at least 14 articles
if len(cultpass_articles) < 14:
    raise AssertionError("You should load the articles with at least 14 records")

with get_session(engine) as session:
    kb = []
    for article in cultpass_articles:
        knowledge = udahub.Knowledge(
            article_id=str(uuid.uuid4()),
            account_id=account_id,
            title=article["title"],
            content=article["content"],
            tags=article["tags"]
        )
        kb.append(knowledge)
    session.add_all(kb)

# =============================================================================
# Initialize RAG Vector Store (Chroma + OpenAI Embeddings)
# =============================================================================
print("\n🔍 Initializing RAG Vector Store...")
print("   - Using OpenAI embeddings (text-embedding-ada-002)")
print("   - Storing in Chroma vector database")

from agentic.tools.rag_tools import initialize_vector_store

# Initialize vector store with the articles
# This creates embeddings and stores them in Chroma
initialize_vector_store(cultpass_articles)

print("   - Semantic search is now enabled!")

# =============================================================================
# Create Sample Ticket
# =============================================================================
print("\n🎫 Creating Sample Ticket...")

# Load cultpass users for reference
cultpass_users = []
with open('data/external/cultpass_users.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        cultpass_users.append(json.loads(line))

# Sample ticket data
ticket_info = {
    "status": "open",
    "content": "I can't log in to my Cultpass account.",
    "owner_id": cultpass_users[0]["id"],
    "owner_name": cultpass_users[0]["name"],
    "role": "user",
    "channel": "chat",
    "tags": "login, access",
}

with get_session(engine) as session:
    # Create or get user
    user = session.query(udahub.User).filter_by(
        account_id=account_id,
        external_user_id=ticket_info["owner_id"],
    ).first()
    
    if not user:
        user = udahub.User(
            user_id=str(uuid.uuid4()),
            account_id=account_id,
            external_user_id=ticket_info["owner_id"],
            user_name=ticket_info["owner_name"],
        )
    
    # Create ticket
    ticket = udahub.Ticket(
        ticket_id=str(uuid.uuid4()),
        account_id=account_id,
        user_id=user.user_id,
        channel=ticket_info["channel"],
    )
    
    # Create metadata
    metadata = udahub.TicketMetadata(
        ticket_id=ticket.ticket_id,
        status=ticket_info["status"],
        main_issue_type=None,
        tags=ticket_info["tags"],
    )
    
    # Create first message
    first_message = udahub.TicketMessage(
        message_id=str(uuid.uuid4()),
        ticket_id=ticket.ticket_id,
        role=udahub.RoleEnum.user,
        content=ticket_info["content"],
    )
    
    session.add_all([user, ticket, metadata, first_message])

# =============================================================================
# Tests - Verify the data
# =============================================================================
print("\n" + "=" * 60)
print("Verification Tests")
print("=" * 60)

print("\n🏢 Account:")
with get_session(engine) as session:
    account = session.query(udahub.Account).filter_by(
        account_id=account_id
    ).first()
    print(account)

print("\n📚 Knowledge Articles:")
with get_session(engine) as session:
    account = session.query(udahub.Account).filter_by(
        account_id=account_id
    ).first()
    for article in account.knowledge_articles:
        print(article)

print("\n👤 Users:")
with get_session(engine) as session:
    users = session.query(udahub.User).all()
    for user in users:
        print(user)

print("\n🎫 Tickets:")
with get_session(engine) as session:
    user = session.query(udahub.User).filter_by(
        account_id=account_id,
        external_user_id=ticket_info["owner_id"],
    ).first()
    
    ticket = user.tickets[0]
    print(f"Ticket: {ticket}")
    print(f"Metadata: {ticket.ticket_metadata}")
    for message in ticket.messages:
        print(f"Message: {message}")

print("\n✅ UDA-Hub database setup complete!")
