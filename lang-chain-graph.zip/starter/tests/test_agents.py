# tests/test_agents.py
# Test cases for UDA-Hub multi-agent system

import os
import sys
import unittest

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

from agentic.agents.classifier import classify_ticket, ISSUE_CATEGORIES
from agentic.agents.resolver import generate_response
from agentic.agents.escalation import generate_escalation_response


class TestClassifierAgent(unittest.TestCase):
    """Tests for the Classifier Agent."""
    
    @classmethod
    def setUpClass(cls):
        cls.model = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    def test_login_classification(self):
        """Test that login issues are classified correctly."""
        result = classify_ticket("I can't log into my account", self.model)
        self.assertEqual(result["category"], "login_access")
        self.assertFalse(result["needs_escalation"])
    
    def test_subscription_classification(self):
        """Test that subscription questions are classified correctly."""
        result = classify_ticket("What's included in my subscription?", self.model)
        self.assertEqual(result["category"], "subscription")
        self.assertFalse(result["needs_escalation"])
    
    def test_blocked_account_escalation(self):
        """Test that blocked accounts trigger escalation."""
        result = classify_ticket("My account is blocked and I can't access it", self.model)
        self.assertEqual(result["category"], "account_blocked")
        self.assertTrue(result["needs_escalation"])
    
    def test_human_request_escalation(self):
        """Test that human requests trigger escalation."""
        result = classify_ticket("I want to speak to a human agent please", self.model)
        self.assertEqual(result["category"], "escalation")
        self.assertTrue(result["needs_escalation"])
    
    def test_billing_classification(self):
        """Test that billing issues are classified correctly."""
        result = classify_ticket("I need a refund for last month", self.model)
        self.assertEqual(result["category"], "billing")
        self.assertFalse(result["needs_escalation"])
    
    def test_reservation_classification(self):
        """Test that reservation questions are classified correctly."""
        result = classify_ticket("How do I cancel my reservation?", self.model)
        self.assertEqual(result["category"], "reservation")
        self.assertFalse(result["needs_escalation"])


class TestRAGRetrieval(unittest.TestCase):
    """Tests for RAG-based knowledge retrieval using Chroma + OpenAI embeddings."""
    
    def test_semantic_search_login(self):
        """Test semantic search finds login-related articles."""
        from agentic.tools.rag_tools import search_knowledge_base
        
        result = search_knowledge_base.invoke("I forgot my password and can't get in")
        
        # Should find login-related article
        self.assertIn("login", result.lower())
        self.assertIn("password", result.lower())
    
    def test_semantic_search_subscription(self):
        """Test semantic search finds subscription articles."""
        from agentic.tools.rag_tools import search_knowledge_base
        
        result = search_knowledge_base.invoke("what do I get with my membership")
        
        # Should find subscription/benefits article
        self.assertTrue(
            "subscription" in result.lower() or 
            "included" in result.lower() or
            "experiences" in result.lower()
        )
    
    def test_semantic_search_refund(self):
        """Test semantic search finds billing/refund articles."""
        from agentic.tools.rag_tools import search_knowledge_base
        
        result = search_knowledge_base.invoke("I want my money back")
        
        # Should find refund-related article
        self.assertTrue(
            "refund" in result.lower() or 
            "billing" in result.lower()
        )
    
    def test_semantic_search_returns_relevance(self):
        """Test that search results include relevance indicators."""
        from agentic.tools.rag_tools import search_knowledge_base
        
        result = search_knowledge_base.invoke("how to book an event")
        
        # Should have relevance scores
        self.assertIn("Relevance:", result)
    
    def test_category_based_search(self):
        """Test category-based RAG search."""
        from agentic.tools.rag_tools import search_knowledge_by_category
        
        result = search_knowledge_by_category.invoke("technical")
        
        # Should find technical articles
        self.assertTrue(
            "app" in result.lower() or 
            "crash" in result.lower() or
            "technical" in result.lower()
        )


class TestResolverAgent(unittest.TestCase):
    """Tests for the Resolver Agent."""
    
    @classmethod
    def setUpClass(cls):
        cls.model = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    def test_response_with_context(self):
        """Test that resolver generates response with knowledge context."""
        response = generate_response(
            user_message="How do I reset my password?",
            category="login_access",
            knowledge_context="Most login issues are resolved with password reset. Ask user to tap 'Forgot Password'.",
            user_context="",
            model=self.model
        )
        self.assertIsInstance(response, str)
        self.assertGreater(len(response), 50)  # Should be a substantial response
    
    def test_response_without_context(self):
        """Test that resolver handles missing context gracefully."""
        response = generate_response(
            user_message="Random question",
            category="general_inquiry",
            knowledge_context="",
            user_context="",
            model=self.model
        )
        self.assertIsInstance(response, str)


class TestEscalationAgent(unittest.TestCase):
    """Tests for the Escalation Agent."""
    
    @classmethod
    def setUpClass(cls):
        cls.model = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    def test_blocked_account_escalation(self):
        """Test escalation response for blocked accounts."""
        response = generate_escalation_response(
            user_message="My account is blocked",
            reason="account_blocked",
            user_context="User: John Doe, Email: john@example.com",
            model=self.model
        )
        self.assertIsInstance(response, str)
        # Should mention human support or agent
        self.assertTrue(
            any(word in response.lower() for word in ["human", "agent", "team", "support"])
        )
    
    def test_explicit_human_request(self):
        """Test escalation for explicit human requests."""
        response = generate_escalation_response(
            user_message="I want to talk to a real person",
            reason="escalation",
            user_context="",
            model=self.model
        )
        self.assertIsInstance(response, str)


class TestWorkflowIntegration(unittest.TestCase):
    """Integration tests for the complete workflow."""
    
    @classmethod
    def setUpClass(cls):
        # Import here to ensure databases are set up
        from agentic.workflow import orchestrator
        cls.orchestrator = orchestrator
    
    def test_simple_query_flow(self):
        """Test end-to-end flow for a simple query."""
        result = self.orchestrator.invoke(
            input={"messages": [HumanMessage(content="How do I reserve an event?")]},
            config={"configurable": {"thread_id": "test-1"}}
        )
        
        # Should have messages in the result
        self.assertIn("messages", result)
        self.assertGreater(len(result["messages"]), 0)
        
        # Last message should be an AI response
        last_message = result["messages"][-1]
        self.assertIsInstance(last_message.content, str)
    
    def test_escalation_flow(self):
        """Test that escalation requests flow correctly."""
        result = self.orchestrator.invoke(
            input={"messages": [HumanMessage(content="I want to speak with a human")]},
            config={"configurable": {"thread_id": "test-2"}}
        )
        
        last_message = result["messages"][-1]
        # Should mention connecting to human/agent
        self.assertTrue(
            any(word in last_message.content.lower() for word in ["human", "agent", "team"])
        )
    
    def test_rag_integration_in_workflow(self):
        """Test that RAG retrieval is working in the full workflow."""
        result = self.orchestrator.invoke(
            input={"messages": [HumanMessage(content="What happens if my QR code doesn't scan at the venue?")]},
            config={"configurable": {"thread_id": "test-3"}}
        )
        
        last_message = result["messages"][-1]
        # Should provide relevant information about QR codes
        self.assertTrue(
            any(word in last_message.content.lower() for word in ["qr", "scan", "venue", "brightness"])
        )


if __name__ == "__main__":
    print("=" * 60)
    print("Running UDA-Hub Test Suite")
    print("=" * 60)
    print()
    
    # Run tests
    unittest.main(verbosity=2)
