import chromadb
from chromadb.config import Settings
from typing import Dict, List, Optional
from pathlib import Path


def discover_chroma_backends() -> Dict[str, Dict[str, str]]:
    """Discover available ChromaDB backends in the project directory."""
    backends = {}
    current_dir = Path(".")
    
    # TODO: Create list of directories that match specific criteria
    chroma_dirs = [d for d in current_dir.iterdir() 
                   if d.is_dir() and d.name.startswith("chroma")]
    
    # TODO: Loop through each discovered directory
    for chroma_dir in chroma_dirs:
        # TODO: Wrap connection attempt in try-except block
        try:
            # TODO: Initialize database client with directory path
            client = chromadb.PersistentClient(
                path=str(chroma_dir),
                settings=Settings(anonymized_telemetry=False)
            )
            
            # TODO: Retrieve list of available collections
            collections = client.list_collections()
            
            # TODO: Loop through each collection found
            for collection in collections:
                # TODO: Create unique identifier key
                key = f"{chroma_dir.name}_{collection.name}"
                
                # TODO: Build information dictionary
                try:
                    doc_count = collection.count()
                except:
                    doc_count = "N/A"
                
                # TODO: Add collection information to backends dictionary
                backends[key] = {
                    "directory": str(chroma_dir),
                    "collection_name": collection.name,
                    "display_name": f"{collection.name} ({chroma_dir.name})",
                    "document_count": doc_count
                }
                
        # TODO: Handle connection or access errors gracefully
        except Exception as e:
            backends[chroma_dir.name] = {
                "directory": str(chroma_dir),
                "collection_name": "unknown",
                "display_name": f"{chroma_dir.name} (Error: {str(e)[:50]})",
                "document_count": "N/A"
            }
    
    # TODO: Return complete backends dictionary
    return backends


def initialize_rag_system(chroma_dir: str, collection_name: str):
    """Initialize the RAG system with specified backend."""
    
    # TODO: Create a chromadb persistentclient
    client = chromadb.PersistentClient(
        path=chroma_dir,
        settings=Settings(anonymized_telemetry=False)
    )
    
    # TODO: Return the collection with the collection_name
    collection = client.get_collection(name=collection_name)
    
    return collection, True, None


def retrieve_documents(collection, query: str, n_results: int = 3,
                       mission_filter: Optional[str] = None) -> Optional[Dict]:
    """Retrieve relevant documents from ChromaDB with optional filtering."""
    
    # TODO: Initialize filter variable to None
    where_filter = None
    
    # TODO: Check if filter parameter exists and is not set to "all"
    if mission_filter and mission_filter.lower() != "all":
        # TODO: Create filter dictionary with appropriate field-value pairs
        where_filter = {"mission": mission_filter}
    
    # TODO: Execute database query with the following parameters
    results = collection.query(
        query_texts=[query],
        n_results=n_results,
        where=where_filter
    )
    
    # TODO: Return query results to caller
    return results


def format_context(documents: List[str], metadatas: List[Dict]) -> str:
    """Format retrieved documents into context."""
    if not documents:
        return ""
    
    # TODO: Initialize list with header text for context section
    context_parts = ["=== Relevant NASA Documents ===\n"]
    
    # TODO: Loop through paired documents and their metadata using enumeration
    for i, (doc, metadata) in enumerate(zip(documents, metadatas)):
        # TODO: Extract mission information from metadata with fallback value
        mission = metadata.get("mission", "Unknown")
        # TODO: Clean up mission name formatting
        mission = mission.replace("_", " ").title()
        
        # TODO: Extract source information from metadata with fallback value
        source = metadata.get("source", "Unknown")
        
        # TODO: Extract category information from metadata with fallback value
        category = metadata.get("document_category", "Document")
        # TODO: Clean up category name formatting
        category = category.replace("_", " ").title()
        
        # TODO: Create formatted source header with index number
        source_header = f"\n[Source {i+1}] Mission: {mission} | Type: {category} | File: {source}"
        # TODO: Add source header to context parts list
        context_parts.append(source_header)
        context_parts.append("-" * 50)
        
        # TODO: Check document length and truncate if necessary
        if len(doc) > 1500:
            doc = doc[:1500] + "... [truncated]"
        
        # TODO: Add truncated or full document content to context parts list
        context_parts.append(doc)
        context_parts.append("")
    
    # TODO: Join all context parts with newlines and return formatted string
    return "\n".join(context_parts)
