#!/usr/bin/env python3
"""
ChromaDB Embedding Pipeline for NASA Space Mission Data - Text Files Only

This script reads parsed text data from various NASA space mission folders and creates
a permanent ChromaDB collection with OpenAI embeddings for RAG applications.
"""

import os
import logging
from pathlib import Path
from typing import Dict, List, Any, Tuple
import chromadb
from chromadb.config import Settings
from openai import OpenAI
import time
from datetime import datetime
import argparse
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('embedding_pipeline.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class ChromaEmbeddingPipelineTextOnly:
    """Pipeline for creating ChromaDB collections with OpenAI embeddings."""
    
    def __init__(self,
                 openai_api_key: str,
                 chroma_persist_directory: str = "./chroma_db",
                 collection_name: str = "nasa_space_missions_text",
                 embedding_model: str = "text-embedding-3-small",
                 chunk_size: int = 1000,
                 chunk_overlap: int = 200):
        """Initialize the embedding pipeline."""
        
        # TODO: Initialize OpenAI client
        self.openai_client = OpenAI(api_key=openai_api_key)
        
        # TODO: Store configuration parameters
        self.embedding_model = embedding_model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
        # TODO: Initialize ChromaDB client
        self.chroma_client = chromadb.PersistentClient(
            path=chroma_persist_directory,
            settings=Settings(anonymized_telemetry=False)
        )
        
        # TODO: Create or get collection
        embedding_function = OpenAIEmbeddingFunction(
            api_key=openai_api_key,
            model_name=embedding_model
        )
        
        self.collection = self.chroma_client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_function,
            metadata={"description": "NASA Space Mission Documents"}
        )
        
        logger.info(f"Initialized pipeline with collection: {collection_name}")
    
    def chunk_text(self, text: str, metadata: Dict[str, Any]) -> List[Tuple[str, Dict[str, Any]]]:
        """Split text into chunks with metadata."""
        
        # TODO: Handle short texts that don't need chunking
        if len(text) <= self.chunk_size:
            chunk_metadata = metadata.copy()
            chunk_metadata["chunk_index"] = 0
            chunk_metadata["total_chunks"] = 1
            return [(text, chunk_metadata)]
        
        chunks = []
        start = 0
        chunk_index = 0
        
        # TODO: Implement chunking logic with overlap
        while start < len(text):
            end = start + self.chunk_size
            
            # TODO: Try to break at sentence boundaries
            if end < len(text):
                for i in range(min(100, end - start), 0, -1):
                    if end - i < len(text) and text[end - i] in '.!?\n':
                        end = end - i + 1
                        break
            
            chunk_text = text[start:end].strip()
            
            if chunk_text:
                # TODO: Create metadata for each chunk
                chunk_metadata = metadata.copy()
                chunk_metadata["chunk_index"] = chunk_index
                chunk_metadata["chunk_start"] = start
                chunk_metadata["chunk_end"] = end
                
                chunks.append((chunk_text, chunk_metadata))
                chunk_index += 1
            
            start = end - self.chunk_overlap
        
        for i, (chunk_text, chunk_meta) in enumerate(chunks):
            chunk_meta["total_chunks"] = len(chunks)
        
        return chunks
    
    def check_document_exists(self, doc_id: str) -> bool:
        """Check if a document with the given ID already exists."""
        # TODO: Query collection for document ID
        try:
            results = self.collection.get(ids=[doc_id])
            # TODO: Return True if exists, False otherwise
            return len(results['ids']) > 0
        except Exception:
            return False
    
    def get_embedding(self, text: str) -> List[float]:
        """Get OpenAI embedding for text."""
        # TODO: Call OpenAI embeddings API
        try:
            response = self.openai_client.embeddings.create(
                input=text,
                model=self.embedding_model
            )
            # TODO: Return embedding vector
            return response.data[0].embedding
        # TODO: Add error handling
        except Exception as e:
            logger.error(f"Error getting embedding: {e}")
            raise
    
    def generate_document_id(self, file_path: Path, metadata: Dict[str, Any]) -> str:
        """Generate stable document ID based on file path and chunk position."""
        # TODO: Create consistent ID format
        # TODO: Use mission, source, and chunk_index
        mission = metadata.get('mission', 'unknown')
        source = metadata.get('source', 'unknown')
        chunk_index = metadata.get('chunk_index', 0)
        return f"{mission}_{source}_chunk_{chunk_index:04d}"
    
    def process_text_file(self, file_path: Path) -> List[Tuple[str, Dict[str, Any]]]:
        """Process plain text files with enhanced metadata extraction."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if not content.strip():
                return []
            
            metadata = {
                'source': file_path.stem,
                'file_path': str(file_path),
                'file_type': 'text',
                'mission': self.extract_mission_from_path(file_path),
                'data_type': self.extract_data_type_from_path(file_path),
                'document_category': self.extract_document_category_from_filename(file_path.name),
                'file_size': len(content),
                'processed_timestamp': datetime.now().isoformat()
            }
            
            return self.chunk_text(content, metadata)
            
        except Exception as e:
            logger.error(f"Error processing text file {file_path}: {e}")
            return []
    
    def extract_mission_from_path(self, file_path: Path) -> str:
        """Extract mission name from file path."""
        path_str = str(file_path).lower()
        if 'apollo11' in path_str or 'apollo_11' in path_str:
            return 'apollo_11'
        elif 'apollo13' in path_str or 'apollo_13' in path_str:
            return 'apollo_13'
        elif 'challenger' in path_str:
            return 'challenger'
        return 'unknown'
    
    def extract_data_type_from_path(self, file_path: Path) -> str:
        """Extract data type from file path."""
        path_str = str(file_path).lower()
        if 'transcript' in path_str:
            return 'transcript'
        elif 'audio' in path_str:
            return 'audio_transcript'
        elif 'flight_plan' in path_str:
            return 'flight_plan'
        return 'document'
    
    def extract_document_category_from_filename(self, filename: str) -> str:
        """Extract document category from filename."""
        filename_lower = filename.lower()
        if 'pao' in filename_lower:
            return 'public_affairs_officer'
        elif 'cm' in filename_lower:
            return 'command_module'
        elif 'tec' in filename_lower:
            return 'technical'
        elif 'flight_plan' in filename_lower:
            return 'flight_plan'
        elif 'mission_audio' in filename_lower:
            return 'mission_audio'
        return 'general_document'
    
    def scan_text_files_only(self, base_path: str) -> List[Path]:
        """Scan data directories for text files only."""
        base_path = Path(base_path)
        files_to_process = []
        
        data_dirs = ['apollo11', 'apollo13', 'challenger']
        
        for data_dir in data_dirs:
            dir_path = base_path / data_dir
            if dir_path.exists():
                logger.info(f"Scanning directory: {dir_path}")
                text_files = list(dir_path.glob('**/*.txt'))
                files_to_process.extend(text_files)
                logger.info(f"Found {len(text_files)} text files in {data_dir}")
        
        filtered_files = []
        for file_path in files_to_process:
            if (file_path.name.startswith('.') or
                'summary' in file_path.name.lower() or
                file_path.suffix.lower() != '.txt'):
                continue
            filtered_files.append(file_path)
        
        logger.info(f"Total text files to process: {len(filtered_files)}")
        return filtered_files
    
    def add_documents_to_collection(self, documents: List[Tuple[str, Dict[str, Any]]],
                                    file_path: Path, batch_size: int = 50,
                                    update_mode: str = 'skip') -> Dict[str, int]:
        """Add documents to ChromaDB collection in batches."""
        if not documents:
            return {'added': 0, 'updated': 0, 'skipped': 0}
        
        stats = {'added': 0, 'updated': 0, 'skipped': 0}
        
        # TODO: Handle different update modes (skip, update, replace)
        # TODO: Process documents in batches
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            
            batch_ids = []
            batch_texts = []
            batch_metadatas = []
            
            # TODO: For each document:
            for text, metadata in batch:
                # - Generate document ID
                doc_id = self.generate_document_id(file_path, metadata)
                
                # - Check if exists
                exists = self.check_document_exists(doc_id)
                
                if exists and update_mode == 'skip':
                    stats['skipped'] += 1
                else:
                    batch_ids.append(doc_id)
                    batch_texts.append(text)
                    batch_metadatas.append(metadata)
            
            if batch_ids:
                try:
                    self.collection.add(
                        ids=batch_ids,
                        documents=batch_texts,
                        metadatas=batch_metadatas
                    )
                    stats['added'] += len(batch_ids)
                except Exception as e:
                    logger.error(f"Error adding batch: {e}")
        
        # TODO: Return statistics
        return stats
    
    def process_all_text_data(self, base_path: str, update_mode: str = 'skip') -> Dict[str, int]:
        """Process all text files and add to ChromaDB."""
        stats = {
            'files_processed': 0,
            'documents_added': 0,
            'documents_skipped': 0,
            'errors': 0,
            'total_chunks': 0,
            'missions': {}
        }
        
        # TODO: Get files to process
        files = self.scan_text_files_only(base_path)
        
        # TODO: Loop through each file
        for file_path in files:
            try:
                logger.info(f"Processing: {file_path}")
                
                # TODO: Process file and add to collection
                documents = self.process_text_file(file_path)
                
                if documents:
                    file_stats = self.add_documents_to_collection(
                        documents, file_path, update_mode=update_mode
                    )
                    
                    # TODO: Update statistics
                    stats['files_processed'] += 1
                    stats['documents_added'] += file_stats['added']
                    stats['documents_skipped'] += file_stats['skipped']
                    stats['total_chunks'] += len(documents)
                    
                    mission = self.extract_mission_from_path(file_path)
                    if mission not in stats['missions']:
                        stats['missions'][mission] = {'files': 0, 'chunks': 0}
                    stats['missions'][mission]['files'] += 1
                    stats['missions'][mission]['chunks'] += len(documents)
                    
            # TODO: Handle errors gracefully
            except Exception as e:
                logger.error(f"Error processing {file_path}: {e}")
                stats['errors'] += 1
        
        return stats
    
    def get_collection_info(self) -> Dict[str, Any]:
        """Get information about the ChromaDB collection."""
        # TODO: Return collection name, document count, metadata
        try:
            return {
                'collection_name': self.collection.name,
                'document_count': self.collection.count(),
                'metadata': self.collection.metadata
            }
        except Exception as e:
            return {'error': str(e)}
    
    def query_collection(self, query_text: str, n_results: int = 5) -> Dict[str, Any]:
        """Query the collection for testing."""
        # TODO: Perform test query and return results
        try:
            return self.collection.query(
                query_texts=[query_text],
                n_results=n_results
            )
        except Exception as e:
            return {'error': str(e)}


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='ChromaDB Embedding Pipeline for NASA Data')
    parser.add_argument('--data-path', default='.', help='Path to data directories')
    parser.add_argument('--openai-key', required=True, help='OpenAI API key')
    parser.add_argument('--chroma-dir', default='./chroma_db_openai', help='ChromaDB persist directory')
    parser.add_argument('--collection-name', default='nasa_space_missions_text', help='Collection name')
    parser.add_argument('--chunk-size', type=int, default=500, help='Text chunk size')
    parser.add_argument('--chunk-overlap', type=int, default=100, help='Chunk overlap size')
    parser.add_argument('--update-mode', choices=['skip', 'update', 'replace'], default='skip')
    parser.add_argument('--test-query', help='Test query after processing')
    parser.add_argument('--stats-only', action='store_true', help='Only show collection statistics')
    
    args = parser.parse_args()
    
    logger.info("Initializing ChromaDB Embedding Pipeline...")
    pipeline = ChromaEmbeddingPipelineTextOnly(
        openai_api_key=args.openai_key,
        chroma_persist_directory=args.chroma_dir,
        collection_name=args.collection_name,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap
    )
    
    if args.stats_only:
        logger.info("Collection Statistics:")
        info = pipeline.get_collection_info()
        for key, value in info.items():
            logger.info(f"{key}: {value}")
        return
    
    logger.info(f"Starting text data processing with update mode: {args.update_mode}")
    start_time = time.time()
    
    stats = pipeline.process_all_text_data(args.data_path, update_mode=args.update_mode)
    
    processing_time = time.time() - start_time
    
    logger.info("=" * 60)
    logger.info("PROCESSING COMPLETE")
    logger.info("=" * 60)
    logger.info(f"Files processed: {stats['files_processed']}")
    logger.info(f"Total chunks created: {stats['total_chunks']}")
    logger.info(f"Documents added: {stats['documents_added']}")
    logger.info(f"Documents skipped: {stats['documents_skipped']}")
    logger.info(f"Errors: {stats['errors']}")
    logger.info(f"Processing time: {processing_time:.2f} seconds")
    
    logger.info("\nMission breakdown:")
    for mission, mission_stats in stats['missions'].items():
        logger.info(f"  {mission}: {mission_stats['files']} files, {mission_stats['chunks']} chunks")
    
    collection_info = pipeline.get_collection_info()
    logger.info(f"\nCollection: {collection_info.get('collection_name', 'N/A')}")
    logger.info(f"Total documents in collection: {collection_info.get('document_count', 'N/A')}")
    
    if args.test_query:
        logger.info(f"\nTesting query: '{args.test_query}'")
        results = pipeline.query_collection(args.test_query)
        if results and 'documents' in results:
            logger.info(f"Found {len(results['documents'][0])} results:")
            for i, doc in enumerate(results['documents'][0][:3]):
                logger.info(f"Result {i+1}: {doc[:200]}...")
    
    logger.info("Pipeline completed successfully!")


if __name__ == "__main__":
    main()
