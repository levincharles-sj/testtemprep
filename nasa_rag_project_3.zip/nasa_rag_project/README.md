# NASA RAG Chat System - Implementation Guide

A Retrieval-Augmented Generation (RAG) system for NASA space mission data with real-time evaluation.

---

## Quick Start

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 2: Set Your OpenAI API Key

```bash
export OPENAI_API_KEY="your-api-key-here"
```

### Step 3: Run the Embedding Pipeline

Process NASA documents and create the ChromaDB database:

```bash
python embedding_pipeline.py --openai-key $OPENAI_API_KEY --data-path ./data
```

### Step 4: Launch the Chat Interface

```bash
streamlit run chat.py
```

Open http://localhost:8501 in your browser.

---

## File Overview

| File | Purpose |
|------|---------|
| `llm_client.py` | Connects to OpenAI API, manages conversation |
| `rag_client.py` | Handles ChromaDB retrieval and document formatting |
| `embedding_pipeline.py` | Processes documents, creates embeddings |
| `ragas_evaluator.py` | Evaluates response quality |
| `chat.py` | Streamlit web interface (pre-built) |

---

## How Each File Works

### 1. llm_client.py

**What it does:** Takes a question + context → sends to OpenAI → returns answer

**Key TODOs implemented:**
- Define system prompt with NASA expert persona
- Set context from retrieved documents in messages
- Add conversation history for follow-up questions
- Create OpenAI client and send request
- Return the response text

**The flow:**
```
User Question + Retrieved Documents + Chat History
                    ↓
              System Prompt (NASA Expert)
                    ↓
              OpenAI API Call
                    ↓
              Answer Text
```

### 2. rag_client.py

**What it does:** Finds relevant documents from ChromaDB using semantic search

**Key TODOs implemented:**
- Discover available ChromaDB collections
- Initialize RAG system with database connection
- Retrieve documents with optional mission filtering
- Format documents into readable context for the LLM

**The flow:**
```
User Question
     ↓
ChromaDB Semantic Search
     ↓
Top N Relevant Documents
     ↓
Formatted Context String
```

### 3. embedding_pipeline.py

**What it does:** Reads NASA text files → chunks them → creates embeddings → stores in ChromaDB

**Key TODOs implemented:**
- Initialize OpenAI client and ChromaDB
- Chunk text with overlap (preserves context at boundaries)
- Generate stable document IDs
- Extract metadata from file paths (mission, document type)
- Process documents in batches
- Handle skip/update modes for existing documents

**The flow:**
```
NASA Text Files
      ↓
Read Content
      ↓
Chunk into ~500 char pieces
      ↓
Generate Embeddings (OpenAI)
      ↓
Store in ChromaDB with Metadata
```

### 4. ragas_evaluator.py

**What it does:** Measures quality of RAG responses using RAGAS metrics

**Key TODOs implemented:**
- Create evaluator LLM (gpt-3.5-turbo)
- Create embedding model for similarity
- Define metrics (Faithfulness, Response Relevancy)
- Evaluate and return scores

**Metrics explained:**
- **Faithfulness:** Does the answer stick to the context? (prevents hallucination)
- **Response Relevancy:** Does the answer address the question?

---

## Data Structure Expected

```
data/
├── apollo11/
│   └── *.txt    # Apollo 11 mission documents
├── apollo13/
│   └── *.txt    # Apollo 13 mission documents
└── challenger/
    └── *.txt    # Challenger mission documents
```

---

## Testing the System

### Test Individual Components

**Test LLM Client:**
```python
from llm_client import generate_response
response = generate_response(api_key, "What was Apollo 11?", "", [])
print(response)
```

**Test RAG Client:**
```python
from rag_client import discover_chroma_backends
backends = discover_chroma_backends()
print(backends)
```

**Test Embedding Pipeline:**
```bash
python embedding_pipeline.py --openai-key YOUR_KEY --stats-only
```

**Test Evaluation:**
```python
from ragas_evaluator import evaluate_response_quality
scores = evaluate_response_quality("question", "answer", ["context"])
print(scores)
```

### Sample Questions to Test

From `evaluation_dataset.txt`:
- "What was Apollo 11?"
- "What went wrong on Apollo 13?"
- "What caused the Challenger disaster?"
- "Who were the astronauts on Apollo 11?"

---

## Troubleshooting

**Problem:** `Collection not found errors`
**Solution:** Run embedding pipeline first to create the database

**Problem:** `OpenAI API key errors`
**Solution:** Check your API key is set correctly and has credits

**Problem:** `RAGAS evaluation fails`
**Solution:** Ensure all dependencies installed: `pip install ragas langchain-openai`

**Problem:** `Out of memory during processing`
**Solution:** Reduce batch size: `--batch-size 25`

---

## What You Learned

By completing this project, you've implemented:

1. **Document Processing** - Chunking text with overlap
2. **Embeddings** - Converting text to vectors using OpenAI
3. **Vector Database** - Storing and querying with ChromaDB
4. **Semantic Search** - Finding relevant documents by meaning
5. **LLM Integration** - Prompting with context for accurate answers
6. **Evaluation** - Measuring response quality with RAGAS

This is a complete RAG system - the same architecture used in production AI applications.
