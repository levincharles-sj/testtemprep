#!/usr/bin/env python3
"""
Batch Evaluation for NASA RAG System
Reads evaluation_dataset.txt, runs retrieval → LLM → RAGAS evaluation
"""

import os
import sys
import json
import argparse
from statistics import mean

import rag_client
import llm_client
import ragas_evaluator


def parse_dataset(filepath):
    """Parse evaluation_dataset.txt."""
    questions = []
    current_q = None
    
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if line.startswith('Expected:'):
                if current_q:
                    questions.append({
                        'question': current_q,
                        'expected': line.replace('Expected:', '').strip()
                    })
                    current_q = None
            else:
                current_q = line
    return questions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='evaluation_dataset.txt')
    parser.add_argument('--openai-key', default=os.getenv('OPENAI_API_KEY'))
    parser.add_argument('--chroma-dir', default='./chroma_db_openai')
    parser.add_argument('--collection', default='nasa_space_missions_text')
    parser.add_argument('--output', default='evaluation_results.json')
    args = parser.parse_args()
    
    if not args.openai_key:
        print("ERROR: Set OPENAI_API_KEY")
        sys.exit(1)
    
    os.environ['OPENAI_API_KEY'] = args.openai_key
    
    questions = parse_dataset(args.dataset)
    print(f"Loaded {len(questions)} questions\n")
    
    collection, success, _ = rag_client.initialize_rag_system(args.chroma_dir, args.collection)
    if not success:
        print("ERROR: Failed to initialize RAG")
        sys.exit(1)
    
    results = []
    metrics_data = {}
    
    for i, q in enumerate(questions, 1):
        print(f"[{i}/{len(questions)}] {q['question'][:50]}...")
        
        # Retrieve
        docs = rag_client.retrieve_documents(collection, q['question'], 3)
        contexts = docs['documents'][0] if docs and docs.get('documents') else []
        metadatas = docs['metadatas'][0] if docs and docs.get('metadatas') else []
        
        # Generate
        context_str = rag_client.format_context(contexts, metadatas)
        answer = llm_client.generate_response(args.openai_key, q['question'], context_str, [])
        
        # Evaluate
        metrics = {}
        if ragas_evaluator.RAGAS_AVAILABLE and contexts:
            metrics = ragas_evaluator.evaluate_response_quality(q['question'], answer, contexts)
        
        results.append({'question': q['question'], 'answer': answer, 'metrics': metrics})
        
        # Print per-question metrics
        for m, s in metrics.items():
            if isinstance(s, float):
                print(f"  {m}: {s:.3f}")
                metrics_data.setdefault(m, []).append(s)
        print()
    
    # Aggregate stats
    print("=" * 50)
    print("AGGREGATE STATISTICS (mean)")
    print("=" * 50)
    for m, scores in metrics_data.items():
        print(f"{m}: {mean(scores):.3f}")
    
    # Save
    with open(args.output, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {args.output}")


if __name__ == "__main__":
    main()
