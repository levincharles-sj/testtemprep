from typing import Dict, List
from openai import OpenAI


def generate_response(openai_key: str, user_message: str, context: str,
                      conversation_history: List[Dict], model: str = "gpt-3.5-turbo") -> str:
    """
    Generate response using OpenAI with context.
    
    Args:
        openai_key: OpenAI API key
        user_message: The user's question
        context: Retrieved documents from RAG system
        conversation_history: Previous conversation turns
        model: OpenAI model to use
    
    Returns:
        Generated response string
    """
    
    # TODO: Define system prompt
    system_prompt = f"""You are a NASA space mission expert assistant with deep knowledge of 
Apollo 11, Apollo 13, and the Challenger missions.

CONTEXT FROM NASA DOCUMENTS:
{context if context else "No specific documents retrieved."}

INSTRUCTIONS:
- Answer based on the provided NASA documents when available
- Cite specific details from mission transcripts and technical documents
- Be accurate, professional, and informative
- If context doesn't have the answer, say so clearly"""
    
    # TODO: Set context in messages
    messages = [{"role": "system", "content": system_prompt}]
    
    # TODO: Add chat history
    for msg in conversation_history:
        messages.append(msg)
    
    messages.append({"role": "user", "content": user_message})
    
    # TODO: Create OpenAI Client
    client = OpenAI(api_key=openai_key)
    
    # TODO: Send request to OpenAI
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0.7,
        max_tokens=1024
    )
    
    # TODO: Return response
    return response.choices[0].message.content
