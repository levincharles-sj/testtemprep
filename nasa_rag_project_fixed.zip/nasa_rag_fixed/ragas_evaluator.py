from typing import Dict, List
import os

# RAGAS imports
try:
    from ragas.llms import LangchainLLMWrapper
    from ragas.embeddings import LangchainEmbeddingsWrapper
    from langchain_openai import ChatOpenAI, OpenAIEmbeddings
    from ragas import SingleTurnSample
    from ragas.metrics import (
        Faithfulness,
        ResponseRelevancy,
        LLMContextPrecisionWithoutReference,
        LLMContextRecall
    )
    RAGAS_AVAILABLE = True
except ImportError:
    RAGAS_AVAILABLE = False


def evaluate_response_quality(question: str, answer: str, contexts: List[str],
                               reference: str = None) -> Dict[str, float]:
    """
    Evaluate response quality using RAGAS metrics.
    
    Args:
        question: The user's question
        answer: The generated answer
        contexts: List of retrieved context documents
        reference: Optional reference answer for recall calculation
    
    Returns:
        Dictionary of metric scores
    """
    if not RAGAS_AVAILABLE:
        return {"error": "RAGAS not available - install with: pip install ragas langchain-openai"}
    
    # TODO: Create evaluator LLM with model gpt-3.5-turbo
    evaluator_llm = LangchainLLMWrapper(
        ChatOpenAI(model="gpt-3.5-turbo")
    )
    
    # TODO: Create evaluator_embeddings with model text-embedding-3-small
    evaluator_embeddings = LangchainEmbeddingsWrapper(
        OpenAIEmbeddings(model="text-embedding-3-small")
    )
    
    # TODO: Define an instance for each metric to evaluate
    # Metric 1: Faithfulness - measures if answer is grounded in context
    faithfulness = Faithfulness(llm=evaluator_llm)
    
    # Metric 2: Response Relevancy - measures if answer addresses the question
    response_relevancy = ResponseRelevancy(llm=evaluator_llm, embeddings=evaluator_embeddings)
    
    # Metric 3: Context Precision - measures if retrieved context is relevant
    context_precision = LLMContextPrecisionWithoutReference(llm=evaluator_llm)
    
    # Metric 4: Context Recall - measures if context contains needed info
    context_recall = LLMContextRecall(llm=evaluator_llm)
    
    # Create sample for evaluation
    sample = SingleTurnSample(
        user_input=question,
        response=answer,
        retrieved_contexts=contexts,
        reference=reference if reference else answer  # Use answer as reference if not provided
    )
    
    # TODO: Evaluate the response using the metrics
    results = {}
    
    # Evaluate Faithfulness
    try:
        score = faithfulness.single_turn_score(sample)
        results["faithfulness"] = round(float(score), 3) if score is not None else 0.0
    except Exception as e:
        results["faithfulness"] = 0.0
        results["faithfulness_error"] = str(e)[:50]
    
    # Evaluate Response Relevancy
    try:
        score = response_relevancy.single_turn_score(sample)
        results["response_relevancy"] = round(float(score), 3) if score is not None else 0.0
    except Exception as e:
        results["response_relevancy"] = 0.0
        results["response_relevancy_error"] = str(e)[:50]
    
    # Evaluate Context Precision
    try:
        score = context_precision.single_turn_score(sample)
        results["context_precision"] = round(float(score), 3) if score is not None else 0.0
    except Exception as e:
        results["context_precision"] = 0.0
        results["context_precision_error"] = str(e)[:50]
    
    # Evaluate Context Recall
    try:
        score = context_recall.single_turn_score(sample)
        results["context_recall"] = round(float(score), 3) if score is not None else 0.0
    except Exception as e:
        results["context_recall"] = 0.0
        results["context_recall_error"] = str(e)[:50]
    
    # TODO: Return the evaluation results
    return results


def get_metric_descriptions() -> Dict[str, str]:
    """Return descriptions of each metric for display in UI."""
    return {
        "faithfulness": "Measures if the answer is grounded in the retrieved context (no hallucination)",
        "response_relevancy": "Measures if the answer actually addresses the user's question",
        "context_precision": "Measures if the retrieved documents are relevant to the question",
        "context_recall": "Measures if the context contains all information needed to answer"
    }
